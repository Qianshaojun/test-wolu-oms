(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~ba53ff15"],{

/***/ "7fe4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/app.vue?vue&type=template&id=35329091&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('a-config-provider',{attrs:{"getPopupContainer":_vm.getPopupContainer,"locale":_vm.locale}},[_c('main',{ref:"main",staticClass:"full-absolute"},[_vm._t("default")],2)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/app.vue?vue&type=template&id=35329091&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.flat.js
var es_array_flat = __webpack_require__("0481");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.unscopables.flat.js
var es_array_unscopables_flat = __webpack_require__("4069");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/assets/locale/index.js
var locale = __webpack_require__("a060");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/app.vue?vue&type=script&lang=ts&













var userModule = Object(lib["c" /* namespace */])('userModule');

var appvue_type_script_lang_ts_App =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](App, _super);

  function App() {
    var _this_1 = _super !== null && _super.apply(this, arguments) || this;

    _this_1.screenHeight = document.documentElement.clientHeight;
    _this_1.timer = false;
    _this_1._timer = 0;
    _this_1.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this_1.publicService = new public_service["a" /* PublicService */]();
    _this_1.loadingService = new loading_service["a" /* LoadingService */]();
    _this_1.flatMenuList = [];
    return _this_1;
  }

  App.prototype.getPopupContainer = function (el, dialogContext) {
    if (dialogContext) {
      return dialogContext;
    } else {
      return document.querySelector('.layout.layout-container');
    }
  };

  Object.defineProperty(App.prototype, "locale", {
    get: function get() {
      return locale["a" /* antdLocale */][this.$app.state.locale].antd;
    },
    enumerable: true,
    configurable: true
  });

  App.prototype.created = function () {
    this.getFlatMenuList(); //获取展开的菜单
  };

  App.prototype.getFlatMenuList = function () {
    if (this.menus) {
      var menus = this.menus.map(function (item) {
        var menu = [];

        if (item.children && item.children.length) {
          menu = item.children.map(function (x) {
            var smenu = [];

            if (x.children && x.children.length) {
              smenu = x.children.map(function (y) {
                return {
                  name: y.name,
                  id: y.id
                };
              });
            }

            smenu.push(x);
            return smenu;
          });
        }

        menu.push({
          name: item.name,
          id: item.id
        });
        var menuTemp = [];

        for (var _i = 0, menu_1 = menu; _i < menu_1.length; _i++) {
          var i = menu_1[_i];

          if (i && i.id) {
            menuTemp.push(i);
          } else {
            for (var _a = 0, i_1 = i; _a < i_1.length; _a++) {
              var k = i_1[_a];
              menuTemp.push(k);
            }
          }
        }

        return menuTemp;
      });
      this.flatMenuList = menus.flat(Infinity);
    }
  };

  App.prototype.getMenuId = function (to) {
    var code = '';
    var path = to.path;
    var index = path.lastIndexOf('/');
    path = path.substring(index + 1, path.length);
    var finds = this.flatMenuList.find(function (x) {
      return x.name === path;
    });

    if (finds) {
      code = finds.id;
    }

    return code;
  };

  App.prototype.mounted = function () {
    var _this_1 = this;

    var _this = this;

    this.$nextTick(function () {
      _this_1._timer = setTimeout(function () {
        _this_1.autoCalcHeight();
      });
    });
    window.addEventListener('resize', function () {
      _this.screenHeight = document.documentElement.clientHeight;
    });
  };

  App.prototype.destroyed = function () {
    window.removeEventListener('resize', this.autoCalcHeight);
    clearTimeout(this._timer);
  }; // @Mutation('updateActionButtonPromise')
  // updateActionButtonPromise
  // @Mutation('updateButtonAuthInfo')
  // updateButtonAuthInfo
  // private getButtonAuthInfo(menuId) {
  //     let p = new Promise((resolve, reject) => {
  //         //获取按钮权限
  //         this.innerAction.setActionAPI(
  //             'common/query_user_button_authority',
  //             CommonService.getMenuCode('menu-manage')
  //         )
  //         this.publicService
  //             .query(
  //                 new RequestParams(
  //                     { menu_id: menuId },
  //                     {
  //                         loading: this.loadingService,
  //                         innerAction: this.innerAction
  //                     }
  //                 )
  //             )
  //             .subscribe(
  //                 data => {
  //                     resolve(data)
  //                     // this.updateButtonAuthInfo(data)
  //                 },
  //                 err => {
  //                     // reject(err)
  //                     this.$message.error(err.message)
  //                 }
  //             )
  //     })
  //     console.log('ppp', p)
  //     // this.updateButtonAuthInfo(p)
  //     // p.then(res => {
  //     //     console.log('111res', res)
  //     //
  //     // })
  //     this.updateActionButtonPromise(p)
  // }


  App.prototype.autoCalcHeight = function () {
    var pageHeader = document.querySelector('.page-header'); //头部标题区域

    var dataForm = document.querySelector('.data-form'); //dataForm 区域

    var autoFlex = document.querySelector('.autoFlex'); //设置了autoFlex类名的区域

    var autoFlexDetail = document.querySelector('.autoFlexDetail'); //设置了autoFlex类名的区域

    var tableDom = document.querySelector('.ant-table-body'); //设置了autoFlex类名的区域内的表格

    var fixedTableDom = document.querySelector('.autoFlex .ant-table-body-inner'); //固定列表格的dom

    var cardTabsDom = document.querySelector('.cardTabs'); //中间tabs高度

    var dataFormHeight = 0;
    var pageHeaderHeight = 0;

    if (dataForm) {
      dataFormHeight = dataForm.clientHeight;
    }

    if (pageHeader) {
      pageHeaderHeight = pageHeader.clientHeight;
    }

    var height = this.screenHeight - dataFormHeight - pageHeaderHeight - 80;

    if (autoFlex) {
      if (!autoFlexDetail) {
        if (cardTabsDom) {
          height -= 25;
        }

        autoFlex.style.height = height + 'px';

        if (tableDom) {
          tableDom.style.maxHeight = height - 120 + 'px'; //设置了autoFlex类名的区域内的表格高度
        }

        if (fixedTableDom) {
          fixedTableDom.style.maxHeight = height - 111 + 'px';
        }
      } else {
        // let detailHeight: any = Math.max(200, Math.ceil(height * 0.3))
        var autoHeight = height - 150; // autoFlexDetail.style.height = detailHeight + 'px'

        autoFlex.style.height = autoHeight + 'px';
        tableDom.style.maxHeight = autoHeight - 120 + 'px';
      }
    }
  };

  App.prototype.handler = function (val) {
    if (!this.timer) {
      // 一旦监听到的screenWidth值改变，就将其重新赋给data里的screenHeight
      this.autoCalcHeight();
      this.timer = true;
      var that_1 = this;
      this._timer = setTimeout(function () {
        that_1.timer = false;
      }, 100);
    }
  };

  App.prototype.heightHandler = function (val) {
    this.autoCalcHeight();
  };

  App.prototype.handleRoute = function (newVal) {
    this.getFlatMenuList();
    var menuId = this.getMenuId(newVal);
    this.updateMenuCode(menuId);
  };

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], App.prototype, "dataFormHeight", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], App.prototype, "menus", void 0);

  tslib_es6["c" /* __decorate */]([Object(lib["a" /* Mutation */])('updateMenuCode'), tslib_es6["f" /* __metadata */]("design:type", Object)], App.prototype, "updateMenuCode", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('screenHeight'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], App.prototype, "handler", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('dataFormHeight'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], App.prototype, "heightHandler", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('$route'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], App.prototype, "handleRoute", null);

  App = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], App);
  return App;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var appvue_type_script_lang_ts_ = (appvue_type_script_lang_ts_App);
// CONCATENATED MODULE: ./src/app.vue?vue&type=script&lang=ts&
 /* harmony default export */ var src_appvue_type_script_lang_ts_ = (appvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/app.vue?vue&type=style&index=0&lang=css&
var appvue_type_style_index_0_lang_css_ = __webpack_require__("fffb");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/app.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  src_appvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var app = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "a210":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "fffb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a210");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_app_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ })

}]);