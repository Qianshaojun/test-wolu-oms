(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chunk-vendors~5fcfb518"],{

/***/ "2a95":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {function _extends() {
  _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

function _inheritsLoose(subClass, superClass) {
  subClass.prototype = Object.create(superClass.prototype);
  subClass.prototype.constructor = subClass;

  _setPrototypeOf(subClass, superClass);
}

function _getPrototypeOf(o) {
  _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function _getPrototypeOf(o) {
    return o.__proto__ || Object.getPrototypeOf(o);
  };
  return _getPrototypeOf(o);
}

function _setPrototypeOf(o, p) {
  _setPrototypeOf = Object.setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}

function _isNativeReflectConstruct() {
  if (typeof Reflect === "undefined" || !Reflect.construct) return false;
  if (Reflect.construct.sham) return false;
  if (typeof Proxy === "function") return true;

  try {
    Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
    return true;
  } catch (e) {
    return false;
  }
}

function _construct(Parent, args, Class) {
  if (_isNativeReflectConstruct()) {
    _construct = Reflect.construct;
  } else {
    _construct = function _construct(Parent, args, Class) {
      var a = [null];
      a.push.apply(a, args);
      var Constructor = Function.bind.apply(Parent, a);
      var instance = new Constructor();
      if (Class) _setPrototypeOf(instance, Class.prototype);
      return instance;
    };
  }

  return _construct.apply(null, arguments);
}

function _isNativeFunction(fn) {
  return Function.toString.call(fn).indexOf("[native code]") !== -1;
}

function _wrapNativeSuper(Class) {
  var _cache = typeof Map === "function" ? new Map() : undefined;

  _wrapNativeSuper = function _wrapNativeSuper(Class) {
    if (Class === null || !_isNativeFunction(Class)) return Class;

    if (typeof Class !== "function") {
      throw new TypeError("Super expression must either be null or a function");
    }

    if (typeof _cache !== "undefined") {
      if (_cache.has(Class)) return _cache.get(Class);

      _cache.set(Class, Wrapper);
    }

    function Wrapper() {
      return _construct(Class, arguments, _getPrototypeOf(this).constructor);
    }

    Wrapper.prototype = Object.create(Class.prototype, {
      constructor: {
        value: Wrapper,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
    return _setPrototypeOf(Wrapper, Class);
  };

  return _wrapNativeSuper(Class);
}

/* eslint no-console:0 */
var formatRegExp = /%[sdj%]/g;
var warning = function warning() {}; // don't print warning message when in production env or node runtime

if (typeof process !== 'undefined' && Object({"VUE_APP_SERVER":"http://47.244.150.247:48069","VUE_APP_TIMEOUT":"3600000","VUE_APP_MOCK":"false","VUE_APP_GOOGLEMAP_APIKEY":"AIzaSyDaBlQ-7bhO534-a-u32apwYYoQeln-1eg","NODE_ENV":"production","BASE_URL":"/","ROUTERS":[{"routePath":"/PurchasePredict/product-pre-sale","componentPath":"PurchasePredict/product-pre-sale.vue"},{"routePath":"/PurchasePredict/product-purchase-approve","componentPath":"PurchasePredict/product-purchase-approve.vue"},{"routePath":"/PurchasePredict/product-purchase-confirm","componentPath":"PurchasePredict/product-purchase-confirm.vue"},{"routePath":"/PurchasePredict/product-purchase-predict","componentPath":"PurchasePredict/product-purchase-predict.vue"},{"routePath":"/PurchasePredict/product-purchase-schedual","componentPath":"PurchasePredict/product-purchase-schedual.vue"},{"routePath":"/PurchasePredict/product-sale-trend","componentPath":"PurchasePredict/product-sale-trend.vue"},{"routePath":"/PurchasePredict/product-sku-sale","componentPath":"PurchasePredict/product-sku-sale.vue"},{"routePath":"/PurchasePredict/requirement-schedule-feedback","componentPath":"PurchasePredict/requirement-schedule-feedback.vue"},{"routePath":"/PurchasePredict/requirement-schedule-reference","componentPath":"PurchasePredict/requirement-schedule-reference.vue"},{"routePath":"/accounts/account-invoice","componentPath":"accounts/account-invoice.vue"},{"routePath":"/accounts/account-page1","componentPath":"accounts/account-page1.vue"},{"routePath":"/accounts/account-page2","componentPath":"accounts/account-page2.vue"},{"routePath":"/accounts/invoice-edit","componentPath":"accounts/invoice-edit.vue"},{"routePath":"/aliexpress/aliexpress-instock-manage","componentPath":"aliexpress/aliexpress-instock-manage.vue"},{"routePath":"/aliexpress/aliexpress-manage","componentPath":"aliexpress/aliexpress-manage.vue"},{"routePath":"/aliexpress/aliexpress-manage1212","componentPath":"aliexpress/aliexpress-manage1212.vue"},{"routePath":"/amazon/amazon-listing-price","componentPath":"amazon/amazon-listing-price.vue"},{"routePath":"/amazon/amazon-listing-stock","componentPath":"amazon/amazon-listing-stock.vue"},{"routePath":"/amazon/amazon-listing-total","componentPath":"amazon/amazon-listing-total.vue"},{"routePath":"/amazon/ebay-listing-stock","componentPath":"amazon/ebay-listing-stock.vue"},{"routePath":"/basic_manage/currency-exchange","componentPath":"basic_manage/currency-exchange.vue"},{"routePath":"/basic_manage/illegal-words","componentPath":"basic_manage/illegal-words.vue"},{"routePath":"/basic_manage/instance-edit","componentPath":"basic_manage/instance-edit.vue"},{"routePath":"/basic_manage/instance-manage","componentPath":"basic_manage/instance-manage.vue"},{"routePath":"/basic_manage/query-condition-manage","componentPath":"basic_manage/query-condition-manage.vue"},{"routePath":"/basic_manage/seller-edit","componentPath":"basic_manage/seller-edit.vue"},{"routePath":"/basic_manage/seller-manage","componentPath":"basic_manage/seller-manage.vue"},{"routePath":"/common/code-manage","componentPath":"common/code-manage.vue"},{"routePath":"/common/list-page-wrapper","componentPath":"common/list-page-wrapper.vue"},{"routePath":"/common/page-wrapper","componentPath":"common/page-wrapper.vue"},{"routePath":"/common/sent-email-wrapper","componentPath":"common/sent-email-wrapper.vue"},{"routePath":"/common/swap-wrapper","componentPath":"common/swap-wrapper.vue"},{"routePath":"/cs_email_return/chat-box","componentPath":"cs_email_return/chat-box.vue"},{"routePath":"/cs_email_return/no-need-reply-customer","componentPath":"cs_email_return/no-need-reply-customer.vue"},{"routePath":"/customer/customer-manage","componentPath":"customer/customer-manage.vue"},{"routePath":"/customer_service/allot-user-map","componentPath":"customer_service/allot-user-map.vue"},{"routePath":"/customer_service/auto-reply-manage","componentPath":"customer_service/auto-reply-manage.vue"},{"routePath":"/customer_service/custom-problem-statistics","componentPath":"customer_service/custom-problem-statistics.vue"},{"routePath":"/customer_service/custom-problem","componentPath":"customer_service/custom-problem.vue"},{"routePath":"/customer_service/customer-auto-reply-manage","componentPath":"customer_service/customer-auto-reply-manage.vue"},{"routePath":"/customer_service/email-template-manage","componentPath":"customer_service/email-template-manage.vue"},{"routePath":"/customer_service/problem-picture","componentPath":"customer_service/problem-picture.vue"},{"routePath":"/customer_service/sent_email","componentPath":"customer_service/sent_email.vue"},{"routePath":"/customer_service/server-customer-map","componentPath":"customer_service/server-customer-map.vue"},{"routePath":"/customer_service/ticket-group-manage","componentPath":"customer_service/ticket-group-manage.vue"},{"routePath":"/customer_service/ticket-manage","componentPath":"customer_service/ticket-manage.vue"},{"routePath":"/dashboard/workspace","componentPath":"dashboard/workspace.vue"},{"routePath":"/demos/calender","componentPath":"demos/calender.vue"},{"routePath":"/demos/chart","componentPath":"demos/chart.vue"},{"routePath":"/demos/data-form","componentPath":"demos/data-form.vue"},{"routePath":"/demos/data-table","componentPath":"demos/data-table.vue"},{"routePath":"/demos/editor","componentPath":"demos/editor.vue"},{"routePath":"/demos/http","componentPath":"demos/http.vue"},{"routePath":"/demos/map","componentPath":"demos/map.vue"},{"routePath":"/demos/order","componentPath":"demos/order.vue"},{"routePath":"/demos/page-header","componentPath":"demos/page-header.vue"},{"routePath":"/exception/404","componentPath":"exception/404.vue"},{"routePath":"/login","componentPath":"login.vue"},{"routePath":"/mobile/dashboard","componentPath":"mobile/dashboard.vue"},{"routePath":"/mobile/login","componentPath":"mobile/login.vue"},{"routePath":"/operation/warehouse-list","componentPath":"operation/warehouse-list.vue"},{"routePath":"/orders/modify-custom-problem","componentPath":"orders/modify-custom-problem.vue"},{"routePath":"/orders/order-aliexpress","componentPath":"orders/order-aliexpress.vue"},{"routePath":"/orders/order-edit","componentPath":"orders/order-edit.vue"},{"routePath":"/orders/order-manage","componentPath":"orders/order-manage.vue"},{"routePath":"/orders/order-test","componentPath":"orders/order-test.vue"},{"routePath":"/orders/order-wrapper","componentPath":"orders/order-wrapper.vue"},{"routePath":"/picking/modify-address","componentPath":"picking/modify-address.vue"},{"routePath":"/picking/picking-manage-aliexpress","componentPath":"picking/picking-manage-aliexpress.vue"},{"routePath":"/picking/picking-manage","componentPath":"picking/picking-manage.vue"},{"routePath":"/picking/picking-wrapper","componentPath":"picking/picking-wrapper.vue"},{"routePath":"/picking/shipment-list","componentPath":"picking/shipment-list.vue"},{"routePath":"/picking/shipment-type","componentPath":"picking/shipment-type.vue"},{"routePath":"/presale/presale-manage","componentPath":"presale/presale-manage.vue"},{"routePath":"/presale/presale-orders-manage","componentPath":"presale/presale-orders-manage.vue"},{"routePath":"/presale/presale-wrapper","componentPath":"presale/presale-wrapper.vue"},{"routePath":"/product/B2C-product-price-check","componentPath":"product/B2C-product-price-check.vue"},{"routePath":"/product/ES-product-price-check","componentPath":"product/ES-product-price-check.vue"},{"routePath":"/product/FR-product-price-check","componentPath":"product/FR-product-price-check.vue"},{"routePath":"/product/GB-product-price-check","componentPath":"product/GB-product-price-check.vue"},{"routePath":"/product/IT-product-price-check","componentPath":"product/IT-product-price-check.vue"},{"routePath":"/product/Wish-product-price-check","componentPath":"product/Wish-product-price-check.vue"},{"routePath":"/product/ae-product-price-check","componentPath":"product/ae-product-price-check.vue"},{"routePath":"/product/ebay-product-price-check","componentPath":"product/ebay-product-price-check.vue"},{"routePath":"/product/generate-code-manage","componentPath":"product/generate-code-manage.vue"},{"routePath":"/product/inout-record","componentPath":"product/inout-record.vue"},{"routePath":"/product/land-haul-fee","componentPath":"product/land-haul-fee.vue"},{"routePath":"/product/manual-manage","componentPath":"product/manual-manage.vue"},{"routePath":"/product/ocean-shipping-fee","componentPath":"product/ocean-shipping-fee.vue"},{"routePath":"/product/ocean-shipping-monitor","componentPath":"product/ocean-shipping-monitor.vue"},{"routePath":"/product/package-chang-sku-monitor","componentPath":"product/package-chang-sku-monitor.vue"},{"routePath":"/product/pre_product_price_check","componentPath":"product/pre_product_price_check.vue"},{"routePath":"/product/product-cate-attr","componentPath":"product/product-cate-attr.vue"},{"routePath":"/product/product-category-manage","componentPath":"product/product-category-manage.vue"},{"routePath":"/product/product-float-price","componentPath":"product/product-float-price.vue"},{"routePath":"/product/product-history-stock","componentPath":"product/product-history-stock.vue"},{"routePath":"/product/product-manage","componentPath":"product/product-manage.vue"},{"routePath":"/product/product-parts","componentPath":"product/product-parts.vue"},{"routePath":"/product/product-search","componentPath":"product/product-search.vue"},{"routePath":"/product/product-wrapper","componentPath":"product/product-wrapper.vue"},{"routePath":"/product/product_price_check","componentPath":"product/product_price_check.vue"},{"routePath":"/product/product_price_check_history","componentPath":"product/product_price_check_history.vue"},{"routePath":"/product/product_price_check_new","componentPath":"product/product_price_check_new.vue"},{"routePath":"/product/product_price_check_result","componentPath":"product/product_price_check_result.vue"},{"routePath":"/product/specification-manage","componentPath":"product/specification-manage.vue"},{"routePath":"/product/stock-transfer","componentPath":"product/stock-transfer.vue"},{"routePath":"/purchase/create-shipping-plan","componentPath":"purchase/create-shipping-plan.vue"},{"routePath":"/purchase/depo-wrapper","componentPath":"purchase/depo-wrapper.vue"},{"routePath":"/purchase/logistics-providers-detail","componentPath":"purchase/logistics-providers-detail.vue"},{"routePath":"/purchase/logistics-providers-manage","componentPath":"purchase/logistics-providers-manage.vue"},{"routePath":"/purchase/purchase-contract-manage","componentPath":"purchase/purchase-contract-manage.vue"},{"routePath":"/purchase/purchase-cost-report","componentPath":"purchase/purchase-cost-report.vue"},{"routePath":"/purchase/purchase-de-po-manage","componentPath":"purchase/purchase-de-po-manage.vue"},{"routePath":"/purchase/purchase-give-date-report","componentPath":"purchase/purchase-give-date-report.vue"},{"routePath":"/purchase/purchase-package-manage","componentPath":"purchase/purchase-package-manage.vue"},{"routePath":"/purchase/purchase-package","componentPath":"purchase/purchase-package.vue"},{"routePath":"/purchase/purchase-pre-make-order","componentPath":"purchase/purchase-pre-make-order.vue"},{"routePath":"/purchase/purchase-product-plan","componentPath":"purchase/purchase-product-plan.vue"},{"routePath":"/purchase/purchase-product-qty-report","componentPath":"purchase/purchase-product-qty-report.vue"},{"routePath":"/purchase/purchase-product-quality-rate","componentPath":"purchase/purchase-product-quality-rate.vue"},{"routePath":"/purchase/purchase-reduce-cost-report","componentPath":"purchase/purchase-reduce-cost-report.vue"},{"routePath":"/purchase/purchase-ship-order-edit","componentPath":"purchase/purchase-ship-order-edit.vue"},{"routePath":"/purchase/purchase-ship-order","componentPath":"purchase/purchase-ship-order.vue"},{"routePath":"/purchase/replenishment-demand","componentPath":"purchase/replenishment-demand.vue"},{"routePath":"/purchase/replenishment-edit","componentPath":"purchase/replenishment-edit.vue"},{"routePath":"/purchase/shipping-plan-manage","componentPath":"purchase/shipping-plan-manage.vue"},{"routePath":"/purchase/vendor-detail","componentPath":"purchase/vendor-detail.vue"},{"routePath":"/purchase/vendor-manage","componentPath":"purchase/vendor-manage.vue"},{"routePath":"/purchase/vendor-product-detail","componentPath":"purchase/vendor-product-detail.vue"},{"routePath":"/purchase/vendor-product-manage","componentPath":"purchase/vendor-product-manage.vue"},{"routePath":"/purchase/vendor-wrapper","componentPath":"purchase/vendor-wrapper.vue"},{"routePath":"/reports/company-product-stock","componentPath":"reports/company-product-stock.vue"},{"routePath":"/reports/data-pivot-table","componentPath":"reports/data-pivot-table.vue"},{"routePath":"/reports/dept-product-factory-transit-stock-report","componentPath":"reports/dept-product-factory-transit-stock-report.vue"},{"routePath":"/reports/dept-sku-month-sales-report","componentPath":"reports/dept-sku-month-sales-report.vue"},{"routePath":"/reports/head-logistics-report","componentPath":"reports/head-logistics-report.vue"},{"routePath":"/reports/product-sale-state-change-report","componentPath":"reports/product-sale-state-change-report.vue"},{"routePath":"/reports/product-unsalable-report-leader","componentPath":"reports/product-unsalable-report-leader.vue"},{"routePath":"/reports/product-unsalable-report","componentPath":"reports/product-unsalable-report.vue"},{"routePath":"/reports/product-user-purchase-vendor-report","componentPath":"reports/product-user-purchase-vendor-report.vue"},{"routePath":"/reports/product-vendor-report","componentPath":"reports/product-vendor-report.vue"},{"routePath":"/reports/profit-detail","componentPath":"reports/profit-detail.vue"},{"routePath":"/reports/purchase-order-daily-report","componentPath":"reports/purchase-order-daily-report.vue"},{"routePath":"/reports/purchase-price-change-report","componentPath":"reports/purchase-price-change-report.vue"},{"routePath":"/reports/purchase-requirement-history-report","componentPath":"reports/purchase-requirement-history-report.vue"},{"routePath":"/reports/reissue-detail","componentPath":"reports/reissue-detail.vue"},{"routePath":"/reports/ship-order-daily-report","componentPath":"reports/ship-order-daily-report.vue"},{"routePath":"/schedule/schedule-list","componentPath":"schedule/schedule-list.vue"},{"routePath":"/schedule/schedule-manage","componentPath":"schedule/schedule-manage.vue"},{"routePath":"/schedule/weekly-manage","componentPath":"schedule/weekly-manage.vue"},{"routePath":"/settings/api-url-manage","componentPath":"settings/api-url-manage.vue"},{"routePath":"/settings/change-log","componentPath":"settings/change-log.vue"},{"routePath":"/settings/data-access-rule","componentPath":"settings/data-access-rule.vue"},{"routePath":"/settings/department-management","componentPath":"settings/department-management.vue"},{"routePath":"/settings/host-data-access-rule","componentPath":"settings/host-data-access-rule.vue"},{"routePath":"/settings/menu-access-manage","componentPath":"settings/menu-access-manage.vue"},{"routePath":"/settings/menu-manage","componentPath":"settings/menu-manage.vue"},{"routePath":"/settings/module-manage","componentPath":"settings/module-manage.vue"},{"routePath":"/settings/role-manage","componentPath":"settings/role-manage.vue"},{"routePath":"/settings/user-manage","componentPath":"settings/user-manage.vue"},{"routePath":"/settings/user-setting","componentPath":"settings/user-setting.vue"},{"routePath":"/shipment/final-shipping-de","componentPath":"shipment/final-shipping-de.vue"},{"routePath":"/shipment/final-shipping-uk","componentPath":"shipment/final-shipping-uk.vue"}]}) && "production" !== 'production' && typeof window !== 'undefined' && typeof document !== 'undefined') {
  warning = function warning(type, errors) {
    if (typeof console !== 'undefined' && console.warn) {
      if (errors.every(function (e) {
        return typeof e === 'string';
      })) {
        console.warn(type, errors);
      }
    }
  };
}

function convertFieldsError(errors) {
  if (!errors || !errors.length) return null;
  var fields = {};
  errors.forEach(function (error) {
    var field = error.field;
    fields[field] = fields[field] || [];
    fields[field].push(error);
  });
  return fields;
}
function format() {
  for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
    args[_key] = arguments[_key];
  }

  var i = 1;
  var f = args[0];
  var len = args.length;

  if (typeof f === 'function') {
    return f.apply(null, args.slice(1));
  }

  if (typeof f === 'string') {
    var str = String(f).replace(formatRegExp, function (x) {
      if (x === '%%') {
        return '%';
      }

      if (i >= len) {
        return x;
      }

      switch (x) {
        case '%s':
          return String(args[i++]);

        case '%d':
          return Number(args[i++]);

        case '%j':
          try {
            return JSON.stringify(args[i++]);
          } catch (_) {
            return '[Circular]';
          }

          break;

        default:
          return x;
      }
    });
    return str;
  }

  return f;
}

function isNativeStringType(type) {
  return type === 'string' || type === 'url' || type === 'hex' || type === 'email' || type === 'date' || type === 'pattern';
}

function isEmptyValue(value, type) {
  if (value === undefined || value === null) {
    return true;
  }

  if (type === 'array' && Array.isArray(value) && !value.length) {
    return true;
  }

  if (isNativeStringType(type) && typeof value === 'string' && !value) {
    return true;
  }

  return false;
}

function asyncParallelArray(arr, func, callback) {
  var results = [];
  var total = 0;
  var arrLength = arr.length;

  function count(errors) {
    results.push.apply(results, errors);
    total++;

    if (total === arrLength) {
      callback(results);
    }
  }

  arr.forEach(function (a) {
    func(a, count);
  });
}

function asyncSerialArray(arr, func, callback) {
  var index = 0;
  var arrLength = arr.length;

  function next(errors) {
    if (errors && errors.length) {
      callback(errors);
      return;
    }

    var original = index;
    index = index + 1;

    if (original < arrLength) {
      func(arr[original], next);
    } else {
      callback([]);
    }
  }

  next([]);
}

function flattenObjArr(objArr) {
  var ret = [];
  Object.keys(objArr).forEach(function (k) {
    ret.push.apply(ret, objArr[k]);
  });
  return ret;
}

var AsyncValidationError = /*#__PURE__*/function (_Error) {
  _inheritsLoose(AsyncValidationError, _Error);

  function AsyncValidationError(errors, fields) {
    var _this;

    _this = _Error.call(this, 'Async Validation Error') || this;
    _this.errors = errors;
    _this.fields = fields;
    return _this;
  }

  return AsyncValidationError;
}( /*#__PURE__*/_wrapNativeSuper(Error));
function asyncMap(objArr, option, func, callback) {
  if (option.first) {
    var _pending = new Promise(function (resolve, reject) {
      var next = function next(errors) {
        callback(errors);
        return errors.length ? reject(new AsyncValidationError(errors, convertFieldsError(errors))) : resolve();
      };

      var flattenArr = flattenObjArr(objArr);
      asyncSerialArray(flattenArr, func, next);
    });

    _pending["catch"](function (e) {
      return e;
    });

    return _pending;
  }

  var firstFields = option.firstFields || [];

  if (firstFields === true) {
    firstFields = Object.keys(objArr);
  }

  var objArrKeys = Object.keys(objArr);
  var objArrLength = objArrKeys.length;
  var total = 0;
  var results = [];
  var pending = new Promise(function (resolve, reject) {
    var next = function next(errors) {
      results.push.apply(results, errors);
      total++;

      if (total === objArrLength) {
        callback(results);
        return results.length ? reject(new AsyncValidationError(results, convertFieldsError(results))) : resolve();
      }
    };

    if (!objArrKeys.length) {
      callback(results);
      resolve();
    }

    objArrKeys.forEach(function (key) {
      var arr = objArr[key];

      if (firstFields.indexOf(key) !== -1) {
        asyncSerialArray(arr, func, next);
      } else {
        asyncParallelArray(arr, func, next);
      }
    });
  });
  pending["catch"](function (e) {
    return e;
  });
  return pending;
}
function complementError(rule) {
  return function (oe) {
    if (oe && oe.message) {
      oe.field = oe.field || rule.fullField;
      return oe;
    }

    return {
      message: typeof oe === 'function' ? oe() : oe,
      field: oe.field || rule.fullField
    };
  };
}
function deepMerge(target, source) {
  if (source) {
    for (var s in source) {
      if (source.hasOwnProperty(s)) {
        var value = source[s];

        if (typeof value === 'object' && typeof target[s] === 'object') {
          target[s] = _extends({}, target[s], value);
        } else {
          target[s] = value;
        }
      }
    }
  }

  return target;
}

/**
 *  Rule for validating required fields.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param source The source object being validated.
 *  @param errors An array of errors that this rule may add
 *  validation errors to.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function required(rule, value, source, errors, options, type) {
  if (rule.required && (!source.hasOwnProperty(rule.field) || isEmptyValue(value, type || rule.type))) {
    errors.push(format(options.messages.required, rule.fullField));
  }
}

/**
 *  Rule for validating whitespace.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param source The source object being validated.
 *  @param errors An array of errors that this rule may add
 *  validation errors to.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function whitespace(rule, value, source, errors, options) {
  if (/^\s+$/.test(value) || value === '') {
    errors.push(format(options.messages.whitespace, rule.fullField));
  }
}

/* eslint max-len:0 */

var pattern = {
  // http://emailregex.com/
  email: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
  url: new RegExp("^(?!mailto:)(?:(?:http|https|ftp)://|//)(?:\\S+(?::\\S*)?@)?(?:(?:(?:[1-9]\\d?|1\\d\\d|2[01]\\d|22[0-3])(?:\\.(?:1?\\d{1,2}|2[0-4]\\d|25[0-5])){2}(?:\\.(?:[0-9]\\d?|1\\d\\d|2[0-4]\\d|25[0-4]))|(?:(?:[a-z\\u00a1-\\uffff0-9]+-*)*[a-z\\u00a1-\\uffff0-9]+)(?:\\.(?:[a-z\\u00a1-\\uffff0-9]+-*)*[a-z\\u00a1-\\uffff0-9]+)*(?:\\.(?:[a-z\\u00a1-\\uffff]{2,})))|localhost)(?::\\d{2,5})?(?:(/|\\?|#)[^\\s]*)?$", 'i'),
  hex: /^#?([a-f0-9]{6}|[a-f0-9]{3})$/i
};
var types = {
  integer: function integer(value) {
    return types.number(value) && parseInt(value, 10) === value;
  },
  "float": function float(value) {
    return types.number(value) && !types.integer(value);
  },
  array: function array(value) {
    return Array.isArray(value);
  },
  regexp: function regexp(value) {
    if (value instanceof RegExp) {
      return true;
    }

    try {
      return !!new RegExp(value);
    } catch (e) {
      return false;
    }
  },
  date: function date(value) {
    return typeof value.getTime === 'function' && typeof value.getMonth === 'function' && typeof value.getYear === 'function' && !isNaN(value.getTime());
  },
  number: function number(value) {
    if (isNaN(value)) {
      return false;
    }

    return typeof value === 'number';
  },
  object: function object(value) {
    return typeof value === 'object' && !types.array(value);
  },
  method: function method(value) {
    return typeof value === 'function';
  },
  email: function email(value) {
    return typeof value === 'string' && !!value.match(pattern.email) && value.length < 255;
  },
  url: function url(value) {
    return typeof value === 'string' && !!value.match(pattern.url);
  },
  hex: function hex(value) {
    return typeof value === 'string' && !!value.match(pattern.hex);
  }
};
/**
 *  Rule for validating the type of a value.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param source The source object being validated.
 *  @param errors An array of errors that this rule may add
 *  validation errors to.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function type(rule, value, source, errors, options) {
  if (rule.required && value === undefined) {
    required(rule, value, source, errors, options);
    return;
  }

  var custom = ['integer', 'float', 'array', 'regexp', 'object', 'method', 'email', 'number', 'date', 'url', 'hex'];
  var ruleType = rule.type;

  if (custom.indexOf(ruleType) > -1) {
    if (!types[ruleType](value)) {
      errors.push(format(options.messages.types[ruleType], rule.fullField, rule.type));
    } // straight typeof check

  } else if (ruleType && typeof value !== rule.type) {
    errors.push(format(options.messages.types[ruleType], rule.fullField, rule.type));
  }
}

/**
 *  Rule for validating minimum and maximum allowed values.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param source The source object being validated.
 *  @param errors An array of errors that this rule may add
 *  validation errors to.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function range(rule, value, source, errors, options) {
  var len = typeof rule.len === 'number';
  var min = typeof rule.min === 'number';
  var max = typeof rule.max === 'number'; // 正则匹配码点范围从U+010000一直到U+10FFFF的文字（补充平面Supplementary Plane）

  var spRegexp = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g;
  var val = value;
  var key = null;
  var num = typeof value === 'number';
  var str = typeof value === 'string';
  var arr = Array.isArray(value);

  if (num) {
    key = 'number';
  } else if (str) {
    key = 'string';
  } else if (arr) {
    key = 'array';
  } // if the value is not of a supported type for range validation
  // the validation rule rule should use the
  // type property to also test for a particular type


  if (!key) {
    return false;
  }

  if (arr) {
    val = value.length;
  }

  if (str) {
    // 处理码点大于U+010000的文字length属性不准确的bug，如"𠮷𠮷𠮷".lenght !== 3
    val = value.replace(spRegexp, '_').length;
  }

  if (len) {
    if (val !== rule.len) {
      errors.push(format(options.messages[key].len, rule.fullField, rule.len));
    }
  } else if (min && !max && val < rule.min) {
    errors.push(format(options.messages[key].min, rule.fullField, rule.min));
  } else if (max && !min && val > rule.max) {
    errors.push(format(options.messages[key].max, rule.fullField, rule.max));
  } else if (min && max && (val < rule.min || val > rule.max)) {
    errors.push(format(options.messages[key].range, rule.fullField, rule.min, rule.max));
  }
}

var ENUM = 'enum';
/**
 *  Rule for validating a value exists in an enumerable list.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param source The source object being validated.
 *  @param errors An array of errors that this rule may add
 *  validation errors to.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function enumerable(rule, value, source, errors, options) {
  rule[ENUM] = Array.isArray(rule[ENUM]) ? rule[ENUM] : [];

  if (rule[ENUM].indexOf(value) === -1) {
    errors.push(format(options.messages[ENUM], rule.fullField, rule[ENUM].join(', ')));
  }
}

/**
 *  Rule for validating a regular expression pattern.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param source The source object being validated.
 *  @param errors An array of errors that this rule may add
 *  validation errors to.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function pattern$1(rule, value, source, errors, options) {
  if (rule.pattern) {
    if (rule.pattern instanceof RegExp) {
      // if a RegExp instance is passed, reset `lastIndex` in case its `global`
      // flag is accidentally set to `true`, which in a validation scenario
      // is not necessary and the result might be misleading
      rule.pattern.lastIndex = 0;

      if (!rule.pattern.test(value)) {
        errors.push(format(options.messages.pattern.mismatch, rule.fullField, value, rule.pattern));
      }
    } else if (typeof rule.pattern === 'string') {
      var _pattern = new RegExp(rule.pattern);

      if (!_pattern.test(value)) {
        errors.push(format(options.messages.pattern.mismatch, rule.fullField, value, rule.pattern));
      }
    }
  }
}

var rules = {
  required: required,
  whitespace: whitespace,
  type: type,
  range: range,
  "enum": enumerable,
  pattern: pattern$1
};

/**
 *  Performs validation for string types.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function string(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value, 'string') && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options, 'string');

    if (!isEmptyValue(value, 'string')) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
      rules.pattern(rule, value, source, errors, options);

      if (rule.whitespace === true) {
        rules.whitespace(rule, value, source, errors, options);
      }
    }
  }

  callback(errors);
}

/**
 *  Validates a function.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function method(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (value !== undefined) {
      rules.type(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates a number.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function number(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (value === '') {
      value = undefined;
    }

    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (value !== undefined) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates a boolean.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function _boolean(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (value !== undefined) {
      rules.type(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates the regular expression type.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function regexp(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (!isEmptyValue(value)) {
      rules.type(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates a number is an integer.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function integer(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (value !== undefined) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates a number is a floating point number.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function floatFn(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (value !== undefined) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates an array.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function array(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if ((value === undefined || value === null) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options, 'array');

    if (value !== undefined && value !== null) {
      rules.type(rule, value, source, errors, options);
      rules.range(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates an object.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function object(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (value !== undefined) {
      rules.type(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

var ENUM$1 = 'enum';
/**
 *  Validates an enumerable list.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function enumerable$1(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (value !== undefined) {
      rules[ENUM$1](rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Validates a regular expression pattern.
 *
 *  Performs validation when a rule only contains
 *  a pattern property but is not declared as a string type.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function pattern$2(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value, 'string') && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (!isEmptyValue(value, 'string')) {
      rules.pattern(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

function date(rule, value, callback, source, options) {
  // console.log('integer rule called %j', rule);
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field); // console.log('validate on %s value', value);

  if (validate) {
    if (isEmptyValue(value, 'date') && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);

    if (!isEmptyValue(value, 'date')) {
      var dateObject;

      if (value instanceof Date) {
        dateObject = value;
      } else {
        dateObject = new Date(value);
      }

      rules.type(rule, dateObject, source, errors, options);

      if (dateObject) {
        rules.range(rule, dateObject.getTime(), source, errors, options);
      }
    }
  }

  callback(errors);
}

function required$1(rule, value, callback, source, options) {
  var errors = [];
  var type = Array.isArray(value) ? 'array' : typeof value;
  rules.required(rule, value, source, errors, options, type);
  callback(errors);
}

function type$1(rule, value, callback, source, options) {
  var ruleType = rule.type;
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value, ruleType) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options, ruleType);

    if (!isEmptyValue(value, ruleType)) {
      rules.type(rule, value, source, errors, options);
    }
  }

  callback(errors);
}

/**
 *  Performs validation for any type.
 *
 *  @param rule The validation rule.
 *  @param value The value of the field on the source object.
 *  @param callback The callback function.
 *  @param source The source object being validated.
 *  @param options The validation options.
 *  @param options.messages The validation messages.
 */

function any(rule, value, callback, source, options) {
  var errors = [];
  var validate = rule.required || !rule.required && source.hasOwnProperty(rule.field);

  if (validate) {
    if (isEmptyValue(value) && !rule.required) {
      return callback();
    }

    rules.required(rule, value, source, errors, options);
  }

  callback(errors);
}

var validators = {
  string: string,
  method: method,
  number: number,
  "boolean": _boolean,
  regexp: regexp,
  integer: integer,
  "float": floatFn,
  array: array,
  object: object,
  "enum": enumerable$1,
  pattern: pattern$2,
  date: date,
  url: type$1,
  hex: type$1,
  email: type$1,
  required: required$1,
  any: any
};

function newMessages() {
  return {
    "default": 'Validation error on field %s',
    required: '%s is required',
    "enum": '%s must be one of %s',
    whitespace: '%s cannot be empty',
    date: {
      format: '%s date %s is invalid for format %s',
      parse: '%s date could not be parsed, %s is invalid ',
      invalid: '%s date %s is invalid'
    },
    types: {
      string: '%s is not a %s',
      method: '%s is not a %s (function)',
      array: '%s is not an %s',
      object: '%s is not an %s',
      number: '%s is not a %s',
      date: '%s is not a %s',
      "boolean": '%s is not a %s',
      integer: '%s is not an %s',
      "float": '%s is not a %s',
      regexp: '%s is not a valid %s',
      email: '%s is not a valid %s',
      url: '%s is not a valid %s',
      hex: '%s is not a valid %s'
    },
    string: {
      len: '%s must be exactly %s characters',
      min: '%s must be at least %s characters',
      max: '%s cannot be longer than %s characters',
      range: '%s must be between %s and %s characters'
    },
    number: {
      len: '%s must equal %s',
      min: '%s cannot be less than %s',
      max: '%s cannot be greater than %s',
      range: '%s must be between %s and %s'
    },
    array: {
      len: '%s must be exactly %s in length',
      min: '%s cannot be less than %s in length',
      max: '%s cannot be greater than %s in length',
      range: '%s must be between %s and %s in length'
    },
    pattern: {
      mismatch: '%s value %s does not match pattern %s'
    },
    clone: function clone() {
      var cloned = JSON.parse(JSON.stringify(this));
      cloned.clone = this.clone;
      return cloned;
    }
  };
}
var messages = newMessages();

/**
 *  Encapsulates a validation schema.
 *
 *  @param descriptor An object declaring validation rules
 *  for this schema.
 */

function Schema(descriptor) {
  this.rules = null;
  this._messages = messages;
  this.define(descriptor);
}

Schema.prototype = {
  messages: function messages(_messages) {
    if (_messages) {
      this._messages = deepMerge(newMessages(), _messages);
    }

    return this._messages;
  },
  define: function define(rules) {
    if (!rules) {
      throw new Error('Cannot configure a schema with no rules');
    }

    if (typeof rules !== 'object' || Array.isArray(rules)) {
      throw new Error('Rules must be an object');
    }

    this.rules = {};
    var z;
    var item;

    for (z in rules) {
      if (rules.hasOwnProperty(z)) {
        item = rules[z];
        this.rules[z] = Array.isArray(item) ? item : [item];
      }
    }
  },
  validate: function validate(source_, o, oc) {
    var _this = this;

    if (o === void 0) {
      o = {};
    }

    if (oc === void 0) {
      oc = function oc() {};
    }

    var source = source_;
    var options = o;
    var callback = oc;

    if (typeof options === 'function') {
      callback = options;
      options = {};
    }

    if (!this.rules || Object.keys(this.rules).length === 0) {
      if (callback) {
        callback();
      }

      return Promise.resolve();
    }

    function complete(results) {
      var i;
      var errors = [];
      var fields = {};

      function add(e) {
        if (Array.isArray(e)) {
          var _errors;

          errors = (_errors = errors).concat.apply(_errors, e);
        } else {
          errors.push(e);
        }
      }

      for (i = 0; i < results.length; i++) {
        add(results[i]);
      }

      if (!errors.length) {
        errors = null;
        fields = null;
      } else {
        fields = convertFieldsError(errors);
      }

      callback(errors, fields);
    }

    if (options.messages) {
      var messages$1 = this.messages();

      if (messages$1 === messages) {
        messages$1 = newMessages();
      }

      deepMerge(messages$1, options.messages);
      options.messages = messages$1;
    } else {
      options.messages = this.messages();
    }

    var arr;
    var value;
    var series = {};
    var keys = options.keys || Object.keys(this.rules);
    keys.forEach(function (z) {
      arr = _this.rules[z];
      value = source[z];
      arr.forEach(function (r) {
        var rule = r;

        if (typeof rule.transform === 'function') {
          if (source === source_) {
            source = _extends({}, source);
          }

          value = source[z] = rule.transform(value);
        }

        if (typeof rule === 'function') {
          rule = {
            validator: rule
          };
        } else {
          rule = _extends({}, rule);
        }

        rule.validator = _this.getValidationMethod(rule);
        rule.field = z;
        rule.fullField = rule.fullField || z;
        rule.type = _this.getType(rule);

        if (!rule.validator) {
          return;
        }

        series[z] = series[z] || [];
        series[z].push({
          rule: rule,
          value: value,
          source: source,
          field: z
        });
      });
    });
    var errorFields = {};
    return asyncMap(series, options, function (data, doIt) {
      var rule = data.rule;
      var deep = (rule.type === 'object' || rule.type === 'array') && (typeof rule.fields === 'object' || typeof rule.defaultField === 'object');
      deep = deep && (rule.required || !rule.required && data.value);
      rule.field = data.field;

      function addFullfield(key, schema) {
        return _extends({}, schema, {
          fullField: rule.fullField + "." + key
        });
      }

      function cb(e) {
        if (e === void 0) {
          e = [];
        }

        var errors = e;

        if (!Array.isArray(errors)) {
          errors = [errors];
        }

        if (!options.suppressWarning && errors.length) {
          Schema.warning('async-validator:', errors);
        }

        if (errors.length && rule.message !== undefined) {
          errors = [].concat(rule.message);
        }

        errors = errors.map(complementError(rule));

        if (options.first && errors.length) {
          errorFields[rule.field] = 1;
          return doIt(errors);
        }

        if (!deep) {
          doIt(errors);
        } else {
          // if rule is required but the target object
          // does not exist fail at the rule level and don't
          // go deeper
          if (rule.required && !data.value) {
            if (rule.message !== undefined) {
              errors = [].concat(rule.message).map(complementError(rule));
            } else if (options.error) {
              errors = [options.error(rule, format(options.messages.required, rule.field))];
            }

            return doIt(errors);
          }

          var fieldsSchema = {};

          if (rule.defaultField) {
            for (var k in data.value) {
              if (data.value.hasOwnProperty(k)) {
                fieldsSchema[k] = rule.defaultField;
              }
            }
          }

          fieldsSchema = _extends({}, fieldsSchema, data.rule.fields);

          for (var f in fieldsSchema) {
            if (fieldsSchema.hasOwnProperty(f)) {
              var fieldSchema = Array.isArray(fieldsSchema[f]) ? fieldsSchema[f] : [fieldsSchema[f]];
              fieldsSchema[f] = fieldSchema.map(addFullfield.bind(null, f));
            }
          }

          var schema = new Schema(fieldsSchema);
          schema.messages(options.messages);

          if (data.rule.options) {
            data.rule.options.messages = options.messages;
            data.rule.options.error = options.error;
          }

          schema.validate(data.value, data.rule.options || options, function (errs) {
            var finalErrors = [];

            if (errors && errors.length) {
              finalErrors.push.apply(finalErrors, errors);
            }

            if (errs && errs.length) {
              finalErrors.push.apply(finalErrors, errs);
            }

            doIt(finalErrors.length ? finalErrors : null);
          });
        }
      }

      var res;

      if (rule.asyncValidator) {
        res = rule.asyncValidator(rule, data.value, cb, data.source, options);
      } else if (rule.validator) {
        res = rule.validator(rule, data.value, cb, data.source, options);

        if (res === true) {
          cb();
        } else if (res === false) {
          cb(rule.message || rule.field + " fails");
        } else if (res instanceof Array) {
          cb(res);
        } else if (res instanceof Error) {
          cb(res.message);
        }
      }

      if (res && res.then) {
        res.then(function () {
          return cb();
        }, function (e) {
          return cb(e);
        });
      }
    }, function (results) {
      complete(results);
    });
  },
  getType: function getType(rule) {
    if (rule.type === undefined && rule.pattern instanceof RegExp) {
      rule.type = 'pattern';
    }

    if (typeof rule.validator !== 'function' && rule.type && !validators.hasOwnProperty(rule.type)) {
      throw new Error(format('Unknown rule type %s', rule.type));
    }

    return rule.type || 'string';
  },
  getValidationMethod: function getValidationMethod(rule) {
    if (typeof rule.validator === 'function') {
      return rule.validator;
    }

    var keys = Object.keys(rule);
    var messageIndex = keys.indexOf('message');

    if (messageIndex !== -1) {
      keys.splice(messageIndex, 1);
    }

    if (keys.length === 1 && keys[0] === 'required') {
      return validators.required;
    }

    return validators[this.getType(rule)] || false;
  }
};

Schema.register = function register(type, validator) {
  if (typeof validator !== 'function') {
    throw new Error('Cannot register a validator by type, validator is not a function');
  }

  validators[type] = validator;
};

Schema.warning = warning;
Schema.messages = messages;
Schema.validators = validators;

/* harmony default export */ __webpack_exports__["a"] = (Schema);
//# sourceMappingURL=index.js.map

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("4362")))

/***/ }),

/***/ "b8ad":
/***/ (function(module, exports, __webpack_require__) {

(function (global, factory) {
	 true ? module.exports = factory() :
	undefined;
}(this, (function () { 'use strict';

function arrayTreeFilter(data, filterFn, options) {
    options = options || {};
    options.childrenKeyName = options.childrenKeyName || "children";
    var children = data || [];
    var result = [];
    var level = 0;
    do {
        var foundItem = children.filter(function (item) {
            return filterFn(item, level);
        })[0];
        if (!foundItem) {
            break;
        }
        result.push(foundItem);
        children = foundItem[options.childrenKeyName] || [];
        level += 1;
    } while (children.length > 0);
    return result;
}

return arrayTreeFilter;

})));


/***/ })

}]);