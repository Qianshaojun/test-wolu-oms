(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~ada1a736"],{

/***/ "00aa":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-sku-sale.vue?vue&type=template&id=26ec14f8&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",on:{"changeSearchState":_vm.showHideSearch}},[_c('data-form',{ref:"dataForm",attrs:{"column":1,"showSearch":_vm.showSearch},on:{"submit":_vm.getSkuSaleList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"sku"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.buyTime')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'order_date',
                        {
                            rules: _vm.rules.required,
                            initialValue: [_vm.start_date, _vm.end_date]
                        }
                    ]),expression:"[\n                        'order_date',\n                        {\n                            rules: rules.required,\n                            initialValue: [start_date, end_date]\n                        }\n                    ]"}],style:({ width: '240px' }),attrs:{"size":"small"}}),_c('a-radio-group',{style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onTimeChange(e); }}},[_c('a-radio-button',{attrs:{"value":"one_month"}},[_vm._v(_vm._s(_vm.$t('near_one_month'))+" ")]),_c('a-radio-button',{attrs:{"value":"three_month"}},[_vm._v(_vm._s(_vm.$t('near_three_month'))+" ")]),_c('a-radio-button',{attrs:{"value":"half_year"}},[_vm._v(_vm._s(_vm.$t('near_half_year'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.operator')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator']),expression:"['operator']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.department')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['department']),expression:"['department']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category']),expression:"['z_category']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"default_code","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, selectedRows) {
                    _vm.selectedRowKeys = keys
                    this$1.changeCharts(keys, selectedRows)
                }
            },"scroll":{ y: 160 }},on:{"on-page-change":_vm.getSkuSaleList,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                    _vm.getDetailSales(record)
                },"change":function (sorter) { return _vm.onTableChange(sorter); }}},[_c('a-table-column',{key:"default_code",attrs:{"title":"sku","data-index":"default_code","width":"6%","align":"left"}}),_c('a-table-column',{key:"order_qty",attrs:{"title":_vm.$t('columns.order_qty'),"data-index":"order_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"sales_qty",attrs:{"title":_vm.$t('columns.sales_qty'),"data-index":"sales_qty","width":"6%","align":"right","sorter":true}}),_c('a-table-column',{key:"total_amount",attrs:{"title":_vm.$t('columns.total_amount'),"data-index":"total_amount","width":"6%","align":"right"}}),_c('a-table-column',{key:"presale_order_qty",attrs:{"title":_vm.$t('columns.presale_order_qty'),"data-index":"presale_order_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"presale_sales_qty",attrs:{"title":_vm.$t('columns.presale_sales_qty'),"data-index":"presale_sales_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"presale_total_amount",attrs:{"title":_vm.$t('columns.presale_total_amount'),"data-index":"presale_total_amount","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_order_qty",attrs:{"title":_vm.$t('columns.uk_order_qty'),"data-index":"uk_order_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_sales_qty",attrs:{"title":_vm.$t('columns.uk_sales_qty'),"data-index":"uk_sales_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_presale_order_qty",attrs:{"title":_vm.$t('columns.uk_presale_order_qty'),"data-index":"uk_presale_order_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_presale_sales_qty",attrs:{"title":_vm.$t('columns.uk_presale_sales_qty'),"data-index":"uk_presale_sales_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_total_amount",attrs:{"title":_vm.$t('columns.uk_total_amount'),"data-index":"uk_total_amount","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_total_tax",attrs:{"title":_vm.$t('columns.uk_total_tax'),"data-index":"uk_total_tax","width":"6%","align":"right"}}),_c('a-table-column',{key:"operator",attrs:{"title":_vm.$t('columns.operator'),"data-index":"operator","width":"6%","align":"left"}}),_c('a-table-column',{key:"department",attrs:{"title":_vm.$t('columns.department'),"data-index":"department","width":"6%","align":"left"}}),_c('a-table-column',{key:"z_category",attrs:{"title":_vm.$t('columns.z_category'),"data-index":"z_category","width":"6%","align":"left"}}),_c('a-table-column',{key:"z_sub_category",attrs:{"title":_vm.$t('columns.z_sub_category'),"data-index":"z_sub_category","width":"6%","align":"left"}})],1)],1),_c('a-card',{staticClass:"margin-y"},[[_c('section',{staticClass:"component customer-detail"},[_c('a-tabs',{attrs:{"defaultActiveKey":"base"},model:{value:(_vm.activeKey),callback:function ($$v) {_vm.activeKey=$$v},expression:"activeKey"}},[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('sku_sale_report')}},[_c('ve-histogram',{attrs:{"data":_vm.chartData1,"settings":_vm.chartSettings}})],1),_c('a-tab-pane',{key:"detail_sales",attrs:{"tab":_vm.$t('sku_sale_detail')}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.chartData1.rows,"page":_vm.pageService,"rowKey":"default_code","bordered":""}},[_c('a-table-column',{key:"order_date",attrs:{"title":_vm.$t('columns.order_date'),"data-index":"order_date","width":"7%","align":"center"}}),_c('a-table-column',{key:"order_qty",attrs:{"title":_vm.$t('columns.order_qty'),"data-index":"order_qty","width":"7%","align":"right"}}),_c('a-table-column',{key:"sales_qty",attrs:{"title":_vm.$t('columns.sales_qty'),"data-index":"sales_qty","width":"7%","align":"right"}}),_c('a-table-column',{key:"total_amount",attrs:{"title":_vm.$t('columns.total_amount'),"data-index":"total_amount","width":"7%","align":"right"}}),_c('a-table-column',{key:"total_tax",attrs:{"title":_vm.$t('columns.total_tax'),"data-index":"total_tax","width":"7%","align":"right"}}),_c('a-table-column',{key:"presale_order_qty",attrs:{"title":_vm.$t('columns.presale_order_qty'),"data-index":"presale_order_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"presale_sales_qty",attrs:{"title":_vm.$t('columns.presale_sales_qty'),"data-index":"presale_sales_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"presale_total_amount",attrs:{"title":_vm.$t('columns.presale_total_amount'),"data-index":"presale_total_amount","width":"8%","align":"right"}}),_c('a-table-column',{key:"presale_total_tax",attrs:{"title":_vm.$t('columns.presale_total_tax'),"data-index":"presale_total_tax","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_order_qty",attrs:{"title":_vm.$t('columns.uk_order_qty'),"data-index":"uk_order_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_sales_qty",attrs:{"title":_vm.$t('columns.uk_sales_qty'),"data-index":"uk_sales_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_presale_order_qty",attrs:{"title":_vm.$t('columns.uk_presale_order_qty'),"data-index":"uk_presale_order_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_presale_sales_qty",attrs:{"title":_vm.$t('columns.uk_presale_sales_qty'),"data-index":"uk_presale_sales_qty","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_total_amount",attrs:{"title":_vm.$t('columns.uk_total_amount'),"data-index":"uk_total_amount","width":"6%","align":"right"}}),_c('a-table-column',{key:"uk_total_tax",attrs:{"title":_vm.$t('columns.uk_total_tax'),"data-index":"uk_total_tax","width":"6%","align":"right"}})],1)],1)],1)],1)]],2)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-sku-sale.vue?vue&type=template&id=26ec14f8&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.sort.js
var es_array_sort = __webpack_require__("4e82");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/skusale.service.ts
var skusale_service = __webpack_require__("74b3");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-sku-sale.vue?vue&type=script&lang=ts&


















var product_sku_salevue_type_script_lang_ts_ProductSkuSale =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductSkuSale, _super);

  function ProductSkuSale() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.showSearch = true;
    _this.yearPick = null;
    _this.yearPickShow = false;
    _this.activeKey = 'base';
    _this.start_date = '';
    _this.end_date = ''; // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.orderBy = '';
    _this.SkuSaleService = new skusale_service["a" /* SkuSaleService */]();
    _this.rules = {
      required: [{
        required: true
      }]
    };
    _this.chartSettings = {
      axisSite: {
        right: ['sales_qty']
      },
      // yAxisType: ['KMB', 'percent'],
      yAxisName: ['销售金额', '销量']
    };
    _this.chartData1 = {
      columns: ['order_date', 'total_amount', 'sales_qty'],
      rows: []
    };
    return _this;
  }

  ProductSkuSale.prototype.showHideSearch = function (flag) {
    this.showSearch = flag;
  };

  ProductSkuSale.prototype.handleOpenChange = function (status) {
    this.yearPickShow = status;
  };
  /**
   * 获取销售趋势数据
   */


  ProductSkuSale.prototype.getSkuSaleList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (values['order_date'][0].constructor.name != 'Moment' || values['order_date'][1].constructor.name != 'Moment') {
        _this.$message.error('请填写购买时间段');

        return false;
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        default_code: 'like'
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array) {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: item.value[0].format('YYYY-MM-DD 00:00:00').toString()
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: item.value[1].format('YYYY-MM-DD 23:59:59').toString()
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      params.query_condition = nowConditions;

      if (_this.orderBy) {
        params['order_by'] = _this.orderBy;
      }

      _this.SkuSaleService.query_sum_all(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.data = data;
        _this.selectedRowKeys = [];
        _this.start_date = values['order_date'][0];
        _this.end_date = values['order_date'][1];
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {// 异常处理
    });
  };

  ProductSkuSale.prototype.onStatusChange = function (e) {
    this.$nextTick(function () {
      this.getSkuSaleList();
    });
  };

  ProductSkuSale.prototype.onTimeChange = function (e) {
    var _this = this;

    if (e.target.value == 'one_month') {
      this.start_date = moment_default()().subtract(1, 'months');
    } else if (e.target.value == 'three_month') {
      this.start_date = moment_default()().subtract(3, 'months');
    } else if (e.target.value == 'half_year') {
      this.start_date = moment_default()().subtract(6, 'months');
    }

    this.end_date = moment_default()();
    var values = this.dataForm.getValues();
    values['order_date'] = [this.start_date, this.end_date];
    var myFirstPromise = new Promise(function (resolve, reject) {
      _this.dataForm.setValues(values);
    });
    myFirstPromise.then(function () {
      _this.getSkuSaleList;
    }).catch();
  };

  ProductSkuSale.prototype.getDetailSales = function (default_code) {
    var _this = this;

    this.SkuSaleService.query_by_time(new http["RequestParams"]({
      default_code: default_code,
      start_date: this.start_date.format('YYYY-MM-DD 00:00:00').toString(),
      end_date: this.end_date.format('YYYY-MM-DD 23:59:59').toString()
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.sort(function (a, b) {
        return a.order_date > b.order_date ? 1 : -1;
      });
      _this.chartData1.rows = data;
    });
  };

  ProductSkuSale.prototype.changeCharts = function (selectedRowKeys, selectedRows) {
    this.getDetailSales(selectedRows[0].default_code);
  };

  ProductSkuSale.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getSkuSaleList();
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductSkuSale.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductSkuSale.prototype, "pageContainer", void 0);

  ProductSkuSale = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-sku-sale'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductSkuSale);
  return ProductSkuSale;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_sku_salevue_type_script_lang_ts_ = (product_sku_salevue_type_script_lang_ts_ProductSkuSale);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-sku-sale.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_product_sku_salevue_type_script_lang_ts_ = (product_sku_salevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/product-sku-sale.vue?vue&type=custom&index=0&blockType=i18n
var product_sku_salevue_type_custom_index_0_blockType_i18n = __webpack_require__("3258");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-sku-sale.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_product_sku_salevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_sku_salevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_sku_salevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_sku_sale = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "064e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/invoice-edit.vue?vue&type=template&id=5f4aad06&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('InvoiceEdit')],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/accounts/invoice-edit.vue?vue&type=template&id=5f4aad06&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/components/account/invoice-edit.vue + 14 modules
var invoice_edit = __webpack_require__("807b");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/invoice-edit.vue?vue&type=script&lang=ts&







var invoice_editvue_type_script_lang_ts_OrderEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderEdit, _super);

  function OrderEdit() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  Object.defineProperty(OrderEdit.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], OrderEdit.prototype, "pageContainer", void 0);

  OrderEdit = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'invoice-edit'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      InvoiceEdit: invoice_edit["a" /* default */]
    }
  })], OrderEdit);
  return OrderEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var invoice_editvue_type_script_lang_ts_ = (invoice_editvue_type_script_lang_ts_OrderEdit);
// CONCATENATED MODULE: ./src/pages/accounts/invoice-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var accounts_invoice_editvue_type_script_lang_ts_ = (invoice_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/accounts/invoice-edit.vue?vue&type=style&index=0&lang=css&
var invoice_editvue_type_style_index_0_lang_css_ = __webpack_require__("716c");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/accounts/invoice-edit.vue?vue&type=custom&index=0&blockType=i18n
var invoice_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("5de6");

// CONCATENATED MODULE: ./src/pages/accounts/invoice-edit.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  accounts_invoice_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof invoice_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(invoice_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var accounts_invoice_edit = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "0b3e":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"name":"Name","vendor_name":"vendor","warehouse_id":"warehouse","calculate_date":"calculate date","create_date":"schedule_date","dept_id":"Department"},"form":{"status":"Status","customer_code":"Customer Code","company_name":"Company Name","contract_start":"Contract Start Date","remote_file_name":"Router url","contract_end":"Contract End Date","female":"Female","field":"Field","draft":"Draft"},"action":{"update_requirement_schedule_state_purchase":"Purchase Submit","update_requirement_schedule_state_back":"Back","update_requirement_schedule_state_done":"Done","import":"Import","open_AttachmentList":"open Attachment"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","yes":"Yes","no":"No"},"zh-cn":{"desc":"这是订单页面1","columns":{"name":"Name","vendor_name":"供应商","warehouse_id":"仓库","calculate_date":"计算日期","create_date":"排单日期","dept_id":"部门"},"form":{"status":"状态","customer_code":"客户编号","company_name":"公司名称","contract_start":"合同开始日期","contract_end":"合同结束日期","field":"字段","draft":"草稿"},"action":{"update_requirement_schedule_state_purchase":"采购提交","update_requirement_schedule_state_back":"退回","update_requirement_schedule_state_done":"完成","import":"上传排单计划","open_AttachmentList":"打开附件列表"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","yes":"是","no":"否"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "0cf6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/aliexpress/aliexpress-manage1212.vue?vue&type=template&id=2527268f&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer"},[_c('data-form',{ref:"dataForm",attrs:{"extends":_vm.extendItems,"column":1,"showHeader":false},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{attrs:{"label":_vm.$t('columns.seller_code')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'seller_code',
                        {
                            rules: _vm.rules.required
                        }
                    ]),expression:"[\n                        'seller_code',\n                        {\n                            rules: rules.required\n                        }\n                    ]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select"}},_vm._l((_vm.sellerCodeList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.modified_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'modified_date',
                        { initialValue: _vm.initialDate }
                    ]),expression:"[\n                        'modified_date',\n                        { initialValue: initialDate }\n                    ]"}],attrs:{"format":"YYYY-MM-DD HH:mm","size":"small"}})],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.importOrders()}}},[_vm._v(" "+_vm._s(_vm.$t('action.import_orders'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.fulfilOrders()}}},[_vm._v(" "+_vm._s(_vm.$t('action.fulfil_orders'))+" ")])]},proxy:true}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-manage1212.vue?vue&type=template&id=2527268f&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/services/seller-instance.service.ts
var seller_instance_service = __webpack_require__("5c97");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/aliexpress.service.ts
var aliexpress_service = __webpack_require__("1c60");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/aliexpress/aliexpress-manage1212.vue?vue&type=script&lang=ts&










 // import router from '../../router'



var datasModule = Object(lib["c" /* namespace */])('datasModule');

var aliexpress_manage1212vue_type_script_lang_ts_AliexpressManage1212 =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AliexpressManage1212, _super);

  function AliexpressManage1212() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.aliexpressService = new aliexpress_service["a" /* AliexpressService */](); // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */](); // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.moment = moment_default.a;
    _this.modified_date_start = '';
    _this.modified_date_end = '';
    _this.object_name = 'aliexpress-manage';
    _this.initialDate = [];
    _this.sellerCodeList = [];
    _this.selectedRows = [];
    _this.sellerInstanceService = new seller_instance_service["a" /* SellerInstanceService */]();
    return _this;
  }

  Object.defineProperty(AliexpressManage1212.prototype, "rules", {
    // @datasModule.State
    // private sellerCodeList
    // @datasModule.Action
    // private getSellerCodeList
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  AliexpressManage1212.prototype.created = function () {
    this.getSellerCodeList();
    this.form = this.$form.createForm(this);
  };

  AliexpressManage1212.prototype.getSellerCodeList = function () {
    var _this = this;

    this.sellerInstanceService.query_seller_name(new http["RequestParams"]({})).subscribe(function (data) {
      _this.sellerCodeList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AliexpressManage1212.prototype.importOrders = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      values['modified_date_start'] = _this.modified_date_start;
      values['modified_date_end'] = _this.modified_date_end;

      _this.aliexpressService.importOrders(new http["RequestParams"](values)).subscribe(function () {
        var msg = _this.$t('tips.import_success');

        _this.$message.success(msg);
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  AliexpressManage1212.prototype.fulfilOrders = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      _this.aliexpressService.fulfilOrders(new http["RequestParams"](values)).subscribe(function () {
        var msg = _this.$t('tips.fulfil_success');

        _this.$message.success(msg);
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], AliexpressManage1212.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], AliexpressManage1212.prototype, "pageContainer", void 0);

  AliexpressManage1212 = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'aliexpress-manage1212'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */]
    }
  })], AliexpressManage1212);
  return AliexpressManage1212;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var aliexpress_manage1212vue_type_script_lang_ts_ = (aliexpress_manage1212vue_type_script_lang_ts_AliexpressManage1212);
// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-manage1212.vue?vue&type=script&lang=ts&
 /* harmony default export */ var aliexpress_aliexpress_manage1212vue_type_script_lang_ts_ = (aliexpress_manage1212vue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-manage1212.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  aliexpress_aliexpress_manage1212vue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var aliexpress_manage1212 = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "13d2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_confirm_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("dcd5");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_confirm_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_confirm_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_confirm_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "18da":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"id":"id","partner_name":"Customer","date_invoice":"Invoice Date","number":"Number","company_name":"Company","user_name":"Salesperson","create_user_name":"Applicant","date_due":"Due Date","origin":"Order Num","amount_total_signed":"Total","residual_signed":"Amount Due","state":"State","payment_method":"Payment Method","need_refund":"Need Refund","refund_time":"Refund Time","refund_memo":"Refund Memo","order_refund_status":"Order Refund Status","operate_message":"Operate Message","default_code":"SKU","name":"Product Name","quantity":"Quantity","price_unit":"Unit Price","account_tax_id":"Account Tax","action":"Action","ebay_buyer_id":"Ebay Buyer ID"},"action":{"today":"Today","yestoday":"Yestoday","3day":"3 Days","more":"More","sendInvoce":"Send Invoice","downloadInvoce":"Download Invoice","edit":"Edit","delete":"Delete","change_state":"Change State","origin":"Order ID","flag_refunded":"Flag Refunded","export_account_invoice":"Export Refund Orders"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","yes":"Yes","no":"No"},"zh-cn":{"desc":"","columns":{"id":"id","partner_name":"客户","date_invoice":"开票日期","number":"发票号","company_name":"公司","user_name":"销售员","create_user_name":"创建人","date_due":"截止日期","origin":"订单号","amount_total_signed":"总计","residual_signed":"退款金额","state":"状态","payment_method":"付款方式","need_refund":"需要退款","refund_time":"退款时间","refund_memo":"退款备注","order_refund_status":"退款状态","operate_message":"信息","default_code":"SKU","name":"产品名称","quantity":"数量","price_unit":"单价","account_tax_id":"税率","action":"操作","ebay_buyer_id":"Ebay买家ID"},"invoice_detail":"发票明细","log":"日志","action":{"today":"前一天","yestoday":"前两天","3day":"前三天","more":"更多","sendInvoce":"发送发票","downloadInvoce":"下载发票","edit":"编辑","delete":"删除","change_state":"修改状态","origin":"订单号","flag_refunded":"标志已退款","export_account_invoice":"导出退款订单"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","yes":"是","no":"否"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "1ec1":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"buyTime":"Buy Time","order_qty":"Order_qty","sales_qty":"Sales Qty","total_amount":"Total Amount","presale_order_qty":"Presale Order Qty","presale_sales_qty":"Presale Sales Qty","presale_total_amount":"Presale Total Amount","uk_order_qty":"Uk Order Qty","uk_sales_qty":"Uk Sales Qty","uk_presale_order_qty":"Uk Presale Order Qty","uk_presale_sales_qty":"Uk Presale Sales Qty","uk_total_amount":"Uk Total Amount","uk_total_tax":"Uk Total Tax","order_date":"Order Date","presale_total_tax":"Presale Total Tax","total_tax":"Total Tax"},"action":{},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","sku_sale_report":"Sku Sale Report","sku_sale_detail":"Sku Sale Detail","near_one_month":"Near One Month","near_three_month":"Near Three Month","near_half_year":"Near Half Year"},"zh-cn":{"desc":"","columns":{"buyTime":"购买时间","order_qty":"订单量","sales_qty":"销量","total_amount":"销售金额","presale_order_qty":"预售订单量","presale_sales_qty":"预售销量","presale_total_amount":"预售销售金额","uk_order_qty":"英线订单量","uk_sales_qty":"英线销量","uk_presale_order_qty":"英线预售订单量","uk_presale_sales_qty":"英线预售销量","uk_total_amount":"英线销量额","uk_total_tax":"英线销售税","order_date":"订单日期","presale_total_tax":"预售销售税","total_tax":"销售税"},"action":{},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","sku_sale_report":"sku销量报表","sku_sale_detail":"sku销量明细","near_one_month":"近一个月","near_three_month":"近三个月","near_half_year":"近半年"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "27dc":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Product Purchase Schedual","columns":{"warehouse_id":"Warehouse","calculate_date":"Calculate Date","finish_calculate":"Calcuate Finish","stock_qty":"Stock","fba_stock_qty":"FBA Stock","cur_month_transit_qty":"Currenct Month","next_month_transit_qty":"Next Month","last_month_transit_qty":"Last Month","unfinish_qty":"Unfinish QTY","scheduled_qty":"Schedualed QTY","factory_finish_qty":"Factory Finish QTY","schedual_available_qty":"Schedual Available QTY","will_12_sales":"12 Week","will_11_sales":"11 Week","will_10_sales":"10 Week","will_9_sales":"9 Week","will_8_sales":"8 Week","will_7_sales":"7 Week","will_6_sales":"6 Week","will_5_sales":"5 Week","will_4_sales":"4 Week","will_3_sales":"3 Week","will_2_sales":"2 Week","will_1_sales":"1 Week","schedule_qty":"Schedual QTY","sales_schedule_qty":"Sales Schedual QTY","length":"Length","width":"Width","height":"Height","weight":"Weight","z_sub_category":"Sub Category","size_info":"Size","vendor_name":"Vendor Name","increase_ratio_text":"Increase Ratio","draft":"Draft","complete":"Complete","cancel":"Cancel","create_date":"schedule date","dept_id":"Department"},"forms":{"draft":"Draft","complete":"Complete","cancel":"Cancel"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","save":"Save","cancel":"Cancel","confirm":"Confirm","export":"Export Excel","import":"Import Excel","view_logs":"Logs","calculate_increase_ratio":"Calculate Ratio","more":"More","update_requirement_schedule_state_20":"Update State by Warehouse","update_requirement_schedule_state_30":"Update State by Yunying"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"采购排单计划","columns":{"warehouse_id":"仓库","calculate_date":"计算日期","finish_calculate":"计算完成","stock_qty":"库存","fba_stock_qty":"FBA库存","cur_month_transit_qty":"当月","next_month_transit_qty":"下月","last_month_transit_qty":"尾月","unfinish_qty":"工厂数量","scheduled_qty":"已排期","factory_finish_qty":"工厂完成","schedual_available_qty":"可排期数","will_12_sales":"近12周","will_11_sales":"近11周","will_10_sales":"近10周","will_9_sales":"近9周","will_8_sales":"近8周","will_7_sales":"近7周","will_6_sales":"近6周","will_5_sales":"近5周","will_4_sales":"近4周","will_3_sales":"近3周","will_2_sales":"近2周","will_1_sales":"近1周","schedule_qty":"排期","sales_schedule_qty":"运营排期","length":"长","width":"宽","height":"高","weight":"重量","z_sub_category":"子类","size_info":"尺寸","vendor_name":"供应商","increase_ratio_text":"环比","draft":"草稿","complete":"完成","cancel":"取消","create_date":"排期时间","dept_id":"部门"},"forms":{"draft":"草稿","complete":"完成","cancel":"取消"},"action":{"create":"新建","edit":"编辑","delete":"删除","ok":"确定","save":"保存","cancel":"取消","confirm":"确认","export":"导出Excel","import":"导入Excel","view_logs":"日志","calculate_increase_ratio":"计算环比","more":"更多操作","update_requirement_schedule_state_20":"库管提交","update_requirement_schedule_state_30":"运营提交"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "2a7c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-confirm.vue?vue&type=template&id=0f00ad90&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('ProductPurchasePredict',{attrs:{"info":_vm.info}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-confirm.vue?vue&type=template&id=0f00ad90&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/components/product/product-purchase-predict.vue + 19 modules
var product_purchase_predict = __webpack_require__("200a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-confirm.vue?vue&type=script&lang=ts&






var product_purchase_confirmvue_type_script_lang_ts_ProductPurchaseConfirm =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPurchaseConfirm, _super);

  function ProductPurchaseConfirm() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.info = 'predict-confirm';
    return _this;
  }

  ProductPurchaseConfirm.prototype.created = function () {};

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], ProductPurchaseConfirm.prototype, "pageContainer", void 0);

  ProductPurchaseConfirm = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-purchase-confirm'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductPurchasePredict: product_purchase_predict["a" /* default */]
    }
  })], ProductPurchaseConfirm);
  return ProductPurchaseConfirm;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_purchase_confirmvue_type_script_lang_ts_ = (product_purchase_confirmvue_type_script_lang_ts_ProductPurchaseConfirm);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-confirm.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_product_purchase_confirmvue_type_script_lang_ts_ = (product_purchase_confirmvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/product-purchase-confirm.vue?vue&type=custom&index=0&blockType=i18n
var product_purchase_confirmvue_type_custom_index_0_blockType_i18n = __webpack_require__("13d2");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-confirm.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_product_purchase_confirmvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_purchase_confirmvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_purchase_confirmvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_purchase_confirm = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "2ba6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_total_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("474d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_total_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_total_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_total_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "2c63":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("de64");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "2e79":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "31f6":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "320b":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"actions":"Actions","view":"View","cn_category":"CN Category","cn_sub_category":"CN Sub Category","aliexpress_sku":"Aliexpress Sku","basic_sku":"Basic Sku","aliexpress_stock":"Aliexpress Stock","auto_state":"Auto State","basic_odoo_stock":"Basic Odoo Stock","basic_related_qty":"Basic Related Qty","compute_time":"Compute Time","critical_value":"Critical Value","from_value":"From Value","id":"ID","import_time":"Import Time","last_write_back_value":"Last Write Back Value","merge_user":"Merge User","odoo_stock":"Odoo Stock","pull_off_value":"Pull Off Value","seller_name":"Seller Name","sku_id":"Sku Id","sku_price":"Sku Price","country":"Country","to_value":"To Value","write_back_time":"Write Back Time","write_back_value":"Write Back Value"},"action":{"create":"Create","batch-create":"EXCEL Import","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","copy":"Copy","pass":"Check","onApiEdit":"Api Edit","merge_user":"Merge User","merge_auto":"Merge Auto","cancel_auto":"Cancel Auto","save":"Save"},"forms":{"operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"actions":"操作","view":"查看","cn_category":"品类","cn_sub_category":"子类","aliexpress_sku":"速卖通货号","basic_sku":"基础SKU","aliexpress_stock":"速卖通库存","auto_state":"托管状态","basic_odoo_stock":"基础货号库存","basic_related_qty":"对应基础数量","compute_time":"计算库存时间","critical_value":"临界值","from_value":"From值","id":"ID","import_time":"导入时间","last_write_back_value":"上次写回值","merge_user":"托管用户","odoo_stock":"Odoo库存","pull_off_value":"下架值","seller_name":"店铺","sku_id":"SkuID","sku_price":"产品售价","country":"发货地","to_value":"To值","write_back_time":"写回时间","write_back_value":"写回值"},"action":{"create":"新建","batch-create":"EXCEL导入","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","copy":"复制","pass":"审核","onApiEdit":"api接口管理","merge_user":"认领Listing","merge_auto":"标记托管","cancel_auto":"取消托管","save":"保存"},"forms":{"operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "3258":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sku_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1ec1");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sku_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sku_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sku_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "366e":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"import_time":"Import Time","compute_time":"Compute Time","write_back_time":"Write Back Time","amazon_sku":"Amazon Sku","amazon_asin":"Amazon Asin","amazon_price":"Amazon Price","instance_id":"Instance ID","user_id":"User ID","basic_product_sku":"Basic Product SKU","basic_related_qty":"Basic Related Qty","category":"Category","sub_category":"Sub category","basic_odoo_stock":"Basic Odoo Stock","amazon_stock":"Amazon Stock","odoo_stock":"Odoo Stock","critical_value":"Critical Value","from_value":"From Value","to_value":"To value","pull_off_value":"Pull off value","write_back_value":"Write Back Value","history_write_back_value":"History WB","auto_state":"Auto State","warehouse":"Warehouse","average_sale_num":"Average Sale Num"},"action":{"merge_user":"Merge User","merge_auto":"Merge Auto","cancel_auto":"Cancel Auto","edit":"Edit","save":"Save"},"delete":"Are you sure delete?","save_success":"Save Success","delete_success":"Delete Success","yes":"Yes","no":"No"},"zh-cn":{"desc":"","columns":{"import_time":"导入时间","compute_time":"计算时间","write_back_time":"写回时间","amazon_sku":"Amazon SKU","amazon_asin":"Asin","amazon_price":"售价","instance_id":"Instance","user_id":"用户","basic_product_sku":"基础SKU","basic_related_qty":"基础数量","category":"分类","sub_category":"子类","basic_odoo_stock":"基础库存","amazon_stock":"Amazon库存","odoo_stock":"Odoo库存","critical_value":"临界值","from_value":"From值","to_value":"To值","pull_off_value":"下架值","write_back_value":"写回值","history_write_back_value":"历史写回值","auto_state":"托管状态","warehouse":"仓库","average_sale_num":"平均销量"},"action":{"merge_user":"认领Listing","merge_auto":"标记托管","cancel_auto":"取消托管","edit":"编辑","save":"保存"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","yes":"是","no":"否"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "38c4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/requirement-schedule-reference.vue?vue&type=template&id=4cdcc32d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"showHeader":false,"actions":true},on:{"submit":_vm.getTicketsList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],style:({ width: '300px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.sku_list')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sku_list']),expression:"['sku_list']"}],style:({ width: '300px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.dept_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'dept_id',
                        {
                            initialValue: ''
                        }
                    ]),expression:"[\n                        'dept_id',\n                        {\n                            initialValue: ''\n                        }\n                    ]"}],style:({ width: '300px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.departmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.give_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['give_date']),expression:"['give_date']"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"show-time":"","size":"small","format":"YYYY-MM-DD HH:mm"}})],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex"},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 1500, y: 400 }},on:{"on-page-change":_vm.getTicketsList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"sku_list",fn:function(text, row){return [_c('a-tooltip',{scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.sku_list)+" ")]}}],null,true)},[_c('span',{attrs:{"title":row.sku_list}},[_vm._v(" "+_vm._s(row.sku_list ? row.sku_list.length > 41 ? row.sku_list.substr(0, 38) + '...' : row.sku_list : '')+" ")])])]}},{key:"dept_id",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getDeptName(text)))])]}}],null,false,1910453637)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"sku_list",fn:function(text, row){return [_c('a-tooltip',{scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.sku_list)+" ")]}}],null,true)},[_c('span',{attrs:{"title":row.sku_list}},[_vm._v(" "+_vm._s(row.sku_list ? row.sku_list.length > 41 ? row.sku_list.substr(0, 38) + '...' : row.sku_list : '')+" ")])])]}},{key:"dept_id",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getDeptName(text)))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/requirement-schedule-reference.vue?vue&type=template&id=4cdcc32d&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/services/user.service.ts
var user_service = __webpack_require__("2138");

// EXTERNAL MODULE: ./src/services/mail.service.ts
var mail_service = __webpack_require__("e342");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/requirement-schedule-reference.vue?vue&type=script&lang=ts&






















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var requirement_schedule_referencevue_type_script_lang_ts_RequirementScheduleReference =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](RequirementScheduleReference, _super);

  function RequirementScheduleReference() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */](); // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.customerServiceUser = [];
    _this.customerServiceUserDict = {};
    _this.sellerCodeList = [];
    _this.siteList = [];
    _this.ticketType = [];
    _this.ticketDict = {};
    _this.userService = new user_service["a" /* UserService */]();
    _this.mailService = new mail_service["a" /* MailService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.detail = '';
    _this.orderBy = ''; //分组相关变量

    _this.groupbyList = [];
    _this.columnList = [];
    _this.allNameAuth = [];
    _this.queryUrl = 'product_management/query_all_requirement_schedule_reference';
    return _this;
  }

  RequirementScheduleReference.prototype.created = function () {
    this.getDepartmentList();
  };

  RequirementScheduleReference.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  RequirementScheduleReference.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  RequirementScheduleReference.prototype.getTicketsList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        name: 'like',
        sku_list: 'like'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0])
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1])
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  RequirementScheduleReference.prototype.getCustomerServiceUserList = function () {
    var _this = this;

    this.userService.customerServiceUser(new http["RequestParams"]({})).subscribe(function (data) {
      _this.customerServiceUser = data;

      for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
        var i = data_1[_i];
        _this.customerServiceUserDict[i.code] = i.name;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  RequirementScheduleReference.prototype.getSellerNameList = function () {
    var _this = this;

    this.mailService.queryTicketSellerName(new http["RequestParams"]({})).subscribe(function (data) {
      _this.sellerCodeList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  RequirementScheduleReference.prototype.update_requirement_schedule_state = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/update_requirement_schedule_state', common_service["a" /* CommonService */].getMenuCode('product-purchase-schedual'));
    this.publicService.modify(new http["RequestParams"]({
      schedule_id_list: this.selectedRowKeys,
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.getTicketsList();

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  RequirementScheduleReference.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getTicketsList();
  };

  RequirementScheduleReference.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  RequirementScheduleReference.prototype.getDeptName = function (id) {
    var ret = '';
    var item = this.departmentList.find(function (x) {
      return x.id === id;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], RequirementScheduleReference.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], RequirementScheduleReference.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], RequirementScheduleReference.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], RequirementScheduleReference.prototype, "getDepartmentList", void 0);

  RequirementScheduleReference = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'requirement-schedule-reference'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], RequirementScheduleReference);
  return RequirementScheduleReference;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var requirement_schedule_referencevue_type_script_lang_ts_ = (requirement_schedule_referencevue_type_script_lang_ts_RequirementScheduleReference);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/requirement-schedule-reference.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_requirement_schedule_referencevue_type_script_lang_ts_ = (requirement_schedule_referencevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/PurchasePredict/requirement-schedule-reference.vue?vue&type=style&index=0&lang=css&
var requirement_schedule_referencevue_type_style_index_0_lang_css_ = __webpack_require__("ceb5");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/requirement-schedule-reference.vue?vue&type=custom&index=0&blockType=i18n
var requirement_schedule_referencevue_type_custom_index_0_blockType_i18n = __webpack_require__("c630");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/requirement-schedule-reference.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_requirement_schedule_referencevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof requirement_schedule_referencevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(requirement_schedule_referencevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var requirement_schedule_reference = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "474d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"amazon_sku":"sku","cn_category":"Chinese Category","cn_sub_category":"Chinese Sub Category","product_price_sku":"product price sku","state":"state","warning_state":"warning state","active_state":"active state","merge_user_id":"merge user","import_time":"Import Time","merge_time":"merge time","write_back_time":"Write Back Time","amazon_asin":"Amazon Asin","amazon_type":"amazon type","standard_price":"standard price","business_price":"business price","instance_id":"Instance ID","product_price":"product price","product_related_qty":"product related qty","write_standard_price":"write standard price","write_discount_price":"write discount price","discount_start":"discount start","discount_end":"discount end","compute_time":"Compute Time","amazon_price":"Amazon Price","user_id":"User ID","basic_product_sku":"Basic Product SKU","basic_related_qty":"Basic Related Qty","category":"Category","sub_category":"Sub category","basic_odoo_stock":"Basic Odoo Stock","amazon_stock":"Amazon Stock","odoo_stock":"Odoo Stock","critical_value":"Critical Value","from_value":"From Value","to_value":"To value","pull_off_value":"Pull off value","write_back_value":"Write Back Value","history_write_back_value":"History WB","auto_state":"Auto State","warehouse":"Warehouse","average_sale_num":"Average Sale Num"},"dict":{"all":"All","draft":"Draft","lower_warning":"lower Warning","upper_warning":"upper warning","safe":"safe","active":"active","inactive":"inactive","need_merge":"need merge","merged":"merged","write_back":"write back"},"action":{"actions":"actions","create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","save":"Save","cancel":"Cancel","confirm":"Confirm","export":"Export Excel","import":"Import Excel","view_logs":"Logs","more":"More","discard":"discard","showlog":"View Log","merge_user":"Merge User","merge_auto":"Merge Auto","cancel_auto":"Cancel Auto","getBaseProductInfo":"Get BP Info","getProductPrice":"Get Product Price","computeNeedMerge":"Compute Need Merge","writeBackPrice":"Write Back Price","writeBackInventory":"Write Back Stock","excel_import":"Upload Excel"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"amazon_sku":"亚马逊sku","cn_category":"中文分类","cn_sub_category":"中文子类","product_price_sku":"有核价产品","state":"状态","warning_state":"预警状态","active_state":"监听状态","merge_user_id":"标记管理人","import_time":"导入时间","merge_time":"标记时间","write_back_time":"写回时间","amazon_asin":"Asin","amazon_type":"亚马逊类型","standard_price":"正常价格","business_price":"business价格","instance_id":"Instance","product_price":"核价产品价格","product_related_qty":"亚马逊产品和核价产品数量对应关系","write_standard_price":"需回写标准价格","write_discount_price":"需回写折扣价格","discount_start":"折扣开始时间","discount_end":"折扣结束时间","compute_time":"计算时间","amazon_price":"售价","user_id":"用户","basic_product_sku":"基础SKU","basic_related_qty":"基础数量","category":"分类","sub_category":"子类","basic_odoo_stock":"基础库存","amazon_stock":"Amazon库存","odoo_stock":"Odoo库存","critical_value":"临界值","from_value":"From值","to_value":"To值","pull_off_value":"下架值","write_back_value":"写回值","history_write_back_value":"历史写回值","auto_state":"托管状态","warehouse":"仓库","average_sale_num":"平均销量"},"dict":{"all":"全部","draft":"草稿","lower_warning":"低价预警","upper_warning":"高价预警","safe":"安全","active":"激活","inactive":"未激活","need_merge":"需标记","merged":"已标记","write_back":"回写价格"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"action":{"actions":"手动操作","create":"新建","edit":"编辑","delete":"删除","ok":"确定","save":"保存","cancel":"取消","confirm":"确认","export":"导出Excel","import":"导入Excel","view_logs":"日志","more":"更多操作","discard":"丢弃","showlog":"查看日志","merge_user":"标注用户","merge_auto":"标记托管","cancel_auto":"取消托管","getBaseProductInfo":"获取基础产品信息","getProductPrice":"获取产品价格","computeNeedMerge":"标记需要预警产品","writeBackPrice":"回写价格","writeBackInventory":"回写库存","excel_import":"上传"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "4839":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-schedual.vue?vue&type=template&id=11b9b3a7&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onCreateSaleTrend}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")])]},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2},on:{"submit":_vm.getProductPurchaseSchedualList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sku']),expression:"['sku']"}],style:({ width: '300px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category']),expression:"['z_sub_category']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.operator')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator', { initialValue: '' }]),expression:"['operator', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_name', { initialValue: '' }]),expression:"['vendor_name', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.dept_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'dept_id',
                        {
                            initialValue: ''
                        }
                    ]),expression:"[\n                        'dept_id',\n                        {\n                            initialValue: ''\n                        }\n                    ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.departmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.create_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['create_date']),expression:"['create_date']"}],attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['status', { initialValue: '' }]),expression:"['status', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"10"}},[_vm._v(_vm._s(_vm.$t('forms.draft'))+" ")]),_c('a-radio-button',{attrs:{"value":"20"}},[_vm._v(" 采购提交 ")]),_c('a-radio-button',{attrs:{"value":"30"}},[_vm._v(" 库管提交 ")]),_c('a-radio-button',{attrs:{"value":"40"}},[_vm._v(" 运营提交 ")]),_c('a-radio-button',{attrs:{"value":"50"}},[_vm._v(" 完成 ")]),_c('a-radio-button',{attrs:{"value":"100"}},[_vm._v(" 退回 ")])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.needSaveNotes.length},on:{"click":_vm.changeNote}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.update_requirement_schedule_state(30)}}},[_vm._v(_vm._s(_vm.$t('action.update_requirement_schedule_state_20'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.update_requirement_schedule_state(40)}}},[_vm._v(_vm._s(_vm.$t('action.update_requirement_schedule_state_30'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y"},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.schedualData,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 1500, y: 400 }},on:{"on-page-change":_vm.getProductPurchaseSchedualList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onTrClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"schedual_available_qty",fn:function(row){return _c('span',{},[_vm._v(" "+_vm._s(row.unfinish_qty - row.factory_finish_qty)+" ")])}},{key:"increase_ratio_text",fn:function(row){return _c('span',{},[_vm._v(" "+_vm._s(row.increase_ratio_text ? row.increase_ratio_text.length > 17 ? row.increase_ratio_text.substr(0, 17) + '...' : row.increase_ratio_text : ''))])}},{key:"status",fn:function(text, row){return _c('span',{},[_vm._v(_vm._s(_vm._f("dict2")(row.status,_vm.stateList))+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"stock_schedule_qty",fn:function(text, row){return [(_vm.editRow.id == row.id && row.status == 20)?_c('a-input-number',{attrs:{"size":"small","value":row.stock_schedule_qty,"min":0},on:{"change":function (e) { return _vm.onRowChange(e, row, 'stock_schedule_qty'); }}}):_c('span',[_vm._v(_vm._s(row.stock_schedule_qty))])]}},{key:"sales_schedule_qty",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                [30, 100].includes(row.status)
                        )?_c('a-input-number',{attrs:{"size":"small","value":row.sales_schedule_qty,"min":0},on:{"change":function (e) { return _vm.onRowChange(e, row, 'sales_schedule_qty'); }}}):_c('span',[_vm._v(_vm._s(row.sales_schedule_qty))])]}},{key:"dept_id",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getDeptName(text)))])]}}],null,false,655785152)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"schedual_available_qty",fn:function(row){return _c('span',{},[_vm._v(" "+_vm._s(row.unfinish_qty - row.factory_finish_qty)+" ")])}},{key:"increase_ratio_text",fn:function(row){return _c('span',{},[_vm._v(" "+_vm._s(row.increase_ratio_text ? row.increase_ratio_text.length > 17 ? row.increase_ratio_text.substr(0, 17) + '...' : row.increase_ratio_text : ''))])}},{key:"status",fn:function(text, row){return _c('span',{},[_vm._v(_vm._s(_vm._f("dict2")(row.status,_vm.stateList))+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"stock_schedule_qty",fn:function(text, row){return [(_vm.editRow.id == row.id && row.status == 20)?_c('a-input-number',{attrs:{"size":"small","value":row.stock_schedule_qty,"min":0},on:{"change":function (e) { return _vm.onRowChange(e, row, 'stock_schedule_qty'); }}}):_c('span',[_vm._v(_vm._s(row.stock_schedule_qty))])]}},{key:"sales_schedule_qty",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            [30, 100].includes(row.status)
                    )?_c('a-input-number',{attrs:{"size":"small","value":row.sales_schedule_qty,"min":0},on:{"change":function (e) { return _vm.onRowChange(e, row, 'sales_schedule_qty'); }}}):_c('span',[_vm._v(_vm._s(row.sales_schedule_qty))])]}},{key:"dept_id",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getDeptName(text)))])]}}])})],1),(_vm.show_log_view)?_c('a-card',[_c('LogView',{attrs:{"object_name":_vm.object_name,"record_code":_vm.record_code}})],1):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-schedual.vue?vue&type=template&id=11b9b3a7&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/product.purchase.service.ts
var product_purchase_service = __webpack_require__("b27d");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-schedual.vue?vue&type=script&lang=ts&

























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_purchase_schedualvue_type_script_lang_ts_ProductPurchaseSchedual =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPurchaseSchedual, _super);

  function ProductPurchaseSchedual() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = []; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.vender_data = []; // 表格数据源

    _this.schedualData = [];
    _this.selectedRows = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.orderBy = '';
    _this.show_log_view = false;
    _this.object_name = 'purchase_requirement_schedule_list';
    _this.record_code = 0;
    _this.need_save_data_list = [];
    _this.editRow = {
      id: null
    };
    _this.productPurchaseService = new product_purchase_service["a" /* ProductPurchaseService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.groupbyList = [];
    _this.allNameAuth = [];
    _this.columnList = [];
    _this.queryUrl = 'product_management/query_all_requirement_schedule';
    _this.stateList = [{
      code: 10,
      name: '草稿'
    }, {
      code: 20,
      name: '采购提交'
    }, {
      code: 30,
      name: '库管提交'
    }, {
      code: 40,
      name: '运营提交'
    }, {
      code: 50,
      name: '完成'
    }, {
      code: 100,
      name: '退回'
    }];
    _this.needSaveNotes = [];
    return _this;
  }

  ProductPurchaseSchedual.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  ProductPurchaseSchedual.prototype.created = function () {
    var _this = this;

    this.getSystemuser();
    this.getDepartmentList();
    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPurchaseSchedual.prototype.onRowClick = function (row) {
    var info = this.schedualData.find(function (x) {
      return x.id === row;
    });
    this.editRow = {
      id: row
    };
    this.record_code = row;
  };

  ProductPurchaseSchedual.prototype.getProductPurchaseSchedualList = function () {
    return tslib_es6["b" /* __awaiter */](this, void 0, void 0, function () {
      var dft_1, result;

      var _this = this;

      return tslib_es6["e" /* __generator */](this, function (_a) {
        switch (_a.label) {
          case 0:
            if (!(this.need_save_data_list.length > 0)) return [3
            /*break*/
            , 2];
            dft_1 = '';
            return [4
            /*yield*/
            , new Promise(function (reslove, reject) {
              _this.$confirm({
                parentContext: dft_1,
                title: '存在未保存数据，确定要查询吗？',
                onOk: function onOk() {
                  return reslove(true);
                },
                onCancel: function onCancel() {
                  return reslove(false);
                }
              });
            })];

          case 1:
            result = _a.sent();

            if (!result) {
              return [2
              /*return*/
              ];
            }

            _a.label = 2;

          case 2:
            this.dataForm.validateFields().then(function (values) {
              if (values['vendor_name'] == '' || values['vendor_name'].length == 0) {
                delete values['vendor_name'];
              }

              var params = common_service["a" /* CommonService */].createQueryCondition(values, {
                sku: 'like',
                warehouse_id: '=',
                operate: '=',
                status: '=',
                z_sub_category: 'like',
                vendor_name: 'in'
              });
              var nowConditions = [];

              for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
                var item = _a[_i];

                if (item.value.constructor == Array && item.operate !== 'in') {
                  if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
                    var startDate = {};

                    for (var key in item.value[0]) {
                      startDate[key] = item.value[0][key];
                    }

                    var vle = new Date(startDate.utc());
                    nowConditions.push({
                      query_name: item.query_name,
                      operate: '>=',
                      value: vle
                    });
                  }

                  if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
                    var endDate = {};

                    for (var key in item.value[1]) {
                      endDate[key] = item.value[1][key];
                    }

                    var vle = new Date(endDate.utc());
                    nowConditions.push({
                      query_name: item.query_name,
                      operate: '<=',
                      value: vle
                    });
                  }
                } else {
                  nowConditions.push(item);
                }
              }

              if (_this.groupbyList.length) {
                var groupbyTable = _this.$refs.groupbyTable;
                groupbyTable.getFirstTableData(nowConditions);
              } else {
                params.query_condition = nowConditions;

                if (_this.orderBy) {
                  params['order_by'] = _this.orderBy;
                }

                _this.innerAction.setActionAPI('product_management/query_all_requirement_schedule', common_service["a" /* CommonService */].getMenuCode());

                _this.publicService.queryPagination(new http["RequestParams"](params, {
                  page: _this.pageService,
                  loading: _this.loadingService,
                  innerAction: _this.innerAction
                })).subscribe(function (data) {
                  _this.schedualData = data;
                  _this.editRow = {
                    id: null
                  };
                  _this.need_save_data_list = [];
                }, function (err) {
                  _this.$message.error(err.message);
                });
              }
            }).catch(function (err) {// 异常处理
            });
            return [2
            /*return*/
            ];
        }
      });
    });
  };

  ProductPurchaseSchedual.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getProductPurchaseSchedualList();
  };

  ProductPurchaseSchedual.prototype.onTrClick = function (id) {
    var info = this.schedualData.find(function (x) {
      return x.id === id;
    });
    this.selectedRowKeys = [info.id];
    this.editRow = {
      id: info.id
    };
    this.record_code = id;
  };

  ProductPurchaseSchedual.prototype.getEditTextChangedStyle = function (row, column) {
    if (column == 'schedule_qty') {
      if (row.hasOwnProperty(column + '_changed')) {
        return 'text-align:right;background-color:yellow;font-weight:bolder';
      }

      return 'text-align:right';
    }

    if (column == 'sales_schedule_qty') {
      if (row.hasOwnProperty(column + '_changed')) {
        return 'text-align:right;background-color:yellow;font-weight:bolder';
      }

      return 'text-align:right';
    }

    return 'text-align:right';
  };

  ProductPurchaseSchedual.prototype.confirm_schedual = function () {
    // for (var id in this.selectedRowKeys) {
    //     let info = this.schedualData.find(x => x.id === id)
    var _this = this; //     if (info.status != 10) {
    //         this.$message.error(info.sku + '为非草稿状态')
    //         return
    //     }
    // }


    this.productPurchaseService.confirm_requirement_schedule(new http["RequestParams"]({
      schedule_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPurchaseSchedual.prototype.update_requirement_schedule_state = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/update_requirement_schedule_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      schedule_id_list: this.selectedRowKeys,
      status: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.getProductPurchaseSchedualList();

      _this.selectedRowKeys = [];

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPurchaseSchedual.prototype.cancel_schedual = function () {
    // for (var id in this.selectedRowKeys) {
    //     let info = this.schedualData.find(x => x.id === id)
    var _this = this; //     if (info.status != 10) {
    //         this.$message.error(info.sku + '为非草稿状态')
    //         return
    //     }
    // }


    this.productPurchaseService.cancel_requirement_schedule(new http["RequestParams"]({
      schedule_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPurchaseSchedual.prototype.export_schedual = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/product_purchase/export_requirement_schedule?schedule_id_list=' + urlParams);
  };

  ProductPurchaseSchedual.prototype.save_changed_data = function () {
    var _this = this;

    if (this.need_save_data_list.length == 0) {
      this.$message.info('没有需要保存的数据。');
      return;
    }

    this.productPurchaseService.change_requirement_schedule_qty(new http["RequestParams"]({
      change_schedule_data_list: this.need_save_data_list
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      for (var index in _this.need_save_data_list) {
        var item = _this.need_save_data_list[index];

        var obj = _this.schedualData.find(function (x) {
          return x.id === item.id;
        });

        if (obj && obj.hasOwnProperty('schedule_qty_changed')) {
          delete obj.schedule_qty_changed;
        }

        if (obj && obj.hasOwnProperty('sales_schedule_qty_changed')) {
          delete obj.sales_schedule_qty_changed;
        }
      }

      _this.need_save_data_list = [];

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  ProductPurchaseSchedual.prototype.onRowChange = function (e, row, column) {
    row[column] = e;
    var item = this.needSaveNotes.find(function (x) {
      return x.id == row.id;
    });

    if (item) {
      item[column] = e;
    } else {
      var note = {
        id: row.id,
        save_flag: 1
      };
      note[column] = e;
      this.needSaveNotes.push(note);
    }
  };

  ProductPurchaseSchedual.prototype.changeNote = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/update_requirement_schedule_qty', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      schedule_list: this.needSaveNotes
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  }; // private handleChange(target, row, column) {
  //     var value = target.value
  //     var reg = new RegExp('^[0-9]*$')
  //     if (value != '') {
  //         if (!reg.test(value)) {
  //             this.$message.info('请输入数字!')
  //             return
  //         }
  //     } else {
  //         this.$message.info('请输入数字!')
  //         return
  //     }
  //     var new_value = Number(value)
  //     var max_value = row.unfinish_qty - row.factory_finish_qty
  //     if (max_value < new_value) {
  //         this.$message.info('最多只能输入' + max_value)
  //         return
  //     }
  //     if (row[column] != value) {
  //         row[column] = new_value
  //         if (column == 'schedule_qty') {
  //             row.schedule_qty_changed = true
  //             var exists_item_1 = this.need_save_data_list.find(
  //                 x => x.id == row.id
  //             )
  //             if (exists_item_1) {
  //                 exists_item_1['schedule_qty'] = new_value
  //             } else {
  //                 this.need_save_data_list.push({
  //                     id: row.id,
  //                     schedule_qty: new_value
  //                 })
  //             }
  //         } else if (column == 'sales_schedule_qty') {
  //             row.sales_schedule_qty_changed = true
  //             var exists_item_2 = this.need_save_data_list.find(
  //                 x => x.id == row.id
  //             )
  //             if (exists_item_2) {
  //                 exists_item_2['sales_schedule_qty'] = new_value
  //             } else {
  //                 this.need_save_data_list.push({
  //                     id: row.id,
  //                     sales_schedule_qty: new_value
  //                 })
  //             }
  //         }
  //     }
  //     let newdata = {
  //         ...this.editRow
  //     }
  //     newdata[column] = value
  //     this.editRow = newdata
  // }


  ProductPurchaseSchedual.prototype.view_logs = function (row) {
    this.show_log_view = !this.show_log_view;
  };

  ProductPurchaseSchedual.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductPurchaseSchedual.prototype.calculate_increase_ratio = function () {
    var _this = this;

    if (this.selectedRowKeys.length == 0) {
      this.$message.info('请选择需要计算的行。');
      return;
    }

    this.productPurchaseService.calculate_category_increase_ratio(new http["RequestParams"]({
      calculate_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.getProductPurchaseSchedualList();
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  ProductPurchaseSchedual.prototype.getDeptName = function (id) {
    var ret = '';
    var item = this.departmentList.find(function (x) {
      return x.id === id;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductPurchaseSchedual.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductPurchaseSchedual.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPurchaseSchedual.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPurchaseSchedual.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPurchaseSchedual.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPurchaseSchedual.prototype, "getDepartmentList", void 0);

  ProductPurchaseSchedual = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-purchase-schedual'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */],
      UploadExcel: upload_excel["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ProductPurchaseSchedual);
  return ProductPurchaseSchedual;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_purchase_schedualvue_type_script_lang_ts_ = (product_purchase_schedualvue_type_script_lang_ts_ProductPurchaseSchedual);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-schedual.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_product_purchase_schedualvue_type_script_lang_ts_ = (product_purchase_schedualvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/product-purchase-schedual.vue?vue&type=custom&index=0&blockType=i18n
var product_purchase_schedualvue_type_custom_index_0_blockType_i18n = __webpack_require__("be50");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-schedual.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_product_purchase_schedualvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_purchase_schedualvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_purchase_schedualvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_purchase_schedual = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "5062":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_price_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eb60");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_price_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_price_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "5114":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":""},"zh-cn":{"desc":""}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "5741":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1"},"zh-cn":{"desc":"这是订单页面1"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "5c98":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"name":"Name","give_date":"give_date","sku_list":"sku_list","dept_id":"Department"},"form":{"status":"Status","customer_code":"Customer Code","company_name":"Company Name","contract_start":"Contract Start Date","remote_file_name":"Router url","contract_end":"Contract End Date","female":"Female","field":"Field"},"action":{"update_requirement_schedule_state_purchase":"Purchase Submit","update_requirement_schedule_state_back":"Back","update_requirement_schedule_state_done":"Done"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","yes":"Yes","no":"No"},"zh-cn":{"desc":"这是订单页面1","columns":{"name":"名称","give_date":"交期","sku_list":"SKU列表","dept_id":"部门"},"form":{"status":"状态","customer_code":"客户编号","company_name":"公司名称","contract_start":"合同开始日期","contract_end":"合同结束日期","field":"字段"},"action":{"update_requirement_schedule_state_purchase":"采购提交","update_requirement_schedule_state_back":"退回","update_requirement_schedule_state_done":"完成"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","yes":"是","no":"否"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "5de6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_invoice_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5741");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_invoice_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_invoice_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_invoice_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "5fb1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_pre_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("dff1");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_pre_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_pre_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_pre_sale_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "69b2a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-pre-sale.vue?vue&type=template&id=55c5f3dc&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",on:{"changeSearchState":_vm.showHideSearch},scopedSlots:_vm._u([{key:"header-action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onCreateSaleTrend}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")])]},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":1,"showSearch":_vm.showSearch},on:{"submit":_vm.getPreSaleList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.presale_type')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['presale_type', { initialValue: '' }]),expression:"['presale_type', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PresaleType),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.presale_object')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['presale_object']),expression:"['presale_object']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"pre_sale"},on:{"on-page-change":_vm.getPreSaleList}},[_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('columns.actions'),"width":"12%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.OnEdit(row)}}},[_vm._v(_vm._s(_vm.$t('action.edit')))]),_c('a',{staticStyle:{"float":"right","margin-right":"15px"},on:{"click":function($event){return _vm.OnCopy(row)}}},[_vm._v(_vm._s(_vm.$t('action.copy')))])]}}])}),_c('a-table-column',{key:"presale_object",attrs:{"title":_vm.$t('columns.presale_object'),"data-index":"presale_object","width":"7%","align":"center"}}),_c('a-table-column',{key:"presale_type",attrs:{"title":_vm.$t('columns.presale_type'),"width":"7%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.presale_type,'PresaleType')))+" ")]}}])}),_c('a-table-column',{key:"warehouse_id",attrs:{"title":_vm.$t('columns.warehouse_id'),"data-index":"warehouse_id","width":"7%","align":"center"}}),_c('a-table-column',{key:"is_presale",attrs:{"title":_vm.$t('columns.is_presale'),"width":"7%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.is_presale)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}}])}),_c('a-table-column',{key:"is_second_presale",attrs:{"title":_vm.$t('columns.is_second_presale'),"width":"7%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.is_second_presale)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}}])}),_c('a-table-column',{key:"presale_ratio",attrs:{"title":_vm.$t('columns.presale_ratio'),"data-index":"presale_ratio","width":"7%","align":"center"}}),_c('a-table-column',{key:"presale_days",attrs:{"title":_vm.$t('columns.presale_days'),"data-index":"presale_days","width":"7%","align":"center"}}),_c('a-table-column',{key:"purchase_cycle",attrs:{"title":_vm.$t('columns.purchase_cycle'),"data-index":"purchase_cycle","width":"7%","align":"center"}}),_c('a-table-column',{key:"sale_cycle",attrs:{"title":_vm.$t('columns.sale_cycle'),"data-index":"sale_cycle","width":"7%","align":"center"}}),_c('a-table-column',{key:"department",attrs:{"title":_vm.$t('columns.department'),"data-index":"department","width":"7%","align":"center"}}),_c('a-table-column',{key:"operator",attrs:{"title":_vm.$t('columns.operator'),"data-index":"operator","width":"7%","align":"center"}}),_c('a-table-column',{key:"z_sub_category",attrs:{"title":_vm.$t('columns.z_sub_category'),"data-index":"z_sub_category","width":"7%","align":"center"}})],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-pre-sale.vue?vue&type=template&id=55c5f3dc&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/product/pre-sale-edit.vue + 4 modules
var pre_sale_edit = __webpack_require__("0b7d");

// EXTERNAL MODULE: ./src/services/presale.service.ts
var presale_service = __webpack_require__("d4a0");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-pre-sale.vue?vue&type=script&lang=ts&












var product_pre_salevue_type_script_lang_ts_ProductPreSale =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPreSale, _super);

  function ProductPreSale() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.showSearch = true; // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.orderBy = '';
    _this.preSaleService = new presale_service["a" /* PreSaleService */]();
    _this.product = [];
    _this.chartData1 = [];
    return _this;
  }

  ProductPreSale.prototype.showHideSearch = function (flag) {
    this.showSearch = flag;
  };
  /**
   * 获取销售趋势数据
   */


  ProductPreSale.prototype.getPreSaleList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        cn_sub_category: 'like'
      });

      if (_this.orderBy) {
        params['order_by'] = _this.orderBy;
      }

      _this.preSaleService.queryAll(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.data = data;
        _this.selectedRowKeys = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {// 异常处理
    });
  };

  ProductPreSale.prototype.onStatusChange = function (e) {
    this.$nextTick(function () {
      this.getPreSaleList();
    });
  };

  ProductPreSale.prototype.onCreateSaleTrend = function () {
    var _this = this;

    this.$modal.open(pre_sale_edit["a" /* default */], {
      saveFlag: 0
    }, {
      title: '新建产品预售数据'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getPreSaleList();
    });
  };

  ProductPreSale.prototype.OnEdit = function (row) {
    var _this = this;

    this.$modal.open(pre_sale_edit["a" /* default */], {
      saveFlag: 1,
      row: row
    }, {
      title: '编辑产品预售数据: ' + row.presale_object
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getPreSaleList();
    });
  };

  ProductPreSale.prototype.OnCopy = function (row) {
    var _this = this;

    this.$modal.open(pre_sale_edit["a" /* default */], {
      saveFlag: 0,
      row: row
    }, {
      title: '新建产品预售数据: ' + row.presale_object
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getPreSaleList();
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductPreSale.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductPreSale.prototype, "pageContainer", void 0);

  ProductPreSale = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-pre-sale'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      PreSaleEdit: pre_sale_edit["a" /* default */]
    }
  })], ProductPreSale);
  return ProductPreSale;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_pre_salevue_type_script_lang_ts_ = (product_pre_salevue_type_script_lang_ts_ProductPreSale);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-pre-sale.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_product_pre_salevue_type_script_lang_ts_ = (product_pre_salevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/product-pre-sale.vue?vue&type=custom&index=0&blockType=i18n
var product_pre_salevue_type_custom_index_0_blockType_i18n = __webpack_require__("5fb1");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-pre-sale.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_product_pre_salevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_pre_salevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_pre_salevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_pre_sale = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "6a4c":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","dict":{"all":"All","draft":"Draft","lower_warning":"lower Warning","upper_warning":"upper warning","safe":"safe","active":"active","inactive":"inactive","need_merge":"need merge","merged":"merged","write_back":"write back"},"columns":{"amazon_sku":"amazon sku","cn_category":"Chinese Category","cn_sub_category":"Chinese Sub Category","product_price_sku":"product price sku","state":"state","warning_state":"warning state","active_state":"active state","merge_user_id":"merge user","import_time":"import time","merge_time":"merge time","write_back_time":"write back time","amazon_asin":"amazon asin","amazon_type":"amazon type","standard_price":"standard price","business_price":"business price","instance_id":"instance","product_price":"product price","product_related_qty":"product related qty","write_standard_price":"write standard price","write_discount_price":"write discount price","discount_start":"discount start","discount_end":"discount end"},"action":{"mergeUser":"Merge User","import_btn":"Import","writeBackPrice":"Write Back Price","save":"Save","getBaseProductInfo":"Get BP Info","getProductPrice":"Get Product Price","computeNeedMerge":"Compute Need Merge","actions":"Actions"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","dict":{"all":"全部","draft":"草稿","lower_warning":"低价预警","upper_warning":"高价预警","safe":"安全","active":"激活","inactive":"未激活","need_merge":"需标记","merged":"已标记","write_back":"回写价格"},"columns":{"amazon_sku":"亚马逊sku","cn_category":"中文分类","cn_sub_category":"中文字类","product_price_sku":"有核价产品","state":"状态","warning_state":"预警状态","active_state":"监听状态","merge_user_id":"标记管理人","import_time":"导入时间","merge_time":"标记时间","write_back_time":"价格回写时间","amazon_asin":"亚马逊asin","amazon_type":"亚马逊类型","standard_price":"正常价格","business_price":"business价格","instance_id":"店铺","product_price":"核价产品价格","product_related_qty":"亚马逊产品和核价产品数量对应关系","write_standard_price":"需回写标准价格","write_discount_price":"需回写折扣价格","discount_start":"折扣开始时间","discount_end":"折扣结束时间"},"action":{"mergeUser":"标注用户","import_btn":"导入","writeBackPrice":"回写价格","save":"保存","getBaseProductInfo":"获取基础产品信息","getProductPrice":"获取产品价格","computeNeedMerge":"标记需要预警产品","actions":"手动执行"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "6a6c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5114");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "716c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_invoice_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2e79");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_invoice_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_invoice_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "7361":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/account-invoice.vue?vue&type=template&id=bfa2ad2a&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('data-form',{ref:"dataForm",attrs:{"extends":_vm.extendItems,"column":2},on:{"submit":_vm.getInvoiceList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.origin')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['origin']),expression:"['origin']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'number',
                        { initialValue: _vm.defaultNumber }
                    ]),expression:"[\n                        'number',\n                        { initialValue: defaultNumber }\n                    ]"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.ebay_buyer_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ebay_buyer_id']),expression:"['ebay_buyer_id']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.partner_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['partner_name']),expression:"['partner_name']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.seller_code')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['seller_code']),expression:"['seller_code']"}],style:({ width: '200px' }),attrs:{"mode":"tags","show-search":"","size":"small","placeholder":_vm.$t('plzSelect'),"filter-option":_vm.filterOption}},_vm._l((_vm.sellerCodeList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])}),1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.refund_memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['refund_memo']),expression:"['refund_memo']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.date_invoice')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'date_invoice',
                        { initialValue: _vm.initialDate }
                    ]),expression:"[\n                        'date_invoice',\n                        { initialValue: initialDate }\n                    ]"}],attrs:{"format":"YYYY-MM-DD HH:mm","size":"small"}}),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fillToday}},[_vm._v(_vm._s(_vm.$t('action.today'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fillYestoday}},[_vm._v(_vm._s(_vm.$t('action.yestoday'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fill3day}},[_vm._v(_vm._s(_vm.$t('action.3day'))+" ")])],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":_vm.selectedRowKeys.length != 1},on:{"click":_vm.sendInvoce}},[_vm._v(" "+_vm._s(_vm.$t('action.sendInvoce'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.downloadInvoce}},[_vm._v(" "+_vm._s(_vm.$t('action.downloadInvoce'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.flagRefunded}},[_vm._v(" "+_vm._s(_vm.$t('action.flag_refunded'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.exportAccountInvoice}},[_vm._v(" "+_vm._s(_vm.$t('action.export_account_invoice'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"id","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
            },"scroll":{ y: 420 }},on:{"on-page-change":_vm.getInvoiceList,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                    _vm.onTrClick(record)
                }}},[_c('a-table-column',{key:"partner_name",attrs:{"title":_vm.$t('columns.partner_name'),"data-index":"partner_name","align":"center"}}),_c('a-table-column',{key:"date_invoice",attrs:{"title":_vm.$t('columns.date_invoice'),"data-index":"date_invoice","align":"center"}}),_c('a-table-column',{key:"number",attrs:{"title":_vm.$t('columns.number'),"data-index":"number","align":"center"}}),_c('a-table-column',{key:"company_name",attrs:{"title":_vm.$t('columns.company_name'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{attrs:{"title":row.company_name}},[_vm._v(" "+_vm._s(row.company_name ? row.company_name.substr(0, 5) + '...' : '')+" ")])]}}])}),_c('a-table-column',{key:"user_name",attrs:{"title":_vm.$t('columns.user_name'),"data-index":"user_name","align":"left"}}),_c('a-table-column',{key:"create_user_name",attrs:{"title":_vm.$t('columns.create_user_name'),"data-index":"create_user_name","align":"left"}}),_c('a-table-column',{key:"date_due",attrs:{"title":_vm.$t('columns.date_due'),"data-index":"date_due","align":"center"}}),_c('a-table-column',{key:"origin",attrs:{"title":_vm.$t('columns.origin'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.toPageOrder(row.origin)}}},[_vm._v(_vm._s(row.origin))])]}}])}),_c('a-table-column',{key:"amount_total_signed",attrs:{"title":_vm.$t('columns.amount_total_signed'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.amount_total_signed.toFixed(2))+" ")]}}])}),_c('a-table-column',{key:"residual_signed",attrs:{"title":_vm.$t('columns.residual_signed'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.residual_signed.toFixed(2))+" ")]}}])}),_c('a-table-column',{key:"state",attrs:{"title":_vm.$t('columns.state'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-dropdown',[_c('a',{staticStyle:{"background":"none","color":"#1890ff"},on:{"click":function (e) { return e.preventDefault(); }}},[_vm._v(" "+_vm._s(row.state)+" "),_c('a-icon',{attrs:{"type":"down"}})],1),_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{key:"draft",attrs:{"disabled":row.state == 'draft' ||
                                        row.state == 'paid'},on:{"click":function($event){return _vm.changeState(row.id, 'draft', row.state)}}},[_vm._v(" Draft ")]),_c('a-menu-item',{key:"open",attrs:{"disabled":row.state == 'open' ||
                                        row.state == 'cancel'},on:{"click":function($event){return _vm.changeState(row.id, 'open', row.state)}}},[_c('span',[_vm._v("Open")])]),_c('a-menu-item',{key:"cancel",attrs:{"disabled":row.state == 'cancel' ||
                                        row.state == 'open' ||
                                        row.state == 'paid'},on:{"click":function($event){return _vm.changeState(row.id, 'cancel', row.state)}}},[_c('span',[_vm._v("Cancel")])]),_c('a-menu-item',{key:"paid",attrs:{"disabled":row.state == 'paid' ||
                                        row.state == 'cancel' ||
                                        row.state == 'draft'},on:{"click":function($event){return _vm.changeState(row.id, 'paid', row.state)}}},[_c('span',[_vm._v("paid")])])],1)],1)]}}])}),_c('a-table-column',{key:"payment_method",attrs:{"title":_vm.$t('columns.payment_method'),"data-index":"payment_method","align":"center"}}),_c('a-table-column',{key:"need_refund",attrs:{"title":_vm.$t('columns.need_refund'),"data-index":"need_refund","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(need_refund){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(need_refund))+" ")]}}])}),_c('a-table-column',{key:"refund_time",attrs:{"title":_vm.$t('columns.refund_time'),"data-index":"refund_time","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(refund_time){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(refund_time))+" ")]}}])}),_c('a-table-column',{key:"refund_memo",attrs:{"title":_vm.$t('columns.refund_memo'),"width":"8%","align":"left","ellipsis":"true"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{attrs:{"title":row.refund_memo}},[_vm._v(" "+_vm._s(row.refund_memo ? row.refund_memo.substr(0, 7) + '...' : '')+" ")])]}}])}),_c('a-table-column',{key:"order_refund_status",attrs:{"title":_vm.$t('columns.order_refund_status'),"data-index":"order_refund_status","align":"center"}}),_c('a-table-column',{key:"operator_message",attrs:{"title":_vm.$t('columns.operate_message'),"width":"8%","align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{attrs:{"title":row.operator_message}},[_vm._v(" "+_vm._s(row.operator_message ? row.operator_message.substr(0, 7) + '...' : '')+" ")])]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('columns.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onEdit(row)}}},[_vm._v(_vm._s(_vm.$t('action.edit'))+" ")]):_vm._e(),_c('a-menu-item',{on:{"click":function($event){return _vm.onChangeState(row)}}},[_vm._v(_vm._s(_vm.$t('action.change_state'))+" ")]),_c('a-menu-item',{on:{"click":function($event){return _vm.onDelete(row)}}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}])})],1)],1),(_vm.selectedRows[0])?_c('a-card',[[_c('section',{staticClass:"component customer-detail"},[_c('a-tabs',{attrs:{"defaultActiveKey":"invoice_detail"},model:{value:(_vm.activeKey),callback:function ($$v) {_vm.activeKey=$$v},expression:"activeKey"}},[_c('a-tab-pane',{key:"invoice_detail",attrs:{"tab":_vm.$t('invoice_detail')}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.invoice_detail,"pagination":false,"scroll":{ y: 300 },"bordered":""}},[_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('columns.default_code'),"align":"center","dataIndex":"default_code"}}),_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('columns.name'),"align":"center","dataIndex":"name"}}),_c('a-table-column',{key:"quantity",attrs:{"title":_vm.$t('columns.quantity'),"align":"center","dataIndex":"quantity"}}),_c('a-table-column',{key:"price_unit",attrs:{"title":_vm.$t('columns.price_unit'),"align":"center","dataIndex":"price_unit"}}),_c('a-table-column',{key:"account_tax_id",attrs:{"title":_vm.$t('columns.account_tax_id'),"align":"left","dataIndex":"account_tax_id"}})],1)],1),_c('a-tab-pane',{key:"log",attrs:{"tab":_vm.$t('log')}},[_c('LogView',{attrs:{"object_name":_vm.object_name,"record_code":_vm.record_code}})],1)],1)],1)]],2):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/accounts/account-invoice.vue?vue&type=template&id=bfa2ad2a&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__("a15b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/account.service.ts
var account_service = __webpack_require__("82e7");

// EXTERNAL MODULE: ./src/components/common/send-email.vue + 3 modules
var send_email = __webpack_require__("b390");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/components/account/change-state.vue + 4 modules
var change_state = __webpack_require__("bb34");

// EXTERNAL MODULE: ./src/services/seller-instance.service.ts
var seller_instance_service = __webpack_require__("5c97");

// EXTERNAL MODULE: ./src/shared/utils/xlsx.util.ts
var xlsx_util = __webpack_require__("771c");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/account-invoice.vue?vue&type=script&lang=ts&



























var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var account_invoicevue_type_script_lang_ts_AccountInvoice =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AccountInvoice, _super);

  function AccountInvoice() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.accountService = new account_service["a" /* AccountService */](); // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.sellerInstanceService = new seller_instance_service["a" /* SellerInstanceService */](); // 表格数据源

    _this.data = [];
    _this.showBtn = false; // 表格选择项

    _this.selectedRowKeys = []; // 详情项

    _this.detailInfo = null;
    _this.isShow = true;
    _this.defaultNumber = '';
    _this.moment = moment_default.a;
    _this.object_name = 'account_invoice';
    _this.initialDate = [];
    _this.sellerCodeList = [];
    _this.activeKey = 'invoice_detail';
    _this.invoice_detail = [];
    _this.record_code = '';
    _this.selectedRows = [];
    return _this;
  }

  Object.defineProperty(AccountInvoice.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });
  Object.defineProperty(AccountInvoice.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  AccountInvoice.prototype.onRouteChange = function (newRoute, oldRoute) {
    if (this.$route.params.number || this.$route.query.number) {
      var values = this.dataForm.getValues();

      if (this.$route.params.number) {
        values['number'] = this.$route.params.number;
      } else {
        values['number'] = this.$route.query.number;
      }

      this.dataForm.setValues(values);

      if (this.data.length === 0) {
        this.getInvoiceList();
      }
    }
  };

  AccountInvoice.prototype.created = function () {
    this.getcountry();
    this.getcurrency();
    this.getSellerCodeList();
  };

  AccountInvoice.prototype.mounted = function () {
    if (this.$route.params.number || this.$route.query.number) {
      if (this.$route.params.number) {
        this.defaultNumber = this.$route.params.number;
      } else {
        this.defaultNumber = this.$route.query.number;
      }

      var values = this.dataForm.getValues();
      values['number'] = this.defaultNumber;
      this.dataForm.setValues(values);
      this.getInvoiceList();
    }
  };

  AccountInvoice.prototype.onTrClick = function (record) {
    var info = this.data.find(function (x) {
      return x.id === record;
    });
    this.selectedRows = [info];
  };

  AccountInvoice.prototype.getSellerCodeList = function () {
    var _this = this;

    this.sellerInstanceService.query_seller_name(new http["RequestParams"]({})).subscribe(function (data) {
      _this.sellerCodeList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AccountInvoice.prototype.sendInvoce = function () {
    var _this = this;

    var row = this.data.find(function (x) {
      return x.id === _this.selectedRowKeys[0];
    });
    this.$modal.open(send_email["a" /* default */], {
      model: 'accountManage',
      recordID: row.id,
      data: {
        orderId: row.order_id,
        templateId: 5
      }
    }, {
      title: this.$t('actions.send_email'),
      width: '1000px'
    }).subscribe(function (data) {});
  };

  AccountInvoice.prototype.fillToday = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(day), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 24 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['date_invoice'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  AccountInvoice.prototype.fillYestoday = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(new Date(day.getTime() - 24 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 48 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['date_invoice'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  AccountInvoice.prototype.fill3day = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(new Date(day.getTime() - 48 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 72 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['date_invoice'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  AccountInvoice.prototype.formatDate = function (time) {
    // 空数据处理
    if (time === null || time === undefined || time === '') {
      return '';
    }

    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    var h = time.getHours();
    var mi = time.getMinutes();
    var s = time.getSeconds();
    m = m < 10 ? "0" + m : m;
    d = d < 10 ? "0" + d : d;
    h = h < 10 ? "0" + h : h;
    mi = mi < 10 ? "0" + mi : mi;
    s = s < 10 ? "0" + s : s;
    return y + "-" + m + "-" + d + " " + h + "\uFF1A" + mi;
  };
  /**
   * 获取账单数据
   */


  AccountInvoice.prototype.getInvoiceList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (values['seller_code'] && values['seller_code'].length > 0) {
        values['seller_code'] = values['seller_code'].join(',');
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        partner_name: 'like',
        refund_memo: 'like',
        number: 'in_or_=',
        origin: 'in_or_=',
        seller_code: 'in_or_=',
        ebay_buyer_id: 'in_or_='
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array) {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      params.query_condition = nowConditions;

      _this.accountService.getInvoiceList(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.data = data;

        if (!_this.record_code) {
          _this.record_code = data[0].id;
        }

        if (!_this.selectedRows[0]) {
          _this.selectedRows = [data[0]];
          _this.selectedRowKeys = [data[0].id];
        }
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  AccountInvoice.prototype.onselectedRowsChange = function () {
    this.invoice_detail = [];

    if (this.activeKey == 'invoice_detail') {
      this.getInvoiceDetail();
    } else {
      this.record_code = this.selectedRows[0].id;
    }
  };

  AccountInvoice.prototype.getInvoiceDetail = function () {
    var _this = this;

    this.accountService.getInvoiceDetail(new http["RequestParams"]({
      invoice_id: this.selectedRows[0].id
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.invoice_detail = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AccountInvoice.prototype.toPageOrder = function (origin) {
    router["a" /* default */].push({
      name: 'order-manage',
      params: {
        origin: origin
      }
    });
  };

  AccountInvoice.prototype.downloadInvoce = function () {
    var params = [];
    params = this.selectedRowKeys.map(function (code) {
      return code;
    });
    var urlParams = encodeURIComponent(JSON.stringify(params));
    window.open(app_config["a" /* default */].server + '/account/download_invoice_pdf?invoice_id_list=' + urlParams);
  };

  AccountInvoice.prototype.onEdit = function (row) {
    var _this = this;

    this.accountService.queryInvoiceDetailForEdit(new http["RequestParams"]({
      invoice_id: this.selectedRows[0].id
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.changeInvoice(data);

      router["a" /* default */].push({
        name: 'invoice-edit',
        params: {
          invoice: data
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AccountInvoice.prototype.onDelete = function (row) {
    var _this = this;

    this.accountService.deleteAccountInvoice(new http["RequestParams"]({
      invoice_id: this.selectedRows[0].id
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('删除成功');

      _this.data = _this.data.filter(function (x) {
        return x.id != row.id;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AccountInvoice.prototype.onChangeState = function (row) {
    var _this = this;

    this.$modal.open(change_state["a" /* default */], {
      invoice: {
        id: row.id,
        state: row.state
      }
    }, {
      title: this.$t('action.change_state')
    }).subscribe(function (data) {
      _this.accountService.changeInvoiceState(new http["RequestParams"]({
        id: row.id,
        state: data.state
      }, {
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.$message.success('操作成功');

        _this.getInvoiceList();
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  AccountInvoice.prototype.filterOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  AccountInvoice.prototype.flagRefunded = function () {
    var _this = this;

    this.accountService.updateRefundTime(new http["RequestParams"]({
      invoice_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.invoice_detail = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AccountInvoice.prototype.exportAccountInvoice = function () {
    var params = [];
    params = this.selectedRowKeys.map(function (code) {
      return code;
    });
    var urlParams = encodeURIComponent(JSON.stringify(params));
    window.open(app_config["a" /* default */].server + '/account/export_refund_orders?invoice_id_list=' + urlParams);
  };

  AccountInvoice.prototype.export22 = function () {
    var xlsxUtil = new xlsx_util["a" /* XLSXUtil */]();
    xlsxUtil.readFromJson({
      name: '预约用户名',
      phone: '预约手机号',
      // appointmentDate: '预约日期',
      state: '订单状态'
    }, this.data.map(function (x) {
      return {
        name: x.partner_name,
        phone: x.partner_name,
        // appointmentDate:
        //     x.refund_time.split(' ')[0] +
        //     '  ' +
        //     x.refund_time.split('-')[0],
        state: x.state
      };
    }), [20, 20, 20, 15]);
    xlsxUtil.exportFile('预约管理-234.xlsx');
  };

  AccountInvoice.prototype.changeState = function (id, state, oldState) {
    var _this = this;

    this.accountService.changeInvoiceState(new http["RequestParams"]({
      id: id,
      state: state,
      oldState: oldState
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getInvoiceList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], AccountInvoice.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], AccountInvoice.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AccountInvoice.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AccountInvoice.prototype, "getcountry", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AccountInvoice.prototype, "currencyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AccountInvoice.prototype, "getcurrency", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('changeInvoice'), tslib_es6["f" /* __metadata */]("design:type", Object)], AccountInvoice.prototype, "changeInvoice", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('$route'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object, Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AccountInvoice.prototype, "onRouteChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('selectedRows'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AccountInvoice.prototype, "onselectedRowsChange", null);

  AccountInvoice = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'account-invoice'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */]
    }
  })], AccountInvoice);
  return AccountInvoice;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var account_invoicevue_type_script_lang_ts_ = (account_invoicevue_type_script_lang_ts_AccountInvoice);
// CONCATENATED MODULE: ./src/pages/accounts/account-invoice.vue?vue&type=script&lang=ts&
 /* harmony default export */ var accounts_account_invoicevue_type_script_lang_ts_ = (account_invoicevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/accounts/account-invoice.vue?vue&type=custom&index=0&blockType=i18n
var account_invoicevue_type_custom_index_0_blockType_i18n = __webpack_require__("af79");

// CONCATENATED MODULE: ./src/pages/accounts/account-invoice.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  accounts_account_invoicevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof account_invoicevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(account_invoicevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var account_invoice = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "7834":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/aliexpress/aliexpress-instock-manage.vue?vue&type=template&id=11d33e68&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":1},on:{"submit":_vm.getInstockList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['type', { initialValue: 'basic_sku' }]),expression:"['type', { initialValue: 'basic_sku' }]"}],style:({ width: '100px' }),attrs:{"placeholder":_vm.$t('plzSelect'),"size":"small"}},[_c('a-select-option',{attrs:{"value":"basic_sku"}},[_vm._v(" "+_vm._s(_vm.$t('columns.basic_sku'))+" ")]),_c('a-select-option',{attrs:{"value":"aliexpress_sku"}},[_vm._v(" "+_vm._s(_vm.$t('columns.aliexpress_sku'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '240px', margin: '0 5px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator', { initialValue: 'ilike' }]),expression:"['operator', { initialValue: 'ilike' }]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"ilike"}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":"="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")]),_c('a-select-option',{attrs:{"value":"in"}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_list'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_category']),expression:"['cn_category']"}],staticStyle:{"width":"120px"},attrs:{"placeholder":"品类","size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1),_c('a-select',{staticStyle:{"width":"20%","margin-left":"5px"},attrs:{"mode":"multiple","placeholder":"子类","size":"small"},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.mergeUser()}}},[_vm._v(_vm._s(_vm.$t('action.merge_user'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.mergeAuto()}}},[_vm._v(_vm._s(_vm.$t('action.merge_auto'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.cancelAuto()}}},[_vm._v(_vm._s(_vm.$t('action.cancel_auto'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.save()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"id","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
            },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getInstockList,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                    _vm.onTrClick(record)
                }}},[_c('a-table-column',{key:"id",attrs:{"title":_vm.$t('columns.id'),"width":"4%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.id))]}}])}),_c('a-table-column',{key:"edit",attrs:{"title":_vm.$t('columns.actions'),"width":"5%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.editValue(row)}}},[_vm._v(_vm._s(_vm.$t('action.edit')))])]}}])}),_c('a-table-column',{key:"import_time",attrs:{"title":_vm.$t('columns.import_time'),"sorter":true,"width":"10%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.import_time))+" ")]}}])}),_c('a-table-column',{key:"compute_time",attrs:{"title":_vm.$t('columns.compute_time'),"sorter":true,"width":"10%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.compute_time))+" ")]}}])}),_c('a-table-column',{key:"write_back_time",attrs:{"title":_vm.$t('columns.write_back_time'),"sorter":true,"width":"10%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.write_back_time))+" ")]}}])}),_c('a-table-column',{key:"aliexpress_sku",attrs:{"title":_vm.$t('columns.aliexpress_sku'),"width":"8%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.aliexpress_sku)+" ")]}}])}),_c('a-table-column',{key:"sku_id'",attrs:{"title":_vm.$t('columns.sku_id'),"width":"8%","dataIndex":"sku_id","align":"center"}}),_c('a-table-column',{key:"country'",attrs:{"title":_vm.$t('columns.country'),"width":"8%","dataIndex":"country","align":"center"}}),_c('a-table-column',{key:"sku_price'",attrs:{"title":_vm.$t('columns.sku_price'),"width":"8%","dataIndex":"sku_price","align":"center"}}),_c('a-table-column',{key:"seller_name'",attrs:{"title":_vm.$t('columns.seller_name'),"width":"8%","dataIndex":"seller_name","align":"center"}}),_c('a-table-column',{key:"merge_user'",attrs:{"title":_vm.$t('columns.merge_user'),"width":"8%","dataIndex":"merge_user","align":"center"}}),_c('a-table-column',{key:"basic_sku'",attrs:{"title":_vm.$t('columns.basic_sku'),"width":"8%","dataIndex":"basic_sku","align":"center"}}),_c('a-table-column',{key:"basic_related_qty'",attrs:{"title":_vm.$t('columns.basic_related_qty'),"width":"8%","dataIndex":"basic_related_qty","align":"center"}}),_c('a-table-column',{key:"cn_category'",attrs:{"title":_vm.$t('columns.cn_category'),"width":"8%","dataIndex":"cn_category","align":"center"}}),_c('a-table-column',{key:"cn_sub_category'",attrs:{"title":_vm.$t('columns.cn_sub_category'),"width":"8%","dataIndex":"cn_sub_category","align":"center"}}),_c('a-table-column',{key:"basic_odoo_stock'",attrs:{"title":_vm.$t('columns.basic_odoo_stock'),"width":"8%","dataIndex":"basic_odoo_stock","align":"center"}}),_c('a-table-column',{key:"aliexpress_stock'",attrs:{"title":_vm.$t('columns.aliexpress_stock'),"width":"8%","dataIndex":"aliexpress_stock","align":"center"}}),_c('a-table-column',{key:"odoo_stock'",attrs:{"title":_vm.$t('columns.odoo_stock'),"width":"8%","dataIndex":"odoo_stock","align":"center"}}),_c('a-table-column',{key:"critical_value'",attrs:{"title":_vm.$t('columns.critical_value'),"width":"8%","dataIndex":"critical_value","align":"center"}}),_c('a-table-column',{key:"from_value'",attrs:{"title":_vm.$t('columns.from_value'),"width":"8%","dataIndex":"from_value","align":"center"}}),_c('a-table-column',{key:"to_value'",attrs:{"title":_vm.$t('columns.to_value'),"width":"8%","dataIndex":"to_value","align":"center"}}),_c('a-table-column',{key:"pull_off_value'",attrs:{"title":_vm.$t('columns.pull_off_value'),"width":"8%","dataIndex":"pull_off_value","align":"center"}}),_c('a-table-column',{key:"write_back_value'",attrs:{"title":_vm.$t('columns.write_back_value'),"width":"8%","dataIndex":"write_back_value","align":"center"}}),_c('a-table-column',{key:"last_write_back_value'",attrs:{"title":_vm.$t('columns.last_write_back_value'),"width":"8%","dataIndex":"last_write_back_value","align":"center"}}),_c('a-table-column',{key:"auto_state",attrs:{"title":_vm.$t('columns.auto_state'),"width":"8%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-checkbox',{attrs:{"checked":row.auto_state,"disabled":true}})]}}])})],1)],1),(_vm.selectedRowKeys.length)?_c('a-card',[_c('LogView',{attrs:{"object_name":_vm.object_name,"record_code":_vm.record_code}})],1):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-instock-manage.vue?vue&type=template&id=11d33e68&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.split.js
var es_string_split = __webpack_require__("1276");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./src/components/seller_instance/seller_view.vue + 4 modules
var seller_view = __webpack_require__("0c8d");

// EXTERNAL MODULE: ./src/components/seller_instance/seller-api-edit.vue + 4 modules
var seller_api_edit = __webpack_require__("76f6");

// EXTERNAL MODULE: ./src/components/product/aliexpress-listing-edit.vue + 4 modules
var aliexpress_listing_edit = __webpack_require__("0a82");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/services/aliexpress.service.ts
var aliexpress_service = __webpack_require__("1c60");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/aliexpress/aliexpress-instock-manage.vue?vue&type=script&lang=ts&




















var userModule = Object(lib["c" /* namespace */])('userModule');
var allUsersModule = Object(lib["c" /* namespace */])('allUsersModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var aliexpress_instock_managevue_type_script_lang_ts_AliexpressInstockManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AliexpressInstockManage, _super);

  function AliexpressInstockManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.aliexpressService = new aliexpress_service["a" /* AliexpressService */](); // 表格数据源

    _this.data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.versionList = [];
    _this.object_name = 'aliexpress_listing_stock';
    _this.record_code = ''; // 表格选择项

    _this.selectedRowKeys = [];
    return _this;
  }

  Object.defineProperty(AliexpressInstockManage.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });
  Object.defineProperty(AliexpressInstockManage.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  AliexpressInstockManage.prototype.created = function () {
    this.getCn_cate();
  };

  AliexpressInstockManage.prototype.onSelectedRowKeysChange = function () {
    if (this.selectedRowKeys.length && !this.record_code) {
      this.record_code = this.selectedRowKeys[0];
    }
  };

  AliexpressInstockManage.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };
  /**
   * 获取订单数据
   */


  AliexpressInstockManage.prototype.getInstockList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (_this.selectedList.length > 0) {
        values['cn_sub_category'] = _this.selectedList;
      }

      var operator = values['operator'];
      var type = values['type'];
      delete values['operator'];
      delete values['type'];

      if (operator == 'in' && values['default_code']) {
        values['default_code'] = values['default_code'].split(',');
      }

      if (type == 'basic_sku') {
        values['basic_sku'] = values['default_code'];
      } else {
        values['aliexpress_sku'] = values['default_code'];
      }

      delete values['default_code'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        basic_sku: operator,
        aliexpress_sku: operator,
        cn_sub_category: 'in'
      }); // params['sku_type'] = type

      _this.aliexpressService.query_all(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.data = data;
        _this.selectedRowKeys = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {
      _this.$message.error('请检查查询条件');
    });
  };

  AliexpressInstockManage.prototype.onEdit = function (row) {
    router["a" /* default */].push({
      name: 'seller-edit',
      params: {
        seller: row
      }
    });
  };

  AliexpressInstockManage.prototype.onDelete = function (row) {// this.sellerInstanceService
    //     .seller_delete(
    //         new RequestParams(
    //             {
    //                 seller_code_list: [row.seller_code]
    //             },
    //             { loading: this.loadingService }
    //         )
    //     )
    //     .subscribe(
    //         data => {
    //             let msg: any = this.$t('delete_success')
    //             this.$message.success(msg)
    //             this.getManualList()
    //         },
    //         err => {
    //             this.$message.error(err.message)
    //         }
    //     )
  };

  AliexpressInstockManage.prototype.onBatchDelete = function (row) {};

  AliexpressInstockManage.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  AliexpressInstockManage.prototype.onTrClick = function (record) {
    this.record_code = record;
  };

  AliexpressInstockManage.prototype.editValue = function (row) {
    var _this = this;

    this.$modal.open(aliexpress_listing_edit["a" /* default */], {
      row: row,
      saveFlag: 1
    }, {
      title: this.$t('action.edit')
    }).subscribe(function (data) {
      var msg = _this.$t('save_success');

      _this.$message.success(msg);

      _this.getInstockList();
    });
  };

  AliexpressInstockManage.prototype.mergeUser = function () {
    var _this = this;

    this.aliexpressService.mergeUser(new http["RequestParams"]({
      listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('认领Listing成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AliexpressInstockManage.prototype.mergeAuto = function () {
    var _this = this;

    this.aliexpressService.mergeAuto(new http["RequestParams"]({
      listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('标注Auto成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AliexpressInstockManage.prototype.cancelAuto = function () {
    var _this = this;

    this.aliexpressService.cancelAuto(new http["RequestParams"]({
      listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('取消Auto成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], AliexpressInstockManage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], AliexpressInstockManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('selectedRowKeys'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AliexpressInstockManage.prototype, "onSelectedRowKeysChange", null);

  AliexpressInstockManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'aliexpress-instock-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      SellerView: seller_view["a" /* default */],
      SellerApiEdit: seller_api_edit["a" /* default */],
      LogView: log_view["a" /* default */],
      AliexpressListingEdit: aliexpress_listing_edit["a" /* default */]
    }
  })], AliexpressInstockManage);
  return AliexpressInstockManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var aliexpress_instock_managevue_type_script_lang_ts_ = (aliexpress_instock_managevue_type_script_lang_ts_AliexpressInstockManage);
// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-instock-manage.vue?vue&type=script&lang=ts&
 /* harmony default export */ var aliexpress_aliexpress_instock_managevue_type_script_lang_ts_ = (aliexpress_instock_managevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/aliexpress/aliexpress-instock-manage.vue?vue&type=custom&index=0&blockType=i18n
var aliexpress_instock_managevue_type_custom_index_0_blockType_i18n = __webpack_require__("caf6");

// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-instock-manage.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  aliexpress_aliexpress_instock_managevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof aliexpress_instock_managevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(aliexpress_instock_managevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var aliexpress_instock_manage = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "7e9a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_price_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("6a4c");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_price_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_price_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_price_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "8121":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-approve.vue?vue&type=template&id=7c93224a&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('ProductPurchasePredict',{attrs:{"info":_vm.info}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-approve.vue?vue&type=template&id=7c93224a&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/components/product/product-purchase-predict.vue + 19 modules
var product_purchase_predict = __webpack_require__("200a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-approve.vue?vue&type=script&lang=ts&






var product_purchase_approvevue_type_script_lang_ts_ProductPurchaseApprove =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPurchaseApprove, _super);

  function ProductPurchaseApprove() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.info = 'predict-approve';
    return _this;
  }

  ProductPurchaseApprove.prototype.created = function () {};

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], ProductPurchaseApprove.prototype, "pageContainer", void 0);

  ProductPurchaseApprove = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-purchase-approve'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductPurchasePredict: product_purchase_predict["a" /* default */]
    }
  })], ProductPurchaseApprove);
  return ProductPurchaseApprove;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_purchase_approvevue_type_script_lang_ts_ = (product_purchase_approvevue_type_script_lang_ts_ProductPurchaseApprove);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-approve.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_product_purchase_approvevue_type_script_lang_ts_ = (product_purchase_approvevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/product-purchase-approve.vue?vue&type=custom&index=0&blockType=i18n
var product_purchase_approvevue_type_custom_index_0_blockType_i18n = __webpack_require__("964f");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-approve.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_product_purchase_approvevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_purchase_approvevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_purchase_approvevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_purchase_approve = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "821a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/requirement-schedule-feedback.vue?vue&type=template&id=ffd88402&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"showHeader":false,"actions":true},on:{"submit":_vm.getTicketsList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sku']),expression:"['sku']"}],style:({ width: '300px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category']),expression:"['z_sub_category']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.operator')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator', { initialValue: '' }]),expression:"['operator', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_name', { initialValue: '' }]),expression:"['vendor_name', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"mode":"multiple"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.dept_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'dept_id',
                        {
                            initialValue: ''
                        }
                    ]),expression:"[\n                        'dept_id',\n                        {\n                            initialValue: ''\n                        }\n                    ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.departmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.create_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['create_date']),expression:"['create_date']"}],attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['status', { initialValue: '' }]),expression:"['status', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"10"}},[_vm._v(_vm._s(_vm.$t('form.draft'))+" ")]),_c('a-radio-button',{attrs:{"value":"20"}},[_vm._v(" 采购提交 ")]),_c('a-radio-button',{attrs:{"value":"30"}},[_vm._v(" 库管提交 ")]),_c('a-radio-button',{attrs:{"value":"40"}},[_vm._v(" 运营提交 ")]),_c('a-radio-button',{attrs:{"value":"50"}},[_vm._v(" 完成 ")]),_c('a-radio-button',{attrs:{"value":"100"}},[_vm._v(" 退回 ")])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.import_schedual()}}},[_vm._v(_vm._s(_vm.$t('action.import'))+" ")]),_c('a-button',{attrs:{"disabled":!_vm.selectedRowKeys.length,"type":"primary"},on:{"click":function($event){return _vm.update_requirement_schedule_state(20)}}},[_vm._v(_vm._s(_vm.$t('action.update_requirement_schedule_state_purchase'))+" ")]),_c('a-button',{attrs:{"disabled":!_vm.selectedRowKeys.length,"type":"primary"},on:{"click":function($event){return _vm.setModal1Visible(true)}}},[_vm._v(_vm._s(_vm.$t('action.update_requirement_schedule_state_back'))+" ")]),_c('a-button',{attrs:{"disabled":!_vm.selectedRowKeys.length,"type":"primary"},on:{"click":function($event){return _vm.update_requirement_schedule_state(50)}}},[_vm._v(_vm._s(_vm.$t('action.update_requirement_schedule_state_done'))+" ")]),_c('a-button',{attrs:{"disabled":_vm.selectedRowKeys.length != 1,"type":"primary"},on:{"click":function($event){return _vm.open_AttachmentList()}}},[_vm._v(_vm._s(_vm.$t('action.open_AttachmentList'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex"},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 1500, y: 400 }},on:{"on-page-change":_vm.getTicketsList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"status",fn:function(text, row){return _c('span',{},[_vm._v(_vm._s(_vm._f("dict2")(row.status,_vm.stateList))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"dept_id",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getDeptName(text)))])]}}],null,false,252084177)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"status",fn:function(text, row){return _c('span',{},[_vm._v(_vm._s(_vm._f("dict2")(row.status,_vm.stateList))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"dept_id",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getDeptName(text)))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/requirement-schedule-feedback.vue?vue&type=template&id=ffd88402&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/components/purchase/purchase-feedback.vue + 4 modules
var purchase_feedback = __webpack_require__("bd4a");

// EXTERNAL MODULE: ./src/shared/common/attachment-list.vue + 4 modules
var attachment_list = __webpack_require__("99f3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/requirement-schedule-feedback.vue?vue&type=script&lang=ts&























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var requirement_schedule_feedbackvue_type_script_lang_ts_RequirementScheduleFeedback =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](RequirementScheduleFeedback, _super);

  function RequirementScheduleFeedback() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */](); // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.detail = '';
    _this.orderBy = ''; //分组相关变量

    _this.groupbyList = [];
    _this.columnList = [];
    _this.allNameAuth = [];
    _this.stateList = [{
      code: 10,
      name: '草稿'
    }, {
      code: 20,
      name: '采购提交'
    }, {
      code: 30,
      name: '库管提交'
    }, {
      code: 40,
      name: '运营提交'
    }, {
      code: 50,
      name: '完成'
    }, {
      code: 100,
      name: '退回'
    }];
    _this.queryUrl = 'product_management/query_all_requirement_schedule_feedback';
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.vender_data = [];
    _this.purchaseFeedback = '';
    return _this;
  }

  RequirementScheduleFeedback.prototype.created = function () {
    var _this = this;

    this.getSystemuser();
    this.getDepartmentList();
    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  RequirementScheduleFeedback.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  RequirementScheduleFeedback.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  RequirementScheduleFeedback.prototype.open_AttachmentList = function () {
    var _this = this;

    this.$modal.open(attachment_list["a" /* default */], {
      virtual_table_name: 'purchase_schedule',
      attachment_object_code: this.selectedRowKeys[0]
    }, {
      title: '附件',
      width: '80%'
    }).subscribe(function () {}, function (err) {
      _this.$message.error(err);
    });
  };

  RequirementScheduleFeedback.prototype.import_schedual = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/system_api/upload?inner_action=product_management/import_requirement_schedule&menu_code=' + common_service["a" /* CommonService */].getMenuCode()
    }, {
      title: 'Excel导入'
    }).subscribe(function () {}, function (err) {
      _this.$message.error(err);
    });
  };

  RequirementScheduleFeedback.prototype.getTicketsList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (values['vendor_name'] == '' || values['vendor_name'].length == 0) {
        delete values['vendor_name'];
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        sku: 'like',
        warehouse_id: '=',
        operate: '=',
        status: '=',
        z_sub_category: 'like',
        vendor_name: 'in'
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0])
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1])
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  RequirementScheduleFeedback.prototype.setModal1Visible = function (value) {
    var _this = this;

    this.$modal.open(purchase_feedback["a" /* default */], {}, {
      title: '退回反馈'
    }).subscribe(function (data) {
      _this.purchaseFeedback = data;

      _this.update_requirement_schedule_state(100);
    }, function (err) {
      _this.$message.error(err);
    });
  };

  RequirementScheduleFeedback.prototype.update_requirement_schedule_state = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/update_requirement_schedule_state', common_service["a" /* CommonService */].getMenuCode('product-purchase-schedual'));
    this.publicService.modify(new http["RequestParams"]({
      schedule_id_list: this.selectedRowKeys,
      status: state,
      purchase_feedback: this.purchaseFeedback
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.getTicketsList();

      _this.selectedRowKeys = [];
      _this.purchaseFeedback = '';

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  RequirementScheduleFeedback.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getTicketsList();
  };

  RequirementScheduleFeedback.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  RequirementScheduleFeedback.prototype.getDeptName = function (id) {
    var ret = '';
    var item = this.departmentList.find(function (x) {
      return x.id === id;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], RequirementScheduleFeedback.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], RequirementScheduleFeedback.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], RequirementScheduleFeedback.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], RequirementScheduleFeedback.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], RequirementScheduleFeedback.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], RequirementScheduleFeedback.prototype, "getDepartmentList", void 0);

  RequirementScheduleFeedback = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'requirement-schedule-feedback'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      UploadExcel: upload_excel["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      PurchaseFeedback: purchase_feedback["a" /* default */],
      AttachmentList: attachment_list["a" /* default */]
    }
  })], RequirementScheduleFeedback);
  return RequirementScheduleFeedback;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var requirement_schedule_feedbackvue_type_script_lang_ts_ = (requirement_schedule_feedbackvue_type_script_lang_ts_RequirementScheduleFeedback);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/requirement-schedule-feedback.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_requirement_schedule_feedbackvue_type_script_lang_ts_ = (requirement_schedule_feedbackvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/PurchasePredict/requirement-schedule-feedback.vue?vue&type=style&index=0&lang=css&
var requirement_schedule_feedbackvue_type_style_index_0_lang_css_ = __webpack_require__("f23a");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/requirement-schedule-feedback.vue?vue&type=custom&index=0&blockType=i18n
var requirement_schedule_feedbackvue_type_custom_index_0_blockType_i18n = __webpack_require__("9d5c");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/requirement-schedule-feedback.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_requirement_schedule_feedbackvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof requirement_schedule_feedbackvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(requirement_schedule_feedbackvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var requirement_schedule_feedback = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "853b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-sale-trend.vue?vue&type=template&id=4e8d100a&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('data-form',{ref:"dataForm",attrs:{"column":1},on:{"submit":_vm.getSaleTrendList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.presale_type')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['trend_type', { initialValue: '' }]),expression:"['trend_type', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PresaleType),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_sub_category']),expression:"['cn_sub_category']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.year')}},[_c('a-date-picker',{style:({ width: '240px' }),attrs:{"mode":"year","format":"YYYY","size":"small","value":_vm.yearPick,"open":_vm.yearPickShow},on:{"change":_vm.clearTime,"panelChange":_vm.handlePanelChange,"openChange":_vm.handleOpenChange}})],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onCreateSaleTrend}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.import_product_sale_trend()}}},[_vm._v(_vm._s(_vm.$t('action.import_product_sale_trend'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"sale_trend","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, selectedRows) {
                    _vm.selectedRowKeys = keys
                    this$1.changeCharts(keys, selectedRows)
                }
            }},on:{"on-page-change":_vm.getSaleTrendList}},[_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('columns.actions'),"width":"5%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.OnEdit(row)}}},[_vm._v(_vm._s(_vm.$t('action.edit')))])]}}])}),_c('a-table-column',{key:"cn_sub_category",attrs:{"title":_vm.$t('columns.cn_sub_category'),"data-index":"cn_sub_category","width":"5%","align":"center"}}),_c('a-table-column',{key:"warehouse_id",attrs:{"title":_vm.$t('columns.warehouse_id'),"data-index":"warehouse_id","width":"5%","align":"center"}}),_c('a-table-column',{key:"year",attrs:{"title":_vm.$t('columns.year'),"data-index":"year","width":"5%","align":"center"}}),_c('a-table-column',{key:"jan_value",attrs:{"title":_vm.$t('columns.jan_value'),"data-index":"jan_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"feb_value",attrs:{"title":_vm.$t('columns.feb_value'),"data-index":"feb_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"mar_value",attrs:{"title":_vm.$t('columns.mar_value'),"data-index":"mar_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"apr_value",attrs:{"title":_vm.$t('columns.apr_value'),"data-index":"apr_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"may_value",attrs:{"title":_vm.$t('columns.may_value'),"data-index":"may_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"jun_value",attrs:{"title":_vm.$t('columns.jun_value'),"data-index":"jun_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"jul_value",attrs:{"title":_vm.$t('columns.jul_value'),"data-index":"jul_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"aug_value",attrs:{"title":_vm.$t('columns.aug_value'),"data-index":"aug_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"sep_value",attrs:{"title":_vm.$t('columns.sep_value'),"data-index":"sep_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"oct_value",attrs:{"title":_vm.$t('columns.oct_value'),"data-index":"oct_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"nov_value",attrs:{"title":_vm.$t('columns.nov_value'),"data-index":"nov_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"dec_value",attrs:{"title":_vm.$t('columns.dec_value'),"data-index":"dec_value","width":"4%","align":"center"}}),_c('a-table-column',{key:"department",attrs:{"title":_vm.$t('columns.department'),"data-index":"department","width":"5%","align":"center"}}),_c('a-table-column',{key:"operator",attrs:{"title":_vm.$t('columns.operator'),"data-index":"operator","width":"5%","align":"center"}}),_c('a-table-column',{key:"z_category",attrs:{"title":_vm.$t('columns.z_category'),"data-index":"z_category","width":"5%","align":"center"}})],1)],1),_c('a-card',{attrs:{"title":_vm.$t('desc')}},[_c('ve-line',{attrs:{"data":_vm.chartData1}})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-sale-trend.vue?vue&type=template&id=4e8d100a&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/product/sale-trend-edit.vue + 4 modules
var sale_trend_edit = __webpack_require__("0a1c");

// EXTERNAL MODULE: ./src/services/saletrend.service.ts
var saletrend_service = __webpack_require__("9cea");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-sale-trend.vue?vue&type=script&lang=ts&













var product_sale_trendvue_type_script_lang_ts_ProductSaleTrend =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductSaleTrend, _super);

  function ProductSaleTrend() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.yearPick = null;
    _this.yearPickShow = false; // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.orderBy = '';
    _this.saletrendService = new saletrend_service["a" /* SaleTrendService */]();
    _this.product = [];
    _this.chartData1 = [];
    return _this;
  }

  ProductSaleTrend.prototype.handleOpenChange = function (status) {
    this.yearPickShow = status;
  }; // 得到年份选择器的值


  ProductSaleTrend.prototype.handlePanelChange = function (value) {
    this.yearPick = value.format('YYYY');
    this.yearPickShow = false;
  }; // 清除时间


  ProductSaleTrend.prototype.clearTime = function () {
    this.yearPick = null;
  };
  /**
   * 获取销售趋势数据
   */


  ProductSaleTrend.prototype.getSaleTrendList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      values['year'] = _this.yearPick;
      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        cn_sub_category: 'like'
      });

      if (_this.orderBy) {
        params['order_by'] = _this.orderBy;
      }

      _this.saletrendService.queryAll(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.data = data;
        _this.selectedRowKeys = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {// 异常处理
    });
  };

  ProductSaleTrend.prototype.onStatusChange = function (e) {
    this.$nextTick(function () {
      this.getSaleTrendList();
    });
  };

  ProductSaleTrend.prototype.onCreateSaleTrend = function () {
    var _this = this;

    this.$modal.open(sale_trend_edit["a" /* default */], {
      saveFlag: 0
    }, {
      title: '新建销售趋势数据'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getSaleTrendList();
    });
  };

  ProductSaleTrend.prototype.OnEdit = function (row) {
    var _this = this;

    this.$modal.open(sale_trend_edit["a" /* default */], {
      saveFlag: 1,
      row: row
    }, {
      title: '编辑销售趋势数据: ' + row.cn_sub_category
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getSaleTrendList();
    });
  };

  ProductSaleTrend.prototype.changeCharts = function (selectedRowKeys, selectedRows) {
    this.chartData1 = {
      columns: ['日期'],
      rows: [{
        日期: '一月'
      }, {
        日期: '二月'
      }, {
        日期: '三月'
      }, {
        日期: '四月'
      }, {
        日期: '五月'
      }, {
        日期: '六月'
      }, {
        日期: '七月'
      }, {
        日期: '八月'
      }, {
        日期: '九月'
      }, {
        日期: '十月'
      }, {
        日期: '十一月'
      }, {
        日期: '十二月'
      }]
    };

    for (var _i = 0, selectedRows_1 = selectedRows; _i < selectedRows_1.length; _i++) {
      var sr = selectedRows_1[_i];
      var new_name = sr['cn_sub_category'] + '-' + sr['year'] + '-' + sr['warehouse_id'];

      if (this.chartData1.columns.indexOf(new_name) < 0) {
        this.chartData1.columns.push(new_name);
        this.chartData1.rows[0][new_name] = sr['jan_value'];
        this.chartData1.rows[1][new_name] = sr['feb_value'];
        this.chartData1.rows[2][new_name] = sr['mar_value'];
        this.chartData1.rows[3][new_name] = sr['apr_value'];
        this.chartData1.rows[4][new_name] = sr['may_value'];
        this.chartData1.rows[5][new_name] = sr['jun_value'];
        this.chartData1.rows[6][new_name] = sr['jul_value'];
        this.chartData1.rows[7][new_name] = sr['aug_value'];
        this.chartData1.rows[8][new_name] = sr['sep_value'];
        this.chartData1.rows[9][new_name] = sr['oct_value'];
        this.chartData1.rows[10][new_name] = sr['nov_value'];
        this.chartData1.rows[11][new_name] = sr['dec_value'];
      }
    }

    this.selectedRowKeys = selectedRowKeys;
  };

  ProductSaleTrend.prototype.import_product_sale_trend = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/product_pre_sale/upload_cn_sub_category_sale_trend',
      attachmentUrlPath: '/attachment/download_import_template?type=categorySaleTrendImport'
    }, {
      title: 'Excel导入'
    }).subscribe(function () {}, function (err) {
      _this.$message.error(err);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductSaleTrend.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductSaleTrend.prototype, "pageContainer", void 0);

  ProductSaleTrend = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-sale-trend'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      SaleTrendEdit: sale_trend_edit["a" /* default */]
    }
  })], ProductSaleTrend);
  return ProductSaleTrend;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_sale_trendvue_type_script_lang_ts_ = (product_sale_trendvue_type_script_lang_ts_ProductSaleTrend);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-sale-trend.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_product_sale_trendvue_type_script_lang_ts_ = (product_sale_trendvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/product-sale-trend.vue?vue&type=custom&index=0&blockType=i18n
var product_sale_trendvue_type_custom_index_0_blockType_i18n = __webpack_require__("87b1");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-sale-trend.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_product_sale_trendvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_sale_trendvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_sale_trendvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_sale_trend = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "87b1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_trend_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d737");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_trend_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_trend_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_trend_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "92ff":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_manage_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b003");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_manage_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_manage_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "964f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_approve_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b7b7");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_approve_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_approve_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_approve_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "9879":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/aliexpress/aliexpress-manage.vue?vue&type=template&id=42f3f2a4&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",scopedSlots:_vm._u([{key:"header-action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.importOrders()}}},[_vm._v(" "+_vm._s(_vm.$t('action.import_orders'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.fulfilOrders()}}},[_vm._v(" "+_vm._s(_vm.$t('action.fulfil_orders'))+" ")])]},proxy:true}])},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('section',{staticClass:"component edit-aliexpress"},[_c('a-form',{attrs:{"form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-card',{staticClass:"margin-top aliexpress-edit-page"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12,"required":""}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.seller_code')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'seller_code',
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        'seller_code',\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],style:({
                                        width: '100%',
                                        'max-width': '300px'
                                    }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect')}},_vm._l((_vm.sellerCodeList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.modified_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'modified_date',
                                        { initialValue: _vm.initialDate }
                                    ]),expression:"[\n                                        'modified_date',\n                                        { initialValue: initialDate }\n                                    ]"}],attrs:{"format":"YYYY-MM-DD HH:mm","size":"small"}})],1)],1)],1)],1)],1)],1)])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-manage.vue?vue&type=template&id=42f3f2a4&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/services/aliexpress.service.ts
var aliexpress_service = __webpack_require__("1c60");

// EXTERNAL MODULE: ./src/services/seller-instance.service.ts
var seller_instance_service = __webpack_require__("5c97");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/aliexpress/aliexpress-manage.vue?vue&type=script&lang=ts&














var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var aliexpress_managevue_type_script_lang_ts_AliexpressManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AliexpressManage, _super);

  function AliexpressManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a;
    _this.initialDate = []; // Loading服务

    _this.orderService = new order_service["a" /* OrderService */](); // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.aliexpressService = new aliexpress_service["a" /* AliexpressService */]();
    _this.sellerInstanceService = new seller_instance_service["a" /* SellerInstanceService */](); // 表格数据源

    _this.order = [];
    _this.orderDetail = [];
    _this.sellerCodeList = [];
    _this.instanceCodeList = [];
    _this.partnerName = '';
    _this.save_flag = 0;
    _this.defaultOrderType = '';
    _this.currentCustomerValue = '';
    _this.originData = [];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  Object.defineProperty(AliexpressManage.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });

  AliexpressManage.prototype.onOrderEditPatamsChange = function () {
    if (this.orderEditParams) {
      this.updateOrder(this.orderEditParams);
    }
  };

  AliexpressManage.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.order.modified_date = moment_default()(_this.order.modified_date, 'YYYY-MM-DD');

      _this.form.setFieldsValue(_this.order);
    });
  };

  AliexpressManage.prototype.created = function () {
    this.getSellerCodeList();
    this.form = this.$form.createForm(this);
  };

  AliexpressManage.prototype.mounted = function () {
    if (this.$route.params.order) {
      this.updateOrder(this.$route.params.order);
    }
  };

  AliexpressManage.prototype.getSellerCodeList = function () {
    var _this = this;

    this.sellerInstanceService.query_seller_name(new http["RequestParams"]({})).subscribe(function (data) {
      _this.sellerCodeList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AliexpressManage.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  AliexpressManage.prototype.onDetailListChange = function (data) {
    this.orderDetail = data;
  };

  AliexpressManage.prototype.importOrders = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      if (values['modified_date'].length != 2) {
        _this.$message.error('导入订单必须要有订单日期！');
      }

      values['modified_date_start'] = new Date(values['modified_date'][0].utc().format('YYYY-MM-DD HH:mm:ss'));
      values['modified_date_end'] = new Date(values['modified_date'][1].utc().format('YYYY-MM-DD HH:mm:ss'));

      _this.aliexpressService.importOrders(new http["RequestParams"](values)).subscribe(function () {
        var msg = _this.$t('tips.import_success');

        _this.$message.success(msg);
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  AliexpressManage.prototype.fulfilOrders = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      delete values.modified_date;

      _this.aliexpressService.fulfilOrders(new http["RequestParams"](values)).subscribe(function () {
        var msg = _this.$t('tips.fulfil_success');

        _this.$message.success(msg);
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], AliexpressManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AliexpressManage.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AliexpressManage.prototype, "getcountry", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AliexpressManage.prototype, "currencyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AliexpressManage.prototype, "getcurrency", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AliexpressManage.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AliexpressManage.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AliexpressManage.prototype, "orderEditParams", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('orderEditParams'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AliexpressManage.prototype, "onOrderEditPatamsChange", null);

  AliexpressManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'aliexpress-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */]
    }
  })], AliexpressManage);
  return AliexpressManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var aliexpress_managevue_type_script_lang_ts_ = (aliexpress_managevue_type_script_lang_ts_AliexpressManage);
// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-manage.vue?vue&type=script&lang=ts&
 /* harmony default export */ var aliexpress_aliexpress_managevue_type_script_lang_ts_ = (aliexpress_managevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/aliexpress/aliexpress-manage.vue?vue&type=style&index=0&lang=css&
var aliexpress_managevue_type_style_index_0_lang_css_ = __webpack_require__("92ff");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/aliexpress/aliexpress-manage.vue?vue&type=custom&index=0&blockType=i18n
var aliexpress_managevue_type_custom_index_0_blockType_i18n = __webpack_require__("2c63");

// CONCATENATED MODULE: ./src/pages/aliexpress/aliexpress-manage.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  aliexpress_aliexpress_managevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof aliexpress_managevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(aliexpress_managevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var aliexpress_manage = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "9d5c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0b3e");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "a034":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/amazon-listing-price.vue?vue&type=template&id=60f41bac&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('data-form',{ref:"dataForm",attrs:{"column":2},on:{"submit":_vm.getVendorProductList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 10 }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 10 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('columns.amazon_sku'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('columns.cn_category'))+" ")]),_c('a-select-option',{attrs:{"value":30}},[_vm._v(" "+_vm._s(_vm.$t('columns.cn_sub_category'))+" ")]),_c('a-select-option',{attrs:{"value":40}},[_vm._v(" "+_vm._s(_vm.$t('columns.product_price_sku'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"draft"}},[_vm._v(" "+_vm._s(_vm.$t('dict.draft'))+" ")]),_c('a-radio-button',{attrs:{"value":"write_back"}},[_vm._v(" "+_vm._s(_vm.$t('dict.write_back'))+" ")]),_c('a-radio-button',{attrs:{"value":"merged"}},[_vm._v(" "+_vm._s(_vm.$t('dict.merged'))+" ")]),_c('a-radio-button',{attrs:{"value":"need_merge"}},[_vm._v(" "+_vm._s(_vm.$t('dict.need_merge'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warning_state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warning_state', { initialValue: '' }]),expression:"['warning_state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"lower_warning"}},[_vm._v(" "+_vm._s(_vm.$t('dict.lower_warning'))+" ")]),_c('a-radio-button',{attrs:{"value":"upper_warning"}},[_vm._v(" "+_vm._s(_vm.$t('dict.upper_warning'))+" ")]),_c('a-radio-button',{attrs:{"value":"safe"}},[_vm._v(" "+_vm._s(_vm.$t('dict.safe'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.active_state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['active_state', { initialValue: '' }]),expression:"['active_state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"active"}},[_vm._v(" "+_vm._s(_vm.$t('dict.active'))+" ")]),_c('a-radio-button',{attrs:{"value":"inactive"}},[_vm._v(" "+_vm._s(_vm.$t('dict.inactive'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.merge_user_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["merge_user_id"]),expression:"[`merge_user_id`]"}],staticStyle:{"width":"300px"},attrs:{"showSearch":"","placeholder":_vm.$t('plzSelect'),"size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.importInfo}},[_vm._v("导入")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"},on:{"click":_vm.exportInfo}},[_vm._v("导出 ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.mergeUser}},[_vm._v(_vm._s(_vm.$t('action.mergeUser'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.writeBackPrice}},[_vm._v(_vm._s(_vm.$t('action.writeBackPrice'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"},on:{"click":_vm.onSave}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":_vm.getBaseProductInfo}},[_vm._v(_vm._s(_vm.$t('action.getBaseProductInfo'))+" ")]),_c('a-menu-item',{on:{"click":_vm.getProductPrice}},[_vm._v(_vm._s(_vm.$t('action.getProductPrice'))+" ")]),_c('a-menu-item',{on:{"click":_vm.computeNeedMerge}},[_vm._v(_vm._s(_vm.$t('action.computeNeedMerge'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v(_vm._s(_vm.$t('action.actions'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('section',{staticClass:"component edit-customer"},[_c('CommonPage',{attrs:{"page":_vm.pageService,"data":_vm.data},on:{"on-page-change":_vm.getVendorProductList}}),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"id","columns":_vm.columnList,"customRow":function (rowKey) { return ({
                        on: {
                            // 单击每行
                            click: function () {
                                _vm.currentRow = rowKey.id
                            }
                        }
                    }); },"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"bordered":"","scroll":{ x: 3000 }},scopedSlots:_vm._u([{key:"write_standard_price",fn:function(row){return [(_vm.currentRow == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['write_standard_price']),expression:"['write_standard_price']"}],style:({
                            width: '100%',
                            background: '#ecc5e9'
                        }),attrs:{"decimalSeparator":",","value":row.write_standard_price,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'write_standard_price', e); }}}):_c('span',[_vm._v(_vm._s(row.write_standard_price))])]}},{key:"write_discount_price",fn:function(row){return [(_vm.currentRow == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['write_discount_price']),expression:"['write_discount_price']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.write_discount_price,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'write_discount_price', e); }}}):_c('span',[_vm._v(_vm._s(row.write_discount_price))])]}},{key:"discount_start",fn:function(row){return [(_vm.currentRow == row.id)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_start']),expression:"['discount_start']"}],attrs:{"value":row.discount_start,"format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(row, 'discount_start', e); }}}):_c('span',[_vm._v(_vm._s(row.discount_start))])]}},{key:"discount_end",fn:function(row){return [(_vm.currentRow == row.id)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_end']),expression:"['discount_end']"}],attrs:{"value":row.discount_end,"format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(row, 'discount_end', e); }}}):_c('span',[_vm._v(_vm._s(row.discount_end))])]}}])})],1)])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-price.vue?vue&type=template&id=60f41bac&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/amazon-listing-price.vue?vue&type=script&lang=ts&

















var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var amazon_listing_pricevue_type_script_lang_ts_AmazonListingPrice =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AmazonListingPrice, _super);

  function AmazonListingPrice() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.columnList = [{
      key: 'import_time',
      title: _this.$t('columns.import_time'),
      dataIndex: 'import_time',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return common_service["a" /* CommonService */].dateToLocal(value);
        }

        return value;
      }
    }, {
      key: 'merge_time',
      title: _this.$t('columns.merge_time'),
      dataIndex: 'merge_time',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return common_service["a" /* CommonService */].dateToLocal(value);
        }

        return value;
      }
    }, {
      key: 'write_back_time',
      title: _this.$t('columns.write_back_time'),
      dataIndex: 'write_back_time',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return common_service["a" /* CommonService */].dateToLocal(value);
        }

        return value;
      }
    }, {
      key: 'amazon_sku',
      title: _this.$t('columns.amazon_sku'),
      dataIndex: 'amazon_sku',
      width: 100
    }, {
      key: 'amazon_asin',
      title: _this.$t('columns.amazon_asin'),
      dataIndex: 'amazon_asin',
      width: 100
    }, {
      key: 'amazon_type',
      title: _this.$t('columns.amazon_type'),
      width: 100
    }, {
      key: 'standard_price',
      title: _this.$t('columns.standard_price'),
      dataIndex: 'standard_price',
      width: 100
    }, {
      key: 'business_price',
      title: _this.$t('columns.business_price'),
      dataIndex: 'business_price',
      width: 100
    }, {
      key: 'instance_id',
      title: _this.$t('columns.instance_id'),
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return value.instance_id[1];
        }

        return value;
      }
    }, {
      key: 'product_price_sku',
      title: _this.$t('columns.product_price_sku'),
      dataIndex: 'product_price_sku',
      width: 100
    }, {
      key: 'product_price',
      title: _this.$t('columns.product_price'),
      dataIndex: 'product_price',
      width: 100
    }, {
      key: 'product_related_qty',
      title: _this.$t('columns.product_related_qty'),
      dataIndex: 'product_related_qty',
      width: 100
    }, {
      key: 'cn_category',
      title: _this.$t('columns.cn_category'),
      dataIndex: 'cn_category',
      width: 100
    }, {
      key: 'cn_sub_category',
      title: _this.$t('columns.cn_sub_category'),
      dataIndex: 'cn_sub_category',
      width: 100
    }, {
      key: 'write_standard_price',
      title: _this.$t('columns.write_standard_price'),
      width: 100,
      scopedSlots: {
        customRender: 'write_standard_price'
      }
    }, {
      key: 'write_discount_price',
      title: _this.$t('columns.write_discount_price'),
      width: 100,
      scopedSlots: {
        customRender: 'write_discount_price'
      }
    }, {
      key: 'discount_start',
      title: _this.$t('columns.discount_start'),
      width: 100,
      scopedSlots: {
        customRender: 'discount_start'
      }
    }, {
      key: 'discount_end',
      title: _this.$t('columns.discount_end'),
      width: 100,
      scopedSlots: {
        customRender: 'discount_end'
      }
    }, {
      key: 'merge_user_id',
      title: _this.$t('columns.merge_user_id'),
      customRender: function customRender(value, row, index) {
        if (value) {
          return value.merge_user_id[1];
        }

        return value;
      },
      width: 100
    }, {
      key: 'state',
      title: _this.$t('columns.state'),
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.switchCodeName(_this.state_list, value.state);
        }

        return value;
      },
      width: 100
    }, {
      key: 'active_state',
      title: _this.$t('columns.active_state'),
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.switchCodeName(_this.active_state_list, value.active_state);
        }

        return value;
      },
      width: 100
    }, {
      key: 'warning_state',
      title: _this.$t('columns.warning_state'),
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.switchCodeName(_this.warning_state_list, value.warning_state);
        }

        return value;
      },
      width: 100
    }];
    _this.warning_state_list = [{
      code: 'lower_warning',
      name: _this.$t('dict.lower_warning')
    }, {
      code: 'upper_warning',
      name: _this.$t('dict.upper_warning')
    }, {
      code: 'safe',
      name: _this.$t('dict.safe')
    }];
    _this.active_state_list = [{
      code: 'active',
      name: _this.$t('dict.active')
    }, {
      code: 'inactive',
      name: _this.$t('dict.inactive')
    }];
    _this.state_list = [{
      code: 'draft',
      name: _this.$t('dict.draft')
    }, {
      code: 'need_merge',
      name: _this.$t('dict.need_merge')
    }, {
      code: 'merged',
      name: _this.$t('dict.merged')
    }, {
      code: 'write_back',
      name: _this.$t('dict.write_back')
    }];
    _this.data = [];
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.moment = moment_default.a;
    _this.pageService = new page_service["a" /* PageService */]();
    _this.selectedRowKeys = [];
    _this.editable = true;
    _this.currentRow = '';
    return _this;
  }

  AmazonListingPrice.prototype.switchCodeName = function (list, value) {
    var ret = value;
    var item = list.find(function (x) {
      return x.code == value;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  AmazonListingPrice.prototype.created = function () {};

  AmazonListingPrice.prototype.mounted = function () {
    this.getSystemuser();
  };

  AmazonListingPrice.prototype.getVendorProductList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var fuzzy_search_value = values['fuzzy_search_value'];

      if (fuzzy_search_value) {
        var fuzzy_search_code = values['fuzzy_search_code'];
        var search_field_name = 'amazon_sku';

        switch (fuzzy_search_code) {
          case 10:
            search_field_name = 'amazon_sku';
            break;

          case 20:
            search_field_name = 'cn_category';
            break;

          case 30:
            search_field_name = 'cn_sub_category';
            break;

          case 40:
            search_field_name = 'product_price_sku';
            break;

          default:
            search_field_name = 'amazon_sku';
        }

        values[search_field_name] = fuzzy_search_value;
      }

      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        amazon_sku: 'like',
        cn_category: 'like',
        cn_sub_category: 'like',
        product_price_sku: 'like'
      });
      var inneraction = new inner_action_service["a" /* InnerActionService */]();
      inneraction.setActionAPI('amazon_management/query_all_amazon_listing_price', common_service["a" /* CommonService */].getMenuCode());

      _this.publicService.queryPagination(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService,
        innerAction: inneraction
      })).subscribe(function (data) {
        _this.data = data;
        _this.selectedRowKeys = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {
      _this.$message.error('请检查查询条件');
    });
  };

  AmazonListingPrice.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target && value.target.value) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }

    row.save_flag = 1;
  };

  AmazonListingPrice.prototype.onSave = function () {
    var _this = this;

    var list = [];
    var flag = false;

    for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
      var i = _a[_i];

      if (i.save_flag == 1) {
        list.push({
          id: i.id,
          write_standard_price: i.write_standard_price,
          write_discount_price: i.write_discount_price,
          discount_start: i.discount_start,
          discount_end: i.discount_end
        });

        if (!i.write_standard_price) {
          this.$message.error('需回写标准价格必须填写');
          break;
        }

        if (i.write_discount_price || i.discount_start || i.discount_end) {
          if (i.write_discount_price && i.discount_start && i.discount_end) {
            flag = true;
          } else {
            this.$message.error('需回写折扣价格,折扣开始时间,折扣结束时间须同时填写');
            break;
          }
        } else {
          flag = true;
        }
      }
    }

    if (flag) {
      var inneraction = new inner_action_service["a" /* InnerActionService */]();
      inneraction.setActionAPI('amazon_management/save_amazon_listing_price', common_service["a" /* CommonService */].getMenuCode());
      this.publicService.modify(new http["RequestParams"]({
        listing_list: list
      }, {
        loading: this.loadingService,
        innerAction: inneraction
      })).subscribe(function () {
        _this.$message.success('保存成功');

        _this.getVendorProductList();
      }, function (err) {
        _this.$message.error(err.message);
      });
    }
  };

  AmazonListingPrice.prototype.mergeUser = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/merge_user', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getVendorProductList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingPrice.prototype.writeBackPrice = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/write_back_price', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getVendorProductList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingPrice.prototype.getBaseProductInfo = function (row) {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/update_amazon_listing_bp_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getVendorProductList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingPrice.prototype.getProductPrice = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/update_amazon_listing_product_price', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getVendorProductList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingPrice.prototype.computeNeedMerge = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/compute_need_merge', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getVendorProductList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingPrice.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], AmazonListingPrice.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _b : Object)], AmazonListingPrice.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AmazonListingPrice.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AmazonListingPrice.prototype, "getSystemuser", void 0);

  AmazonListingPrice = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'amazon-listing-price'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      CommonPage: common_page["a" /* default */]
    }
  })], AmazonListingPrice);
  return AmazonListingPrice;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var amazon_listing_pricevue_type_script_lang_ts_ = (amazon_listing_pricevue_type_script_lang_ts_AmazonListingPrice);
// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-price.vue?vue&type=script&lang=ts&
 /* harmony default export */ var amazon_amazon_listing_pricevue_type_script_lang_ts_ = (amazon_listing_pricevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/amazon/amazon-listing-price.vue?vue&type=style&index=0&lang=css&
var amazon_listing_pricevue_type_style_index_0_lang_css_ = __webpack_require__("5062");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/amazon/amazon-listing-price.vue?vue&type=custom&index=0&blockType=i18n
var amazon_listing_pricevue_type_custom_index_0_blockType_i18n = __webpack_require__("7e9a");

// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-price.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  amazon_amazon_listing_pricevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof amazon_listing_pricevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(amazon_listing_pricevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var amazon_listing_price = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "aa1a":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "ad28":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("366e");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_amazon_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "af79":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_account_invoice_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("18da");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_account_invoice_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_account_invoice_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_account_invoice_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b003":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "b7b7":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":""},"zh-cn":{"desc":""}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "be50":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_schedual_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("27dc");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_schedual_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_schedual_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_schedual_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "c44b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/account-page1.vue?vue&type=template&id=8d682c92&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',[_vm._v("AccountPage1")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/accounts/account-page1.vue?vue&type=template&id=8d682c92&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/account-page1.vue?vue&type=script&lang=ts&




var account_page1vue_type_script_lang_ts_AccountPage1 =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AccountPage1, _super);

  function AccountPage1() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  AccountPage1 = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    name: 'account-page1',
    layout: 'workspace'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AccountPage1);
  return AccountPage1;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var account_page1vue_type_script_lang_ts_ = (account_page1vue_type_script_lang_ts_AccountPage1);
// CONCATENATED MODULE: ./src/pages/accounts/account-page1.vue?vue&type=script&lang=ts&
 /* harmony default export */ var accounts_account_page1vue_type_script_lang_ts_ = (account_page1vue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/pages/accounts/account-page1.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  accounts_account_page1vue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var account_page1 = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "c4b7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-predict.vue?vue&type=template&id=5280479c&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('ProductPurchasePredict',{attrs:{"info":_vm.info}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-predict.vue?vue&type=template&id=5280479c&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/components/product/product-purchase-predict.vue + 19 modules
var product_purchase_predict = __webpack_require__("200a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/PurchasePredict/product-purchase-predict.vue?vue&type=script&lang=ts&






var product_purchase_predictvue_type_script_lang_ts_ProductPurchaseCal =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPurchaseCal, _super);

  function ProductPurchaseCal() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.info = '';
    return _this;
  }

  ProductPurchaseCal.prototype.created = function () {};

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], ProductPurchaseCal.prototype, "pageContainer", void 0);

  ProductPurchaseCal = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-purchase-predict'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductPurchasePredict: product_purchase_predict["a" /* default */]
    }
  })], ProductPurchaseCal);
  return ProductPurchaseCal;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_purchase_predictvue_type_script_lang_ts_ = (product_purchase_predictvue_type_script_lang_ts_ProductPurchaseCal);
// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-predict.vue?vue&type=script&lang=ts&
 /* harmony default export */ var PurchasePredict_product_purchase_predictvue_type_script_lang_ts_ = (product_purchase_predictvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/PurchasePredict/product-purchase-predict.vue?vue&type=custom&index=0&blockType=i18n
var product_purchase_predictvue_type_custom_index_0_blockType_i18n = __webpack_require__("6a6c");

// CONCATENATED MODULE: ./src/pages/PurchasePredict/product-purchase-predict.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  PurchasePredict_product_purchase_predictvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_purchase_predictvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_purchase_predictvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var PurchasePredict_product_purchase_predict = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "c630":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_reference_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5c98");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_reference_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_reference_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_reference_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "c6c9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/amazon-listing-total.vue?vue&type=template&id=04e9a540&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getAmazonStockPrice},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 10 }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 10 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('columns.amazon_sku'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('columns.cn_category'))+" ")]),_c('a-select-option',{attrs:{"value":30}},[_vm._v(" "+_vm._s(_vm.$t('columns.cn_sub_category'))+" ")]),_c('a-select-option',{attrs:{"value":40}},[_vm._v(" "+_vm._s(_vm.$t('columns.product_price_sku'))+" ")]),_c('a-select-option',{attrs:{"value":50}},[_vm._v(" "+_vm._s(_vm.$t('columns.basic_product_sku'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"draft"}},[_vm._v(" "+_vm._s(_vm.$t('dict.draft'))+" ")]),_c('a-radio-button',{attrs:{"value":"write_back"}},[_vm._v(" "+_vm._s(_vm.$t('dict.write_back'))+" ")]),_c('a-radio-button',{attrs:{"value":"merged"}},[_vm._v(" "+_vm._s(_vm.$t('dict.merged'))+" ")]),_c('a-radio-button',{attrs:{"value":"need_merge"}},[_vm._v(" "+_vm._s(_vm.$t('dict.need_merge'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warning_state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warning_state', { initialValue: '' }]),expression:"['warning_state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"lower_warning"}},[_vm._v(" "+_vm._s(_vm.$t('dict.lower_warning'))+" ")]),_c('a-radio-button',{attrs:{"value":"upper_warning"}},[_vm._v(" "+_vm._s(_vm.$t('dict.upper_warning'))+" ")]),_c('a-radio-button',{attrs:{"value":"safe"}},[_vm._v(" "+_vm._s(_vm.$t('dict.safe'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.active_state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['active_state', { initialValue: '' }]),expression:"['active_state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"active"}},[_vm._v(" "+_vm._s(_vm.$t('dict.active'))+" ")]),_c('a-radio-button',{attrs:{"value":"inactive"}},[_vm._v(" "+_vm._s(_vm.$t('dict.inactive'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.merge_user_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["user_id"]),expression:"[`user_id`]"}],staticStyle:{"width":"300px"},attrs:{"showSearch":"","placeholder":_vm.$t('plzSelect'),"size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.auto_state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['auto_state', { initialValue: '' }]),expression:"['auto_state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["warehouse"]),expression:"[`warehouse`]"}],staticStyle:{"width":"300px"},attrs:{"showSearch":"","placeholder":_vm.$t('plzSelect'),"size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-select-option',{attrs:{"value":"de"}},[_vm._v(" DE ")]),_c('a-select-option',{attrs:{"value":"uk"}},[_vm._v(" UK ")])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.mergeUser()}}},[_vm._v(_vm._s(_vm.$t('action.merge_user'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.mergeAuto()}}},[_vm._v(_vm._s(_vm.$t('action.merge_auto'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.cancelAuto()}}},[_vm._v(_vm._s(_vm.$t('action.cancel_auto'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.save_changed_data()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.uploadFile}},[_vm._v(_vm._s(_vm.$t('action.excel_import'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.showLog}},[_vm._v(_vm._s(_vm.$t('action.showlog'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.writeBackInventory}},[_vm._v(_vm._s(_vm.$t('action.writeBackInventory'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.writeBackPrice}},[_vm._v(_vm._s(_vm.$t('action.writeBackPrice'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":_vm.getBaseProductInfo}},[_vm._v(_vm._s(_vm.$t('action.getBaseProductInfo'))+" ")]),_c('a-menu-item',{on:{"click":_vm.getProductPrice}},[_vm._v(_vm._s(_vm.$t('action.getProductPrice'))+" ")]),_c('a-menu-item',{on:{"click":_vm.computeNeedMerge}},[_vm._v(_vm._s(_vm.$t('action.computeNeedMerge'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v(_vm._s(_vm.$t('action.actions'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getAmazonStockPrice,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"open_url",fn:function(text, row){return [_c('span',[_c('a-icon',{attrs:{"type":"amazon"},on:{"click":function($event){return _vm.open_url(row)}}})],1)]}},{key:"warning_state",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm.swichStateName(text, _vm.warning_state_list))+" ")])}},{key:"state",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm.swichStateName(text, _vm.state_list))+" ")])}},{key:"active_state",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm.swichStateName(text, _vm.active_state_list))+" ")])}},{key:"write_standard_price",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['write_standard_price']),expression:"['write_standard_price']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.write_standard_price,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'write_standard_price', e); }}}):_c('span',[_vm._v(_vm._s(row.write_standard_price))])]}},{key:"write_discount_price",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['write_discount_price']),expression:"['write_discount_price']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.write_discount_price,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'write_discount_price', e); }}}):_c('span',[_vm._v(_vm._s(row.write_discount_price))])]}},{key:"discount_start",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_start']),expression:"['discount_start']"}],attrs:{"value":row.discount_start,"format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(row, 'discount_start', e); }}}):_c('span',[_vm._v(_vm._s(row.discount_start))])]}},{key:"discount_end",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_end']),expression:"['discount_end']"}],attrs:{"value":row.discount_end,"format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(row, 'discount_end', e); }}}):_c('span',[_vm._v(_vm._s(row.discount_end))])]}},{key:"critical_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['critical_value']),expression:"['critical_value']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.critical_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'critical_value', e); }}}):_c('span',[_vm._v(_vm._s(row.critical_value))])]}},{key:"from_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['from_value']),expression:"['from_value']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.from_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'from_value', e); }}}):_c('span',[_vm._v(_vm._s(row.from_value))])]}},{key:"to_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['to_value']),expression:"['to_value']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.to_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'to_value', e); }}}):_c('span',[_vm._v(_vm._s(row.to_value))])]}},{key:"pull_off_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pull_off_value']),expression:"['pull_off_value']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.pull_off_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'pull_off_value', e); }}}):_c('span',[_vm._v(_vm._s(row.pull_off_value))])]}},{key:"auto_state",fn:function(text, row){return [(row.auto_state)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}}],null,false,2136499296)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":"purchase_order_plan/query_all"},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"open_url",fn:function(text, row){return [_c('span',[_c('a-icon',{attrs:{"type":"amazon"},on:{"click":function($event){return _vm.open_url(row)}}})],1)]}},{key:"write_standard_price",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['write_standard_price']),expression:"['write_standard_price']"}],style:({
                        width: '100%',
                        background: '#ecc5e9'
                    }),attrs:{"decimalSeparator":",","value":row.write_standard_price,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'write_standard_price', e); }}}):_c('span',[_vm._v(_vm._s(row.write_standard_price))])]}},{key:"write_discount_price",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['write_discount_price']),expression:"['write_discount_price']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.write_discount_price,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'write_discount_price', e); }}}):_c('span',[_vm._v(_vm._s(row.write_discount_price))])]}},{key:"discount_start",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_start']),expression:"['discount_start']"}],attrs:{"value":row.discount_start,"format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(row, 'discount_start', e); }}}):_c('span',[_vm._v(_vm._s(row.discount_start))])]}},{key:"discount_end",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_end']),expression:"['discount_end']"}],attrs:{"value":row.discount_end,"format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(row, 'discount_end', e); }}}):_c('span',[_vm._v(_vm._s(row.discount_end))])]}},{key:"critical_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['critical_value']),expression:"['critical_value']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.critical_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'critical_value', e); }}}):_c('span',[_vm._v(_vm._s(row.critical_value))])]}},{key:"from_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['from_value']),expression:"['from_value']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.from_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'from_value', e); }}}):_c('span',[_vm._v(_vm._s(row.from_value))])]}},{key:"to_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['to_value']),expression:"['to_value']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.to_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'to_value', e); }}}):_c('span',[_vm._v(_vm._s(row.to_value))])]}},{key:"pull_off_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pull_off_value']),expression:"['pull_off_value']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.pull_off_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'pull_off_value', e); }}}):_c('span',[_vm._v(_vm._s(row.pull_off_value))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-total.vue?vue&type=template&id=04e9a540&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__("159b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/services/amazon_listing_stock.service.ts
var amazon_listing_stock_service = __webpack_require__("8ba7");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/amazon-listing-total.vue?vue&type=script&lang=ts&


























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var amazon_listing_totalvue_type_script_lang_ts_AmazonListingTotal =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AmazonListingTotal, _super);

  function AmazonListingTotal() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.amazonListingStockService = new amazon_listing_stock_service["a" /* AmazonListingStockService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.defaultBoolValue = '';
    _this.warning_state_list = [{
      code: 'lower_warning',
      name: _this.$t('dict.lower_warning')
    }, {
      code: 'upper_warning',
      name: _this.$t('dict.upper_warning')
    }, {
      code: 'safe',
      name: _this.$t('dict.safe')
    }];
    _this.active_state_list = [{
      code: 'active',
      name: _this.$t('dict.active')
    }, {
      code: 'inactive',
      name: _this.$t('dict.inactive')
    }];
    _this.state_list = [{
      code: 'draft',
      name: _this.$t('dict.draft')
    }, {
      code: 'need_merge',
      name: _this.$t('dict.need_merge')
    }, {
      code: 'merged',
      name: _this.$t('dict.merged')
    }, {
      code: 'write_back',
      name: _this.$t('dict.write_back')
    }];
    _this.record_code = 0;
    _this.orderBy = 'id desc';
    _this.need_save_data_list = [];
    _this.moment = moment_default.a;
    _this.editRow = {
      id: null
    };
    _this.groupbyList = [];
    _this.columnList = [];
    _this.allNameAuth = [];
    return _this;
  }

  AmazonListingTotal.prototype.switchCodeName = function (list, value) {
    var ret = value;
    var item = list.find(function (x) {
      return x.code == value;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  AmazonListingTotal.prototype.uploadFile = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/system_api/upload?inner_action=/amazon/import_excel_modify_record&menu_code=' + common_service["a" /* CommonService */].getMenuCode(),
      fileExt: '.xlsx,.xls',
      attachmentUrlPath: '/system/download_import_template?type=AmazonListingImport'
    }, {
      title: this.$t('action.excel_import')
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.selectedRowKeys = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.open_url = function (record) {
    var url = 'https://www.amazon.de/dp/' + record.amazon_asin;
    window.open(url);
  };

  AmazonListingTotal.prototype.swichStateName = function (value, value_list) {
    var ret = value;
    var item = value_list.find(function (x) {
      return x.code == value;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  Object.defineProperty(AmazonListingTotal.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  AmazonListingTotal.prototype.created = function () {
    this.getSystemuser();
  };

  AmazonListingTotal.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  AmazonListingTotal.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  AmazonListingTotal.prototype.getAmazonStockPrice = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var fuzzy_search_value = values['fuzzy_search_value'];

      if (fuzzy_search_value) {
        var fuzzy_search_code = values['fuzzy_search_code'];
        var search_field_name = 'amazon_sku';

        switch (fuzzy_search_code) {
          case 10:
            search_field_name = 'amazon_sku';
            break;

          case 20:
            search_field_name = 'cn_category';
            break;

          case 30:
            search_field_name = 'cn_sub_category';
            break;

          case 40:
            search_field_name = 'product_price_sku';
            break;

          case 50:
            search_field_name = 'basic_product_sku';
            break;

          default:
            search_field_name = 'amazon_sku';
        }

        values[search_field_name] = fuzzy_search_value;
      }

      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        amazon_sku: 'like',
        cn_category: 'like',
        cn_sub_category: 'like',
        product_price_sku: 'like',
        basic_product_sku: 'ilike'
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            var startDate = {};

            for (var key in item.value[0]) {
              startDate[key] = item.value[0][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(startDate.utc())
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            var endDate = {};

            for (var key in item.value[1]) {
              endDate[key] = item.value[1][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(endDate.utc())
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI('/amazon/query_stock_price_all', common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  AmazonListingTotal.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  AmazonListingTotal.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getAmazonStockPrice();
  };

  AmazonListingTotal.prototype.onRowClick = function (row) {
    var info = this.data.find(function (x) {
      return x.id === row;
    });
    this.editRow = {
      id: row
    };
    this.record_code = row;
  };

  AmazonListingTotal.prototype.getEditTextChangedStyle = function (row, column) {
    if (column == 'write_standard_price' || column == 'write_discount_price' || column == 'discount_start' || column == 'discount_end' || column == 'critical_value' || column == 'from_value' || column == 'to_value' || column == 'pull_off_value') {
      if (row.hasOwnProperty(column + '_changed')) {
        return 'text-align:right;background-color:yellow;font-weight:bolder';
      }

      return 'text-align:right';
    }

    return 'text-align:right';
  };

  AmazonListingTotal.prototype.save_changed_data = function () {
    var _this = this;

    if (this.need_save_data_list.length == 0) {
      this.$message.info('没有需要保存的数据。');
      return;
    }

    this.innerAction.setActionAPI('amazon_management/batch_save_stock_price', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      change_schedule_data_list: this.need_save_data_list
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.reset_data();

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  AmazonListingTotal.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target != undefined && value.target.value != undefined) {
        value = value.target.value;
      }
    }

    if (row[column] != value) {
      row[column] = value;

      if (column == 'write_standard_price') {
        row.write_standard_price_changed = true;
        var exists_item_1 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_1) {
          exists_item_1['write_standard_price'] = value;
        } else {
          this.need_save_data_list.push({
            price_id: row.price_id,
            id: row.id,
            write_standard_price: value
          });
        }
      } else if (column == 'write_discount_price') {
        row.write_discount_price_changed = true;
        var exists_item_2 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_2) {
          exists_item_2['write_discount_price'] = value;
        } else {
          this.need_save_data_list.push({
            price_id: row.price_id,
            id: row.id,
            write_discount_price: value
          });
        }
      } else if (column == 'discount_start') {
        row.discount_start_changed = true;
        var exists_item_3 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_3) {
          exists_item_3['discount_start'] = value;
        } else {
          this.need_save_data_list.push({
            price_id: row.price_id,
            id: row.id,
            discount_start: value
          });
        }
      } else if (column == 'discount_end') {
        row.discount_end_changed = true;
        var exists_item_4 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_4) {
          exists_item_4['discount_end'] = value;
        } else {
          this.need_save_data_list.push({
            price_id: row.price_id,
            id: row.id,
            discount_end: value
          });
        }
      } else if (column == 'critical_value') {
        row.critical_value_changed = true;
        var exists_item_5 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_5) {
          exists_item_5['critical_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            price_id: row.price_id,
            critical_value: value
          });
        }
      } else if (column == 'from_value') {
        row.from_value_changed = true;
        var exists_item_6 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_6) {
          exists_item_6['from_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            price_id: row.price_id,
            from_value: value
          });
        }
      } else if (column == 'to_value') {
        row.to_value_changed = true;
        var exists_item_7 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_7) {
          exists_item_7['to_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            price_id: row.price_id,
            to_value: value
          });
        }
      } else if (column == 'pull_off_value') {
        row.pull_off_value_changed = true;
        var exists_item_8 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_8) {
          exists_item_8['pull_off_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            price_id: row.price_id,
            pull_off_value: value
          });
        }
      }
    }

    var newdata = tslib_es6["a" /* __assign */]({}, this.editRow);

    newdata[column] = value;
    this.editRow = newdata;
  };

  AmazonListingTotal.prototype.getBaseProductInfo = function (row) {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/update_amazon_listing_bp_info', common_service["a" /* CommonService */].getMenuCode('amazon-listing-price'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.getProductPrice = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/update_amazon_listing_product_price', common_service["a" /* CommonService */].getMenuCode('amazon-listing-price'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.writeBackPrice = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/write_back_price', common_service["a" /* CommonService */].getMenuCode('amazon-listing-price'));
    var price_id_list = [];
    this.selectedRowKeys.forEach(function (value) {
      price_id_list.push(_this.data.filter(function (item) {
        return value === item.id;
      })[0].price_id);
    });
    this.publicService.modify(new http["RequestParams"]({
      listing_id_list: price_id_list
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.computeNeedMerge = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/compute_need_merge', common_service["a" /* CommonService */].getMenuCode('amazon-listing-price'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  AmazonListingTotal.prototype.reset_data = function () {
    for (var index in this.need_save_data_list) {
      var item = this.need_save_data_list[index];
      var obj = this.data.find(function (x) {
        return x.id === item.id;
      });

      if (obj && obj.hasOwnProperty('write_standard_price_changed')) {
        delete obj.write_standard_price_changed;
      }

      if (obj && obj.hasOwnProperty('write_discount_price_changed')) {
        delete obj.write_discount_price_changed;
      }

      if (obj && obj.hasOwnProperty('discount_start_changed')) {
        delete obj.discount_start_changed;
      }

      if (obj && obj.hasOwnProperty('discount_end_changed')) {
        delete obj.discount_end_changed;
      }

      if (obj && obj.hasOwnProperty('critical_value_changed')) {
        delete obj.critical_value_changed;
      }

      if (obj && obj.hasOwnProperty('from_value_changed')) {
        delete obj.from_value_changed;
      }

      if (obj && obj.hasOwnProperty('to_value_changed')) {
        delete obj.to_value_changed;
      }

      if (obj && obj.hasOwnProperty('pull_off_value_changed')) {
        delete obj.pull_off_value_changed;
      }
    }

    this.need_save_data_list = [];
  };

  AmazonListingTotal.prototype.discard_changed_data = function () {
    this.reset_data();
  };

  AmazonListingTotal.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  AmazonListingTotal.prototype.showLog = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('每次只能查看一条数据的日志');
      return;
    }

    this.$modal.open(log_view["a" /* default */], {
      object_name: 'amazon_listing',
      is_special_table: false,
      record_code: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showlog'),
      width: '1000px'
    }).subscribe(function () {//
    }, function (err) {
      _this.$message.error('error');
    });
  };

  AmazonListingTotal.prototype.mergeUser = function () {
    var _this = this;

    var price_id_list = [];
    this.selectedRowKeys.forEach(function (value) {
      price_id_list.push(_this.data.filter(function (item) {
        return value === item.id;
      })[0].price_id);
    });
    this.amazonListingStockService.mergeUser(new http["RequestParams"]({
      amazon_listing_id_list: this.selectedRowKeys,
      price_id_list: price_id_list
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('标注用户成功!');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.mergeAuto = function () {
    var _this = this;

    this.amazonListingStockService.mergeAuto(new http["RequestParams"]({
      amazon_listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('标注Auto成功!');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.cancelAuto = function () {
    var _this = this;

    this.amazonListingStockService.cancelAuto(new http["RequestParams"]({
      amazon_listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('取消Auto成功!');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingTotal.prototype.writeBackInventory = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('amazon_management/write_back_inventory', common_service["a" /* CommonService */].getMenuCode('amazon-listing-total'));
    var stock_id_list = [];
    this.selectedRowKeys.forEach(function (value) {
      stock_id_list.push(_this.data.filter(function (item) {
        return value === item.id;
      })[0].id);
    });
    this.publicService.modify(new http["RequestParams"]({
      listing_id_list: stock_id_list
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getAmazonStockPrice();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], AmazonListingTotal.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], AmazonListingTotal.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AmazonListingTotal.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AmazonListingTotal.prototype, "getSystemuser", void 0);

  AmazonListingTotal = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'amazon-listing-total'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      CommonPage: common_page["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], AmazonListingTotal);
  return AmazonListingTotal;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var amazon_listing_totalvue_type_script_lang_ts_ = (amazon_listing_totalvue_type_script_lang_ts_AmazonListingTotal);
// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-total.vue?vue&type=script&lang=ts&
 /* harmony default export */ var amazon_amazon_listing_totalvue_type_script_lang_ts_ = (amazon_listing_totalvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/amazon/amazon-listing-total.vue?vue&type=custom&index=0&blockType=i18n
var amazon_listing_totalvue_type_custom_index_0_blockType_i18n = __webpack_require__("2ba6");

// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-total.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  amazon_amazon_listing_totalvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof amazon_listing_totalvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(amazon_listing_totalvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var amazon_listing_total = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "caf6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_instock_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("320b");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_instock_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_instock_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_aliexpress_instock_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ceb5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_reference_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("31f6");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_reference_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_reference_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "d0b1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/amazon-listing-stock.vue?vue&type=template&id=4212cfe1&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",on:{"changeSearchState":_vm.showHideSearch}},[_c('data-form',{ref:"dataForm",attrs:{"column":1,"showSearch":_vm.showSearch},on:{"submit":_vm.getAmazonListingStockList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.import_time')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['import_time']),expression:"['import_time']"}],attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.write_back_time')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['write_back_time']),expression:"['write_back_time']"}],attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.amazon_sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['amazon_sku']),expression:"['amazon_sku']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.basic_product_sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['basic_product_sku']),expression:"['basic_product_sku']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.mergeUser()}}},[_vm._v(_vm._s(_vm.$t('action.merge_user'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.mergeAuto()}}},[_vm._v(_vm._s(_vm.$t('action.merge_auto'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.cancelAuto()}}},[_vm._v(_vm._s(_vm.$t('action.cancel_auto'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.save()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"id","scroll":{ y: 360, x: 3000 },"rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, select_rows) {
                    _vm.selectedRows = select_rows
                    _vm.selectedRowKeys = keys
                }
            }},on:{"on-page-change":_vm.getAmazonListingStockList,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                    _vm.onTrClick(record)
                }}},[_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('columns.actions'),"width":60,"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.OnEdit(row)}}},[_vm._v(_vm._s(_vm.$t('action.edit')))])]}}])}),_c('a-table-column',{key:"import_time",attrs:{"title":_vm.$t('columns.import_time'),"align":"left","dataIndex":"import_time"},scopedSlots:_vm._u([{key:"default",fn:function(import_time){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(import_time))+" ")]}}])}),_c('a-table-column',{key:"compute_time",attrs:{"title":_vm.$t('columns.compute_time'),"align":"right","dataIndex":"compute_time"},scopedSlots:_vm._u([{key:"default",fn:function(compute_time){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(compute_time))+" ")]}}])}),_c('a-table-column',{key:"write_back_time",attrs:{"title":_vm.$t('columns.write_back_time'),"align":"left","dataIndex":"write_back_time"},scopedSlots:_vm._u([{key:"default",fn:function(write_back_time){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(write_back_time))+" ")]}}])}),_c('a-table-column',{key:"amazon_sku",attrs:{"title":_vm.$t('columns.amazon_sku'),"align":"left","dataIndex":"amazon_sku"}}),_c('a-table-column',{key:"amazon_asin",attrs:{"title":_vm.$t('columns.amazon_asin'),"align":"left","dataIndex":"amazon_asin"}}),_c('a-table-column',{key:"amazon_price",attrs:{"title":_vm.$t('columns.amazon_price'),"align":"left","dataIndex":"amazon_price"}}),_c('a-table-column',{key:"instance_id",attrs:{"title":_vm.$t('columns.instance_id'),"align":"left","dataIndex":"instance_id"}}),_c('a-table-column',{key:"user_id",attrs:{"title":_vm.$t('columns.user_id'),"align":"left","dataIndex":"user_id"}}),_c('a-table-column',{key:"basic_product_sku",attrs:{"title":_vm.$t('columns.basic_product_sku'),"align":"left","dataIndex":"basic_product_sku"}}),_c('a-table-column',{key:"basic_related_qty",attrs:{"title":_vm.$t('columns.basic_related_qty'),"align":"left","dataIndex":"basic_related_qty"}}),_c('a-table-column',{key:"category",attrs:{"title":_vm.$t('columns.category'),"align":"left","dataIndex":"category"}}),_c('a-table-column',{key:"sub_category",attrs:{"title":_vm.$t('columns.sub_category'),"align":"left","dataIndex":"sub_category"}}),_c('a-table-column',{key:"auto_state",attrs:{"title":_vm.$t('columns.auto_state'),"align":"left","dataIndex":"auto_state"}}),_c('a-table-column',{key:"warehouse",attrs:{"title":_vm.$t('columns.warehouse'),"align":"left","dataIndex":"warehouse"}}),_c('a-table-column',{key:"basic_odoo_stock",attrs:{"title":_vm.$t('columns.basic_odoo_stock'),"align":"left","dataIndex":"basic_odoo_stock"}}),_c('a-table-column',{key:"odoo_stock",attrs:{"title":_vm.$t('columns.odoo_stock'),"align":"left","dataIndex":"odoo_stock"}}),_c('a-table-column',{key:"critical_value",attrs:{"title":_vm.$t('columns.critical_value'),"align":"left","dataIndex":"critical_value"}}),_c('a-table-column',{key:"from_value",attrs:{"title":_vm.$t('columns.from_value'),"align":"left","dataIndex":"from_value"}}),_c('a-table-column',{key:"to_value",attrs:{"title":_vm.$t('columns.to_value'),"align":"left","dataIndex":"to_value"}}),_c('a-table-column',{key:"pull_off_value",attrs:{"title":_vm.$t('columns.pull_off_value'),"align":"left","dataIndex":"pull_off_value"}}),_c('a-table-column',{key:"write_back_value",attrs:{"title":_vm.$t('columns.write_back_value'),"align":"left","dataIndex":"write_back_value"}}),_c('a-table-column',{key:"history_write_back_value",attrs:{"title":_vm.$t('columns.history_write_back_value'),"align":"left","dataIndex":"history_write_back_value"}}),_c('a-table-column',{key:"average_sale_num",attrs:{"title":_vm.$t('columns.average_sale_num'),"align":"left","dataIndex":"average_sale_num"}})],1)],1),(_vm.selectedRows[0])?_c('a-card',[_c('LogView',{attrs:{"object_name":_vm.object_name,"record_code":_vm.record_code}})],1):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-stock.vue?vue&type=template&id=4212cfe1&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/amazon_listing_stock.service.ts
var amazon_listing_stock_service = __webpack_require__("8ba7");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/components/product/amazon-listing-edit.vue + 4 modules
var amazon_listing_edit = __webpack_require__("31fb");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/amazon-listing-stock.vue?vue&type=script&lang=ts&

















var datasModule = Object(lib["c" /* namespace */])('datasModule');
var userModule = Object(lib["c" /* namespace */])('userModule');

var amazon_listing_stockvue_type_script_lang_ts_AmazonListingStockManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AmazonListingStockManage, _super);

  function AmazonListingStockManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.amazonListingStockService = new amazon_listing_stock_service["a" /* AmazonListingStockService */](); // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */](); // 表格数据源

    _this.data = [];
    _this.object_name = 'amazon_listing_stock';
    _this.record_code = ''; // 表格选择项

    _this.selectedRowKeys = [];
    _this.selectedRows = [];
    _this.moment = moment_default.a;
    _this.userDict = {};
    _this.showSearch = true;
    return _this;
  }

  AmazonListingStockManage.prototype.showHideSearch = function (flag) {
    this.showSearch = flag;
  };

  AmazonListingStockManage.prototype.created = function () {
    var _this = this;

    this.getSystemuser();
    this.systemUsers.map(function (x) {
      return _this.userDict[x.code] = x.name;
    });
  };

  AmazonListingStockManage.prototype.mounted = function () {};

  AmazonListingStockManage.prototype.getAmazonListingStockList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        amazon_sku: 'ilike',
        basic_product_sku: 'ilike'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array) {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      params.query_condition = nowConditions;

      _this.amazonListingStockService.queryAll(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
          var item_1 = data_1[_i];
          item_1['import_time_start'] = moment_default.a.parseZone(item_1['import_time']).local().format('YYYY-MM-DD HH:mm:ss');
          item_1['import_time_end'] = moment_default.a.parseZone(item_1['write_back_time']).local().format('YYYY-MM-DD HH:mm:ss');
        }

        _this.data = data;
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  AmazonListingStockManage.prototype.OnEdit = function (row) {
    var _this = this;

    this.$modal.open(amazon_listing_edit["a" /* default */], {
      saveFlag: 1,
      row: row
    }, {
      title: 'Edit Amazon Listing Stock: ' + row.amazon_sku
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getAmazonListingStockList();
    });
  };

  AmazonListingStockManage.prototype.mergeUser = function () {
    var _this = this;

    this.amazonListingStockService.mergeUser(new http["RequestParams"]({
      amazon_listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('认领Listing成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingStockManage.prototype.mergeAuto = function () {
    var _this = this;

    this.amazonListingStockService.mergeAuto(new http["RequestParams"]({
      amazon_listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('标注Auto成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AmazonListingStockManage.prototype.cancelAuto = function () {
    var _this = this;

    this.amazonListingStockService.cancelAuto(new http["RequestParams"]({
      amazon_listing_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('取消Auto成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], AmazonListingStockManage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], AmazonListingStockManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AmazonListingStockManage.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AmazonListingStockManage.prototype, "getSystemuser", void 0);

  AmazonListingStockManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'amazon-listing-stock-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */]
    }
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AmazonListingEdit: amazon_listing_edit["a" /* default */]
    }
  })], AmazonListingStockManage);
  return AmazonListingStockManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var amazon_listing_stockvue_type_script_lang_ts_ = (amazon_listing_stockvue_type_script_lang_ts_AmazonListingStockManage);
// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-stock.vue?vue&type=script&lang=ts&
 /* harmony default export */ var amazon_amazon_listing_stockvue_type_script_lang_ts_ = (amazon_listing_stockvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/amazon/amazon-listing-stock.vue?vue&type=custom&index=0&blockType=i18n
var amazon_listing_stockvue_type_custom_index_0_blockType_i18n = __webpack_require__("ad28");

// CONCATENATED MODULE: ./src/pages/amazon/amazon-listing-stock.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  amazon_amazon_listing_stockvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof amazon_listing_stockvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(amazon_listing_stockvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var amazon_listing_stock = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "d737":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Sale Trend","columns":{"warehouse_id":"warehouse_id","year":"Year","jan_value":"January","feb_value":"February","mar_value":"March","apr_value":"April","may_value":"May","jun_value":"June","jul_value":"July","aug_value":"August","sep_value":"September","oct_value":"October","nov_value":"November","dec_value":"December","cn_sub_category":"cn_sub_category","presale_type":"Trend Type"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","cancel":"Cancel","import_product_sale_trend":"Import","more":"More"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"销售趋势","columns":{"warehouse_id":"仓库","year":"年份","jan_value":"一月","feb_value":"二月","mar_value":"三月","apr_value":"四月","may_value":"五月","jun_value":"六月","jul_value":"七月","aug_value":"八月","sep_value":"九月","oct_value":"十月","nov_value":"十一月","dec_value":"十二月","cn_sub_category":"中文子类","presale_type":"趋势类型"},"action":{"create":"新建","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","import_product_sale_trend":"导入","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "dcd5":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":""},"zh-cn":{"desc":""}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "de64":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"seller_code":"Seller Code","modified_date":"Modified Date"},"action":{"import_orders":"Import Orders","fulfil_orders":"Fulfil Orders"},"rules":{"date_range_error":"start date can\u0027t later start date"},"import_success":"Import Success","fulfil_success":"Fulfil Success"},"zh-cn":{"columns":{"seller_code":"店铺","modified_date":"订单起止日期"},"action":{"import_orders":"手动导入订单","fulfil_orders":"速卖通手动结单"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"import_success":"导入订单成功","fulfil_success":"速卖通结单成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "dff1":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"presale_type":"presale_type","warehouse_id":"warehouse_id","presale_object":"presale_object","is_presale":"Is Presale","is_second_presale":"Is Second Presale","presale_ratio":"Presale_ratio","presale_days":"Presale_days","purchase_cycle":"Purchase Cycle","sale_cycle":"Sale Cycle"},"action":{"create":"Create","copy":"Copy","edit":"Edit","delete":"Delete","ok":"Ok","cancel":"Cancel","more":"More"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"","columns":{"presale_type":"预售类型","warehouse_id":"仓库","presale_object":"预售设置对象","is_presale":"第一期预售","is_second_presale":"第二期预售","presale_ratio":"预售系数","presale_days":"预售天数","purchase_cycle":"采购周期/天","sale_cycle":"销售周期/天"},"action":{"create":"新建","copy":"复制","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "e5a6":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"ebay_sku":"sku","cn_category":"Chinese Category","cn_sub_category":"Chinese Sub Category","product_price_sku":"product price sku","state":"state","warning_state":"warning state","active_state":"active state","merge_user_id":"merge user","import_time":"Import Time","merge_time":"merge time","write_back_time":"Write Back Time","standard_price":"standard price","business_price":"business price","instance_id":"Instance ID","product_price":"product price","product_related_qty":"product related qty","write_standard_price":"write standard price","write_discount_price":"write discount price","discount_start":"discount start","discount_end":"discount end","ebay_price":"Ebay Price","compute_time":"Compute Time","user_id":"User ID","basic_product_sku":"Basic Product SKU","basic_related_qty":"Basic Related Qty","category":"Category","sub_category":"Sub category","basic_odoo_stock":"Basic Odoo Stock","ebay_stock":"Amazon Stock","odoo_stock":"Odoo Stock","critical_value":"Critical Value","from_value":"From Value","to_value":"To value","pull_off_value":"Pull off value","write_back_value":"Write Back Value","history_write_back_value":"History WB","auto_state":"Auto State","warehouse":"Warehouse","average_sale_num":"Average Sale Num","parent_sku":"Parent Sku","listing_status":"Listing Status","variations_status":"Variations Status","pre_sale":"Pre Sale"},"dict":{"all":"All","draft":"Draft","lower_warning":"lower Warning","upper_warning":"upper warning","safe":"safe","active":"active","inactive":"inactive","need_merge":"need merge","merged":"merged","write_back":"write back"},"action":{"actions":"actions","create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","save":"Save","cancel":"Cancel","confirm":"Confirm","export":"Export Excel","import":"Import Excel","view_logs":"Logs","more":"More","discard":"discard","showlog":"View Log","change_ebay_merge_user":"Change Operator","change_status":"Change Auto Status","set_pre_end_listing":"Pre End Listing","compute_listing":"Compute Listing","export_to_ebay":"Export To Ebay","excel_import":"Upload Excel"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"ebay_sku":"Ebay sku","cn_category":"中文分类","cn_sub_category":"中文子类","product_price_sku":"有核价产品","state":"状态","warning_state":"预警状态","active_state":"监听状态","merge_user_id":"标记管理人","import_time":"导入时间","merge_time":"标记时间","write_back_time":"写回时间","standard_price":"正常价格","business_price":"business价格","instance_id":"Instance","product_price":"核价产品价格","product_related_qty":"亚马逊产品和核价产品数量对应关系","write_standard_price":"需回写标准价格","write_discount_price":"需回写折扣价格","discount_start":"折扣开始时间","discount_end":"折扣结束时间","compute_time":"计算时间","ebay_price":"Ebay售价","user_id":"用户","basic_product_sku":"基础SKU","basic_related_qty":"基础数量","category":"分类","sub_category":"子类","basic_odoo_stock":"基础库存","ebay_stock":"Ebay库存","odoo_stock":"Odoo库存","critical_value":"临界值","from_value":"From值","to_value":"To值","pull_off_value":"下架值","write_back_value":"写回值","history_write_back_value":"历史写回值","auto_state":"托管状态","warehouse":"仓库","average_sale_num":"平均销量","parent_sku":"父货号","listing_status":"Listing状态","variations_status":"变化状态","pre_sale":"预售"},"dict":{"all":"全部","draft":"草稿","lower_warning":"低价预警","upper_warning":"高价预警","safe":"安全","active":"激活","inactive":"未激活","need_merge":"需标记","merged":"已标记","write_back":"回写价格"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"action":{"actions":"手动操作","create":"新建","edit":"编辑","delete":"删除","ok":"确定","save":"保存","cancel":"取消","confirm":"确认","export":"导出Excel","import":"导入Excel","view_logs":"日志","more":"更多操作","discard":"丢弃","showlog":"查看日志","change_ebay_merge_user":"修改运营","change_status":"修改托管状态","set_pre_end_listing":"Pre End Listing","compute_listing":"计算Listing","export_to_ebay":"导出到Ebay","excel_import":"上传"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "ea25":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/account-page2.vue?vue&type=template&id=afeabe0a&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',[_vm._v("AccountPage2")])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/accounts/account-page2.vue?vue&type=template&id=afeabe0a&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/accounts/account-page2.vue?vue&type=script&lang=ts&




var account_page2vue_type_script_lang_ts_AccountPage2 =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AccountPage2, _super);

  function AccountPage2() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  AccountPage2 = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    name: 'account-page2',
    layout: 'workspace'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AccountPage2);
  return AccountPage2;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var account_page2vue_type_script_lang_ts_ = (account_page2vue_type_script_lang_ts_AccountPage2);
// CONCATENATED MODULE: ./src/pages/accounts/account-page2.vue?vue&type=script&lang=ts&
 /* harmony default export */ var accounts_account_page2vue_type_script_lang_ts_ = (account_page2vue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// CONCATENATED MODULE: ./src/pages/accounts/account-page2.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  accounts_account_page2vue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* harmony default export */ var account_page2 = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "eb60":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "f23a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_feedback_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("aa1a");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_feedback_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_requirement_schedule_feedback_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "f832":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ebay_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("e5a6");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ebay_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ebay_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ebay_listing_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "fa38":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/ebay-listing-stock.vue?vue&type=template&id=528dd4cc&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getEbayListingStock},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 10 }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 10 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('columns.ebay_sku'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('columns.category'))+" ")]),_c('a-select-option',{attrs:{"value":30}},[_vm._v(" "+_vm._s(_vm.$t('columns.sub_category'))+" ")]),_c('a-select-option',{attrs:{"value":40}},[_vm._v(" "+_vm._s(_vm.$t('columns.parent_sku'))+" ")]),_c('a-select-option',{attrs:{"value":50}},[_vm._v(" "+_vm._s(_vm.$t('columns.basic_product_sku'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.listing_status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'listing_status',
                        { initialValue: 'Active' }
                    ]),expression:"[\n                        'listing_status',\n                        { initialValue: 'Active' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":"Active"}},[_vm._v(" Active ")]),_c('a-radio-button',{attrs:{"value":"Ended"}},[_vm._v(" Ended ")]),_c('a-radio-button',{attrs:{"value":"Completed"}},[_vm._v(" Completed ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.merge_user_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["user_id"]),expression:"[`user_id`]"}],staticStyle:{"width":"300px"},attrs:{"showSearch":"","placeholder":_vm.$t('plzSelect'),"size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.variations_status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'variations_status',
                        { initialValue: '' }
                    ]),expression:"[\n                        'variations_status',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.pre_sale')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pre_sale', { initialValue: '' }]),expression:"['pre_sale', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.auto_state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['auto_state', { initialValue: true }]),expression:"['auto_state', { initialValue: true }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["warehouse"]),expression:"[`warehouse`]"}],staticStyle:{"width":"300px"},attrs:{"showSearch":"","placeholder":_vm.$t('plzSelect'),"size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-select-option',{attrs:{"value":"DE"}},[_vm._v(" DE ")]),_c('a-select-option',{attrs:{"value":"UK"}},[_vm._v(" UK ")])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.change_ebay_merge_user()}}},[_vm._v(_vm._s(_vm.$t('action.change_ebay_merge_user'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.change_status()}}},[_vm._v(_vm._s(_vm.$t('action.change_status'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.set_pre_end_listing()}}},[_vm._v(_vm._s(_vm.$t('action.set_pre_end_listing'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.compute_listing()}}},[_vm._v(_vm._s(_vm.$t('action.compute_listing'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.export_to_ebay()}}},[_vm._v(_vm._s(_vm.$t('action.export_to_ebay'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.save_changed_data()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getEbayListingStock,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"date_ranger",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_id",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_id']),expression:"['user_id']"}],style:({ width: '85px' }),attrs:{"showSearch":"","dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small","placeholder":"Select User","filterOption":_vm.filterSelectOption},on:{"change":function (e) { return _vm.onRowChange(row, 'user_id', e); }},model:{value:(row.user_id),callback:function ($$v) {_vm.$set(row, "user_id", $$v)},expression:"row.user_id"}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code,"title":item.name}},[_vm._v(_vm._s(item.name)+" ")])}),1):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"from_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['from_value']),expression:"['from_value']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.from_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'from_value', e); }}}):_c('span',[_vm._v(_vm._s(row.from_value))])]}},{key:"to_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['to_value']),expression:"['to_value']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.to_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'to_value', e); }}}):_c('span',[_vm._v(_vm._s(row.to_value))])]}},{key:"pull_off_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pull_off_value']),expression:"['pull_off_value']"}],style:({
                            width: '100%'
                        }),attrs:{"decimalSeparator":",","value":row.pull_off_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'pull_off_value', e); }}}):_c('span',[_vm._v(_vm._s(row.pull_off_value))])]}},{key:"auto_state",fn:function(text, row){return [(row.auto_state)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}},{key:"variations_status",fn:function(text, row){return [(row.variations_status)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}}],null,false,3106793495)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"date_ranger",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_id",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_id']),expression:"['user_id']"}],style:({ width: '85px' }),attrs:{"showSearch":"","dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small","placeholder":"Select User","filterOption":_vm.filterSelectOption},on:{"change":function (e) { return _vm.onRowChange(row, 'user_id', e); }}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code,"title":item.name}},[_vm._v(_vm._s(item.name)+" ")])}),1):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"from_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['from_value']),expression:"['from_value']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.from_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'from_value', e); }}}):_c('span',[_vm._v(_vm._s(row.from_value))])]}},{key:"to_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['to_value']),expression:"['to_value']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.to_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'to_value', e); }}}):_c('span',[_vm._v(_vm._s(row.to_value))])]}},{key:"pull_off_value",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pull_off_value']),expression:"['pull_off_value']"}],style:({
                        width: '100%'
                    }),attrs:{"decimalSeparator":",","value":row.pull_off_value,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'pull_off_value', e); }}}):_c('span',[_vm._v(_vm._s(row.pull_off_value))])]}},{key:"auto_state",fn:function(text, row){return [(row.auto_state)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}},{key:"variations_status",fn:function(text, row){return [(row.variations_status)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/amazon/ebay-listing-stock.vue?vue&type=template&id=528dd4cc&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/components/ebay/ebay-listing-form-edit.vue + 4 modules
var ebay_listing_form_edit = __webpack_require__("b90b");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/amazon/ebay-listing-stock.vue?vue&type=script&lang=ts&























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var ebay_listing_stockvue_type_script_lang_ts_EbayListingStock =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](EbayListingStock, _super);

  function EbayListingStock() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.defaultBoolValue = '';
    _this.queryUrl = '/ebay/query_ebay_listing'; // private uploadFile() {
    //     this.$modal
    //         .open(
    //             UploadExcel,
    //             {
    //                 urlPath:
    //                     '/system_api/upload?inner_action=/amazon/import_excel_modify_record&menu_code=' +
    //                     CommonService.getMenuCode(),
    //                 fileExt: '.xlsx,.xls',
    //                 attachmentUrlPath:
    //                     '/system/download_import_template?type=AmazonListingImport'
    //             },
    //             {
    //                 title: this.$t('action.excel_import')
    //             }
    //         )
    //         .subscribe(
    //             data => {
    //                 this.$message.success('操作成功')
    //                 this.selectedRowKeys = []
    //             },
    //             err => {
    //                 this.$message.error(err.message)
    //             }
    //         )
    // }

    _this.record_code = 0;
    _this.orderBy = 'id desc';
    _this.need_save_data_list = [];
    _this.moment = moment_default.a;
    _this.editRow = {
      id: null
    };
    _this.groupbyList = [];
    _this.columnList = [];
    _this.allNameAuth = [];
    return _this;
  }

  Object.defineProperty(EbayListingStock.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  EbayListingStock.prototype.created = function () {
    this.getSystemuser();
  };

  EbayListingStock.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  EbayListingStock.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  EbayListingStock.prototype.getEbayListingStock = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var fuzzy_search_value = values['fuzzy_search_value'];

      if (fuzzy_search_value) {
        var fuzzy_search_code = values['fuzzy_search_code'];
        var search_field_name = 'ebay_sku';

        switch (fuzzy_search_code) {
          case 10:
            search_field_name = 'ebay_sku';
            break;

          case 20:
            search_field_name = 'category';
            break;

          case 30:
            search_field_name = 'sub_category';
            break;

          case 40:
            search_field_name = 'parent_sku';
            break;

          case 50:
            search_field_name = 'basic_product_sku';
            break;

          default:
            search_field_name = 'ebay_sku';
        }

        values[search_field_name] = fuzzy_search_value;
      }

      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        ebay_sku: 'like',
        cn_category: 'like',
        cn_sub_category: 'like',
        search_field_name: 'like',
        basic_product_sku: 'ilike'
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            var startDate = {};

            for (var key in item.value[0]) {
              startDate[key] = item.value[0][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(startDate.utc())
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            var endDate = {};

            for (var key in item.value[1]) {
              endDate[key] = item.value[1][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(endDate.utc())
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  EbayListingStock.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  EbayListingStock.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getEbayListingStock();
  };

  EbayListingStock.prototype.onRowClick = function (row) {
    var info = this.data.find(function (x) {
      return x.id === row;
    });
    this.editRow = {
      id: row
    };
    this.record_code = row;
  };

  EbayListingStock.prototype.getEditTextChangedStyle = function (row, column) {
    if (column == 'user_id' || column == 'critical_value' || column == 'from_value' || column == 'to_value' || column == 'pull_off_value') {
      if (row.hasOwnProperty(column + '_changed')) {
        return 'text-align:right;background-color:yellow;font-weight:bolder';
      }

      return 'text-align:right';
    }

    return 'text-align:right';
  };

  EbayListingStock.prototype.save_changed_data = function () {
    var _this = this;

    if (this.need_save_data_list.length == 0) {
      this.$message.info('没有需要保存的数据。');
      return;
    }

    this.innerAction.setActionAPI('/ebay/modify_listing', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      change_schedule_data_list: this.need_save_data_list
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.reset_data();

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  EbayListingStock.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target != undefined && value.target.value != undefined) {
        value = value.target.value;
      }
    }

    if (column == 'user_id') {
      row.user_id_changed = true;
      var exists_item_1 = this.need_save_data_list.find(function (x) {
        return x.id == row.id;
      });

      if (exists_item_1) {
        exists_item_1['user_id'] = value;
      } else {
        this.need_save_data_list.push({
          id: row.id,
          user_id: value
        });
      }
    }

    if (row[column] != value) {
      row[column] = value;

      if (column == 'critical_value') {
        row.critical_value_changed = true;
        var exists_item_5 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_5) {
          exists_item_5['critical_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            critical_value: value
          });
        }
      } else if (column == 'from_value') {
        row.from_value_changed = true;
        var exists_item_6 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_6) {
          exists_item_6['from_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            from_value: value
          });
        }
      } else if (column == 'to_value') {
        row.to_value_changed = true;
        var exists_item_7 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_7) {
          exists_item_7['to_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            to_value: value
          });
        }
      } else if (column == 'pull_off_value') {
        row.pull_off_value_changed = true;
        var exists_item_8 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_8) {
          exists_item_8['pull_off_value'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            pull_off_value: value
          });
        }
      }
    }

    var newdata = tslib_es6["a" /* __assign */]({}, this.editRow);

    newdata[column] = value;
    this.editRow = newdata;
  };

  EbayListingStock.prototype.set_pre_end_listing = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('/ebay/set_pre_end_listing', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getEbayListingStock();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  EbayListingStock.prototype.compute_listing = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('/ebay/compute_listing', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getEbayListingStock();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  EbayListingStock.prototype.export_to_ebay = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('/ebay/export_to_ebay', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getEbayListingStock();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  EbayListingStock.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  EbayListingStock.prototype.reset_data = function () {
    for (var index in this.need_save_data_list) {
      var item = this.need_save_data_list[index];
      var obj = this.data.find(function (x) {
        return x.id === item.id;
      });

      if (obj && obj.hasOwnProperty('user_id')) {
        delete obj.user_id;
      }

      if (obj && obj.hasOwnProperty('critical_value_changed')) {
        delete obj.critical_value_changed;
      }

      if (obj && obj.hasOwnProperty('from_value_changed')) {
        delete obj.from_value_changed;
      }

      if (obj && obj.hasOwnProperty('to_value_changed')) {
        delete obj.to_value_changed;
      }

      if (obj && obj.hasOwnProperty('pull_off_value_changed')) {
        delete obj.pull_off_value_changed;
      }
    }

    this.need_save_data_list = [];
  };

  EbayListingStock.prototype.discard_changed_data = function () {
    this.reset_data();
  };

  EbayListingStock.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  EbayListingStock.prototype.showLog = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('每次只能查看一条数据的日志');
      return;
    }

    this.$modal.open(log_view["a" /* default */], {
      object_name: 'amazon_listing',
      is_special_table: false,
      record_code: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showlog'),
      width: '1000px'
    }).subscribe(function () {//
    }, function (err) {
      _this.$message.error('error');
    });
  };

  EbayListingStock.prototype.change_ebay_merge_user = function () {
    var _this = this;

    if (this.selectedRowKeys.length == 0) {
      this.$message.error('必须选择至少一条记录');
      return;
    }

    this.$modal.open(ebay_listing_form_edit["a" /* default */], {
      systemUsers: this.systemUsers,
      id_list: this.selectedRowKeys,
      type: 'change_user'
    }, {
      title: this.$t('action.change_ebay_merge_user'),
      width: '1000px'
    }).subscribe(function () {
      _this.getEbayListingStock();
    }, function (err) {
      _this.$message.error('error');
    });
  };

  EbayListingStock.prototype.change_status = function () {
    var _this = this;

    if (this.selectedRowKeys.length == 0) {
      this.$message.error('必须选择至少一条记录');
      return;
    }

    this.$modal.open(ebay_listing_form_edit["a" /* default */], {
      id_list: this.selectedRowKeys,
      type: 'change_state'
    }, {
      title: this.$t('action.change_status'),
      width: '1000px'
    }).subscribe(function () {
      _this.getEbayListingStock();
    }, function (err) {
      _this.$message.error('error');
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], EbayListingStock.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], EbayListingStock.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], EbayListingStock.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], EbayListingStock.prototype, "getSystemuser", void 0);

  EbayListingStock = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'ebay-listing-stock'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      CommonPage: common_page["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      EbayLisitingFormEdit: ebay_listing_form_edit["a" /* default */]
    }
  })], EbayListingStock);
  return EbayListingStock;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var ebay_listing_stockvue_type_script_lang_ts_ = (ebay_listing_stockvue_type_script_lang_ts_EbayListingStock);
// CONCATENATED MODULE: ./src/pages/amazon/ebay-listing-stock.vue?vue&type=script&lang=ts&
 /* harmony default export */ var amazon_ebay_listing_stockvue_type_script_lang_ts_ = (ebay_listing_stockvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/amazon/ebay-listing-stock.vue?vue&type=custom&index=0&blockType=i18n
var ebay_listing_stockvue_type_custom_index_0_blockType_i18n = __webpack_require__("f832");

// CONCATENATED MODULE: ./src/pages/amazon/ebay-listing-stock.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  amazon_ebay_listing_stockvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof ebay_listing_stockvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(ebay_listing_stockvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var ebay_listing_stock = __webpack_exports__["default"] = (component.exports);

/***/ })

}]);