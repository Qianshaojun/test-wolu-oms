(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~5cdbb274"],{

/***/ "0759":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/reissue-detail.vue?vue&type=template&id=0fb4abe9&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 6 },"wrapperCol":{ span: 15, offset: 0 }},on:{"submit":_vm.getDetailList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.reissue_order_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['picking_name']),expression:"['picking_name']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.origin_order_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['origin_order_no']),expression:"['origin_order_no']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.origin_order_articlenumber')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['src_default_code']),expression:"['src_default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.manual_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['manual_code']),expression:"['manual_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.reissue_content')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('fuzzy_search')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.reissue_object')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['part_no']),expression:"['part_no']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('fuzzy_search')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category']),expression:"['z_category']"}],staticStyle:{"width":"100px"},attrs:{"placeholder":"品类","size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category']),expression:"['z_sub_category']"}],staticStyle:{"width":"200px","margin-left":"10px"},attrs:{"mode":"multiple","placeholder":"子类","size":"small"},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)]},proxy:true},{key:"collapse",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.reissue_type')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['resend_type', { initialValue: '' }]),expression:"['resend_type', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.ReissueType),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.customer_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['customer_reason']),expression:"['customer_reason']"}],style:({ width: '200px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.reasonList.customer_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.product_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_tag']),expression:"['sale_tag']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.productReasonList),function(i){return _c('a-select-option',{key:i,attrs:{"value":i,"title":i}},[_vm._v(" "+_vm._s(i)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.shipment_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['logistic_reason']),expression:"['logistic_reason']"}],style:({ width: '200px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.reasonList.logistic_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_reason']),expression:"['warehouse_reason']"}],style:({ width: '200px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.reasonList.warehouse_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_time')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['date_order']),expression:"['date_order']"}],attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.reissue_time')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['picking_date']),expression:"['picking_date']"}],attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.create_uid')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['create_uid', { initialValue: '' }]),expression:"['create_uid', { initialValue: '' }]"}],style:({ width: '300px' }),attrs:{"size":"small","showSearch":"","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.customerServiceUser),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])})],2)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 1560, y: 600 },"queryUrl":_vm.queryUrl,"menu_code":_vm.menu_code,"queryCondition":_vm.queryConsition,"selectedRowCnt":_vm.selectedRowKeys.length},on:{"on-page-change":_vm.getDetailList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onTrClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}}],null,false,4242965402)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":1560,"scrollY":600},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/reissue-detail.vue?vue&type=template&id=0fb4abe9&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.split.js
var es_string_split = __webpack_require__("1276");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/components/product/add-ocean-shipping-fee.vue + 4 modules
var add_ocean_shipping_fee = __webpack_require__("5629");

// EXTERNAL MODULE: ./src/services/user.service.ts
var user_service = __webpack_require__("2138");

// EXTERNAL MODULE: ./src/services/custom_problem.service.ts
var custom_problem_service = __webpack_require__("6a1c");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/reissue-detail.vue?vue&type=script&lang=ts&




























var userModule = Object(lib["c" /* namespace */])('userModule');
var allUsersModule = Object(lib["c" /* namespace */])('allUsersModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var reissue_detailvue_type_script_lang_ts_ReissueDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ReissueDetail, _super);

  function ReissueDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.userService = new user_service["a" /* UserService */]();
    _this.customProblemService = new custom_problem_service["a" /* CustomProblemService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = [];
    _this.customerServiceUser = [];
    _this.customerServiceUserDict = {}; // 表格选择项

    _this.selectedRowKeys = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.groupbyList = [];
    _this.allNameAuth = [];
    _this.columnList = [];
    _this.queryUrl = 'reports/query_all_resend_detail';
    _this.queryConsition = [];
    _this.orderBy = '';
    _this.menu_code = '';
    _this.productReasonList = [];
    return _this;
  }

  Object.defineProperty(ReissueDetail.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ReissueDetail.prototype.created = function () {
    this.getReasonList();
    this.getCustomerServiceUserList();
    this.getCn_cate();
    this.getProductReason(['']);
  };

  ReissueDetail.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
    this.menu_code = this.dataForm.menu_code;
  };

  ReissueDetail.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ReissueDetail.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  ReissueDetail.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ReissueDetail.prototype.getCustomerServiceUserList = function () {
    var _this = this;

    this.userService.customerServiceUser(new http["RequestParams"]({})).subscribe(function (data) {
      _this.customerServiceUser = data;

      for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
        var i = data_1[_i];
        _this.customerServiceUserDict[i.code] = i.name;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReissueDetail.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  ReissueDetail.prototype.getReasonList = function () {
    var _this = this;

    this.customProblemService.queryCpReasonEnum(new http["RequestParams"]({})).subscribe(function (data) {
      if (data.length) {
        _this.reasonList = data[0];
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };
  /**
   * 获取订单数据
   */


  ReissueDetail.prototype.getDetailList = function () {
    var _this = this;

    var params = {};
    this.getQueryCondition().then(function (nowConditions) {
      _this.queryConsition = nowConditions;

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.data = data.map(function (x, i) {
            x['id'] = i + 1;
            x.customer_reason = _this.getReason(x.customer_reason, 'customer');
            x.warehouse_reason = _this.getReason(x.warehouse_reason, 'warehouse');
            x.logistic_reason = _this.getReason(x.logistic_reason, 'logistic');
            return x;
          });
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ReissueDetail.prototype.onStatusChange = function (e) {
    this.$nextTick(function () {
      this.getDetailList();
    });
  };

  ReissueDetail.prototype.getReason = function (value, type) {
    var list = [];

    if (type == 'customer') {
      list = this.reasonList.customer_reason;
    } else if (type == 'product') {
      list = this.reasonList.product_reason;
    } else if (type == 'logistic') {
      list = this.reasonList.logistic_reason;
    } else if (type == 'warehouse') {
      list = this.reasonList.warehouse_reason;
    }

    var arr = value.split(',');
    arr = this.unique(arr);
    var ret = '';

    var _loop_1 = function _loop_1(i) {
      var item = list.find(function (x) {
        return x.code == arr[i];
      });

      if (item) {
        ret += ',' + item.name;
      }
    };

    for (var i in arr) {
      _loop_1(i);
    }

    return ret.substring(1);
  };

  ReissueDetail.prototype.unique = function (arr) {
    var hash = [];

    for (var i in arr) {
      var item = arr[i];

      if (hash.indexOf(item) == -1) {
        hash.push(item);
      }
    }

    return hash;
  };

  ReissueDetail.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        if (_this.selectedList.length > 0) {
          values['z_sub_category'] = _this.selectedList;
        }

        var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
          picking_name: 'in_or_=',
          default_code: 'like',
          manual_code: 'in_or_=',
          part_no: 'like',
          origin_order_no: 'like',
          z_sub_category: 'in'
        }, form_config["a" /* formConfig */].condition));
        var nowConditions = [];

        for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
          var item = _a[_i];

          if (item.value.constructor == Array && item.operate !== 'in') {
            if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
              var startDate = {};

              for (var key in item.value[0]) {
                startDate[key] = item.value[0][key];
              }

              nowConditions.push({
                query_name: item.query_name,
                operate: '>=',
                value: new Date(startDate.utc())
              });
            }

            if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
              var endDate = {};

              for (var key in item.value[1]) {
                endDate[key] = item.value[1][key];
              }

              nowConditions.push({
                query_name: item.query_name,
                operate: '<=',
                value: new Date(endDate.utc())
              });
            }
          } else {
            nowConditions.push(item);
          }
        }

        reslove(nowConditions);
      }).catch(function (err) {
        _this.$message.error(JSON.stringify(err));
      });
    });
  };

  ReissueDetail.prototype.onTrClick = function (record) {
    var info = this.data.find(function (x) {
      return x.id == record;
    }); // if (info) {
    //     this.onDetail(info)
    // } else if (this.groupbyList.length) {
    //     this.onDetail({ id: record })
    // }
  };

  ReissueDetail.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDetailList();
  };

  ReissueDetail.prototype.getProductReason = function (sku) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_product_reason_enum', common_service["a" /* CommonService */].getMenuCode('common-menu'));
    this.publicService.query(new http["RequestParams"]({
      sku_list: sku
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.productReasonList = data[''];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ReissueDetail.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ReissueDetail.prototype, "pageContainer", void 0);

  ReissueDetail = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'reissue-detail'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddOceanShippingFee: add_ocean_shipping_fee["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ReissueDetail);
  return ReissueDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var reissue_detailvue_type_script_lang_ts_ = (reissue_detailvue_type_script_lang_ts_ReissueDetail);
// CONCATENATED MODULE: ./src/pages/reports/reissue-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_reissue_detailvue_type_script_lang_ts_ = (reissue_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/reissue-detail.vue?vue&type=custom&index=0&blockType=i18n
var reissue_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("1cc4");

// CONCATENATED MODULE: ./src/pages/reports/reissue-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_reissue_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof reissue_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(reissue_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var reissue_detail = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "1cc4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reissue_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b685");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reissue_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reissue_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_reissue_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "4c09":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ship_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9154");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ship_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ship_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_ship_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "62ed":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/ship-order-daily-report.vue?vue&type=template&id=c9d79de2&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":1,"labelCol":{ span: 3 },"wrapperCol":{ span: 20, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.month')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['months']),expression:"['months']"}],style:({ width: '200px' }),attrs:{"min":1,"max":12,"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 'default_code' }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 'default_code' }\n                    ]"}],style:({ width: '150px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"order2_name"}},[_vm._v(" "+_vm._s(_vm.$t('columns.order_id'))+" ")]),_c('a-select-option',{attrs:{"value":"out_number"}},[_vm._v(" "+_vm._s(_vm.$t('columns.contact_no'))+" ")]),_c('a-select-option',{attrs:{"value":"default_code"}},[_vm._v(" "+_vm._s(_vm.$t('columns.default_code'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_operator',
                        { initialValue: 'like' }
                    ]),expression:"[\n                        'fuzzy_search_operator',\n                        { initialValue: 'like' }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"like"}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":"="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")]),_c('a-select-option',{attrs:{"value":"in_or="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_list'))+" ")])],1)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}],null,false,1435417471)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/ship-order-daily-report.vue?vue&type=template&id=c9d79de2&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/ship-order-daily-report.vue?vue&type=script&lang=ts&




















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var ship_order_daily_reportvue_type_script_lang_ts_ShipOrderDailyReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ShipOrderDailyReport, _super);

  function ShipOrderDailyReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.queryUrl = 'report_management/query_all_ship_order_daily_report';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    return _this;
  }

  Object.defineProperty(ShipOrderDailyReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ShipOrderDailyReport.prototype.created = function () {
    this.getSystemuser();
    this.getVendorList();
  };

  ShipOrderDailyReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  ShipOrderDailyReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  ShipOrderDailyReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var operator = values['fuzzy_search_operator'];
      var search_field_name = values['fuzzy_search_code'];
      values[search_field_name] = values['fuzzy_search_value'];
      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      delete values['fuzzy_search_operator'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: operator,
        order2_name: operator,
        out_number: operator
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ShipOrderDailyReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ShipOrderDailyReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ShipOrderDailyReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ShipOrderDailyReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ShipOrderDailyReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipOrderDailyReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipOrderDailyReport.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipOrderDailyReport.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipOrderDailyReport.prototype, "getVendorList", void 0);

  ShipOrderDailyReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'ship-order-daily-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ShipOrderDailyReport);
  return ShipOrderDailyReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var ship_order_daily_reportvue_type_script_lang_ts_ = (ship_order_daily_reportvue_type_script_lang_ts_ShipOrderDailyReport);
// CONCATENATED MODULE: ./src/pages/reports/ship-order-daily-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_ship_order_daily_reportvue_type_script_lang_ts_ = (ship_order_daily_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/ship-order-daily-report.vue?vue&type=custom&index=0&blockType=i18n
var ship_order_daily_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("4c09");

// CONCATENATED MODULE: ./src/pages/reports/ship-order-daily-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_ship_order_daily_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof ship_order_daily_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(ship_order_daily_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var ship_order_daily_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "9154":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return"},"columns":{"z_sub_category":"Sub Category","vendor_id":"Vendor","month":"Month","order_id":"Order No.","contact_no":"Contact No.","default_code":"Default Code"},"rules":{"date_range_error":"start date can\u0027t later start date"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货"},"columns":{"z_sub_category":"中文子类","vendor_id":"供应商","month":"月度","order_id":"订单号","contact_no":"实际采购合同号","default_code":"货号"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "b685":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"reissue_order_number":"Reissue Order Number","origin_order_number":"Origin Order Numbere","origin_order_articlenumber":"Origin Order Articlenumber","manual_number":"Manual Number","reissue_content":"Reissue Content","reissue_object":"Reissue object","reissue_type":"Reissue Type","customer_reason":"Customer Reason","product_reason":"Product Reason","shipment_reason":"Shipment Reason","warehouse_reason":"Warehouse Reason(cs)","order_time":"Order Time","reissue_time":"Reissue Time","reissue_qty":"Reissue Quantity","create_uid":"Resend Customer Service","z_sub_category":"Sub Category"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"reissue_order_number":"补发单号","origin_order_number":"原订单号","origin_order_articlenumber":"原订单货号","manual_number":"说明书编号","reissue_content":"补发内容","reissue_object":"补发对象","reissue_type":"补发类型","customer_reason":"客户原因","product_reason":"产品原因","shipment_reason":"物流原因","warehouse_reason":"仓库原因(cs)","order_time":"订单时间","reissue_time":"补发时间","reissue_qty":"补发数量","create_uid":"补发客服","z_sub_category":"中文子类"},"action":{"create":"新建","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ })

}]);