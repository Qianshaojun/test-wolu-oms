(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~5fd7ddd6"],{

/***/ "00b7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_customer_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9a51");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_customer_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_customer_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_customer_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "18ac":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c431");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1a9a":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"sku":"SKU","product_name":"Product Name","order_qty":"Order Qty","unit_price":"Unit_Price","available_qty":"Available Qty","taxes":"Taxes","fullfilment_center":"Fullfilment Center","stock_de_available_qty":"stock_de_available_qty","stock_uk_available_qty":"stock_uk_available_qty"},"zh-cn":{"sku":"SKU","product_name":"产品名称","order_qty":"订单数量","unit_price":"单价","available_qty":"可用数量","taxes":"税额","fullfilment_center":"履行中心","stock_de_available_qty":"DE可用数量","stock_uk_available_qty":"UK可用数量"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "2a40":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "30d7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_download_invoice_other_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cd8c");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_download_invoice_other_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_download_invoice_other_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_download_invoice_other_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "3f9f":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"base":"Order Detail","customerProblem":"Customer Problem","pickingList":"Picking List","invoices":"Invoices","operateLogs":"Operate Logs","pickingdetail":"Picking Detail","title-1":"Details of the products to be shipped","title-2":"Details of the reserved position of the shipped product in the warehouse","title-3":"Logistics package details required to ship products"},"zh-cn":{"base":"订单详情","customerProblem":"客户问题","pickingList":"拣货列表","invoices":"发票","operateLogs":"操作日志","pickingdetail":"发货明细","title-1":"所需发货产品明细","title-2":"发货产品在仓库预留位置明细","title-3":"发货产品打包物流包裹明细"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "443e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-base-detail.vue?vue&type=template&id=381d7ec3&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail",style:({ height: _vm.divHeight + 'px', overflow: 'auto' })},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"sku","bordered":""}},[_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('sku'),"align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.product_url && row.product_url.length > 10)?_c('a',{attrs:{"title":"Download the Product Manual(产品说明书)","href":row.product_url,"target":"_blank"}},[_vm._v(_vm._s(row.default_code))]):_c('span',[_vm._v(" "+_vm._s(row.default_code)+" ")]),(row.product_link)?_c('span',{staticStyle:{"float":"right"}},[_c('a-popover',{attrs:{"placement":"right"}},[_c('template',{slot:"content"},[_c('img',{staticStyle:{"width":"200px"},attrs:{"src":row.product_link}})]),_c('a-icon',{attrs:{"type":"file-image"}})],2)],1):_vm._e()]}}])}),_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('product_name'),"align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',{attrs:{"title":row.name}},[_vm._v(_vm._s(row.name ? row.name.length > 40 ? row.name.substr(0, 37) + '...' : row.name : ''))])]}}])}),_c('a-table-column',{key:"product_uom_qty",attrs:{"title":_vm.$t('order_qty'),"data-index":"product_uom_qty","align":"right"}}),_c('a-table-column',{key:"price_unit",attrs:{"title":_vm.$t('unit_price'),"data-index":"price_unit","align":"right"}}),_c('a-table-column',{key:"stock_de_available_qty",attrs:{"title":_vm.$t('stock_de_available_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.stock_de_available_qty)+" ")]}}])}),_c('a-table-column',{key:"stock_uk_available_qty",attrs:{"title":_vm.$t('stock_uk_available_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.stock_uk_available_qty)+" ")]}}])}),_c('a-table-column',{key:"tax_name",attrs:{"title":_vm.$t('taxes'),"data-index":"tax_name","align":"center"}}),_c('a-table-column',{key:"fulfillment_center_id",attrs:{"title":_vm.$t('fullfilment_center'),"data-index":"fulfillment_center_id","align":"center"}})],1),_c('div',{staticStyle:{"width":"100%","display":"inline-block"}},[_c('div',{staticStyle:{"width":"200px","float":"right"}},[_c('p',{staticStyle:{"padding":"0","margin":"0"}},[_vm._v(" Untaxed Amount： "+_vm._s(parseFloat(_vm.untax.toFixed(2)))+" ")]),_c('p',{staticStyle:{"padding":"0","margin":"0","border-bottom":"1px solid #aaa"}},[_vm._v(" Taxes： "+_vm._s(_vm.tax.toFixed(2))+" ")]),_c('p',{staticStyle:{"padding":"0","margin":"0"}},[_vm._v(" Total： "+_vm._s(_vm.total.toFixed(2))+" ")])])])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-base-detail.vue?vue&type=template&id=381d7ec3&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-base-detail.vue?vue&type=script&lang=ts&




var order_base_detailvue_type_script_lang_ts_OrderBaseDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderBaseDetail, _super);

  function OrderBaseDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.divHeight = 100;
    _this.data = [];
    _this.untax = 0;
    _this.tax = 0;
    _this.total = 0;
    return _this;
  }

  OrderBaseDetail.prototype.onHeightChange = function () {
    this.divHeight = this.height;
  };

  OrderBaseDetail.prototype.mounted = function () {
    this.data = this.info.map(function (x) {
      return x;
    });
    this.divHeight = this.height;
  };

  OrderBaseDetail.prototype.onInfoChange = function () {
    if (this.info.length) {
      this.data = this.info.map(function (x) {
        return x;
      });
      this.untax = 0;
      this.tax = 0;
      this.total = 0;

      for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
        var i = _a[_i];
        this.total += i.price_total;
        this.tax += i.price_tax;
        this.untax += i.price_subtotal;
      }
    } else {
      this.data = [];
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderBaseDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderBaseDetail.prototype, "height", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('height'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderBaseDetail.prototype, "onHeightChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderBaseDetail.prototype, "onInfoChange", null);

  OrderBaseDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], OrderBaseDetail);
  return OrderBaseDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_base_detailvue_type_script_lang_ts_ = (order_base_detailvue_type_script_lang_ts_OrderBaseDetail);
// CONCATENATED MODULE: ./src/components/orders/order-base-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_base_detailvue_type_script_lang_ts_ = (order_base_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/orders/order-base-detail.vue?vue&type=custom&index=0&blockType=i18n
var order_base_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("ee51");

// CONCATENATED MODULE: ./src/components/orders/order-base-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_order_base_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_base_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_base_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var order_base_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "4ffa":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"action":{"save":"Save","cancel":"Cancel"},"customer_problem":"Customer Problem"},"zh-cn":{"action":{"save":"保存","cancel":"取消"},"customer_problem":"客户问题"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "58db":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-detail.vue?vue&type=template&id=5d7f3db0&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-detail"},[_c('a-tabs',{style:({ height: _vm.divHeight }),attrs:{"defaultActiveKey":"base","v-model":_vm.activeKey},on:{"change":function (e) { return _vm.onPanelChange(e); }}},[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('base')}},[_c('OrderBaseDetail',{attrs:{"info":_vm.info,"height":_vm.divHeight}})],1),_c('a-tab-pane',{key:"picking",attrs:{"tab":_vm.$t('pickingList')}},[_c('OrderPickingDetail',{attrs:{"info":_vm.pick,"height":_vm.divHeight}})],1),_c('a-tab-pane',{key:"invoice",attrs:{"tab":_vm.$t('invoices')}},[_c('OrderInvoiceDetail',{attrs:{"info":_vm.invoice,"height":_vm.divHeight,"systemUsers":_vm.systemUsers,"companyList":_vm.companyList,"changeSpinning":_vm.changeSpinning}})],1),_c('a-tab-pane',{key:"customer",attrs:{"tab":_vm.$t('customerProblem')}},[_c('OrderCustomerDetail',{attrs:{"info":_vm.customer,"height":_vm.divHeight,"systemUsers":_vm.systemUsers,"orderId":_vm.id,"changeSpinning":_vm.changeSpinning}})],1),(_vm.changeSpinning && this.picking_id)?_c('a-tab-pane',{key:"pickingdetail",attrs:{"tab":_vm.$t('pickingdetail')}},[_c('div',[_c('a-card',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 1. "+_vm._s(_vm.$t('title-1'))+" ")]),_c('DemandDetail',{attrs:{"info":_vm.demands,"id":_vm.id,"changeSpinning":_vm.changeSpinning}})],1),_c('a-card',{staticStyle:{"margin-top":"10px"}},[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 2. "+_vm._s(_vm.$t('title-2'))+" ")]),_c('OperationDetail',{attrs:{"info":_vm.operations,"id":_vm.id,"changeSpinning":_vm.changeSpinning}})],1),_c('a-card',{staticStyle:{"margin-top":"10px"}},[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 3. "+_vm._s(_vm.$t('title-3'))+" ")]),_c('ShipmentDetail',{attrs:{"info":_vm.shipments,"id":_vm.id,"systemUsers":_vm.systemUsers,"shipTypeList":_vm.shipTypeList,"saveShipment":_vm.saveShipment,"changeSpinning":_vm.changeSpinning}})],1)],1)]):_vm._e(),_c('a-tab-pane',{key:"log",attrs:{"tab":_vm.$t('operateLogs')}},[_c('OrderLogDetail',{attrs:{"info":_vm.logs,"height":_vm.divHeight,"systemUsers":_vm.systemUsers}})],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-detail.vue?vue&type=template&id=5d7f3db0&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/components/orders/order-base-detail.vue + 4 modules
var order_base_detail = __webpack_require__("443e");

// EXTERNAL MODULE: ./src/components/orders/order-customer-detail.vue + 4 modules
var order_customer_detail = __webpack_require__("b5e3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-picking-detail.vue?vue&type=template&id=4dba7370&
var order_picking_detailvue_type_template_id_4dba7370_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-product-detail",style:({ height: _vm.divHeight + 'px', 'overflow-y': 'auto' })},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"id","bordered":""}},[_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('picking_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.toPagePicking(row)}}},[_vm._v(_vm._s(row.name))])]}}])}),_c('a-table-column',{key:"state",attrs:{"title":_vm.$t('state'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'PickingStatus')))+" ")]}}])}),_c('a-table-column',{key:"pick_pre_sale",attrs:{"title":_vm.$t('pre_sale'),"data-index":"pick_pre_sale","align":"center"}}),_c('a-table-column',{key:"send_gift",attrs:{"title":_vm.$t('send_gift'),"data-index":"send_gift","align":"center"}}),_c('a-table-column',{key:"is_resend",attrs:{"title":_vm.$t('resend'),"data-index":"is_resend","align":"center"}}),_c('a-table-column',{key:"remote_distinct",attrs:{"title":_vm.$t('remote_distinct'),"data-index":"remote_distinct","align":"center"}}),_c('a-table-column',{key:"is_sold_out",attrs:{"title":_vm.$t('sold_out'),"data-index":"is_sold_out","align":"center"}}),_c('a-table-column',{key:"sold_out_time",attrs:{"title":_vm.$t('sold_out_time'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.sold_out_time))+" ")]}}])}),_c('a-table-column',{key:"cs_process_time",attrs:{"title":_vm.$t('service_process'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.cs_process_time))+" ")]}}])}),_c('a-table-column',{key:"stock_process_time",attrs:{"title":_vm.$t('stock_process'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.stock_process_time))+" ")]}}])}),_c('a-table-column',{key:"confirm_return_time",attrs:{"title":_vm.$t('confirm_return_time'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.confirm_return_time))+" ")]}}])}),_c('a-table-column',{key:"return_process_time",attrs:{"title":_vm.$t('return_process_time'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.return_process_time))+" ")]}}])}),_c('a-table-column',{key:"validate_s",attrs:{"title":_vm.$t('validate_state'),"data-index":"validate_s","align":"center"}})],1)],1)}
var order_picking_detailvue_type_template_id_4dba7370_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-picking-detail.vue?vue&type=template&id=4dba7370&

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-picking-detail.vue?vue&type=script&lang=ts&





var order_picking_detailvue_type_script_lang_ts_OrderPickingDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderPickingDetail, _super);

  function OrderPickingDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.divHeight = 100;
    _this.data = [];
    return _this;
  }

  OrderPickingDetail.prototype.onHeightChange = function () {
    this.divHeight = this.height;
  };

  OrderPickingDetail.prototype.mounted = function () {
    this.data = this.info.map(function (x) {
      return x;
    });
    this.divHeight = this.height;
  };

  OrderPickingDetail.prototype.onInfoChange = function () {
    this.data = this.info.map(function (x) {
      return x;
    });
  };

  OrderPickingDetail.prototype.toPagePicking = function (row) {
    // router.push({
    //     name: 'picking-manage',
    //     params: { name: origin }
    // })
    if (this.$route.name != 'chat-box') {
      this.$router.push({
        name: 'picking-detail',
        path: "/picking/picking-detail/" + row.id,
        params: {
          id: row.id,
          name: row.name
        }
      });
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderPickingDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderPickingDetail.prototype, "height", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('height'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderPickingDetail.prototype, "onHeightChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderPickingDetail.prototype, "onInfoChange", null);

  OrderPickingDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], OrderPickingDetail);
  return OrderPickingDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_picking_detailvue_type_script_lang_ts_ = (order_picking_detailvue_type_script_lang_ts_OrderPickingDetail);
// CONCATENATED MODULE: ./src/components/orders/order-picking-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_picking_detailvue_type_script_lang_ts_ = (order_picking_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/orders/order-picking-detail.vue?vue&type=custom&index=0&blockType=i18n
var order_picking_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("ac02");

// CONCATENATED MODULE: ./src/components/orders/order-picking-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_order_picking_detailvue_type_script_lang_ts_,
  order_picking_detailvue_type_template_id_4dba7370_render,
  order_picking_detailvue_type_template_id_4dba7370_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_picking_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_picking_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var order_picking_detail = (component.exports);
// EXTERNAL MODULE: ./src/components/orders/order-invoice-detail.vue + 4 modules
var order_invoice_detail = __webpack_require__("9100");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-log-detail.vue?vue&type=template&id=69c83826&
var order_log_detailvue_type_template_id_69c83826_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-product-detail",style:({ height: _vm.divHeight + 'px', 'overflow-y': 'auto' })},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"log_content",attrs:{"title":_vm.$t('log'),"data-index":"log_content","align":"left","width":"40%"}}),_c('a-table-column',{key:"log_type",attrs:{"title":_vm.$t('type'),"data-index":"log_type","align":"center","width":"15%"}}),_c('a-table-column',{key:"who_log",attrs:{"title":_vm.$t('operater'),"align":"center","width":"15%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.who_log,_vm.systemUsers))+" ")]}}])}),_c('a-table-column',{key:"log_date",attrs:{"title":_vm.$t('date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.log_date))+" ")]}}])})],1)],1)}
var order_log_detailvue_type_template_id_69c83826_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-log-detail.vue?vue&type=template&id=69c83826&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.sort.js
var es_array_sort = __webpack_require__("4e82");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-log-detail.vue?vue&type=script&lang=ts&





var order_log_detailvue_type_script_lang_ts_OrderLogDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderLogDetail, _super);

  function OrderLogDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.divHeight = 100;
    _this.data = [];

    _this.compare = function (prop) {
      return function (obj1, obj2) {
        var val1 = obj1[prop];
        var val2 = obj2[prop];

        if (val1 > val2) {
          return -1;
        } else if (val1 < val2) {
          return 1;
        } else {
          return 0;
        }
      };
    };

    return _this;
  }

  OrderLogDetail.prototype.onHeightChange = function () {
    this.divHeight = this.height;
  };

  OrderLogDetail.prototype.mounted = function () {
    this.data = this.info.map(function (x, i) {
      x['index'] = i + 1;
      return x;
    }).sort(this.compare('log_date'));
    this.divHeight = this.height;
  };

  OrderLogDetail.prototype.onInfoChange = function () {
    this.data = this.info.map(function (x, i) {
      x['index'] = i + 1;
      return x;
    }).sort(this.compare('log_date'));
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderLogDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderLogDetail.prototype, "height", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderLogDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('height'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderLogDetail.prototype, "onHeightChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderLogDetail.prototype, "onInfoChange", null);

  OrderLogDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], OrderLogDetail);
  return OrderLogDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_log_detailvue_type_script_lang_ts_ = (order_log_detailvue_type_script_lang_ts_OrderLogDetail);
// CONCATENATED MODULE: ./src/components/orders/order-log-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_log_detailvue_type_script_lang_ts_ = (order_log_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/orders/order-log-detail.vue?vue&type=custom&index=0&blockType=i18n
var order_log_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("18ac");

// CONCATENATED MODULE: ./src/components/orders/order-log-detail.vue





/* normalize component */

var order_log_detail_component = Object(componentNormalizer["a" /* default */])(
  orders_order_log_detailvue_type_script_lang_ts_,
  order_log_detailvue_type_template_id_69c83826_render,
  order_log_detailvue_type_template_id_69c83826_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_log_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_log_detailvue_type_custom_index_0_blockType_i18n["default"])(order_log_detail_component)

/* harmony default export */ var order_log_detail = (order_log_detail_component.exports);
// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/components/picking/operation-detail.vue + 4 modules
var operation_detail = __webpack_require__("228e");

// EXTERNAL MODULE: ./src/components/picking/demand-detail.vue + 4 modules
var demand_detail = __webpack_require__("bc03");

// EXTERNAL MODULE: ./src/components/picking/shipment-detail.vue + 4 modules
var shipment_detail = __webpack_require__("055d");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-detail.vue?vue&type=script&lang=ts&



















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var order_detailvue_type_script_lang_ts_OrderDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderDetail, _super);

  function OrderDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.id = 0;
    _this.activeKey = 'base';
    _this.divHeight = 300;
    _this.saveShipment = 0;
    _this.info = [];
    _this.pick = [];
    _this.invoice = [];
    _this.customer = [];
    _this.logs = [];
    _this.operations = [];
    _this.demands = [];
    _this.shipments = [];
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    return _this;
  }

  OrderDetail.prototype.onDetailChange = function () {
    // if (!this.detail.id || (this.detail.id && this.id != this.detail.id)) {
    if (this.detail.id) {
      this.id = this.detail.id;
      this.info = [];
      this.pick = [];
      this.invoice = [];
      this.customer = [];
      this.logs = [];

      if (this.activeKey == 'base') {
        this.getOrderDetail();
      } else if (this.activeKey == 'picking') {
        this.getPickList();
      } else if (this.activeKey == 'invoice') {
        this.getInvoiceList();
      } else if (this.activeKey == 'customer') {
        this.getCustomerList();
      } else if (this.activeKey == 'log') {
        this.getLogList();
      } else if (this.picking_id && this.activeKey == 'pickingdetail') {
        this.getOperations();
        this.getDemands();
        this.getShipments();
      }
    } else {
      this.info = [];
      this.pick = [];
      this.invoice = [];
      this.customer = [];
      this.logs = [];
      this.operations = [];
      this.demands = [];
      this.shipments = [];
    }
  };

  OrderDetail.prototype.onCntChange = function () {
    this.info = [];
    this.pick = [];
    this.invoice = [];
    this.customer = [];
    this.logs = [];
    this.operations = [];
    this.demands = [];
    this.shipments = [];
  };

  OrderDetail.prototype.onPickingIDChange = function () {
    this.operations = [];
    this.demands = [];
    this.shipments = [];

    if (this.picking_id && this.activeKey == 'pickingdetail') {
      this.getOperations();
      this.getDemands();
      this.getShipments();
    }
  };

  OrderDetail.prototype.onHeightChange = function () {
    this.divHeight = this.height;
  };

  OrderDetail.prototype.created = function () {
    this.getShipType();

    if (this.detail && this.detail.id) {
      this.getOrderDetail();
    }

    this.divHeight = this.height;
  };

  OrderDetail.prototype.onPanelChange = function (e) {
    this.activeKey = e;

    if (e == 'base') {
      this.getOrderDetail();
    } else if (e == 'picking') {
      this.getPickList();
    } else if (e == 'invoice') {
      this.getInvoiceList();
    } else if (e == 'customer') {
      this.getCustomerList();
    } else if (e == 'log') {
      this.getLogList();
    } else if (this.picking_id && e == 'pickingdetail') {
      this.getOperations();
      this.getDemands();
      this.getShipments();
    }
  };

  Object.defineProperty(OrderDetail.prototype, "loading", {
    get: function get() {
      var loading = {};

      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }

      return loading;
    },
    enumerable: true,
    configurable: true
  });

  OrderDetail.prototype.closeLoading = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }
  };

  OrderDetail.prototype.getOrderDetail = function () {
    var _this = this;

    if (!this.detail) return;
    this.orderService.getDetail(new http["RequestParams"]({
      order_id: this.detail.id
    }, this.loading)).subscribe(function (data) {
      _this.info = data.order_lines.map(function (x) {
        var tax = _this.detail.taxList.find(function (t) {
          return t.id === x.account_tax_id;
        });

        if (tax) {
          x['tax_name'] = tax.name;
          x.account_tax_id = tax.amount;
        } else {
          x['tax_name'] = x.account_tax_id;
          x.account_tax_id = 0;
        }

        return x;
      });

      _this.closeLoading();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error(err.message);
    });
  };

  OrderDetail.prototype.getPickList = function () {
    var _this = this;

    if (!this.detail) return;
    this.orderService.getPickList(new http["RequestParams"]({
      order_id: this.detail.id
    }, this.loading)).subscribe(function (data) {
      _this.pick = data;

      _this.closeLoading();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error(err.message);
    });
  };

  OrderDetail.prototype.getInvoiceList = function () {
    var _this = this;

    if (!this.detail) return;
    this.orderService.getInvoiceList(new http["RequestParams"]({
      order_name: this.detail.name
    }, this.loading)).subscribe(function (data) {
      _this.invoice = data;

      _this.closeLoading();
    }, function (err) {
      _this.$message.error(err.message);

      _this.closeLoading();
    });
  };

  OrderDetail.prototype.getCustomerList = function () {
    var _this = this;

    if (!this.detail) return;
    this.orderService.getCustomerList(new http["RequestParams"]({
      order_id: this.detail.id
    }, this.loading)).subscribe(function (data) {
      _this.customer = data;

      _this.closeLoading();
    }, function (err) {
      _this.$message.error(err.message);

      _this.closeLoading();
    });
  };

  OrderDetail.prototype.getLogList = function () {
    var _this = this;

    if (!this.detail) return;
    this.orderService.getLogList(new http["RequestParams"]({
      order_id: this.detail.id
    }, this.loading)).subscribe(function (data) {
      _this.logs = data;

      _this.closeLoading();
    }, function (err) {
      _this.$message.error(err.message);

      _this.closeLoading();
    });
  };

  OrderDetail.prototype.getOperations = function () {
    var _this = this;

    this.pickingService.queryStockOperation(new http["RequestParams"]({
      picking_id: parseInt(this.picking_id)
    }, this.loading)).subscribe(function (data) {
      _this.operations = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this.closeLoading();
    }, function (err) {
      _this.$message.error(err.message);

      _this.closeLoading();
    });
  };

  OrderDetail.prototype.getDemands = function () {
    var _this = this;

    this.pickingService.queryStockMove(new http["RequestParams"]({
      picking_id: parseInt(this.picking_id)
    }, this.loading)).subscribe(function (data) {
      _this.demands = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this.closeLoading();
    }, function (err) {
      _this.$message.error(err.message);

      _this.closeLoading();
    });
  };

  OrderDetail.prototype.getShipments = function () {
    var _this = this;

    this.pickingService.queryShipment(new http["RequestParams"]({
      picking_id: parseInt(this.picking_id)
    }, this.loading)).subscribe(function (data) {
      _this.shipments = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this.closeLoading();
    }, function (err) {
      _this.$message.error(err.message);

      _this.closeLoading();
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "detail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "height", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "cnt", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 0
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "picking_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "shipTypeList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderDetail.prototype, "getShipType", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('detail'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderDetail.prototype, "onDetailChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('cnt'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderDetail.prototype, "onCntChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('picking_id'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderDetail.prototype, "onPickingIDChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('height'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderDetail.prototype, "onHeightChange", null);

  OrderDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      OrderBaseDetail: order_base_detail["a" /* default */],
      OrderCustomerDetail: order_customer_detail["a" /* default */],
      OrderPickingDetail: order_picking_detail,
      OrderInvoiceDetail: order_invoice_detail["a" /* default */],
      OrderLogDetail: order_log_detail,
      OperationDetail: operation_detail["a" /* default */],
      DemandDetail: demand_detail["a" /* default */],
      ShipmentDetail: shipment_detail["a" /* default */]
    }
  })], OrderDetail);
  return OrderDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_detailvue_type_script_lang_ts_ = (order_detailvue_type_script_lang_ts_OrderDetail);
// CONCATENATED MODULE: ./src/components/orders/order-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_detailvue_type_script_lang_ts_ = (order_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/orders/order-detail.vue?vue&type=custom&index=0&blockType=i18n
var order_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("a7b0");

// CONCATENATED MODULE: ./src/components/orders/order-detail.vue





/* normalize component */

var order_detail_component = Object(componentNormalizer["a" /* default */])(
  orders_order_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_detailvue_type_custom_index_0_blockType_i18n["default"])(order_detail_component)

/* harmony default export */ var order_detail = __webpack_exports__["a"] = (order_detail_component.exports);

/***/ }),

/***/ "5c59":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-manage-content.vue?vue&type=template&id=285cd19d&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('data-form',{directives:[{name:"show",rawName:"v-show",value:(_vm.isShow),expression:"isShow"}],ref:"dataForm",attrs:{"extends":_vm.extendItems,"column":2,"actions":true},on:{"submit":_vm.getOrderList,"heightChange":_vm.onHeightChange},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.orderID')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'name',
                        {
                            initialValue: _vm.defaultOrigin
                        }
                    ]),expression:"[\n                        'name',\n                        {\n                            initialValue: defaultOrigin\n                        }\n                    ]"}],style:({ width: '303px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.OrderStatus),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 30 }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 30 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('columns.orderID'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('columns.ebay_buyer_id'))+" ")]),_c('a-select-option',{attrs:{"value":30}},[_vm._v(" Email ")]),_c('a-select-option',{attrs:{"value":40}},[_vm._v(" "+_vm._s(_vm.$t('columns.sku'))+" ")]),_c('a-select-option',{attrs:{"value":50,"title":_vm.$t('columns.eBay_payment_id')}},[_vm._v(" "+_vm._s(_vm.$t('columns.eBay_payment_id'))+" ")]),_c('a-select-option',{attrs:{"value":60,"title":_vm.$t('columns.sales_order_number')}},[_vm._v(" "+_vm._s(_vm.$t('columns.sales_order_number'))+" ")]),_c('a-select-option',{attrs:{"value":70}},[_vm._v(" "+_vm._s(_vm.$t('columns.customer'))+" ")]),_c('a-select-option',{attrs:{"value":80}},[_vm._v(" "+_vm._s(_vm.$t('columns.zip'))+" ")]),_c('a-select-option',{attrs:{"value":90}},[_vm._v(" "+_vm._s(_vm.$t('columns.street'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', margin: '0 5px' }),attrs:{"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_operator',
                        { initialValue: 20 }
                    ]),expression:"[\n                        'fuzzy_search_operator',\n                        { initialValue: 20 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.ebay_buyer_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ebay_buyer_id']),expression:"['ebay_buyer_id']"}],style:({ width: '257px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '303px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.eBay_payment_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['eBay_payment_id']),expression:"['eBay_payment_id']"}],style:({ width: '257px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.platform')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'platform',
                        {
                            initialValue:
                                _vm.page_flag === 'aliexpress' ? 60 : ''
                        }
                    ]),expression:"[\n                        'platform',\n                        {\n                            initialValue:\n                                page_flag === 'aliexpress' ? 60 : ''\n                        }\n                    ]"}],style:({ width: '303px' }),attrs:{"size":"small","disabled":_vm.page_flag === 'aliexpress'}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.SellerPlatform),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.date_order')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['date_order', { initialValue: [] }]),expression:"['date_order', { initialValue: [] }]"}],style:({ width: '257px' }),attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm","size":"small"}}),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fillToday}},[_vm._v(_vm._s(_vm.$t('action.today'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fillYestoday}},[_vm._v(_vm._s(_vm.$t('action.yestoday'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fill3day}},[_vm._v(_vm._s(_vm.$t('action.3day'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fill3days}},[_vm._v(_vm._s(_vm.$t('action.3days'))+" ")])],1)]},proxy:true},{key:"collapse",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.seller_code')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['seller_code', { initialValue: '' }]),expression:"['seller_code', { initialValue: '' }]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sellerCodeList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.instance_code')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['instance_code', { initialValue: '' }]),expression:"['instance_code', { initialValue: '' }]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sellerInstanceList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.email')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['email']),expression:"['email']"}],style:({ width: '240px' }),attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.country')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'country_id',
                        { initialValue: '' },
                        {
                            rules: _vm.rules.required
                        }
                    ]),expression:"[\n                        'country_id',\n                        { initialValue: '' },\n                        {\n                            rules: rules.required\n                        }\n                    ]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.countryList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.sales_order_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sales_order_number']),expression:"['sales_order_number']"}],style:({ width: '240px' }),attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.customer')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['partner_name']),expression:"['partner_name']"}],style:({ width: '240px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onCreate}},[_vm._v(" "+_vm._s(_vm.$t('action.create'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.confirm}},[_vm._v(_vm._s(_vm.$t('action.confirm_order'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.cancelOrder}},[_vm._v(_vm._s(_vm.$t('action.cancel_order'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.backToDraft}},[_vm._v(_vm._s(_vm.$t('action.back_to_draft'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.multiCreateInvoice}},[_vm._v(" "+_vm._s(_vm.$t('action.create_invovice'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.deliveryMore}},[_vm._v(_vm._s(_vm.$t('action.deliveryMore'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onReturn2()}}},[_vm._v(_vm._s(_vm.$t('action.refund'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.markOrderAsPaid}},[_vm._v(" "+_vm._s(_vm.$t('action.mark_order_as_paid'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length ||
                                _vm.selectedRowKeys.length > 1},on:{"click":_vm.amaEbayDz}},[_vm._v(" "+_vm._s(_vm.$t('action.ama_ebay_dz'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":_vm.selectedRowKeys.length === 0},on:{"click":_vm.batchViewAmazonInvoicePDF}},[_vm._v(" "+_vm._s(_vm.$t('action.viewAmazonInvoicePDF'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":_vm.selectedRowKeys.length === 0},on:{"click":_vm.downloadAmazonInvoiceOther}},[_vm._v(" "+_vm._s(_vm.$t('action.downloadAmazonInvoiceOther'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"8px"}},[_vm._v(_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]},proxy:true}])}),_c('DragArea',{attrs:{"formShow":_vm.isDataFormShow},on:{"traggle":_vm.onDragChange},scopedSlots:_vm._u([{key:"up",fn:function(){return [(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                        selectedRowKeys: _vm.selectedRowKeys,
                        onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                    },"scroll":{ x: 1500, y: _vm.formDivHeight }},on:{"on-page-change":_vm.getOrderList,"onClick":function (record) {
                            _vm.selectedRowKeys = [record]
                            _vm.onTrClick(record)
                        },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"buyer_message",fn:function(text, row){return [_c('a',{attrs:{"title":text},on:{"click":function($event){return _vm.showMessage(text)}}},[_vm._v(_vm._s(text ? text.length > 26 ? text.substr(0, 23) + '...' : text : ''))])]}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.onDetail(row)}}},[_vm._v(_vm._s(row.name ? row.name : ''))])]}},{key:"sku",fn:function(text, row){return [_c('span',{staticStyle:{"color":"red"}},[_vm._v(_vm._s(row.sku ? row.sku : ''))])]}},{key:"state",fn:function(state){return [_c('span',{style:({ color: _vm.calcStateColor(state) })},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(state,'OrderStatus'))))])]}},{key:"memo",fn:function(text, row){return [_c('a',{attrs:{"title":row.memo},on:{"click":function($event){return _vm.onEditMemo(row)}}},[_vm._v(" "+_vm._s(row.memo ? row.memo.substr(0, 10) : _vm.$t('no'))+" ")])]}},{key:"instance_code",fn:function(instance_code){return [_c('span',[_vm._v(_vm._s(instance_code ? _vm.sellerInstanceDict[instance_code] : ''))])]}},{key:"country_name_render",fn:function(country_id){return [_c('span',[_vm._v(_vm._s(_vm.getCountryName(country_id)))])]}},{key:"amount_total",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("getcurrency")(row.currency))+" "+_vm._s(row.amount_total.toFixed(2))+" ")]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onEdit(row)}}},[_vm._v(" "+_vm._s(_vm.$t('action.edit'))+" ")]),_c('a-menu-item',{on:{"click":function($event){return _vm.onDetail(row)}}},[_vm._v(" "+_vm._s(_vm.$t('action.detail'))+" ")]),_c('a-menu-item',{on:{"click":function($event){return _vm.onReturn(row)}}},[_vm._v(_vm._s(_vm.$t('action.refund'))+" ")]),_c('a-menu-item',{on:{"click":function($event){return _vm.createCPofAllProduct(row)}}},[_vm._v(_vm._s(_vm.$t('action.createCPofAllProduct'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-menu-item',{on:{"click":function($event){return _vm.viewAmazonInvoicePDF(row)}}},[_vm._v(_vm._s(_vm.$t('action.viewAmazonInvoicePDF'))+" ")])],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}],null,false,3452859395)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":1500,"scrollY":_vm.formDivHeight},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 26 ? text.substr(0, 23) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.onDetail(row)}}},[_vm._v(_vm._s(row.name ? row.name : ''))])]}},{key:"sku",fn:function(text, row){return [_c('span',{staticStyle:{"color":"red"}},[_vm._v(_vm._s(row.sku ? row.sku : ''))])]}},{key:"state",fn:function(state){return [_c('span',{style:({ color: _vm.calcStateColor(state) })},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(state,'OrderStatus'))))])]}},{key:"memo",fn:function(text, row){return [_c('a',{attrs:{"title":row.memo},on:{"click":function($event){return _vm.onEditMemo(row)}}},[_vm._v(" "+_vm._s(row.memo ? row.memo.substr(0, 10) : _vm.$t('no'))+" ")])]}},{key:"instance_code",fn:function(instance_code){return [_c('span',[_vm._v(_vm._s(instance_code ? _vm.sellerInstanceDict[instance_code] : ''))])]}},{key:"country_name_render",fn:function(country_id){return [_c('span',[_vm._v(_vm._s(_vm.getCountryName(country_id)))])]}},{key:"amount_total",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("getcurrency")(row.currency))+" "+_vm._s(row.amount_total.toFixed(2))+" ")]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onEdit(row)}}},[_vm._v(" "+_vm._s(_vm.$t('action.edit'))+" ")]),_c('a-menu-item',{on:{"click":function($event){return _vm.onDetail(row)}}},[_vm._v(" "+_vm._s(_vm.$t('action.detail'))+" ")]),_c('a-menu-item',{on:{"click":function($event){return _vm.onReturn(row)}}},[_vm._v(_vm._s(_vm.$t('action.refund'))+" ")]),_c('a-menu-item',{on:{"click":function($event){return _vm.createCPofAllProduct(row)}}},[_vm._v(_vm._s(_vm.$t('action.createCPofAllProduct'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-menu-item',{on:{"click":function($event){return _vm.viewAmazonInvoicePDF(row)}}},[_vm._v(_vm._s(_vm.$t('action.viewAmazonInvoicePDF'))+" ")])],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}])})]},proxy:true},{key:"down",fn:function(){return [_c('OrderDetail',{attrs:{"detail":_vm.detailInfo,"height":_vm.detailDivHeight,"systemUsers":_vm.systemUsers,"companyList":_vm.companyList,"cnt":_vm.changeCnt}})]},proxy:true}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-manage-content.vue?vue&type=template&id=285cd19d&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__("a15b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__("00b4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.starts-with.js
var es_string_starts_with = __webpack_require__("2ca0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/components/orders/order-detail.vue + 14 modules
var order_detail = __webpack_require__("58db");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/services/seller-instance.service.ts
var seller_instance_service = __webpack_require__("5c97");

// EXTERNAL MODULE: ./src/services/account.service.ts
var account_service = __webpack_require__("82e7");

// EXTERNAL MODULE: ./src/shared/components/drag-area.vue + 4 modules
var drag_area = __webpack_require__("4ad2");

// EXTERNAL MODULE: ./src/components/common/send-email.vue + 3 modules
var send_email = __webpack_require__("b390");

// EXTERNAL MODULE: ./src/components/common/refund-form.vue + 4 modules
var refund_form = __webpack_require__("28e6");

// EXTERNAL MODULE: ./src/components/orders/cancel-order-form.vue + 4 modules
var cancel_order_form = __webpack_require__("a03e");

// EXTERNAL MODULE: ./src/services/taxes.service.ts
var taxes_service = __webpack_require__("3723");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-modify-memo.vue?vue&type=template&id=1bb83ee6&
var order_modify_memovue_type_template_id_1bb83ee6_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component"},[_c('a-form',{staticClass:"data-form",attrs:{"form":_vm.form}},[_c('a-form-item',{attrs:{"required":""}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                    "memo",
                    {
                        initialValue: _vm.memo
                    },
                    {
                        rules: _vm.rules.required
                    }
                ]),expression:"[\n                    `memo`,\n                    {\n                        initialValue: memo\n                    },\n                    {\n                        rules: rules.required\n                    }\n                ]"}],attrs:{"placeholder":"Memo","rows":4}})],1)],1),_c('div',{staticClass:"flex-row",staticStyle:{"margin-top":"-15px","margin-bottom":"15px"}},[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.save')))]),_c('a-button',{staticClass:"margin-right",staticStyle:{"margin-left":"5px"},on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))])],1),_c('div',{staticClass:"page-container",staticStyle:{"width":"100%","height":"280px"}},[_c('a-tabs',{attrs:{"defaultActiveKey":"base"}},[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('customer_problem')}},[_c('OrderCustomerDetail',{attrs:{"info":_vm.customer,"height":200,"systemUsers":_vm.systemUsers,"orderId":_vm.id}})],1)],1)],1)],1)}
var order_modify_memovue_type_template_id_1bb83ee6_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-modify-memo.vue?vue&type=template&id=1bb83ee6&

// EXTERNAL MODULE: ./src/components/orders/order-customer-detail.vue + 4 modules
var order_customer_detail = __webpack_require__("b5e3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-modify-memo.vue?vue&type=script&lang=ts&







var order_modify_memovue_type_script_lang_ts_OrderModifyMemo =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderModifyMemo, _super);

  function OrderModifyMemo() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.customer = [];
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  OrderModifyMemo.prototype.submit = function (value) {
    return value;
  };

  OrderModifyMemo.prototype.cancel = function () {
    return;
  };

  OrderModifyMemo.prototype.created = function () {
    this.getCustomerList();
    this.form = this.$form.createForm(this);
  };

  OrderModifyMemo.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      _this.submit(values.memo);
    });
  };

  OrderModifyMemo.prototype.getCustomerList = function () {
    var _this = this;

    this.orderService.getCustomerList(new http["RequestParams"]({
      order_id: this.id
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.customer = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderModifyMemo.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderModifyMemo.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderModifyMemo.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderModifyMemo.prototype, "memo", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderModifyMemo.prototype, "systemUsers", void 0);

  OrderModifyMemo = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      OrderCustomerDetail: order_customer_detail["a" /* default */]
    }
  })], OrderModifyMemo);
  return OrderModifyMemo;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_modify_memovue_type_script_lang_ts_ = (order_modify_memovue_type_script_lang_ts_OrderModifyMemo);
// CONCATENATED MODULE: ./src/components/orders/order-modify-memo.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_modify_memovue_type_script_lang_ts_ = (order_modify_memovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/orders/order-modify-memo.vue?vue&type=custom&index=0&blockType=i18n
var order_modify_memovue_type_custom_index_0_blockType_i18n = __webpack_require__("63af");

// CONCATENATED MODULE: ./src/components/orders/order-modify-memo.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_order_modify_memovue_type_script_lang_ts_,
  order_modify_memovue_type_template_id_1bb83ee6_render,
  order_modify_memovue_type_template_id_1bb83ee6_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_modify_memovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_modify_memovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var order_modify_memo = (component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/download-invoice-other.vue?vue&type=template&id=6f4467be&
var download_invoice_othervue_type_template_id_6f4467be_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.company_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["company_name"]),expression:"[`company_name`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.vat')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["vat"]),expression:"[`vat`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.street1')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["street1"]),expression:"[`street1`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.street2')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["street2"]),expression:"[`street2`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.country')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["country"]),expression:"[`country`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.state')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["state"]),expression:"[`state`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.city')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["city"]),expression:"[`city`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.postcode')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["postcode"]),expression:"[`postcode`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit')))])],1)],1)}
var download_invoice_othervue_type_template_id_6f4467be_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/download-invoice-other.vue?vue&type=template&id=6f4467be&

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/download-invoice-other.vue?vue&type=script&lang=ts&








var download_invoice_othervue_type_script_lang_ts_DownloadInvoiceOther =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](DownloadInvoiceOther, _super);

  function DownloadInvoiceOther() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = {
      country: 'CN',
      state: 'Guangdong',
      city: 'Shenzhen',
      postcode: '518000'
    }; // 分页服务

    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.innerActionService = new inner_action_service["a" /* InnerActionService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.defaultWarehouse = '';
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    _this.instanceRequired = false;
    return _this;
  }

  DownloadInvoiceOther.prototype.submit = function () {
    return true;
  };

  DownloadInvoiceOther.prototype.cancel = function () {
    return;
  };

  DownloadInvoiceOther.prototype.mounted = function () {
    this.setFormValues();
  };

  DownloadInvoiceOther.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  DownloadInvoiceOther.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.data);
  };

  DownloadInvoiceOther.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['order_name'] = _this.order_name;

        _this.saveCustomer(values);
      }
    });
  };

  DownloadInvoiceOther.prototype.saveCustomer = function (data) {
    var _this = this;

    this.innerActionService.setActionAPI('order_management/create_invoice_pdf_for_other_instance', common_service["a" /* CommonService */].getMenuCode('order-manage'));
    this.publicService.modify(new http["RequestParams"](data, {
      loading: this.loadingService,
      innerAction: this.innerActionService
    })).subscribe(function () {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], DownloadInvoiceOther.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], DownloadInvoiceOther.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DownloadInvoiceOther.prototype, "order_name", void 0);

  DownloadInvoiceOther = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], DownloadInvoiceOther);
  return DownloadInvoiceOther;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var download_invoice_othervue_type_script_lang_ts_ = (download_invoice_othervue_type_script_lang_ts_DownloadInvoiceOther);
// CONCATENATED MODULE: ./src/components/orders/download-invoice-other.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_download_invoice_othervue_type_script_lang_ts_ = (download_invoice_othervue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/orders/download-invoice-other.vue?vue&type=custom&index=0&blockType=i18n
var download_invoice_othervue_type_custom_index_0_blockType_i18n = __webpack_require__("30d7");

// CONCATENATED MODULE: ./src/components/orders/download-invoice-other.vue





/* normalize component */

var download_invoice_other_component = Object(componentNormalizer["a" /* default */])(
  orders_download_invoice_othervue_type_script_lang_ts_,
  download_invoice_othervue_type_template_id_6f4467be_render,
  download_invoice_othervue_type_template_id_6f4467be_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof download_invoice_othervue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(download_invoice_othervue_type_custom_index_0_blockType_i18n["default"])(download_invoice_other_component)

/* harmony default export */ var download_invoice_other = (download_invoice_other_component.exports);
// EXTERNAL MODULE: ./src/services/cs-email.service.ts
var cs_email_service = __webpack_require__("00a1");

// EXTERNAL MODULE: ./src/components/picking/delivery-more.vue + 4 modules
var delivery_more = __webpack_require__("2b19");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/shared/components/show-text-message.vue + 4 modules
var show_text_message = __webpack_require__("340c");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-manage-content.vue?vue&type=script&lang=ts&












































var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var order_manage_contentvue_type_script_lang_ts_OrderManageContent =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderManageContent, _super);

  function OrderManageContent() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.showSearch = true; // Loading服务

    _this.orderService = new order_service["a" /* OrderService */]();
    _this.accountService = new account_service["a" /* AccountService */](); // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.sellerInstanceService = new seller_instance_service["a" /* SellerInstanceService */]();
    _this.taxesService = new taxes_service["a" /* TaxesService */]();
    _this.emailService = new cs_email_service["a" /* EmailService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.showBtn = false;
    _this.sellerInstanceList = [];
    _this.sellerInstanceDict = {}; // 表格选择项

    _this.selectedRowKeys = [];
    _this.sellerCodeList = []; // 详情项

    _this.detailInfo = null;
    _this.isShow = true;
    _this.isDataFormShow = true;
    _this.formDivHeight = 400;
    _this.detailDivHeight = 300;
    _this.defaultOrigin = '';
    _this.changeCnt = 0;
    _this.orderBy = '';
    _this.defaultCondition = '';
    _this.hzData = [];
    _this.showHz = false;
    _this.defaultPlatform = '';
    _this.groupbyList = [];
    _this.allNameAuth = [];
    _this.columnList = [];
    _this.queryUrl = '/sale_order/query_all';
    _this.moment = moment_default.a;
    _this.initialDate = [];
    return _this;
  }

  OrderManageContent.prototype.showhideSearch = function (flag) {
    this.showSearch = flag;
  };

  Object.defineProperty(OrderManageContent.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });
  Object.defineProperty(OrderManageContent.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  OrderManageContent.prototype.onRouteChange = function (newRoute, oldRoute) {
    if (this.$route.params.origin || this.$route.query.origin) {
      var values = this.dataForm.getValues();

      for (var i in values) {
        values[i] = undefined;
      }

      if (this.$route.params.origin) {
        values['name'] = this.$route.params.origin;
      } else {
        values['name'] = this.$route.query.origin;
      }

      this.dataForm.setValues(values); // if (this.data.length === 0) {

      this.getOrderList(); // }
    }
  };

  OrderManageContent.prototype.onDragChange = function (param) {
    this.formDivHeight = param[0] - 110 > 0 ? param[0] - 110 : 0;
    this.detailDivHeight = param[1] - 97 > 0 ? param[1] - 97 : 0;
  };

  OrderManageContent.prototype.created = function () {
    this.getcountry();
    this.getcurrency();
    this.getSystemuser();
    this.getcompany();
    this.getSellerCodeList();
    this.getSellerInstanceList();
  };

  OrderManageContent.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;

    if (this.$route.params.origin || this.$route.query.origin) {
      if (this.$route.params.origin) {
        this.defaultOrigin = this.$route.params.origin;
      } else {
        this.defaultOrigin = this.$route.query.origin;
      }

      var values = this.dataForm.getValues();
      values['name'] = this.defaultOrigin;
      this.dataForm.setValues(values);
      this.getOrderList();
    }
  };

  OrderManageContent.prototype.onCreate = function () {
    this.$router.push({
      name: 'order-edit'
    });
  };

  OrderManageContent.prototype.getSellerCodeList = function () {
    var _this = this;

    this.sellerInstanceService.query_seller_name(new http["RequestParams"]({})).subscribe(function (data) {
      _this.sellerCodeList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.onHeightChange = function (key) {
    this.isDataFormShow = key;
  };

  OrderManageContent.prototype.getSellerInstanceList = function () {
    var _this = this;

    this.sellerInstanceService.queryInstanceList(new http["RequestParams"]()).subscribe(function (data) {
      _this.sellerInstanceList = data;

      for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
        var i = data_1[_i];
        _this.sellerInstanceDict[i.code] = i.name;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.onSendMail = function () {
    var _this = this;

    var target = this.data.filter(function (x) {
      return x.id === _this.selectedRowKeys[0];
    });
    this.$modal.open(send_email["a" /* default */], {
      model: 'orderManage',
      recordID: this.selectedRowKeys[0],
      data: {
        recipient: target[0].email,
        orderId: this.selectedRowKeys[0]
      }
    }, {
      title: this.$t('action.send_email'),
      width: '1000px'
    }).subscribe(function (data) {});
  };

  OrderManageContent.prototype.onReturn = function (row) {
    var _this = this;

    this.$modal.open(refund_form["a" /* default */], {
      countryList: this.countryList,
      order_id: row.id
    }, {
      title: this.$t('action.refund_wizard'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.changeCnt += 1;
    });
  };

  OrderManageContent.prototype.onReturn2 = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只能选择一条数据进行操作');
      return;
    }

    var row = this.data.find(function (x) {
      return x.id == _this.selectedRowKeys[0];
    });

    if (row) {
      this.$modal.open(refund_form["a" /* default */], {
        countryList: this.countryList,
        order_id: row.id
      }, {
        title: this.$t('action.refund_wizard'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.changeCnt += 1;
      });
    } else {
      this.$message.error('数据错误，请联系管理员');
    }
  };

  OrderManageContent.prototype.fillToday = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(day), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime())), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['date_order'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  OrderManageContent.prototype.fillYestoday = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(new Date(day.getTime() - 24 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 24 * 60 * 60 * 1000)), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['date_order'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  OrderManageContent.prototype.fill3day = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(new Date(day.getTime() - 48 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 48 * 60 * 60 * 1000)), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['date_order'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  OrderManageContent.prototype.fill3days = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(day), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 48 * 60 * 60 * 1000)), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['date_order'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  OrderManageContent.prototype.formatDate = function (time) {
    // 空数据处理
    if (time === null || time === undefined || time === '') {
      return '';
    }

    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    var h = time.getHours();
    var mi = time.getMinutes();
    var s = time.getSeconds();
    m = m < 10 ? "0" + m : m;
    d = d < 10 ? "0" + d : d;
    h = h < 10 ? "0" + h : h;
    mi = mi < 10 ? "0" + mi : mi;
    s = s < 10 ? "0" + s : s;
    return y + "-" + m + "-" + d + " 23:59";
  };
  /**
   * 获取订单数据
   */


  OrderManageContent.prototype.getOrderList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (values['seller_code'] && values['seller_code'].length > 0) {
        values['seller_code'] = values['seller_code'].join(',');
      }

      if (values['instance_code'] && values['instance_code'].length > 0) {
        values['instance_code'] = values['instance_code'].join(',');
      }

      if (values['eBay_payment_id']) {
        values['eBay_payment_id'] = values['eBay_payment_id'].toUpperCase();
      }

      var name_operator = 'in_or_=';
      var ebay_buyer_id_operator = 'in_or_=';
      var email_operator = 'like';
      var default_code_operator = 'in_or_=';
      var sales_order_number_operator = 'suffix_like';
      var ebay_payment_id_operator = 'in_or_prefix_like';
      var customer_name_operator = 'in_or_like';
      var zip_operator = 'like';
      var street_operator = 'like';
      var fuzzy_search_operator = values['fuzzy_search_operator'];
      var operator = 'like';

      if (fuzzy_search_operator == 20) {
        operator = '=';
      }

      var fuzzy_search_value = values['fuzzy_search_value'];

      if (fuzzy_search_value) {
        var fuzzy_search_code = values['fuzzy_search_code'];
        var search_field_name = 'name';

        switch (fuzzy_search_code) {
          case 10:
            search_field_name = 'name';
            name_operator = operator;
            break;

          case 20:
            search_field_name = 'ebay_buyer_id';
            ebay_buyer_id_operator = operator;
            break;

          case 30:
            search_field_name = 'email';
            email_operator = operator;
            break;

          case 40:
            search_field_name = 'default_code';
            default_code_operator = operator;
            break;

          case 50:
            search_field_name = 'eBay_payment_id';
            ebay_payment_id_operator = operator;
            fuzzy_search_value = fuzzy_search_value.toUpperCase();
            break;

          case 60:
            search_field_name = 'sales_order_number';
            sales_order_number_operator = operator;
            break;

          case 70:
            search_field_name = 'partner_name';
            sales_order_number_operator = operator;
            break;

          case 80:
            search_field_name = 'zip';
            zip_operator = operator;
            break;

          case 90:
            search_field_name = 'street';
            street_operator = operator;
            break;

          default:
            search_field_name = 'name';
            name_operator = operator;
        }

        values[search_field_name] = fuzzy_search_value;
      }

      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      delete values['fuzzy_search_operator'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        name: name_operator,
        default_code: default_code_operator,
        customer_code: 'like',
        ebay_buyer_id: ebay_buyer_id_operator,
        eBay_payment_id: ebay_payment_id_operator,
        sales_order_number: sales_order_number_operator,
        email: email_operator,
        seller_code: 'in_or_=',
        instance_code: 'in_or_=',
        partner_name: customer_name_operator,
        zip: zip_operator,
        street: street_operator
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            var startDate = {};

            for (var key in item.value[0]) {
              startDate[key] = item.value[0][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(startDate.utc())
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            var endDate = {};

            for (var key in item.value[1]) {
              endDate[key] = item.value[1][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(endDate.utc())
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.data = data.map(function (item) {
            for (var _i = 0, _a = _this.countryList; _i < _a.length; _i++) {
              var cty = _a[_i];

              if (cty.code == item['country_id']) {
                item['country'] = cty.name;
              }
            }

            for (var _b = 0, _c = _this.currencyList; _b < _c.length; _b++) {
              var currency = _c[_b];

              if (currency.code == item['pricelist_id']) {
                item['currency'] = currency.name;
              }
            }

            return item;
          });
          _this.selectedRowKeys = [];

          if (_this.data.length > 0) {
            _this.selectedRowKeys.push(_this.data[0].id);

            _this.onDetail(_this.data[0]);
          }

          _this.changeCnt += 1;
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  OrderManageContent.prototype.onEdit = function (row) {
    var _this = this;

    this.orderService.queryOrderInfo(new http["RequestParams"]({
      order_id: row.id
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.orderService.getDetail(new http["RequestParams"]({
        order_id: row.id
      }, {
        loading: _this.loadingService
      })).subscribe(function (list) {
        data[0]['order_detail_list'] = list.order_lines;
        data[0]['id'] = row.id;
        data[0]['name'] = row.name;

        _this.changeOrder(data);

        router["a" /* default */].push({
          name: 'order-edit',
          params: {
            order: data
          }
        });
      });
    });
  };

  OrderManageContent.prototype.onDelete = function (row) {};

  OrderManageContent.prototype.onBatchDelete = function () {};

  OrderManageContent.prototype.onDetail = function (row) {
    var _this = this;

    row['taxList'] = [];

    if (row.seller_code) {
      this.taxesService.queryAll(new http["RequestParams"]({
        seller_code: row.seller_code
      }, {
        loading: this.loadingService
      })).subscribe(function (data) {
        row.taxList = data;
        _this.detailInfo = row; // this.$nextTick(() => this.pageContainer.scrollToBottom())
      });
    } else {
      this.detailInfo = row; // this.$nextTick(() => this.pageContainer.scrollToBottom())
    }
  };

  OrderManageContent.prototype.onClose = function () {
    this.detailInfo = null;
  };

  OrderManageContent.prototype.onTrClick = function (record) {
    var info = this.data.find(function (x) {
      return x.id === record;
    });

    if (info) {
      this.onDetail(info);
    } else if (this.groupbyList.length) {
      this.onDetail({
        id: record
      });
    }
  };

  OrderManageContent.prototype.onStatusChange = function (e) {
    this.$nextTick(function () {
      this.getOrderList();
    });
  };

  OrderManageContent.prototype.onShow = function () {
    this.isShow = this.isShow ? false : true;
  };

  OrderManageContent.prototype.copy = function (e, email) {
    e.stopPropagation(); // TODO
  };

  OrderManageContent.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  OrderManageContent.prototype.modifyCP = function () {
    router["a" /* default */].push({
      name: 'modify-custom-problem',
      params: {
        orderList: JSON.stringify(this.selectedRowKeys)
      }
    });
  };

  OrderManageContent.prototype.createCPofAllProduct = function (row) {
    router["a" /* default */].push({
      name: 'modify-custom-problem',
      params: {
        orderId: row.id
      }
    });
  };

  OrderManageContent.prototype.viewAmazonInvoicePDF = function (row) {
    var order_name = row.name;
    var pattern = /^[0-9]{3}-[0-9]{7}-[0-9]{7}$/;

    if (!pattern.test(order_name)) {
      this.$message.success('Only support Amazon Order to view invoice');
      return;
    }

    var url = app_config["a" /* default */].server + '/account/create_invoice_pdf?order_name=' + order_name;
    window.open(url, '_blank');
  };

  OrderManageContent.prototype.confirm = function () {
    var _this = this;

    this.orderService.confirm(new http["RequestParams"]({
      order_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('订单生成picking成功');

      _this.getOrderList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.autoConfirm = function () {
    var _this = this;

    this.orderService.confirm(new http["RequestParams"]({
      order_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('订单自动生成picking成功');

      _this.getOrderList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.multiCreateInvoice = function () {
    var _this = this;

    this.accountService.createInvoice(new http["RequestParams"]({
      order_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('入账发票生成成功');

      _this.getOrderList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.backToDraft = function () {
    var _this = this;

    this.orderService.setToDraft(new http["RequestParams"]({
      order_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getOrderList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.cancelOrder = function () {
    var _this = this;

    var compare_flag = '';

    var _loop_1 = function _loop_1(i) {
      var item = this_1.data.find(function (x) {
        return x.id == i;
      });
      var shop_type = '';

      if (item.shop_type) {
        shop_type = item.shop_type.toLowerCase();
      }

      var flag = '';

      switch (true) {
        case shop_type.indexOf('amazon') >= 0:
          flag = 'amazon';
          break;

        case shop_type.indexOf('ebay') >= 0:
          flag = 'ebay';
          break;

        case shop_type.indexOf('b2c') >= 0:
          flag = 'b2c';
          break;

        case shop_type.indexOf('wish') >= 0:
          flag = 'wish';
          break;

        case shop_type.indexOf('cdiscount') >= 0:
          flag = 'cdiscount';
          break;

        case shop_type.indexOf('aliexpress') >= 0:
          flag = 'aliexpress';
          break;

        case shop_type.indexOf('wayfair') >= 0:
          flag = 'wayfair';
          break;
      }

      if (flag == '' && item.platform_type) {
        switch (item.platform_type) {
          case 10:
            flag = 'b2c';
            break;

          case 20:
            flag = 'amazon';
            break;

          case 30:
            flag = 'ebay';
            break;

          case 40:
            flag = 'wish';
            break;

          case 50:
            flag = 'cdiscount';
            break;

          case 60:
            flag = 'aliexpress';
            break;

          case 100:
            flag = 'wayfair';
            break;
        }
      }

      if (compare_flag != '') {
        if (compare_flag != flag) {
          this_1.$message.error('请选择相同平台订单');
          return {
            value: void 0
          };
        }
      } else {
        compare_flag = flag;
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      var state_1 = _loop_1(i);

      if (Object(esm_typeof["a" /* default */])(state_1) === "object") return state_1.value;
    }

    if (compare_flag == '') {
      this.$message.info('unknow platform of the order, pls contact admin./订单平台类型未知，请联系管理员');
      return;
    }

    this.innerAction.setActionAPI('common/query_general_code_detail_by_group', common_service["a" /* CommonService */].getMenuCode('code-manage'));
    this.publicService.query(new http["RequestParams"]({
      group_name: 'platform_cancel_reason'
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var refundReasonList = [];

      for (var _i = 0, data_2 = data; _i < data_2.length; _i++) {
        var item = data_2[_i];

        if (item.general_code.startsWith(compare_flag + '/')) {
          refundReasonList.push({
            code: item.general_code.replace(compare_flag + '/', ''),
            name: item.general_name
          });
        }
      }

      if (refundReasonList.length == 0) {
        var cancelReason = '';

        if (compare_flag == 'amazon') {
          cancelReason = 'BuyerCanceled';
        }

        var refundData = {
          order_id_list: _this.selectedRowKeys,
          refund_reason: cancelReason
        };

        _this.orderService.cancelOrder(new http["RequestParams"](refundData, {
          loading: _this.loadingService
        })).subscribe(function (data) {
          _this.$message.success('success');

          _this.getOrderList();
        }, function (err) {
          _this.$message.error(err.message);
        });
      } else {
        _this.$modal.open(cancel_order_form["a" /* default */], {
          order_id_list: _this.selectedRowKeys,
          platform: compare_flag,
          refundReasonList: refundReasonList
        }, {
          title: _this.$t('action.cancel_order'),
          width: '500px'
        }).subscribe(function (data) {
          _this.orderService.cancelOrder(new http["RequestParams"](data, {
            loading: _this.loadingService
          })).subscribe(function (data) {
            _this.$message.success('success');

            _this.getOrderList();
          }, function (err) {
            _this.$message.error(err.message);
          });
        });
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.markOrderAsPaid = function () {
    var _this = this;

    var order_id_list = [];

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];
      var item = this.data.find(function (x) {
        return x.id === i;
      });

      if (item) {
        order_id_list.push(item.id);
      }
    }

    this.orderService.markEbayOrderAsPaid(new http["RequestParams"]({
      order_id_list: order_id_list
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.amaEbayDz = function () {
    var _this = this;

    if (this.selectedRowKeys.length === 0) {
      return;
    } else if (this.selectedRowKeys.length > 1) {
      this.$message.error('只能选择一个订单');
      return;
    }

    var row = this.data.find(function (x) {
      return x.id === _this.selectedRowKeys[0];
    });
    this.$modal.open(send_email["a" /* default */], {
      model: 'orderManage',
      recordID: row.id,
      data: {
        orderId: row.id,
        templateId: 260
      }
    }, {
      title: this.$t('action.send_email'),
      width: '1000px'
    }).subscribe(function (data) {});
  };

  OrderManageContent.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getOrderList();
  };

  OrderManageContent.prototype.calcStateColor = function (state) {
    var color = '#333;';

    if (state === 'cancel') {
      color = '#999';
    }

    return color;
  };

  OrderManageContent.prototype.onEditMemo = function (record) {
    var _this = this;

    this.$modal.open(order_modify_memo, {
      memo: record.memo,
      id: record.id,
      systemUsers: this.systemUsers
    }, {
      title: this.$t('action.modify_memo'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.modifyMemo(record.id, data);
    });
  };

  OrderManageContent.prototype.modifyMemo = function (order_id, memo) {
    var _this = this;

    this.emailService.modifyMemo(new http["RequestParams"]({
      order_id: order_id,
      memo: memo
    })).subscribe(function (data) {
      var msg = _this.$t('save_success');

      _this.$message.success(msg);

      _this.getOrderList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderManageContent.prototype.deliveryMore = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只限选择一条');
      return;
    }

    this.$modal.open(delivery_more["a" /* default */], {
      order_id: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.deliveryMore'),
      width: '800px'
    }).subscribe(function (data) {
      var msg = _this.$t('save_success');

      _this.$message.success(msg);

      _this.$router.push({
        name: 'picking-detail',
        path: "/picking/picking-detail/" + data.new_picking_id,
        params: {
          id: data.new_picking_id,
          name: data.new_picking_name
        }
      });
    });
  };

  OrderManageContent.prototype.batchViewAmazonInvoicePDF = function () {
    var order_name_list = [];

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var selected_code = _a[_i];
      var row = this.data.find(function (x) {
        return x.id === selected_code;
      });
      var pattern = /^[0-9]{3}-[0-9]{7}-[0-9]{7}$/;

      if (!pattern.test(row.name)) {
        this.$message.success('Only support Amazon Order to view invoice');
        return;
      }

      order_name_list.push(row.name);
    }

    var urlParams = encodeURIComponent(JSON.stringify(order_name_list));
    var url = app_config["a" /* default */].server + '/account/download_order_invoice_pdf?order_name_list=' + urlParams;
    window.open(url, '_blank');
  };

  OrderManageContent.prototype.downloadAmazonInvoiceOther = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只限选择一条');
      return;
    }

    var row = this.data.find(function (x) {
      return x.id === _this.selectedRowKeys[0];
    });
    this.$modal.open(download_invoice_other, {
      order_name: row.name
    }, {
      title: 'Download Amazon Invoice',
      width: '800px'
    }).subscribe(function (data) {
      var url = app_config["a" /* default */].server + '/account/download_order_invoice_pdf_other_instance?order_name=' + row.name;
      window.open(url, '_blank');
    });
  };

  OrderManageContent.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  OrderManageContent.prototype.getCountryName = function (id) {
    var ret = id;
    var item = this.countryList.find(function (x) {
      return x.code == id;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  OrderManageContent.prototype.showMessage = function (text) {
    this.$modal.open(show_text_message["a" /* default */], {
      text: text
    }, {
      title: 'Woltu OMS',
      width: '800px'
    }).subscribe(function (data) {//
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], OrderManageContent.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], OrderManageContent.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "page_flag", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "getcountry", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "currencyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "getcurrency", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('changeOrder'), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderManageContent.prototype, "changeOrder", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('$route'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object, Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderManageContent.prototype, "onRouteChange", null);

  OrderManageContent = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'order-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      OrderDetail: order_detail["a" /* default */],
      CancelOrderForm: cancel_order_form["a" /* default */],
      DragArea: drag_area["a" /* default */],
      OrderModifyMemo: order_modify_memo,
      DeliveryMore: delivery_more["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      DownloadInvoiceOther: download_invoice_other
    }
  })], OrderManageContent);
  return OrderManageContent;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_manage_contentvue_type_script_lang_ts_ = (order_manage_contentvue_type_script_lang_ts_OrderManageContent);
// CONCATENATED MODULE: ./src/components/orders/order-manage-content.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_manage_contentvue_type_script_lang_ts_ = (order_manage_contentvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/orders/order-manage-content.vue?vue&type=style&index=0&lang=css&
var order_manage_contentvue_type_style_index_0_lang_css_ = __webpack_require__("fdbca");

// EXTERNAL MODULE: ./src/components/orders/order-manage-content.vue?vue&type=custom&index=0&blockType=i18n
var order_manage_contentvue_type_custom_index_0_blockType_i18n = __webpack_require__("8097");

// CONCATENATED MODULE: ./src/components/orders/order-manage-content.vue






/* normalize component */

var order_manage_content_component = Object(componentNormalizer["a" /* default */])(
  orders_order_manage_contentvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_manage_contentvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_manage_contentvue_type_custom_index_0_blockType_i18n["default"])(order_manage_content_component)

/* harmony default export */ var order_manage_content = __webpack_exports__["a"] = (order_manage_content_component.exports);

/***/ }),

/***/ "63af":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4ffa");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7103":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"customer":"Customer","invoice_date":"Invoice Date","invoice_number":"Invoice Number","company":"Company","sales_person":"Sales_Person","applicant":"Applicant","due_date":"Due Date","source_document":"Source Document","total":"Total","amount_due":"Amount Due","status":"Status","payment_method":"Payment Method","need_refund":"Need Refund","refund_time":"Refund Time","refund_memo":"Refund Memo","order_refund_status":"Order Refund Status","operate_message":"Operate Message","actions":{"send_email":"Send Invoice"}},"zh-cn":{"customer":"客户","invoice_date":"发票日期","invoice_number":"发票号","company":"公司","sales_person":"销售人员","applicant":"申请人","due_date":"截止日期","source_document":"源文件","total":"总金额","amount_due":"应付金额","status":"状态","payment_method":"支付方式","need_refund":"需要退款","refund_time":"退款时间","refund_memo":"退款原因","order_refund_status":"退款状态","operate_message":"操作消息","actions":{"send_email":"发送发票"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "71c0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_customer_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2a40");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_customer_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_customer_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "8097":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a04d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "8890":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_invoice_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7103");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_invoice_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_invoice_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_invoice_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "9029":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "9100":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-invoice-detail.vue?vue&type=template&id=03765460&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-product-detail",style:({ height: _vm.divHeight + 'px', 'overflow-y': 'auto' })},[_c('a-table',{staticStyle:{"table-layout":"fixed","max-height":"300px"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"number","scroll":{ x: 1500 },"bordered":""}},[_c('a-table-column',{key:"partner_id",attrs:{"title":_vm.$t('customer'),"data-index":"partner_id","align":"center"}}),_c('a-table-column',{key:"date_invoice",attrs:{"title":_vm.$t('invoice_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.date_invoice))+" ")]}}])}),_c('a-table-column',{key:"number",attrs:{"title":_vm.$t('invoice_number'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.toPageInvoice(row.number)}}},[_vm._v(_vm._s(row.number))])]}}])}),_c('a-table-column',{key:"company_id",attrs:{"title":_vm.$t('company'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.company_id,_vm.companyList))+" ")]}}])}),_c('a-table-column',{key:"user_id",attrs:{"title":_vm.$t('sales_person'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.user_id,_vm.systemUsers))+" ")]}}])}),_c('a-table-column',{key:"applicant",attrs:{"title":_vm.$t('applicant'),"data-index":"applicant","align":"center"}}),_c('a-table-column',{key:"date_due",attrs:{"title":_vm.$t('due_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.date_due))+" ")]}}])}),_c('a-table-column',{key:"origin",attrs:{"title":_vm.$t('source_document'),"data-index":"origin","align":"center"}}),_c('a-table-column',{key:"amount_total_signed",attrs:{"title":_vm.$t('total'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.amount_total ? row.amount_total.toFixed(2) : '')+" ")]}}])}),_c('a-table-column',{key:"amount_due",attrs:{"title":_vm.$t('amount_due'),"data-index":"amount_due","align":"center"}}),_c('a-table-column',{key:"state",attrs:{"title":_vm.$t('status'),"data-index":"state","align":"center"}}),_c('a-table-column',{key:"payment_method",attrs:{"title":_vm.$t('payment_method'),"data-index":"payment_method","align":"center"}}),_c('a-table-column',{key:"need_refund",attrs:{"title":_vm.$t('need_refund'),"data-index":"need_refund","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(scope){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(scope))+" ")]}}])}),_c('a-table-column',{key:"refund_time",attrs:{"title":_vm.$t('refund_time'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.refund_time))+" ")]}}])}),_c('a-table-column',{key:"refund_memo",attrs:{"title":_vm.$t('refund_memo'),"data-index":"refund_memo","align":"center"}}),_c('a-table-column',{key:"orderRefundStatus",attrs:{"title":_vm.$t('order_refund_status'),"data-index":"orderRefundStatus","align":"center"}}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('operate_message'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-icon',{staticStyle:{"margin-right":"10px"},attrs:{"type":"file"},on:{"click":function($event){return _vm.downloadInvoce(row)}}}),_c('a-icon',{staticStyle:{"margin-right":"10px"},attrs:{"type":"setting"},on:{"click":function($event){return _vm.editInvoice(row)}}}),_c('a-icon',{attrs:{"type":"mail"},on:{"click":function($event){return _vm.sendInvoce(row)}}})]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-invoice-detail.vue?vue&type=template&id=03765460&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/components/common/send-email.vue + 3 modules
var send_email = __webpack_require__("b390");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./src/services/account.service.ts
var account_service = __webpack_require__("82e7");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-invoice-detail.vue?vue&type=script&lang=ts&












var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');
var chatModule = Object(lib["c" /* namespace */])('chatModule');

var order_invoice_detailvue_type_script_lang_ts_OrderInvoiceDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderInvoiceDetail, _super);

  function OrderInvoiceDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.divHeight = 100;
    _this.data = [];
    _this.accountService = new account_service["a" /* AccountService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  OrderInvoiceDetail.prototype.onHeightChange = function () {
    this.divHeight = this.height;
  };

  OrderInvoiceDetail.prototype.mounted = function () {
    this.data = this.info.map(function (x) {
      return x;
    });
    this.divHeight = this.height;
  };

  OrderInvoiceDetail.prototype.onInfoChange = function () {
    this.data = this.info.map(function (x) {
      return x;
    });
  };

  OrderInvoiceDetail.prototype.sendInvoce = function (row) {
    this.$modal.open(send_email["a" /* default */], {
      model: 'accountManage',
      recordID: row.id,
      data: {
        orderId: row.order_id,
        templateId: 5
      },
      changeSpinning: this.changeSpinning
    }, {
      title: this.$t('actions.send_email'),
      width: '1000px'
    }).subscribe(function (data) {});
  };

  OrderInvoiceDetail.prototype.editInvoice = function (row) {
    var _this = this;

    if (this.$route.name == 'chat-box') {
      this.changeInvoiceId(row.id);
    } else {
      this.accountService.queryInvoiceDetailForEdit(new http["RequestParams"]({
        invoice_id: row.id
      }, {
        loading: this.loadingService
      })).subscribe(function (data) {
        _this.changeInvoice(data);

        router["a" /* default */].push({
          name: 'invoice-edit',
          params: {
            invoice: data
          }
        });
      }, function (err) {
        _this.$message.error(err.message);
      });
    }
  };

  OrderInvoiceDetail.prototype.toPageInvoice = function (origin) {
    if (this.changeSpinning) {
      var url = this.$router.resolve({
        name: 'account-invoice',
        query: {
          number: origin
        }
      });
      window.open(url.href, '_blank');
    } else {
      router["a" /* default */].push({
        name: 'account-invoice',
        params: {
          number: origin
        }
      });
    }
  };

  OrderInvoiceDetail.prototype.downloadInvoce = function (row) {
    var urlParams = encodeURIComponent(JSON.stringify([row.id]));
    window.open(app_config["a" /* default */].server + '/account/download_invoice_pdf?invoice_id_list=' + urlParams);
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderInvoiceDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderInvoiceDetail.prototype, "height", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderInvoiceDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderInvoiceDetail.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('height'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderInvoiceDetail.prototype, "onHeightChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderInvoiceDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([chatModule.Mutation('changeSpinning'), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderInvoiceDetail.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('changeInvoice'), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderInvoiceDetail.prototype, "changeInvoice", void 0);

  tslib_es6["c" /* __decorate */]([chatModule.Mutation('changeInvoiceId'), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderInvoiceDetail.prototype, "changeInvoiceId", void 0);

  OrderInvoiceDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], OrderInvoiceDetail);
  return OrderInvoiceDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_invoice_detailvue_type_script_lang_ts_ = (order_invoice_detailvue_type_script_lang_ts_OrderInvoiceDetail);
// CONCATENATED MODULE: ./src/components/orders/order-invoice-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_invoice_detailvue_type_script_lang_ts_ = (order_invoice_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/orders/order-invoice-detail.vue?vue&type=custom&index=0&blockType=i18n
var order_invoice_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("8890");

// CONCATENATED MODULE: ./src/components/orders/order-invoice-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_order_invoice_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_invoice_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_invoice_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var order_invoice_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "9152":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"product":"Product","quantity":"Quantity","description":"Description","available_qty":"Available Qty","delivered":"Ship Type","invoiced":"Pre Sale","price_unit":"Unit Price","price_tax":"Taxes","subtotal":"Subtotal","fulfillment_center":"Fulfillment Center","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Cancel"}},"zh-cn":{"product":"产品","quantity":"数量","description":"描述","available_qty":"可用数量","delivered":"发货数量","invoiced":"发票数量","price_unit":"单价","price_tax":"税","subtotal":"合计","fulfillment_center":"履行中心","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"取消"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "9a51":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"product":"Product","quantity":"Quantity","ship":"Ship","state":"State","product_info":"Product Info","w_warehouse_reason":"WareHouse Reason(rt)","w_return_reason":"Grund Ruckgabe","customer_reason":"Customer Reason","product_problem":"Customer Problem(cs)","logistic_reason":"Logistic Reason","warehouse_reason":"Warehouse Reason(cs)","solution_type":"Solution Type","stock_processed":"Stock Processed","create_time":"Create Time","create_user":"Create User","is_return_user":"Is Return User","sale_tag":"Product Problem","null":"None","ship_num":"Shipment Number","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Discard"}},"zh-cn":{"product":"产品","quantity":"数量","ship":"物流","state":"产品状态","product_info":"产品信息","w_warehouse_reason":"仓库原因(rt)","w_return_reason":"退货原因","customer_reason":"客户原因","product_problem":"客户原因(cs)","logistic_reason":"物流原因","warehouse_reason":"仓库原因(cs)","solution_type":"解决方案类型","stock_processed":"库存处理","create_time":"创建时间","create_user":"创建者","is_return_user":"Is Return User","sale_tag":"产品问题","null":"无","ship_num":"运单号","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"丢弃"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a03e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/cancel-order-form.vue?vue&type=template&id=778c12d6&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form2,"labelCol":{ span: 6 },"wrapperCol":{ span: 10, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.refund_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['refund_reason']),expression:"['refund_reason']"}],style:({ width: '400px' }),attrs:{"showSearch":"","size":"small","placeholder":"Select a Refund Reason"}},_vm._l((_vm.refundReasonList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])}),1)],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(" "+_vm._s(_vm.$t('action.cancel'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(" "+_vm._s(_vm.$t('action.submit'))+" ")])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/cancel-order-form.vue?vue&type=template&id=778c12d6&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/cancel-order-form.vue?vue&type=script&lang=ts&



var datasModule = Object(lib["c" /* namespace */])('datasModule'); // interface orderDetail []

var cancel_order_formvue_type_script_lang_ts_CancelOrderForm =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](CancelOrderForm, _super);

  function CancelOrderForm() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.orderData = {
      paypal: '',
      receiver_name: '',
      iban: ''
    };
    _this.data = [];
    return _this;
  }

  CancelOrderForm.prototype.submit = function (values) {
    return values;
  };

  CancelOrderForm.prototype.cancel = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }

    return;
  };

  CancelOrderForm.prototype.mounted = function () {
    if (this.order_id_list) {
      this.setFormValues();
    }
  };

  CancelOrderForm.prototype.setFormValues = function () {
    this.form2.setFieldsValue(this.orderData);
  };

  CancelOrderForm.prototype.created = function () {
    this.form2 = this.$form.createForm(this);
  };

  CancelOrderForm.prototype.onSubmit = function () {
    var _this = this;

    this.form2.validateFields({}, function (err, values) {
      if (!err) {
        if (_this.refundReasonList.length && values['refund_reason'] == undefined) {
          _this.$message.info('please selecte refund reason');

          return;
        } else if (_this.refundReasonList.length == 0) {
          values['refund_reason'] = '';
        }

        values['order_id_list'] = _this.order_id_list;

        _this.submit(values);
      }
    });
  };

  CancelOrderForm.prototype.handleChange = function (value, row, column) {
    row[column] = value;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], CancelOrderForm.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], CancelOrderForm.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], CancelOrderForm.prototype, "order_id_list", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], CancelOrderForm.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: Array
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], CancelOrderForm.prototype, "refundReasonList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], CancelOrderForm.prototype, "platform", void 0);

  CancelOrderForm = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], CancelOrderForm);
  return CancelOrderForm;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var cancel_order_formvue_type_script_lang_ts_ = (cancel_order_formvue_type_script_lang_ts_CancelOrderForm);
// CONCATENATED MODULE: ./src/components/orders/cancel-order-form.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_cancel_order_formvue_type_script_lang_ts_ = (cancel_order_formvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/orders/cancel-order-form.vue?vue&type=custom&index=0&blockType=i18n
var cancel_order_formvue_type_custom_index_0_blockType_i18n = __webpack_require__("d030");

// CONCATENATED MODULE: ./src/components/orders/cancel-order-form.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_cancel_order_formvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof cancel_order_formvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(cancel_order_formvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var cancel_order_form = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "a04d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"no":"no","desc":"this is a Order Page1","columns":{"status":"Status","orderID":"Order ID","date_order":"Order Date","ebay_buyer_id":"Buyer ID","email":"Email","sku":"Sku","country":"Country","customer":"Customer","transaction_code":"TransactionCode","instance":"Instance","ebay_type":"Ebay Type","is_prime":"Prime","payment_method":"PaymentMethod","invoice_status":"Invoice Status","qty":"QTY","amount_total":"Amount","memo":"Memo","buyer_message":"BuyerMessage","lastest_shipping_date":"Lastest Shipping Date","latest_delivery_date":"Latest Delivery Date","operate":"Operate","platform":"Platform","seller_code":"Seller","instance_code":"Instance","eBay_payment_id":"eBayPaymentID","sales_order_number":"eBayOrderID","zip":"Zip","street":"Street"},"action":{"create":"Create","batch-create":"EXCEL Import","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","today":"Today","yestoday":"Yestoday","3day":"3 Day","3days":"3 Days","send_email":"Send Email","refund_wizard":"Refund Supplement Wizard","modify_cp":"Modify CP","back_to_draft":"To Draft","mark_order_as_paid":"Mark Order as Paid","ama_ebay_dz":"AMA/EBAY DZ","modify_memo":"Modify Memo","deliveryMore":"Delivery More","refund":"Refund","createCPofAllProduct":"Create CP(All Product)","viewAmazonInvoicePDF":"view AMA PDF","downloadAmazonInvoiceOther":"view AMA PDF WOWO","operation":"Action"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"no":"无","desc":"这是订单页面1","columns":{"status":"状态","orderID":"订单号","date_order":"订单日期","ebay_buyer_id":"买家ID","email":"邮箱","sku":"SKU","country":"国家","customer":"客户","transaction_code":"交易号","instance":"实例","ebay_type":"eBay 类型","is_prime":"Prime","payment_method":"支付方式","invoice_status":"发票状态","qty":"数量","amount_total":"总金额","memo":"备注","buyer_message":"买家留言","lastest_shipping_date":"发货时间","latest_delivery_date":"交货时间","operate":"操作","platform":"平台","seller_code":"店铺","instance_code":"实例","eBay_payment_id":"付款码","sales_order_number":"eBayOrderID","zip":"邮编","street":"街道"},"action":{"create":"新建","batch-create":"EXCEL导入","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","today":"今天","yestoday":"昨天","3day":"前天","3days":"近3天","send_email":"发送邮件","refund_wizard":"退款管理","modify_cp":"修改CP","back_to_draft":"设为草稿","mark_order_as_paid":"标为已付款","ama_ebay_dz":"AMA/EBAY DZ","modify_memo":"编辑Memo","deliveryMore":"补发","refund":"退款","createCPofAllProduct":"创建CP(全部产品)","viewAmazonInvoicePDF":"查看AMA账单","downloadAmazonInvoiceOther":"查看AMA账单WOWO店铺","operation":"操作"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a3da":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"picking_id":"PickingID","state":"State","pre_sale":"Pre Sale","send_gift":"Send Gift","resend":"Resend","remote_distinct":"Remote Distinct","sold_out":"Sold Out","sold_out_time":"Sold Out Time","service_process":"Service Process","stock_process":"Stock Process","confirm_return_time":"Confirm Return Time","return_process_time":"Return Process Time","validate_state":"Validate State"},"zh-cn":{"picking_id":"拣货单号","state":"状态","pre_sale":"预售","send_gift":"送礼物","resend":"补发","remote_distinct":"偏远地区","sold_out":"售罄","sold_out_time":"售罄时间","service_process":"服务进程","stock_process":"库存进程","confirm_return_time":"确认退货时间","return_process_time":"退货时间","validate_state":"验证状态"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a732":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"sku":"SKU","product_name":"Product Name","order_qty":"Order Qty","unit_price":"Unit_Price","available_qty":"Available Qty","taxes":"Taxes","fullfilment_center":"Fullfilment Center","columns":{"type":"Type","need_refund":"Need Refund","need_origin":"Need Origin","amount":"Amount","special_refund":"Special Refund","refund_reason":"Reason","paypal":"PayPal","street":"Street","receiver_name":"Receiver Name","nr":"Nr.","iban":"IBAN","city":"City","bic":"BIC","country":"Country","bank_name":"Bank Name","zip":"Zip","refund_memo":"Refund Memo"},"action":{"submit":"Submit","add":"Add","del":"Delete","cancel":"Cancel"}},"zh-cn":{"sku":"SKU","product_name":"产品名称","order_qty":"订单数量","unit_price":"单价","available_qty":"可用数量","taxes":"税额","fullfilment_center":"履行中心","columns":{"type":"类型","need_refund":"需要退款","need_origin":"需要原始发票","amount":"金额","special_refund":"特殊退款","refund_reason":"原因","paypal":"PayPal","street":"街道","receiver_name":"接受人","nr":"门牌号","iban":"IBAN","city":"城市","bic":"BIC","country":"国家","bank_name":"银行名称","zip":"邮编","refund_memo":"退款说明"},"action":{"submit":"提交","add":"添加","del":"删除","cancel":"取消"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a7b0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3f9f");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ac02":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a3da");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b5e3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-customer-detail.vue?vue&type=template&id=0a7b83a3&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-customer-detail",style:({ height: _vm.divHeight + 'px', 'overflow-y': 'auto' })},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px"}},[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.addBtn}},[_vm._v(_vm._s(_vm.$t('actions.add'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.saveBtn}},[_vm._v(_vm._s(_vm.$t('actions.save'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.cancelBtn}},[_vm._v(_vm._s(_vm.$t('actions.cancel'))+" ")])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"scroll":{ x: 1500 },"rowKey":"index","customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"bordered":""}},[_c('a-table-column',{key:"name",staticClass:"tip-color",attrs:{"title":_vm.$t('product'),"align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],style:({ width: '100%' }),attrs:{"value":row.name,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'name', e); }}},[_vm._l((_vm.productList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(row)}}},[_vm._v(" Search More ")])])],2):_c('span',{class:_vm.calculateRowStyle(row),attrs:{"title":row.name}},[_vm._v(_vm._s(row.name ? row.name.substr(0, 20) + (row.name.length > 17 ? '...' : '') : ''))])]}}])}),_c('a-table-column',{key:"product_qty",attrs:{"title":_vm.$t('quantity'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_qty']),expression:"['product_qty']"}],style:({ width: '100%' }),attrs:{"decimalSeparator":",","value":row.product_qty,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_qty', e); }}}):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.product_qty))])]}}])}),_c('a-table-column',{key:"ship_type",attrs:{"title":_vm.$t('ship'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_type']),expression:"['ship_type']"}],style:({ width: '100%' }),attrs:{"value":row.ship_type,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'ship_type', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.ship_type),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.ship_type,_vm.reasonList.ship_type)))])]}}])}),_c('a-table-column',{key:"ship_num",attrs:{"title":_vm.$t('ship_num'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_num']),expression:"['ship_num']"}],style:({ width: '100%' }),attrs:{"decimalSeparator":",","value":row.ship_num,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'ship_num', e); }}}):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.ship_num))])]}}])}),_c('a-table-column',{key:"product_status",attrs:{"title":_vm.$t('state'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_status']),expression:"['product_status']"}],style:({ width: '100%' }),attrs:{"value":row.product_status,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_status', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.product_status),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.product_status,_vm.reasonList.product_status)))])]}}])}),_c('a-table-column',{key:"info1",attrs:{"title":_vm.$t('product_info'),"data-index":"info1","align":"center"}}),_c('a-table-column',{key:"w_warehouse_reason",attrs:{"title":_vm.$t('w_warehouse_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['w_warehouse_reason']),expression:"['w_warehouse_reason']"}],style:({ width: '100%' }),attrs:{"value":row.w_warehouse_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'w_warehouse_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.w_warehouse_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.w_warehouse_reason,_vm.reasonList.w_warehouse_reason)))])]}}])}),_c('a-table-column',{key:"w_return_reason",attrs:{"title":_vm.$t('w_return_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['w_return_reason']),expression:"['w_return_reason']"}],style:({ width: '100%' }),attrs:{"value":row.w_return_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'w_return_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.w_return_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.w_return_reason,_vm.reasonList.w_return_reason)))])]}}])}),_c('a-table-column',{key:"customer_reason",attrs:{"title":_vm.$t('customer_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['customer_reason']),expression:"['customer_reason']"}],style:({ width: '100%' }),attrs:{"value":row.customer_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'customer_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.customer_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.customer_reason,_vm.reasonList.customer_reason)))])]}}])}),_c('a-table-column',{key:"sale_tag",attrs:{"title":_vm.$t('sale_tag'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_tag']),expression:"['sale_tag']"}],style:({ width: '100%' }),attrs:{"value":row.sale_tag,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'sale_tag', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.productReason[row.default_code]),function(i){return _c('a-select-option',{key:i,attrs:{"value":i,"title":i}},[_vm._v(" "+_vm._s(i)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.sale_tag,_vm.productReason[row.default_code])))])]}}])}),_c('a-table-column',{key:"logistic_reason",attrs:{"title":_vm.$t('logistic_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['logistic_reason']),expression:"['logistic_reason']"}],style:({ width: '100%' }),attrs:{"value":row.logistic_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'logistic_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.logistic_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.logistic_reason,_vm.reasonList.logistic_reason)))])]}}])}),_c('a-table-column',{key:"warehouse_reason",attrs:{"title":_vm.$t('warehouse_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_reason']),expression:"['warehouse_reason']"}],style:({ width: '100%' }),attrs:{"value":row.warehouse_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'warehouse_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.warehouse_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.warehouse_reason,_vm.reasonList.warehouse_reason)))])]}}])}),_c('a-table-column',{key:"solution_type",attrs:{"title":_vm.$t('solution_type'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['solution_type']),expression:"['solution_type']"}],style:({ width: '100%' }),attrs:{"mode":"multiple","value":row.solution_type,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'solution_type', e); }}},_vm._l((_vm.reasonList.solution_type),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])}),1):_c('span',{class:_vm.calculateRowStyle(row)},_vm._l((row.solution_type),function(x){return _c('p',{key:x},[_vm._v(" "+_vm._s(_vm._f("dict2")((x ? x : ''),_vm.reasonList.solution_type))+" ")])}),0)]}}])}),_c('a-table-column',{key:"stock_processed",attrs:{"title":_vm.$t('stock_processed'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['stock_processed']),expression:"['stock_processed']"}],attrs:{"value":row.stock_processed,"format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.onRowChange(row, 'stock_processed', e); }}}):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.stock_processed ? row.stock_processed.format('YY-MM-DD HH:mm') : ''))])]}}])}),_c('a-table-column',{key:"create_time",attrs:{"title":_vm.$t('create_time'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.save_flag)?_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("datetolocal")(row.create_time.toString())))]):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.create_time.format('YY-MM-DD HH:mm')))])]}}])}),_c('a-table-column',{key:"create_user",attrs:{"title":_vm.$t('create_user'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.create_user,_vm.systemUsers)))])]}}])}),_c('a-table-column',{key:"is_return_user",attrs:{"title":_vm.$t('is_return_user'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(['is_return_user']),expression:"['is_return_user']"}],attrs:{"disabled":_vm.currentRow !== row.index,"checked":row.is_return_user},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'is_return_user',
                                e.target.checked
                            ); }}})]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.onDel(row)}}},[_vm._v(" "+_vm._s(_vm.$t('actions.delete'))+" ")])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/order-customer-detail.vue?vue&type=template&id=0a7b83a3&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__("00b4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.constructor.js
var es_regexp_constructor = __webpack_require__("4d63");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.dot-all.js
var es_regexp_dot_all = __webpack_require__("c607");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.sticky.js
var es_regexp_sticky = __webpack_require__("2c3e");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.keys.js
var es_object_keys = __webpack_require__("b64b");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/custom_problem.service.ts
var custom_problem_service = __webpack_require__("6a1c");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/store/index.ts + 9 modules
var store = __webpack_require__("0613");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/order-customer-detail.vue?vue&type=script&lang=ts&































var order_customer_detailvue_type_script_lang_ts_OrderCustomerDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OrderCustomerDetail, _super);

  function OrderCustomerDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.divHeight = 100;
    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.reasonList = [];
    _this.productList = [];
    _this.deleteList = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.customProblemService = new custom_problem_service["a" /* CustomProblemService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.productReason = {};
    return _this;
  }

  Object.defineProperty(OrderCustomerDetail.prototype, "loading", {
    get: function get() {
      var loading = {};

      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }

      return loading;
    },
    enumerable: true,
    configurable: true
  });

  OrderCustomerDetail.prototype.closeLoading = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }
  };

  OrderCustomerDetail.prototype.created = function () {
    this.getSelectList();
    this.getProductList();
  };

  OrderCustomerDetail.prototype.onHeightChange = function () {
    this.divHeight = this.height;
  };

  OrderCustomerDetail.prototype.mounted = function () {
    var _this = this;

    this.moment = moment_default.a;
    this.divHeight = this.height;

    if (this.info.length) {
      this.data = this.info.map(function (x) {
        if (x.stock_processed) {
          x.stock_processed = _this.moment(_this.datetolocal(x.stock_processed), 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.stock_processed = '';
        }

        if (x.create_time) {
          x.create_time = _this.moment(x.create_time, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.create_time = '';
        } // if (!(x.solution_type instanceof Array)) {
        //     x.solution_type = [x.solution_type]
        // }


        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        x.w_warehouse_reason = x.w_warehouse_reason ? x.w_warehouse_reason : '';
        x.w_return_reason = x.w_return_reason ? x.w_return_reason : '';
        x.customer_reason = x.customer_reason ? x.customer_reason : '';
        x.sale_tag = x.sale_tag ? x.sale_tag : '';
        x.logistic_reason = x.logistic_reason ? x.logistic_reason : '';
        x.warehouse_reason = x.warehouse_reason ? x.warehouse_reason : '';
        x.stock_processed = x.stock_processed ? x.stock_processed : '';
        x.ship_type = x.ship_type ? x.ship_type : '';
        x.product_status = x.product_status ? x.product_status : '';
        x.solution_type = x.solution_type ? x.solution_type : [];
        return x;
      });
      var skus = this.data.map(function (x) {
        return x.default_code;
      });
      this.getProductReason(skus);
    }
  };

  OrderCustomerDetail.prototype.onInfoChange = function () {
    var _this = this;

    this.deleteList = [];

    if (this.info.length) {
      this.data = this.info.map(function (x) {
        if (x.stock_processed) {
          x.stock_processed = _this.moment(_this.datetolocal(x.stock_processed), 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.stock_processed = '';
        }

        if (x.create_time) {
          x.create_time = _this.moment(x.create_time, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.create_time = '';
        } // if (!(x.solution_type instanceof Array)) {
        //     x.solution_type = [x.solution_type]
        // }


        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        x.w_warehouse_reason = x.w_warehouse_reason ? x.w_warehouse_reason : '';
        x.w_return_reason = x.w_return_reason ? x.w_return_reason : '';
        x.customer_reason = x.customer_reason ? x.customer_reason : '';
        x.sale_tag = x.sale_tag ? x.sale_tag : '';
        x.logistic_reason = x.logistic_reason ? x.logistic_reason : '';
        x.warehouse_reason = x.warehouse_reason ? x.warehouse_reason : '';
        x.stock_processed = x.stock_processed ? x.stock_processed : '';
        x.ship_type = x.ship_type ? x.ship_type : '';
        x.product_status = x.product_status ? x.product_status : '';
        x.solution_type = x.solution_type ? x.solution_type : [];
        return x;
      });
      var skus = this.info.map(function (x) {
        return x.default_code;
      });
      this.getProductReason(skus);
    } else {
      this.data = [];
    }
  };

  OrderCustomerDetail.prototype.onOrderIdChange = function () {
    if (this.orderId) {
      this.getProductList();
    } else {
      this.productList = [];
    }
  };

  OrderCustomerDetail.prototype.getSelectList = function () {
    var _this = this;

    this.customProblemService.queryCpReasonEnum(new http["RequestParams"]({})).subscribe(function (data) {
      if (data.length) {
        _this.reasonList = data[0];
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderCustomerDetail.prototype.getProductList = function () {
    var _this = this;

    this.productList = [];
    this.customProblemService.queryCustomerProblemProduct(new http["RequestParams"]({
      order_id: this.orderId
    })).subscribe(function (data) {
      _this.productList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  OrderCustomerDetail.prototype.addBtn = function () {
    this.data.push({
      save_flag: 0,
      index: uuid_default.a.generate(),
      create_time: moment_default()(new Date()),
      create_user: store["a" /* default */].state.userModule.id,
      customer_reason: '',
      default_code: '',
      info1: '',
      is_return_user: false,
      logistic_reason: '',
      name: '',
      note: '',
      product: 0,
      product_qty: 1,
      product_status: '',
      sale_tag: '',
      ship_type: '',
      stock_processed: '',
      w_return_reason: '',
      w_warehouse_reason: '',
      warehouse_reason: '',
      is_warehouse_in: false,
      solution_type: []
    });
    this.currentRow = this.data.length;
  };

  OrderCustomerDetail.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target && value.target.value) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }

    if (column === 'name') {
      var item = this.productList.find(function (x) {
        return x.id === value;
      });

      if (item) {
        row.name = item.name;
        row.product = item.product_id;
        row.default_code = item.default_code;

        if (this.productReason[item.default_code] === undefined) {
          this.getProductReason([item.default_code]);
        }
      }
    }
  };

  OrderCustomerDetail.prototype.saveBtn = function () {
    var _this = this;

    var list = [];
    var beforeSaveData = JSON.parse(JSON.stringify(this.data));

    for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
      var i = _a[_i];
      i.solution_type = i.solution_type.filter(function (x) {
        return x != null;
      });
      delete i.index;
      delete i.default_code;
      delete i.name;
      delete i.product_name;
      delete i.is_warehouse_in;

      if (i.save_flag) {
        delete i.create_time;
      }

      if (!i.ship_type) {
        delete i.ship_type;
      }

      if (!i.product_status) {
        delete i.product_status;
      }

      if (!i.stock_processed) {
        i.stock_processed = null;
      }

      list.push(i);
    }

    if (this.deleteList.length) {
      for (var _b = 0, _c = this.deleteList; _b < _c.length; _b++) {
        var j = _c[_b];
        j.solution_type = j.solution_type.filter(function (x) {
          return x != null;
        });
        delete j.index;
        delete j.default_code;
        delete j.name;
        delete j.product_name;
        delete j.is_warehouse_in;

        if (j.save_flag) {
          delete j.create_time;
        }

        if (!j.ship_type) {
          delete j.ship_type;
        }

        if (!j.product_status) {
          delete j.product_status;
        }

        if (!j.stock_processed) {
          j.stock_processed = null;
        }

        list.push(j);
      }
    }

    this.pickingService.saveCustomerProblemByOrderId(new http["RequestParams"]({
      order_id: parseInt(this.orderId),
      problem_list: list
    }, this.loading)).subscribe(function () {
      _this.deleteList = [];

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.getCustomerList();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error(err.message);

      _this.data = JSON.parse(JSON.stringify(beforeSaveData));
    });
  };

  OrderCustomerDetail.prototype.cancelBtn = function () {
    this.currentRow = -1;
    this.getCustomerList();
  };

  OrderCustomerDetail.prototype.onDel = function (row) {
    this.currentRow = -1;
    var item = this.data.find(function (x) {
      return x.index === row.index;
    });

    if (item.save_flag == 1) {
      item['save_flag'] = 2;
      this.deleteList.push(item);
    }

    item['save_flag'] = 2;
    this.data = this.data.filter(function (x) {
      return !x.save_flag || x.save_flag < 2;
    });
  };

  OrderCustomerDetail.prototype.onSkuSearch = function (key) {
    var _this = this;

    var params = common_service["a" /* CommonService */].createQueryCondition({
      product_number: key
    }, tslib_es6["a" /* __assign */]({
      product_number: 'like'
    }, form_config["a" /* formConfig */].condition));
    params['page_index'] = 1;
    params['page_size'] = 10;
    this.productService.queryProducForStockMove(new http["RequestParams"](params)).subscribe(function (data) {
      _this.skuSource = data.map(function (x) {
        return '[' + x.default_code + ']' + x.name;
      });
      _this.skuQueryResult = data;
    });
  };

  OrderCustomerDetail.prototype.onSkuChange = function (key, row) {
    if (key && key.length > 1) {
      var productItem = this.skuQueryResult.find(function (x) {
        return '[' + x.default_code + ']' + x.name === key;
      });
      row.product = productItem ? productItem.id : '';
    }
  };

  OrderCustomerDetail.prototype.searchMore = function (row) {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {}, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      if (_this.productReason[data.default_code] === undefined) {
        _this.getProductReason([data.default_code]);
      } //sku不能重复


      var item = _this.data.find(function (x) {
        return x.index === row.index;
      });

      item['name'] = '[' + data.default_code + ']' + data.name;
      item['product'] = data.product_id;
      item['default_code'] = data.default_code;
      _this.currentRow = -1;
      setTimeout(function () {
        _that.currentRow = row.index;
      }, 1000);
    });
  };

  OrderCustomerDetail.prototype.getCustomerList = function () {
    var _this = this;

    this.orderService.getCustomerList(new http["RequestParams"]({
      order_id: this.orderId
    }, this.loading)).subscribe(function (data) {
      _this.data = data.map(function (x) {
        if (x.stock_processed) {
          x.stock_processed = _this.moment(x.stock_processed, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.stock_processed = '';
        }

        if (x.create_time) {
          x.create_time = _this.moment(x.create_time, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.create_time = '';
        }

        if (!(x.solution_type instanceof Array)) {
          x.solution_type = [x.solution_type];
        }

        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        return x;
      });

      _this.closeLoading();
    }, function (err) {
      _this.closeLoading(); // this.$message.error(err.message)

    });
  };

  OrderCustomerDetail.prototype.calculateRowStyle = function (row) {
    if (row.is_return_user) {
      return 'red-text';
    } else if (row.is_warehouse_in) {
      return 'green-text';
    } else {
      return 'default-text';
    }
  };

  OrderCustomerDetail.prototype.datetolocal = function (date, fmt) {
    if (fmt === void 0) {
      fmt = 'yyyy-MM-dd hh:mm';
    } // 空数据处理


    if (date === null || date === undefined || date === '') {
      return '';
    } // 如果是时间戳则转化为时间


    if (typeof date === 'number') {
      date = new Date(date);
    }

    date = new Date(Date.parse(date.replace(/-/g, '/')));
    var utc = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
    date = new Date(utc);
    var o = {
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds(),
      'q+': Math.floor((date.getMonth() + 3) / 3),
      S: date.getMilliseconds() // 毫秒

    };

    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, date.getFullYear() + '');
    }

    for (var k in o) {
      // tslint:disable-next-line:max-line-length
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
    }

    return fmt;
  };

  OrderCustomerDetail.prototype.getProductReason = function (sku) {
    // this.productReason = [
    //     'B-WARE 收到二手退货产品',
    //     'AR01-große Beschädigung 大面积破损',
    //     'AR02-kleine Macke小瑕疵/破损',
    //     'AR03-Geruch有气味',
    //     'AR07-Funktion beeinträchtigt 功能受损不能用',
    //     'PN-Passt nicht 不适合',
    //     'AN-Artikeln nicht wie angegeben 产品与描述不符',
    //     'IU-Inkompatibel oder ungeeignet 与客人家居不匹配',
    //     'LQ-Leistung oder Qualität ungenügend 质量不好',
    //     'OI-Oder ID 批次问题',
    //     'ZW-Zu Wenig Verschickt 少发货',
    //     'FP-von Produktion falsch gepackt工厂包错'
    // ]
    var _this = this;

    var that = this;
    that.innerAction.setActionAPI('product_management/query_product_reason_enum', common_service["a" /* CommonService */].getMenuCode('common-menu'));
    this.loading['innerAction'] = this.innerAction;
    this.publicService.query(new http["RequestParams"]({
      sku_list: sku
    }, this.loading)).subscribe(function (data) {
      _this.closeLoading();

      if (!Object.keys(_this.productReason).length) {
        _this.productReason = data;
      } else {
        for (var i in data) {
          if (_this.productReason[i] === undefined) {
            _this.productReason[i] = data[i];
          }
        }
      }
    }, function (err) {
      _this.closeLoading();

      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderCustomerDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderCustomerDetail.prototype, "height", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderCustomerDetail.prototype, "orderId", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderCustomerDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OrderCustomerDetail.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('height'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderCustomerDetail.prototype, "onHeightChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderCustomerDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('orderId'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OrderCustomerDetail.prototype, "onOrderIdChange", null);

  OrderCustomerDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], OrderCustomerDetail);
  return OrderCustomerDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var order_customer_detailvue_type_script_lang_ts_ = (order_customer_detailvue_type_script_lang_ts_OrderCustomerDetail);
// CONCATENATED MODULE: ./src/components/orders/order-customer-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_order_customer_detailvue_type_script_lang_ts_ = (order_customer_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/orders/order-customer-detail.vue?vue&type=style&index=0&lang=css&
var order_customer_detailvue_type_style_index_0_lang_css_ = __webpack_require__("71c0");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/orders/order-customer-detail.vue?vue&type=custom&index=0&blockType=i18n
var order_customer_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("00b7");

// CONCATENATED MODULE: ./src/components/orders/order-customer-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_order_customer_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof order_customer_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(order_customer_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var order_customer_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "bd43":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/add-order-detail.vue?vue&type=template&id=acdf1fa2&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px"}},[_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.addBtn}},[_c('a-icon',{attrs:{"type":"plus"}}),_vm._v(_vm._s(_vm.$t('actions.add')))],1)],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"index","customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"bordered":""}},[_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('product'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-auto-complete',{staticStyle:{"width":"100%"},attrs:{"dataSource":_vm.skuSource,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"defaultValue":row.default_code,"size":"small","placeholder":"input for search"},on:{"search":_vm.onSkuSearch,"change":function (e) { return _vm.onRowChange(row, 'default_code', e); }}},[_c('template',{slot:"dataSource"},[_vm._l((_vm.skuSource),function(opt){return _c('a-select-option',{key:opt,attrs:{"value":opt,"title":opt}},[_vm._v(" "+_vm._s(opt)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(row)}}},[_vm._v(" Search More ")])])],2)],2):_c('span',[_vm._v(_vm._s(row.default_code))])]}}])}),_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('description'),"data-index":"name","align":"center"}}),_c('a-table-column',{key:"product_uom_qty",attrs:{"title":_vm.$t('quantity'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_uom_qty']),expression:"['product_uom_qty']"}],style:({ width: '100%', background: '#ecc5e9' }),attrs:{"decimalSeparator":",","value":row.product_uom_qty,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_uom_qty', e); }}}):_c('span',[_vm._v(_vm._s(row.product_uom_qty))])]}}])}),_c('a-table-column',{key:"available_qty",attrs:{"title":_vm.$t('available_qty'),"data-index":"available_qty","align":"center"}}),_c('a-table-column',{key:"delivered",attrs:{"title":_vm.$t('delivered'),"data-index":"delivered","align":"center"}}),_c('a-table-column',{key:"invoiced",attrs:{"title":_vm.$t('invoiced'),"data-index":"invoiced","align":"center"}}),_c('a-table-column',{key:"price_unit",attrs:{"title":_vm.$t('price_unit'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['price_unit']),expression:"['price_unit']"}],style:({ width: '100%', background: '#ecc5e9' }),attrs:{"decimalSeparator":",","value":row.price_unit,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'price_unit', e); }}}):_c('span',[_vm._v(_vm._s(row.price_unit))])]}}])}),_c('a-table-column',{key:"price_tax",attrs:{"title":_vm.$t('price_tax'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['price_tax']),expression:"['price_tax']"}],style:({ width: '100%' }),attrs:{"value":row.price_tax,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'price_tax', e); }}},_vm._l((_vm.taxesList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.price_tax,_vm.taxesList))+" ")])]}}])}),_c('a-table-column',{key:"subtotal",attrs:{"title":_vm.$t('subtotal'),"data-index":"subtotal","align":"center"}}),_c('a-table-column',{key:"fulfillment_center",attrs:{"title":_vm.$t('fulfillment_center'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fulfillment_center']),expression:"['fulfillment_center']"}],style:({ width: '100%' }),attrs:{"value":row.fulfillment_center,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'fulfillment_center', e); }}}):_c('span',[_vm._v(_vm._s(row.fulfillment_center))])]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.onDel(row)}}},[_vm._v(" "+_vm._s(_vm.$t('actions.delete'))+" ")]),_c('a',{on:{"click":function (e) { return _vm.cancelBtn(e); }}},[_vm._v(" "+_vm._s(_vm.$t('actions.cancel'))+" ")])]}}])})],1),_c('div',{staticStyle:{"width":"100%","display":"inline-block"}},[_c('div',{staticStyle:{"width":"200px","float":"right"}},[_c('p',{staticStyle:{"padding":"0","margin":"0"}},[_vm._v(" Untaxed Amount： "+_vm._s(_vm.untax.toFixed(2))+" ")]),_c('p',{staticStyle:{"padding":"0","margin":"0","border-bottom":"1px solid #aaa"}},[_vm._v(" Taxes： "+_vm._s(_vm.tax.toFixed(2))+" ")]),_c('p',{staticStyle:{"padding":"0","margin":"0"}},[_vm._v(" Total： "+_vm._s(parseFloat(_vm.total.toFixed(2)).toFixed(2))+" ")])])])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/orders/add-order-detail.vue?vue&type=template&id=acdf1fa2&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.to-fixed.js
var es_number_to_fixed = __webpack_require__("b680");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/orders/add-order-detail.vue?vue&type=script&lang=ts&

















var add_order_detailvue_type_script_lang_ts_AddOrderDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AddOrderDetail, _super);

  function AddOrderDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.operateCnt = 0;
    _this.untax = 0;
    _this.tax = 0;
    _this.total = 0;
    return _this;
  }

  AddOrderDetail.prototype.mounted = function () {
    if (this.taxesList.length) {
      this.calcTaxs();
    }
  };

  AddOrderDetail.prototype.onInfoChange = function () {
    if (this.info.length) {
      this.data = this.info.map(function (x) {
        return x;
      });
      this.calcTaxs();
    }
  };

  AddOrderDetail.prototype.onTaxesListChange = function () {
    if (this.info.length) {
      this.data = this.info.map(function (x) {
        return x;
      });
      this.calcTaxs();
    }
  };

  AddOrderDetail.prototype.addBtn = function () {
    this.data.push({
      index: uuid_default.a.generate(),
      default_code: '',
      name: '',
      product_uom_qty: 1,
      delivered: 0,
      invoiced: 0,
      price_unit: 0,
      price_tax: 0,
      subtotal: 0,
      fulfillment_center: '',
      product_id: 0
    });
    this.$emit('change', this.data);
    this.currentRow = this.data.length;
  };

  AddOrderDetail.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      row[column] = value.target.value;
    } else {
      row[column] = value;
    }

    if (column === 'default_code') {
      var productItem = this.skuQueryResult.find(function (x) {
        return '[' + x.default_code + ']' + x.name == value;
      });

      if (productItem) {
        row.default_code = productItem.default_code;
        row.name = productItem.name;
        row.product_id = productItem.product_id;
        row.available_qty = productItem.stock_available_quantity > 0 ? productItem.stock_available_quantity : 0;
      }
    }

    if (column === 'price_unit' && row.product_uom_qty > 0) {
      var total = (row.price_unit * row.product_uom_qty).toFixed(2);
      row.subtotal = total;
      this.calcTaxs();
    }

    if (column === 'product_uom_qty' && row.price_unit > 0) {
      var total = (row.price_unit * row.product_uom_qty).toFixed(2);
      row.subtotal = total;
      this.calcTaxs();
    }

    if (column === 'price_tax') {
      var tax = this.taxesList.find(function (x) {
        return x.id === value;
      });

      if (tax && tax.amount < 0) {
        this.$message.error('税率不能为负数，请重新选择');
        return;
      }
    }

    if (column === 'price_tax' && row.product_uom_qty > 0 && row.price_unit > 0) {
      this.calcTaxs();
    }

    this.$emit('change', this.data);
  };

  AddOrderDetail.prototype.calcTaxs = function () {
    if (this.data.length) {
      this.untax = 0;
      this.total = 0;
      this.tax = 0;

      for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
        var i = _a[_i];
        var subtotal = i.subtotal ? i.subtotal : 0;
        this.total += parseFloat(subtotal);

        if (i.price_tax > 0) {
          var amount = 0;
          var tax = this.taxesList.find(function (x) {
            return x.id === i.price_tax;
          });

          if (tax && tax.amount > 0) {
            amount = tax.amount;
          }

          this.tax += subtotal * amount / (100 + amount);
        }
      }

      this.untax = this.total - this.tax;
    }
  };

  AddOrderDetail.prototype.cancelBtn = function (e) {
    e.stopPropagation();
    this.currentRow = -1;
  };

  AddOrderDetail.prototype.onDel = function (row) {
    this.currentRow = -1;
    var item = this.data.find(function (x) {
      return x.index === row.index;
    });
    item['save_flag'] = 2;
    this.data = this.data.filter(function (x) {
      return !x.save_flag || x.save_flag < 2;
    });
    this.$emit('change', this.data);
  };

  AddOrderDetail.prototype.onSkuSearch = function (key) {
    var _this = this;

    var params = common_service["a" /* CommonService */].createQueryCondition({
      default_code: key
    }, tslib_es6["a" /* __assign */]({
      default_code: 'like'
    }, form_config["a" /* formConfig */].condition));
    params['page_index'] = 1;
    params['page_size'] = 10;
    this.productService.queryAsyncProductInfo(new http["RequestParams"](params, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.skuSource = data.map(function (x) {
        return '[' + x.default_code + ']' + x.name;
      });
      _this.skuQueryResult = data;
    });
  };

  AddOrderDetail.prototype.searchMore = function (row) {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {}, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      var item = _this.data.find(function (x) {
        return x.index === row.index;
      });

      item['name'] = '[' + data.default_code + ']' + data.name;
      item['product_id'] = data.product_id;
      item['default_code'] = data.default_code;
      row.available_qty = data.stock_available_quantity > 0 ? data.stock_available_quantity : 0;
      _this.currentRow = -1;
      setTimeout(function () {
        _that.currentRow = row.index;
      }, 100);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddOrderDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddOrderDetail.prototype, "taxesList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddOrderDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('taxesList'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddOrderDetail.prototype, "onTaxesListChange", null);

  AddOrderDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AddOrderDetail);
  return AddOrderDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var add_order_detailvue_type_script_lang_ts_ = (add_order_detailvue_type_script_lang_ts_AddOrderDetail);
// CONCATENATED MODULE: ./src/components/orders/add-order-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var orders_add_order_detailvue_type_script_lang_ts_ = (add_order_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/orders/add-order-detail.vue?vue&type=style&index=0&lang=css&
var add_order_detailvue_type_style_index_0_lang_css_ = __webpack_require__("d6b6e");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/orders/add-order-detail.vue?vue&type=custom&index=0&blockType=i18n
var add_order_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("d8ed");

// CONCATENATED MODULE: ./src/components/orders/add-order-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  orders_add_order_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof add_order_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(add_order_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var add_order_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "c431":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"log":"Log","type":"Type","operater":"Operater","date":"Date"},"zh-cn":{"log":"日志","type":"类型","operater":"操作人","date":"日期"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "cd8c":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"company_name":"Company Name","vat":"Vat","street1":"street1","street2":"street2","country":"Country","state":"State","city":"City","postcode":"postcode"},"action":{"submit":"Create","cancel":"Cancel"}},"zh-cn":{"columns":{"company_name":"公司名称","vat":"Vat","street1":"街道1","street2":"街道2","country":"国家","state":"省","city":"城市","postcode":"邮编"},"action":{"submit":"提交","cancel":"取消"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "d030":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_cancel_order_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a732");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_cancel_order_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_cancel_order_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_cancel_order_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "d2de":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "d6b6e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_order_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9029");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_order_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_order_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "d8ed":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9152");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_order_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ee51":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1a9a");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "fdbca":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_manage_content_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d2de");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_manage_content_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_order_manage_content_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ })

}]);