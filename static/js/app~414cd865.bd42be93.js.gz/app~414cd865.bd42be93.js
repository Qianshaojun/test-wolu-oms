(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~414cd865"],{

/***/ "112a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_logistics_provider_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b694");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_logistics_provider_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_logistics_provider_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_logistics_provider_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "15f4":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"alerts":"alerts","ann_sales":"ann_sales","buyer_change_give_date":"buyer_change_give_date","buyer_change_give_date_memo":"buyer_change_give_date_memo","cp_note":"cp_note","date_expected":"date_expected","eqty":"eqty","finish_qty":"finish_qty","give_date":"give_date","id":"id","ist_box_qty":"ist_box_qty","merchandiser":"merchandiser","mrate":"mrate","dept_id":"Department","note":"note","period":"period","persist":"persist","product_id":"product_id","product_manual_code":"product_manual_code","product_manual_url":"product_manual_url","product_manual_version":"product_manual_version","product_qty":"product_qty","product_specification_url":"product_specification_url","product_specification_version":"product_specification_version","product_uom":"product_uom","product_ve":"product_ve","real_pre_purchase_order":"real_pre_purchase_order","sales_change_give_date":"sales_change_give_date","sales_change_give_date_memo":"sales_change_give_date_memo","sales_expected_give_date":"sales_expected_give_date","sequence":"sequence","sqty":"sqty","state":"state","user_purchase":"user_purchase","warehouse_id":"warehouse_id","import_memo":"Import Memo","sale_range_from":"Sale Range From","sale_range_to":"Sale Range To","is_special_check":"Is Need Special Check","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Cancel"}},"zh-cn":{"alerts":"alerts","ann_sales":"ann_sales","buyer_change_give_date":"采购变更交期","buyer_change_give_date_memo":"采购变更交期备注","cp_note":"客诉备注","date_expected":"期望入库","eqty":"eqty","finish_qty":"已发货数量","give_date":"合同交期","id":"id","ist_box_qty":"箱数","merchandiser":"跟单员","mrate":"装箱率","dept_id":"部门","note":"备注","period":"period","persist":"persist","product_id":"产品","product_manual_code":"product_manual_code","product_manual_url":"product_manual_url","product_manual_version":"说明书版本号","product_qty":"产品数量","product_specification_url":"product_specification_url","product_specification_version":"工艺单版本号","product_uom":"产品计量单位","product_ve":"product_ve","real_pre_purchase_order":"实际采购合同号","sales_change_give_date":"运营变更交期","sales_change_give_date_memo":"运营变更交期备注","sales_expected_give_date":"运营期望交期","sequence":"sequence","sqty":"需求个数","state":"状态","user_purchase":"采购员","warehouse_id":"仓库","import_memo":"合同交期备注","sale_range_from":"预售开始月份","sale_range_to":"预售结束月份","is_special_check":"是否需特批","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"取消"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "187f":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "1f5f":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"submit":"Submit","cancel":"Cancel","columns":{"product_id":"Product Id","product_qty":"Product Qty","package_qty":"Package Qty","box_qty":"Box Qty","order2_id":"Final Purchase Order","pack_qty":"Pack Qty","out_number":"Out Number","width":"Width","length":"Length","height":"Height","dept_id":"Department"}},"zh-cn":{"submit":"提交","cancel":"取消","columns":{"product_id":"产品","product_qty":"产品数量","package_qty":"实际数量","box_qty":"实际箱数","order2_id":"Final Purchase Order","pack_qty":"装箱量","out_number":"外箱合同号","width":"宽度","length":"长度","height":"高度","dept_id":"部门"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "37c1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("6dd0");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "3c91":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-package-order-product.vue?vue&type=template&id=1eab377a&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.product_id'),"required":""}},[_c('a-auto-complete',{staticStyle:{"width":"200px"},attrs:{"dataSource":_vm.skuSource,"dropdown-match-select-width":false,"dropdown-style":{ width: '350px' },"size":"small","placeholder":"input for search"},on:{"search":_vm.onSkuSearch,"change":function (e) { return _vm.onProductChange(e); }},model:{value:(_vm.product.name),callback:function ($$v) {_vm.$set(_vm.product, "name", $$v)},expression:"product.name"}},[_c('template',{slot:"dataSource"},[_vm._l((_vm.skuSource),function(opt){return _c('a-select-option',{key:opt,attrs:{"value":opt,"title":opt}},[_vm._v(" "+_vm._s(opt)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(_vm.row)}}},[_vm._v(" Search More ")])])],2)],2)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.product_qty'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "product_qty",
                            { rules: _vm.rules.required }
                        ]),expression:"[\n                            `product_qty`,\n                            { rules: rules.required }\n                        ]"}],style:({
                            width: '200px',
                            background: '#ecc5e9'
                        }),attrs:{"size":"small","min":0}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.package_qty'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "package_qty",
                            { rules: _vm.rules.required }
                        ]),expression:"[\n                            `package_qty`,\n                            { rules: rules.required }\n                        ]"}],style:({
                            width: '200px',
                            background: '#ecc5e9'
                        }),attrs:{"size":"small","min":0}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.box_qty')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["box_qty"]),expression:"[`box_qty`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","min":0}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.dept_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'dept_id',
                            {
                                initialValue: ''
                            },
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'dept_id',\n                            {\n                                initialValue: ''\n                            },\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],staticStyle:{"width":"190px"},attrs:{"size":"small","filterOption":_vm.filterSelectOption}},_vm._l((_vm.departmentList),function(item){return _c('a-select-option',{key:item.id,attrs:{"value":item.id}},[_vm._v(" "+_vm._s(_vm.$t(item.dept_name))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.order2_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["order2_id"]),expression:"[`order2_id`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.pack_qty')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["pack_qty"]),expression:"[`pack_qty`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","min":0}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.out_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["out_number"]),expression:"[`out_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.width')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["width"]),expression:"[`width`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","min":0}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.height')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["height"]),expression:"[`height`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","min":0}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.length')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["length"]),expression:"[`length`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","min":0}})],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/add-package-order-product.vue?vue&type=template&id=1eab377a&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-package-order-product.vue?vue&type=script&lang=ts&















var add_package_order_productvue_type_script_lang_ts_AddPackageOrderProduct =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AddPackageOrderProduct, _super);

  function AddPackageOrderProduct() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.productService = new product_service["a" /* ProductService */]();
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.product = {};
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  AddPackageOrderProduct.prototype.submit = function () {
    return true;
  };

  AddPackageOrderProduct.prototype.cancel = function () {
    return;
  };

  AddPackageOrderProduct.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  AddPackageOrderProduct.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!_this.product || !_this.product.product_id) {
        _this.$message.info('请选择产品再添加');

        return;
      }

      if (!values['dept_id']) {
        delete values['dept_id'];
      }

      if (!err) {
        values['package_id'] = _this.package_id;
        values['product_id'] = _this.product.product_id;

        _this.saveInfo(values);
      }
    });
  };

  AddPackageOrderProduct.prototype.saveInfo = function (values) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/create_package_order_line', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"](values, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AddPackageOrderProduct.prototype.onSkuSearch = function (key) {
    var _this = this;

    var params = common_service["a" /* CommonService */].createQueryCondition({
      default_code: key
    }, tslib_es6["a" /* __assign */]({
      default_code: 'like'
    }, form_config["a" /* formConfig */].condition));
    params['page_index'] = 1;
    params['page_size'] = 10;
    this.productService.queryAsyncProductInfo(new http["RequestParams"](params, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.skuSource = data.map(function (x) {
        return '[' + x.default_code + ']' + x.name;
      });
      _this.skuQueryResult = data;
    });
  };

  AddPackageOrderProduct.prototype.searchMore = function () {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {}, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      _this.product['name'] = '[' + data.default_code + ']' + data.name;
      _this.product['product_id'] = data.product_id;
      _this.product['default_code'] = data.default_code;

      _this.skuSource.push(_this.product['name']);

      _this.skuQueryResult.push(data);
    });
  };

  AddPackageOrderProduct.prototype.onProductChange = function (e) {
    var item = this.skuQueryResult.find(function (x) {
      return '[' + x.default_code + ']' + x.name == e;
    });

    if (item) {
      this.product['name'] = '[' + item.default_code + ']' + item.name;
      this.product['product_id'] = item.product_id;
      this.product['default_code'] = item.default_code;
    } else {
      this.product['product_id'] = 0;
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddPackageOrderProduct.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddPackageOrderProduct.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddPackageOrderProduct.prototype, "package_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddPackageOrderProduct.prototype, "departmentList", void 0);

  AddPackageOrderProduct = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AddPackageOrderProduct);
  return AddPackageOrderProduct;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var add_package_order_productvue_type_script_lang_ts_ = (add_package_order_productvue_type_script_lang_ts_AddPackageOrderProduct);
// CONCATENATED MODULE: ./src/components/purchase/add-package-order-product.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_add_package_order_productvue_type_script_lang_ts_ = (add_package_order_productvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/add-package-order-product.vue?vue&type=style&index=0&lang=css&
var add_package_order_productvue_type_style_index_0_lang_css_ = __webpack_require__("d870");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/add-package-order-product.vue?vue&type=custom&index=0&blockType=i18n
var add_package_order_productvue_type_custom_index_0_blockType_i18n = __webpack_require__("c47d");

// CONCATENATED MODULE: ./src/components/purchase/add-package-order-product.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_add_package_order_productvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof add_package_order_productvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(add_package_order_productvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var add_package_order_product = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "42f5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-logistics-provider-detail.vue?vue&type=template&id=25586c20&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.editAble),expression:"editAble"}],staticStyle:{"padding":"0 20px 10px 0px"}},[_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.addBtn}},[_c('a-icon',{attrs:{"type":"plus"}}),_vm._v(" "+_vm._s(_vm.$t('actions.add'))+" ")],1)],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"index","columns":_vm.columns,"customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"scroll":{ x: 2500, y: 500 },"bordered":""},scopedSlots:_vm._u([{key:"prescription",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['prescription']),expression:"['prescription']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"value":row.prescription,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e, row, 'prescription'); }}},_vm._l((_vm.$dict.LogisticsProviderAging),function(i){return _c('a-select-option',{key:i.value,attrs:{"value":i.value}},[_vm._v(" "+_vm._s(_vm.$t(i.label))+" ")])}),1):_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(typeof row.prescription == 'object' && row.prescription.length == 2 ? row.prescription[0] : row.prescription,'LogisticsProviderAging'))))])]}},{key:"dest_country_id",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dest_country_id']),expression:"['dest_country_id']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"showSearch":"","value":row.dest_country_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small","filterOption":_vm.filterSelectOption},on:{"change":function (e) { return _vm.handleChange(e, row, 'dest_country_id'); }}},_vm._l((_vm.countryList),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code}},[_vm._v(" "+_vm._s(i.name)+" ")])}),1):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(typeof row.dest_country_id == 'object' && row.dest_country_id.length == 2 ? row.dest_country_id[0] : row.dest_country_id,_vm.countryList)))])]}},{key:"shipping_channel",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{staticClass:"required",attrs:{"size":"small","value":row.shipping_channel},on:{"change":function (e) { return _vm.handleChange(
                            e.target.value,
                            row,
                            'shipping_channel'
                        ); }}}):_c('span',[_vm._v(_vm._s(row.shipping_channel))])]}},{key:"shipping_schedule_timeliness",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{staticClass:"required",attrs:{"size":"small","value":row.shipping_schedule_timeliness},on:{"change":function (e) { return _vm.handleChange(
                            e.target.value,
                            row,
                            'shipping_schedule_timeliness'
                        ); }}}):_c('span',[_vm._v(_vm._s(row.shipping_schedule_timeliness))])]}},{key:"payment_method",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{staticClass:"required",attrs:{"size":"small","value":row.payment_method},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'payment_method'); }}}):_c('span',[_vm._v(_vm._s(row.payment_method))])]}},{key:"is_include_tax",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-checkbox',{attrs:{"size":"small","checked":row.is_include_tax},on:{"change":function (e) { return _vm.handleChange(
                            e.target.checked,
                            row,
                            'is_include_tax'
                        ); }}}):_c('span',[_c('a-checkbox',{attrs:{"size":"small","checked":row.is_include_tax,"disabled":""}})],1)]}},{key:"is_charged_magnetic_sensitive",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-checkbox',{attrs:{"size":"small","checked":row.is_charged_magnetic_sensitive},on:{"change":function (e) { return _vm.handleChange(
                            e.target.checked,
                            row,
                            'is_charged_magnetic_sensitive'
                        ); }}}):_c('span',[_c('a-checkbox',{attrs:{"size":"small","checked":row.is_charged_magnetic_sensitive,"disabled":""}})],1)]}},{key:"is_self_mention",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-checkbox',{attrs:{"size":"small","checked":row.is_self_mention},on:{"change":function (e) { return _vm.handleChange(
                            e.target.checked,
                            row,
                            'is_self_mention'
                        ); }}}):_c('span',[_c('a-checkbox',{attrs:{"size":"small","checked":row.is_self_mention,"disabled":""}})],1)]}},{key:"is_self_report",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-checkbox',{attrs:{"size":"small","checked":row.is_self_report},on:{"change":function (e) { return _vm.handleChange(
                            e.target.checked,
                            row,
                            'is_self_report'
                        ); }}}):_c('span',[_c('a-checkbox',{attrs:{"size":"small","checked":row.is_self_report,"disabled":""}})],1)]}},{key:"overall_aging",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.overall_aging},on:{"change":function (e) { return _vm.handleChange(e, row, 'overall_aging'); }}}):_c('span',[_vm._v(_vm._s(row.overall_aging))])]}},{key:"head_aging",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.head_aging},on:{"change":function (e) { return _vm.handleChange(e, row, 'head_aging'); }}}):_c('span',[_vm._v(_vm._s(row.head_aging))])]}},{key:"delivery_aging",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.delivery_aging},on:{"change":function (e) { return _vm.handleChange(e, row, 'delivery_aging'); }}}):_c('span',[_vm._v(_vm._s(row.delivery_aging))])]}},{key:"loading_aging",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.loading_aging},on:{"change":function (e) { return _vm.handleChange(e, row, 'loading_aging'); }}}):_c('span',[_vm._v(_vm._s(row.loading_aging))])]}},{key:"transfer_aging",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.transfer_aging},on:{"change":function (e) { return _vm.handleChange(e, row, 'transfer_aging'); }}}):_c('span',[_vm._v(_vm._s(row.transfer_aging))])]}},{key:"unloading_aging",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.unloading_aging},on:{"change":function (e) { return _vm.handleChange(e, row, 'unloading_aging'); }}}):_c('span',[_vm._v(_vm._s(row.unloading_aging))])]}},{key:"kg_15_20",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_15_20},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_15_20'); }}}):_c('span',[_vm._v(_vm._s(row.kg_15_20))])]}},{key:"kg_21_50",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_21_50},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_21_50'); }}}):_c('span',[_vm._v(_vm._s(row.kg_21_50))])]}},{key:"kg_51_99",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_51_99},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_51_99'); }}}):_c('span',[_vm._v(_vm._s(row.kg_51_99))])]}},{key:"kg_100_199",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_100_199},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_100_199'); }}}):_c('span',[_vm._v(_vm._s(row.kg_100_199))])]}},{key:"kg_200_299",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_200_299},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_200_299'); }}}):_c('span',[_vm._v(_vm._s(row.kg_200_299))])]}},{key:"kg_300_499",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_300_499},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_300_499'); }}}):_c('span',[_vm._v(_vm._s(row.kg_300_499))])]}},{key:"kg_500_999",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_500_999},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_500_999'); }}}):_c('span',[_vm._v(_vm._s(row.kg_500_999))])]}},{key:"kg_1000",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.kg_1000},on:{"change":function (e) { return _vm.handleChange(e, row, 'kg_1000'); }}}):_c('span',[_vm._v(_vm._s(row.kg_1000))])]}},{key:"area_zone",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{attrs:{"size":"small","value":row.area_zone},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'area_zone'); }}}):_c('span',[_vm._v(_vm._s(row.area_zone))])]}},{key:"cbm_1",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.cbm_1},on:{"change":function (e) { return _vm.handleChange(e, row, 'cbm_1'); }}}):_c('span',[_vm._v(_vm._s(row.cbm_1))])]}},{key:"cbm_2",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.cbm_2},on:{"change":function (e) { return _vm.handleChange(e, row, 'cbm_2'); }}}):_c('span',[_vm._v(_vm._s(row.cbm_2))])]}},{key:"cbm_3",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.cbm_3},on:{"change":function (e) { return _vm.handleChange(e, row, 'cbm_3'); }}}):_c('span',[_vm._v(_vm._s(row.cbm_3))])]}},{key:"cbm_4",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","min":0,"value":row.cbm_4},on:{"change":function (e) { return _vm.handleChange(e, row, 'cbm_4'); }}}):_c('span',[_vm._v(_vm._s(row.cbm_4))])]}},{key:"customs_fee",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{attrs:{"size":"small","value":row.customs_fee},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'customs_fee'); }}}):_c('span',[_vm._v(_vm._s(row.customs_fee))])]}},{key:"clearance_fee",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{attrs:{"size":"small","value":row.clearance_fee},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'clearance_fee'); }}}):_c('span',[_vm._v(_vm._s(row.clearance_fee))])]}},{key:"action",fn:function(row){return [_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('actions.ok'),"cancelText":_vm.$t('actions.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDel(row)}}},[_c('a',{staticClass:"btnDel"},[_c('a-icon',{attrs:{"type":"delete"}})],1)])]}}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/add-logistics-provider-detail.vue?vue&type=template&id=25586c20&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__("a434");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-logistics-provider-detail.vue?vue&type=script&lang=ts&

















var add_logistics_provider_detailvue_type_script_lang_ts_AddLogisticsProviderDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AddLogisticsProviderDetail, _super);

  function AddLogisticsProviderDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.operateCnt = 0;
    _this.moment = moment_default.a;
    _this.columns = [{
      title: _this.$t('columns.channel_info'),
      children: [{
        title: _this.$t('columns.prescription'),
        key: 'prescription',
        dataIndex: 'prescription',
        width: 100,
        scopedSlots: {
          customRender: 'prescription'
        }
      }, {
        title: _this.$t('columns.dest_country_id'),
        key: 'dest_country_id',
        dataIndex: 'dest_country_id',
        width: 100,
        scopedSlots: {
          customRender: 'dest_country_id'
        }
      }, {
        title: _this.$t('columns.shipping_channel'),
        key: 'shipping_channel',
        dataIndex: 'shipping_channel',
        width: 100,
        scopedSlots: {
          customRender: 'shipping_channel'
        }
      }, {
        title: _this.$t('columns.shipping_schedule_timeliness'),
        key: 'shipping_schedule_timeliness',
        dataIndex: 'shipping_schedule_timeliness',
        width: 100,
        scopedSlots: {
          customRender: 'shipping_schedule_timeliness'
        }
      }, {
        title: _this.$t('columns.payment_method'),
        key: 'payment_method',
        dataIndex: 'payment_method',
        width: 100,
        scopedSlots: {
          customRender: 'payment_method'
        }
      }, {
        title: _this.$t('columns.is_include_tax'),
        key: 'is_include_tax',
        dataIndex: 'is_include_tax',
        width: 100,
        scopedSlots: {
          customRender: 'is_include_tax'
        }
      }, {
        title: _this.$t('columns.is_charged_magnetic_sensitive'),
        key: 'is_charged_magnetic_sensitive',
        dataIndex: 'is_charged_magnetic_sensitive',
        width: 100,
        scopedSlots: {
          customRender: 'is_charged_magnetic_sensitive'
        }
      }, {
        title: _this.$t('columns.is_self_mention'),
        key: 'is_self_mention',
        dataIndex: 'is_self_mention',
        width: 100,
        scopedSlots: {
          customRender: 'is_self_mention'
        }
      }, {
        title: _this.$t('columns.is_self_report'),
        key: 'is_self_report',
        dataIndex: 'is_self_report',
        width: 100,
        scopedSlots: {
          customRender: 'is_self_report'
        }
      }]
    }, {
      title: _this.$t('columns.aging_info'),
      children: [{
        title: _this.$t('columns.overall_aging'),
        key: 'overall_aging',
        dataIndex: 'overall_aging',
        width: 100,
        scopedSlots: {
          customRender: 'overall_aging'
        }
      }, {
        title: _this.$t('columns.head_aging'),
        key: 'head_aging',
        dataIndex: 'head_aging',
        width: 100,
        scopedSlots: {
          customRender: 'head_aging'
        }
      }, {
        title: _this.$t('columns.delivery_aging'),
        key: 'delivery_aging',
        dataIndex: 'delivery_aging',
        width: 100,
        scopedSlots: {
          customRender: 'delivery_aging'
        }
      }, {
        title: _this.$t('columns.loading_aging'),
        key: 'loading_aging',
        dataIndex: 'loading_aging',
        width: 100,
        scopedSlots: {
          customRender: 'loading_aging'
        }
      }, {
        title: _this.$t('columns.transfer_aging'),
        key: 'transfer_aging',
        dataIndex: 'transfer_aging',
        width: 100,
        scopedSlots: {
          customRender: 'transfer_aging'
        }
      }, {
        title: _this.$t('columns.unloading_aging'),
        key: 'unloading_aging',
        dataIndex: 'unloading_aging',
        width: 100,
        scopedSlots: {
          customRender: 'unloading_aging'
        }
      }]
    }, {
      title: _this.$t('columns.price_info'),
      children: [{
        title: _this.$t('columns.kg_15_20'),
        key: 'kg_15_20',
        dataIndex: 'kg_15_20',
        width: 100,
        scopedSlots: {
          customRender: 'kg_15_20'
        }
      }, {
        title: _this.$t('columns.kg_21_50'),
        key: 'kg_21_50',
        dataIndex: 'kg_21_50',
        width: 100,
        scopedSlots: {
          customRender: 'kg_21_50'
        }
      }, {
        title: _this.$t('columns.kg_51_99'),
        key: 'kg_51_99',
        dataIndex: 'kg_51_99',
        width: 100,
        scopedSlots: {
          customRender: 'kg_51_99'
        }
      }, {
        title: _this.$t('columns.kg_100_199'),
        key: 'kg_100_199',
        dataIndex: 'kg_100_199',
        width: 100,
        scopedSlots: {
          customRender: 'kg_100_199'
        }
      }, {
        title: _this.$t('columns.kg_200_299'),
        key: 'kg_200_299',
        dataIndex: 'kg_200_299',
        width: 100,
        scopedSlots: {
          customRender: 'kg_200_299'
        }
      }, {
        title: _this.$t('columns.kg_300_499'),
        key: 'kg_300_499',
        dataIndex: 'kg_300_499',
        width: 100,
        scopedSlots: {
          customRender: 'kg_300_499'
        }
      }, {
        title: _this.$t('columns.kg_500_999'),
        key: 'kg_500_999',
        dataIndex: 'kg_500_999',
        width: 100,
        scopedSlots: {
          customRender: 'kg_500_999'
        }
      }, {
        title: _this.$t('columns.kg_1000'),
        key: 'kg_1000',
        dataIndex: 'kg_1000',
        width: 100,
        scopedSlots: {
          customRender: 'kg_1000'
        }
      }]
    }, {
      title: _this.$t('columns.price_info2'),
      children: [{
        title: _this.$t('columns.area_zone'),
        key: 'area_zone',
        dataIndex: 'area_zone',
        width: 100,
        scopedSlots: {
          customRender: 'area_zone'
        }
      }, {
        title: _this.$t('columns.cbm_1'),
        key: 'cbm_1',
        dataIndex: 'cbm_1',
        width: 100,
        scopedSlots: {
          customRender: 'cbm_1'
        }
      }, {
        title: _this.$t('columns.cbm_2'),
        key: 'cbm_2',
        dataIndex: 'cbm_2',
        width: 100,
        scopedSlots: {
          customRender: 'cbm_2'
        }
      }, {
        title: _this.$t('columns.cbm_3'),
        key: 'cbm_3',
        dataIndex: 'cbm_3',
        width: 100,
        scopedSlots: {
          customRender: 'cbm_3'
        }
      }, {
        title: _this.$t('columns.cbm_4'),
        key: 'cbm_4',
        dataIndex: 'cbm_4',
        width: 100,
        scopedSlots: {
          customRender: 'cbm_4'
        }
      }]
    }, {
      title: _this.$t('columns.fee_info'),
      children: [{
        title: _this.$t('columns.customs_fee'),
        key: 'customs_fee',
        dataIndex: 'customs_fee',
        width: 100,
        scopedSlots: {
          customRender: 'customs_fee'
        }
      }, {
        title: _this.$t('columns.clearance_fee'),
        key: 'clearance_fee',
        dataIndex: 'clearance_fee',
        width: 100,
        scopedSlots: {
          customRender: 'clearance_fee'
        }
      }]
    }, {
      title: _this.$t('actions.action'),
      key: 'action',
      width: 100,
      scopedSlots: {
        customRender: 'action'
      }
    }];
    return _this;
  }

  AddLogisticsProviderDetail.prototype.mounted = function () {
    this.editable = this.editAble;

    if (this.info && this.info.length) {
      this.data = this.info.map(function (x) {
        x['index'] = uuid_default.a.generate();
        x['save_flag'] = 1;
        return x;
      });
    }
  };

  AddLogisticsProviderDetail.prototype.onInfoChange = function () {
    if (this.info && this.info.length) {
      this.data = this.info.map(function (x) {
        if (!x.index) {
          x['index'] = uuid_default.a.generate();
          x['save_flag'] = 1;
        }

        return x;
      });
    }
  };

  AddLogisticsProviderDetail.prototype.onEditAbleChange = function () {
    this.editable = this.editAble;
  };

  AddLogisticsProviderDetail.prototype.addBtn = function () {
    this.currentRow = uuid_default.a.generate();
    var item = {
      index: this.currentRow,
      save_flag: 0,
      prescription: '',
      dest_country_id: '',
      shipping_channel: '',
      shipping_schedule_timeliness: '',
      payment_method: '',
      is_include_tax: false,
      is_charged_magnetic_sensitive: false,
      is_self_mention: false,
      is_self_report: false,
      overall_aging: 0,
      head_aging: 0,
      delivery_aging: 0,
      loading_aging: 0,
      transfer_aging: 0,
      unloading_aging: 0,
      kg_15_20: 0,
      kg_21_50: 0,
      kg_51_99: 0,
      kg_100_199: 0,
      kg_200_299: 0,
      kg_300_499: 0,
      kg_500_999: 0,
      kg_1000: 0,
      area_zone: '',
      cbm_1: 0,
      cbm_2: 0,
      cbm_3: 0,
      cbm_4: 0,
      customs_fee: '',
      clearance_fee: ''
    };
    var pos = this.data.length > 0 ? this.data.length - 1 : 0;
    this.data.splice(pos, 0, item);
    this.$emit('change', this.data);
  };

  AddLogisticsProviderDetail.prototype.handleChange = function (e, row, column) {
    row[column] = e;
    this.$emit('change', this.data);
  };

  AddLogisticsProviderDetail.prototype.cancelBtn = function (e) {
    e.stopPropagation();
    this.currentRow = -1;
  };

  AddLogisticsProviderDetail.prototype.onDel = function (row) {
    var _this = this;

    this.currentRow = -1;

    if (row.id) {
      var item = this.data.find(function (x) {
        return x.index === row.index;
      });
      this.innerAction.setActionAPI('/logistics_providers/modify_record', common_service["a" /* CommonService */].getMenuCode('logistics-providers-detail'));
      this.publicService.modify(new http["RequestParams"]({
        id: this.id,
        delete_channel_list: [item.id],
        save_flag: 1,
        channel_list: this.data.map(function (x) {
          delete x.index;
          return x;
        })
      }, {
        loading: this.loadingService,
        innerAction: this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('删除成功');

        _this.data = _this.data.filter(function (x) {
          return x.id != row.id;
        });

        _this.$emit('change', _this.data);
      }, function (err) {
        _this.$message.error(err.message);
      });
    } else {
      this.data = this.data.filter(function (x) {
        return x.index !== row.index;
      });
      this.$emit('change', this.data);
    }
  };

  AddLogisticsProviderDetail.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddLogisticsProviderDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddLogisticsProviderDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddLogisticsProviderDetail.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddLogisticsProviderDetail.prototype, "currencyList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddLogisticsProviderDetail.prototype, "editAble", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddLogisticsProviderDetail.prototype, "state", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddLogisticsProviderDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddLogisticsProviderDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('editAble'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddLogisticsProviderDetail.prototype, "onEditAbleChange", null);

  AddLogisticsProviderDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AddLogisticsProviderDetail);
  return AddLogisticsProviderDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var add_logistics_provider_detailvue_type_script_lang_ts_ = (add_logistics_provider_detailvue_type_script_lang_ts_AddLogisticsProviderDetail);
// CONCATENATED MODULE: ./src/components/purchase/add-logistics-provider-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_add_logistics_provider_detailvue_type_script_lang_ts_ = (add_logistics_provider_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/add-logistics-provider-detail.vue?vue&type=style&index=0&lang=css&
var add_logistics_provider_detailvue_type_style_index_0_lang_css_ = __webpack_require__("88a3");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/add-logistics-provider-detail.vue?vue&type=custom&index=0&blockType=i18n
var add_logistics_provider_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("112a");

// CONCATENATED MODULE: ./src/components/purchase/add-logistics-provider-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_add_logistics_provider_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof add_logistics_provider_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(add_logistics_provider_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var add_logistics_provider_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "68ca":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("15f4");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "694a":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "6dd0":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "88a3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_logistics_provider_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("694a");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_logistics_provider_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_logistics_provider_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "958f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_contract_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("fd17");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_contract_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_contract_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "adb8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c69f");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b277":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"supplier":"Supplier","give_date":"Give Date","company_id":"Company","order_date":"Order Date","is_add_purchase_contract":"is_add_purchase_contract","is_add_delivery_contract":"is_add_delivery_contract","delivery_contract_no":"Delivery Contract No.","purchase_contract_no":"Purchase Contract No.","req_name":"Req Name","default_code":"Default Code","product_qty":"Quantity","product_purchase_price":"Product Purchase Price","sales_expected_give_date":"Sales Expected Give Date","date_expected":"Expected Date","contract_give_date":"Contract Given Date","product_uom":"Product Uom","user_require":"Require User","delete":"Are you sure delete?","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Cancel","ok":"submit"}},"zh-cn":{"req_name":"需求编号","default_code":"货号","product_qty":"数量","product_purchase_price":"产品采购价","sales_expected_give_date":"运营期望交期","date_expected":"期望入库","contract_give_date":"合同交期","product_uom":"产品计量单位","user_require":"需求人","supplier":"供货商","give_date":"合同交期","company_id":"公司","order_date":"订单日期","is_add_purchase_contract":"是否追加采购合同","is_add_delivery_contract":"是否追加发货合同","delivery_contract_no":"发货合同号","purchase_contract_no":"补货合同号","delete":"确定要删除吗？","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"取消","ok":"确定"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "b694":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"delete":"delete ?","columns":{"prescription":"prescription","dest_country_id":"dest_country_id","shipping_channel":"shipping_channel","shipping_schedule_timeliness":"shipping_schedule_timeliness","payment_method":"payment_method","is_include_tax":"is_include_tax","is_charged_magnetic_sensitive":"is_charged_magnetic_sensitive","is_self_mention":"is_self_mention","is_self_report":"is_self_report","overall_aging":"overall_aging","head_aging":"head_aging","delivery_aging":"delivery_aging","loading_aging":"loading_aging","transfer_aging":"transfer_aging","unloading_aging":"unloading_aging","logistics_providers_id":"logistics_providers_id","kg_15_20":"kg_15_20","kg_21_50":"kg_21_50","kg_51_99":"kg_51_99","kg_100_199":"kg_100_199","kg_200_299":"kg_200_299","kg_300_499":"kg_300_499","kg_500_999":"kg_500_999","kg_1000":"kg_1000","area_zone":"area_zone","cbm_1":"cbm_1","cbm_2":"cbm_2","cbm_3":"cbm_3","cbm_4":"cbm_4","customs_fee":"customs_fee","clearance_fee":"clearance_fee","channel_info":"Channel Info","aging_info":"Aging Info","price_info":"Price Info(weight)","price_info2":"Price Info(volume)","fee_info":"Fee Info"},"actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Cancel","ok":"Ok"}},"zh-cn":{"delete":"确定要删除吗?","columns":{"prescription":"时效","dest_country_id":"目的国家","shipping_channel":"发货渠道","shipping_schedule_timeliness":"船期/时效","payment_method":"付款方式","is_include_tax":"是否包税","is_charged_magnetic_sensitive":"带电/磁/敏感货","is_self_mention":"是否自提(前端)","is_self_report":"是否自报","overall_aging":"整体时效","head_aging":"头程时效","delivery_aging":"派送时效","loading_aging":"装车时效","transfer_aging":"运输时效","unloading_aging":"卸柜时效","logistics_providers_id":"logistics_providers_id","kg_15_20":"15-20kg","kg_21_50":"21-50kg","kg_51_99":"51-99kg","kg_100_199":"100-199kg","kg_200_299":"200-299kg","kg_300_499":"300-499kg","kg_500_999":"500-999kg","kg_1000":"1000+kg","area_zone":"所在区zone","cbm_1":"1.5-3cbm","cbm_2":"3-5cbm","cbm_3":"5-10cbm","cbm_4":"10cbm+","customs_fee":"报关税","clearance_fee":"情关税","channel_info":"渠道信息","aging_info":"时效(天)","price_info":"价格信息(重量)","price_info2":"价格信息(体积)","fee_info":"其它费用"},"actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"取消","ok":"确定"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "bfcc":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "c47d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_package_order_product_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1f5f");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_package_order_product_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_package_order_product_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_package_order_product_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "c69f":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"purchase_detail":"Requiremnet Lines","contact_no":"Contact No.","trace_memo":"Track Memo","name":"Name","quantity":"Quantity","order_date":"Finish QTY","give_date":"Is Finish","warehouse_id":"Cn Category","id":"Line ID","select_col":"Select"},"submit":"Submit","cancel":"Cancel"},"zh-cn":{"columns":{"purchase_detail":"采购明细","contact_no":"合同号","trace_memo":"跟踪备注","name":"物品","quantity":"数量","order_date":"下单日期","give_date":"合同交期","warehouse_id":"仓库","id":"Line ID","select_col":"选择"},"submit":"提交","cancel":"取消"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "d1f0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_purchase_product_plan_memo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("187f");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_purchase_product_plan_memo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_purchase_product_plan_memo_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "d870":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_package_order_product_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("bfcc");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_package_order_product_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_package_order_product_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "e186":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-purchase-product-plan-memo.vue?vue&type=template&id=4e4d5169&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('table',{staticClass:"xtb"},[_c('tr',[_c('td',[_vm._v(_vm._s(_vm.$t('columns.contact_no')))]),_c('td',{staticClass:"required"},[_vm._v(" "+_vm._s(_vm.contact_no)+" ")])]),_c('tr',[_c('td',[_vm._v(_vm._s(_vm.$t('columns.trace_memo')))]),_c('td',{staticClass:"required"},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['trace_memo']),expression:"['trace_memo']"}],ref:"trace_memo",staticStyle:{"width":"100%"},attrs:{"size":"small"},model:{value:(_vm.trace_memo),callback:function ($$v) {_vm.trace_memo=$$v},expression:"trace_memo"}})],1)]),_c('tr',[_c('td',{staticStyle:{"color":"red","width":"15%"}},[_vm._v(" "+_vm._s(_vm.$t('columns.purchase_detail'))+" ")]),_c('td',{staticStyle:{"padding":"0"}},[_c('table',{staticClass:"xtb",staticStyle:{"border":"none"}},[_c('tr',[_c('th',{staticStyle:{"text-align":"center"}},[_vm._v(" "+_vm._s(_vm.$t('columns.select_col'))+" ")]),_c('th',{staticStyle:{"text-align":"center"}},[_vm._v("SKU")]),_c('th',{staticStyle:{"text-align":"center"}},[_vm._v(" "+_vm._s(_vm.$t('columns.quantity'))+" ")]),_c('th',{staticStyle:{"text-align":"center"}},[_vm._v(" "+_vm._s(_vm.$t('columns.order_date'))+" ")]),_c('th',{staticStyle:{"text-align":"center"}},[_vm._v(" "+_vm._s(_vm.$t('columns.give_date'))+" ")]),_c('th',{staticStyle:{"text-align":"center"}},[_vm._v(" "+_vm._s(_vm.$t('columns.warehouse_id'))+" ")]),_c('th',{staticStyle:{"text-align":"center"}},[_vm._v(" "+_vm._s(_vm.$t('columns.id'))+" ")])]),_vm._l((_vm.info),function(x,i){return _c('tr',{key:i},[_c('td',{staticStyle:{"text-align":"center"}},[_c('input',{attrs:{"type":"checkbox","checked":"checked"},on:{"change":function (e) { return _vm.change_checked(x, e.target.checked); }}})]),_c('td',{key:x.default_code,staticStyle:{"text-align":"right"}},[_vm._v(" "+_vm._s(x.default_code)+" ")]),_c('td',{key:x.product_qty},[_vm._v(_vm._s(x.product_qty))]),_c('td',{key:x.order_date},[_vm._v(_vm._s(x.order_date))]),_c('td',{key:x.give_date},[_vm._v(_vm._s(x.give_date))]),_c('td',{key:x.warehouser_id},[_vm._v(" "+_vm._s(x.warehouser_id)+" ")]),_c('td',{key:x.id},[_vm._v(" "+_vm._s(x.id)+" ")])])})],2)])])]),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/add-purchase-product-plan-memo.vue?vue&type=template&id=4e4d5169&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__("a434");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-purchase-product-plan-memo.vue?vue&type=script&lang=ts&












var add_purchase_product_plan_memovue_type_script_lang_ts_AddTraceMemoDlg =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AddTraceMemoDlg, _super);

  function AddTraceMemoDlg() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.trace_memo = '';
    _this.ids = [];
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  AddTraceMemoDlg.prototype.submit = function () {
    return true;
  };

  AddTraceMemoDlg.prototype.cancel = function () {
    return;
  };

  AddTraceMemoDlg.prototype.mounted = function () {
    var _this = this;

    if (this.info.length) {
      this.ids = this.info.map(function (x) {
        return x.id;
      });
    }

    this.$nextTick(function () {
      var reasonInput = _this.$refs.trace_memo;
      reasonInput.focus();
    });
  };

  AddTraceMemoDlg.prototype.change_checked = function (row, e) {
    if (e) {
      if (!this.ids.includes(row.id)) {
        this.ids.push(row.id);
      }
    } else {
      if (this.ids.includes(row.id)) {
        for (var i in this.ids) {
          if (this.ids[i] == row.id) {
            this.ids.splice(i, 1);
          }
        }
      }
    }
  };

  AddTraceMemoDlg.prototype.onSubmit = function () {
    var _this = this;

    if (!this.trace_memo) {
      this.$message.error('跟踪备注不能为空!');
      var reasonInput = this.$refs.trace_memo;
      reasonInput.focus();
      return;
    }

    this.innerAction.setActionAPI('purchase_order_plan/multi_edit_info', common_service["a" /* CommonService */].getMenuCode('purchase-product-plan'));
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.ids,
      data: {
        memo: this.trace_memo
      }
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.info(data.message);

      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddTraceMemoDlg.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddTraceMemoDlg.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddTraceMemoDlg.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddTraceMemoDlg.prototype, "contact_no", void 0);

  AddTraceMemoDlg = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AddTraceMemoDlg);
  return AddTraceMemoDlg;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var add_purchase_product_plan_memovue_type_script_lang_ts_ = (add_purchase_product_plan_memovue_type_script_lang_ts_AddTraceMemoDlg);
// CONCATENATED MODULE: ./src/components/purchase/add-purchase-product-plan-memo.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_add_purchase_product_plan_memovue_type_script_lang_ts_ = (add_purchase_product_plan_memovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/add-purchase-product-plan-memo.vue?vue&type=style&index=0&lang=css&
var add_purchase_product_plan_memovue_type_style_index_0_lang_css_ = __webpack_require__("d1f0");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/add-purchase-product-plan-memo.vue?vue&type=custom&index=0&blockType=i18n
var add_purchase_product_plan_memovue_type_custom_index_0_blockType_i18n = __webpack_require__("adb8");

// CONCATENATED MODULE: ./src/components/purchase/add-purchase-product-plan-memo.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_add_purchase_product_plan_memovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof add_purchase_product_plan_memovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(add_purchase_product_plan_memovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var add_purchase_product_plan_memo = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "e29e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_contract_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b277");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_contract_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_contract_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_replenish_contract_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "f5bb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-replenish-detail.vue?vue&type=template&id=6ab236e4&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.editAble),expression:"editAble"}],staticStyle:{"padding":"0 20px 10px 0px"}},[_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.addBtn}},[_c('a-icon',{attrs:{"type":"plus"}}),_vm._v(" "+_vm._s(_vm.$t('actions.add'))+" ")],1)],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"index","customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"scroll":{ x: 2500, y: 500 },"bordered":""}},[_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('product_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            _vm.state &&
                            row.id != 'summary'
                    )?_c('a-auto-complete',{style:({ width: '100%', background: '#ecc5e9' }),attrs:{"dataSource":_vm.skuSource,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"defaultValue":row.default_code,"size":"small","placeholder":"input for search"},on:{"search":_vm.onSkuSearch,"change":function (e) { return _vm.onRowChange(row, 'default_code', e); },"blur":function($event){return _vm.onSkuBlur(row)}}},[_c('template',{slot:"dataSource"},[_vm._l((_vm.skuSource),function(opt){return _c('a-select-option',{key:opt,attrs:{"value":opt,"title":opt}},[_vm._v(" "+_vm._s(opt)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(row)}}},[_vm._v(" Search More ")])])],2)],2):_c('span',[_vm._v(_vm._s(row.default_code))])]}}])}),_c('a-table-column',{key:"product_qty",staticStyle:{"width":"'80px'"},attrs:{"title":_vm.$t('product_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            _vm.state &&
                            row.id != 'summary'
                    )?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_qty']),expression:"['product_qty']"}],style:({ width: '100%', background: '#ecc5e9' }),attrs:{"decimalSeparator":",","value":row.product_qty,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_qty', e); }}}):_c('span',[_vm._v(_vm._s(row.product_qty))])]}}])}),_c('a-table-column',{key:"is_fba",attrs:{"title":"FBA","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.id != 'summary')?_c('span',[_c('a-checkbox',{attrs:{"disabled":"","checked":row.is_fba}})],1):_c('span')]}}])}),_c('a-table-column',{key:"ist_box_qty",attrs:{"title":_vm.$t('ist_box_qty'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.id != 'summary')?_c('span',[_c('a-checkbox',{attrs:{"disabled":"","checked":row.ist_box_qty}})],1):_c('span')]}}])}),_c('a-table-column',{key:"sales_expected_give_date",attrs:{"title":_vm.$t('sales_expected_give_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            _vm.state &&
                            row.id != 'summary'
                    )?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sales_expected_give_date']),expression:"['sales_expected_give_date']"}],staticClass:"required",style:({ width: '100%', background: '#ecc5e9' }),attrs:{"default-value":row.sales_expected_give_date
                            ? _vm.moment(
                                  row.sales_expected_give_date,
                                  'YYYY-MM-DD'
                              )
                            : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'sales_expected_give_date',
                                e.format('YYYY-MM-DD').toString()
                            ); }}}):_c('span',[_vm._v(_vm._s(row.sales_expected_give_date))])]}}])}),_c('a-table-column',{key:"date_expected",attrs:{"title":_vm.$t('date_expected'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            _vm.state &&
                            row.id != 'summary'
                    )?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['date_expected']),expression:"['date_expected']"}],staticClass:"required",style:({ width: '100%', background: '#ecc5e9' }),attrs:{"default-value":row.date_expected
                            ? _vm.moment(row.date_expected, 'YYYY-MM-DD')
                            : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'date_expected',
                                e.format('YYYY-MM-DD').toString()
                            ); }}}):_c('span',[_vm._v(_vm._s(row.date_expected))])]}}])}),_c('a-table-column',{key:"product_uom",attrs:{"title":_vm.$t('product_uom'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.id && row.id != 'summary' ? 'Units' : ''))])]}}])}),_c('a-table-column',{key:"warehouse_id",attrs:{"title":_vm.$t('warehouse_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            _vm.state &&
                            row.id != 'summary'
                    )?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'warehouse_id',
                        { initialValue: _vm.$dict.WarehouseId[0].value }
                    ]),expression:"[\n                        'warehouse_id',\n                        { initialValue: $dict.WarehouseId[0].value }\n                    ]"}],staticClass:"required",style:({ width: '100%', background: '#ecc5e9' }),attrs:{"value":row.warehouse_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '120px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'warehouse_id', e); }}},_vm._l((_vm.$dict.WarehouseId),function(i){return _c('a-select-option',{key:i.value,attrs:{"value":i.value,"title":_vm.$t(i.label)}},[_vm._v(" "+_vm._s(_vm.$t(i.label))+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.warehouse_id,'WarehouseId')))+" ")])]}}])}),_c('a-table-column',{key:"dept_id",attrs:{"title":_vm.$t('dept_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(_vm.getDepartName(row.dept_id)))])]}}])}),_c('a-table-column',{key:"is_special_check",attrs:{"title":_vm.$t('is_special_check'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.id != 'summary')?_c('span',[_c('a-checkbox',{attrs:{"disabled":"","checked":row.is_special_check}})],1):_c('span')]}}])}),_c('a-table-column',{key:"import_memo",attrs:{"title":_vm.$t('import_memo'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.import_memo))])]}}])}),_c('a-table-column',{key:"give_date",attrs:{"title":_vm.$t('give_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.give_date))])]}}])}),_c('a-table-column',{key:"buyer_change_give_date",attrs:{"title":_vm.$t('buyer_change_give_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.buyer_change_give_date))])]}}])}),_c('a-table-column',{key:"buyer_change_give_date_memo",attrs:{"title":_vm.$t('buyer_change_give_date_memo'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.buyer_change_give_date_memo))])]}}])}),_c('a-table-column',{key:"real_pre_purchase_order",attrs:{"title":_vm.$t('real_pre_purchase_order'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.real_pre_purchase_order))])]}}])}),_c('a-table-column',{key:"finish_qty",attrs:{"title":_vm.$t('finish_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.finish_qty))])]}}])}),_c('a-table-column',{key:"mrate",attrs:{"title":_vm.$t('mrate'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.mrate))])]}}])}),_c('a-table-column',{key:"state",attrs:{"title":_vm.$t('state'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'ReplenishmentState')))+" ")])]}}])}),_c('a-table-column',{key:"sales_change_give_date",attrs:{"title":_vm.$t('sales_change_give_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            row.id != 'summary'
                    )?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sales_change_give_date']),expression:"['sales_change_give_date']"}],style:({ width: '100%' }),attrs:{"default-value":row.sales_change_give_date
                            ? _vm.moment(
                                  row.sales_change_give_date,
                                  'YYYY-MM-DD'
                              )
                            : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'sales_change_give_date',
                                e.format('YYYY-MM-DD').toString()
                            ); }}}):_c('span',[_vm._v(_vm._s(row.sales_change_give_date))])]}}])}),_c('a-table-column',{key:"sales_change_give_date_memo",attrs:{"title":_vm.$t('sales_change_give_date_memo'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            row.id != 'summary'
                    )?_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sales_change_give_date_memo']),expression:"['sales_change_give_date_memo']"}],style:({ width: '100%' }),attrs:{"value":row.sales_change_give_date_memo,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'sales_change_give_date_memo',
                                e
                            ); }}}):_c('span',[_vm._v(_vm._s(row.sales_change_give_date_memo))])]}}])}),_c('a-table-column',{key:"sale_range_from",attrs:{"title":_vm.$t('sale_range_from'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            row.id != 'summary'
                    )?_c('a-month-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_range_from']),expression:"['sale_range_from']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"default-value":row.sale_range_from
                            ? _vm.moment(row.sale_range_from, 'YYYY-MM')
                            : null,"size":"small","format":"YYYY-MM"},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'sale_range_from',
                                e.format('YYYY-MM').toString()
                            ); }}}):_c('span',[_vm._v(_vm._s(row.sale_range_from))])]}}])}),_c('a-table-column',{key:"sale_range_to",attrs:{"title":_vm.$t('sale_range_to'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            row.id != 'summary'
                    )?_c('a-month-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_range_to']),expression:"['sale_range_to']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"default-value":row.sale_range_to
                            ? _vm.moment(row.sale_range_to, 'YYYY-MM')
                            : null,"size":"small","format":"YYYY-MM"},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'sale_range_to',
                                e.format('YYYY-MM').toString()
                            ); }}}):_c('span',[_vm._v(_vm._s(row.sale_range_to))])]}}])}),_c('a-table-column',{key:"note",attrs:{"title":_vm.$t('note'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            row.id != 'summary'
                    )?_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(['note']),expression:"['note']"}],style:({ width: '100%' }),attrs:{"value":row.note,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'note', e); }}}):_c('span',[_vm._v(_vm._s(row.note))])]}}])}),_c('a-table-column',{key:"cp_note",attrs:{"title":_vm.$t('cp_note'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            row.id != 'summary'
                    )?_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cp_note']),expression:"['cp_note']"}],style:({ width: '100%' }),attrs:{"value":row.cp_note,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'cp_note', e); }}}):_c('span',[_vm._v(_vm._s(row.cp_note))])]}}])}),_c('a-table-column',{key:"user_purchase",attrs:{"title":_vm.$t('user_purchase'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.user_purchase,_vm.systemUsers))+" ")])]}}])}),_c('a-table-column',{key:"merchandiser",attrs:{"title":_vm.$t('merchandiser'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.merchandiser,_vm.systemUsers))+" ")])]}}])}),_c('a-table-column',{key:"product_manual_version",attrs:{"title":_vm.$t('product_manual_version'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(row.product_manual_version)+" ")])]}}])}),_c('a-table-column',{key:"product_specification_version",attrs:{"title":_vm.$t('product_specification_version'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(row.product_specification_version)+" ")])]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.state && row.id != 'summary')?_c('a',{on:{"click":function($event){return _vm.onDel(row)}}},[_vm._v(" "+_vm._s(_vm.$t('actions.delete'))+" ")]):_vm._e(),(row.id != 'summary')?_c('a',{on:{"click":function (e) { return _vm.cancelBtn(e); }}},[_vm._v(" "+_vm._s(_vm.$t('actions.cancel'))+" ")]):_vm._e()]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/add-replenish-detail.vue?vue&type=template&id=6ab236e4&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__("a434");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-replenish-detail.vue?vue&type=script&lang=ts&



















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var add_replenish_detailvue_type_script_lang_ts_AddReplenishDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AddReplenishDetail, _super);

  function AddReplenishDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.operateCnt = 0;
    _this.moment = moment_default.a;
    _this.manualVersionList = [];
    _this.specVersionList = [];
    _this.summaryList = ['product_qty'];
    return _this;
  }

  AddReplenishDetail.prototype.mounted = function () {
    this.editable = this.editAble;

    if (this.info && this.info.length) {
      this.data = this.info.map(function (x) {
        x['index'] = uuid_default.a.generate();
        x['save_flag'] = 1;
        return x;
      });
    }
  };

  AddReplenishDetail.prototype.onInfoChange = function () {
    if (this.info && this.info.length) {
      this.data = this.info.map(function (x) {
        if (!x.index) {
          x['index'] = uuid_default.a.generate();
          x['save_flag'] = 1;
        }

        return x;
      });

      if (this.summaryList != undefined && this.summaryList.length && this.data.length) {
        var sm = this.data.find(function (x) {
          return x.id == 'summary';
        });
        var ret = common_service["a" /* CommonService */].getSummaryData(this.data, this.summaryList);

        if (sm) {
          for (var _i = 0, _a = this.summaryList; _i < _a.length; _i++) {
            var i = _a[_i];
            sm[i] = ret[i];
          }
        } else {
          ret['id'] = 'summary';
          ret['index'] = 'summary';
          this.data.push(ret);
          this.$nextTick(function () {
            var querySelector = 'tr[data-row-key="summary"]';
            var tr = document.querySelector(querySelector);
            tr.style.background = '#fdfdfd';
          });
        }
      }
    }
  };

  AddReplenishDetail.prototype.onEditAbleChange = function () {
    this.editable = this.editAble;
  };

  AddReplenishDetail.prototype.onDataChange = function () {
    if (this.data.length) {
      var sm = this.data.find(function (x) {
        return x.id == 'summary';
      });

      if (sm) {
        var ret = common_service["a" /* CommonService */].getSummaryData(this.data, this.summaryList);

        for (var _i = 0, _a = this.summaryList; _i < _a.length; _i++) {
          var i = _a[_i];
          sm[i] = ret[i];
        }
      }
    }
  };

  AddReplenishDetail.prototype.created = function () {
    this.getManualVersion();
    this.getSpecVersion();
    this.getDepartmentList();
  };

  AddReplenishDetail.prototype.getManualVersion = function () {
    var _this = this;

    this.productService.query_manual_version(new http["RequestParams"]({})).subscribe(function (data) {
      _this.manualVersionList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AddReplenishDetail.prototype.getSpecVersion = function () {
    var _this = this;

    this.productService.query_specification_version(new http["RequestParams"]({})).subscribe(function (data) {
      _this.specVersionList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AddReplenishDetail.prototype.addBtn = function () {
    this.currentRow = uuid_default.a.generate();
    var item = {
      index: this.currentRow,
      save_flag: 0,
      alerts: 0,
      ann_sales: 0,
      buyer_change_give_date: null,
      buyer_change_give_date_memo: null,
      cp_note: '',
      date_expected: null,
      default_code: '',
      eqty: 0,
      finish_qty: 0,
      give_date: null,
      ist_box_qty: false,
      is_special_check: false,
      merchandiser: null,
      mrate: 0,
      note: '',
      period: '',
      persist: 0,
      product_id: 0,
      product_manual_code: '',
      product_manual_url: '',
      product_manual_version: '',
      product_qty: 1,
      product_specification_url: '',
      product_specification_version: '',
      product_ve: '',
      real_pre_purchase_order: '',
      sales_change_give_date: null,
      sales_change_give_date_memo: '',
      sales_expected_give_date: null,
      sequence: 10,
      sqty: 0,
      state: '',
      user_purchase: null,
      warehouse_id: this.$dict.WarehouseId[0].value
    };
    var pos = this.data.length > 0 ? this.data.length - 1 : 0;
    this.data.splice(pos, 0, item);
    this.$emit('change', this.data);
  };

  AddReplenishDetail.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target != undefined && value.target.value != undefined) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }

    if (column === 'default_code') {
      var productItem = this.skuQueryResult.find(function (x) {
        return x.default_code == value;
      });

      if (productItem) {
        row.default_code = productItem.default_code;
        row.product_id = productItem.product_id;
      } else {
        row.default_code = '';
        row.product_id = 0;
      }
    }

    this.$emit('change', this.data);
  };

  AddReplenishDetail.prototype.cancelBtn = function (e) {
    e.stopPropagation();
    this.currentRow = -1;
  };

  AddReplenishDetail.prototype.onDel = function (row) {
    var _this = this;

    this.currentRow = -1;

    if (row.id) {
      var item = this.data.find(function (x) {
        return x.index === row.index;
      });
      this.innerAction.setActionAPI('purchase_management/delete_purchase_requirement_line', common_service["a" /* CommonService */].getMenuCode('replenishment-demand'));
      this.publicService.modify(new http["RequestParams"]({
        req_line_id_list: [item.id],
        state: item.state
      }, {
        loading: this.loadingService,
        innerAction: this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('删除成功');

        _this.data = _this.data.filter(function (x) {
          return x.id != row.id;
        });

        _this.$emit('change', _this.data);
      }, function (err) {
        _this.$message.error(err.message);
      });
    } else {
      this.data = this.data.filter(function (x) {
        return x.index !== row.index;
      });
    }
  };

  AddReplenishDetail.prototype.onSkuSearch = function (key) {
    var _this = this;

    var params = common_service["a" /* CommonService */].createQueryCondition({
      default_code: key
    }, tslib_es6["a" /* __assign */]({
      default_code: 'like'
    }, form_config["a" /* formConfig */].condition));
    params['page_index'] = 1;
    params['page_size'] = 10;
    params['active_ignore'] = true;
    this.productService.queryAsyncProductInfo(new http["RequestParams"](params, {
      loading: this.loadingService
    })).subscribe(function (data) {
      if (data && data.length) {
        _this.skuSource = data.map(function (x) {
          return x.default_code;
        });
        _this.skuQueryResult = data;
      }
    });
  };

  AddReplenishDetail.prototype.searchMore = function (row) {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {}, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      var item = _this.data.find(function (x) {
        return x.index === row.index;
      }); // item['name'] = '[' + data.default_code + ']' + data.name


      item['product_id'] = data.product_id;
      item['default_code'] = data.default_code;
      _this.currentRow = -1;
      setTimeout(function () {
        _that.currentRow = row.index;
      }, 100);
    });
  };

  AddReplenishDetail.prototype.serverDelete = function (id, state) {
    var _this = this; //save


    this.innerAction.setActionAPI('purchase_management/delete_purchase_requirement_line', common_service["a" /* CommonService */].getMenuCode('replenishment-demand'));
    this.publicService.modify(new http["RequestParams"]({
      req_line_id_list: [id],
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('删除成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AddReplenishDetail.prototype.getDepartName = function (department) {
    var ret = department;
    var item = this.departmentList.find(function (x) {
      return x.id == department;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  AddReplenishDetail.prototype.onSkuBlur = function (row) {
    if (row.product_id == 0) {
      row.default_code = '';
      this.$message.error('请输入正确的SKU,或者从列表中选择SKU');
      var cr = this.currentRow;
      this.currentRow = '';
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishDetail.prototype, "editAble", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishDetail.prototype, "state", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishDetail.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishDetail.prototype, "getDepartmentList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddReplenishDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('editAble'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddReplenishDetail.prototype, "onEditAbleChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('data'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddReplenishDetail.prototype, "onDataChange", null);

  AddReplenishDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AddReplenishDetail);
  return AddReplenishDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var add_replenish_detailvue_type_script_lang_ts_ = (add_replenish_detailvue_type_script_lang_ts_AddReplenishDetail);
// CONCATENATED MODULE: ./src/components/purchase/add-replenish-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_add_replenish_detailvue_type_script_lang_ts_ = (add_replenish_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/add-replenish-detail.vue?vue&type=style&index=0&lang=css&
var add_replenish_detailvue_type_style_index_0_lang_css_ = __webpack_require__("37c1");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-detail.vue?vue&type=custom&index=0&blockType=i18n
var add_replenish_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("68ca");

// CONCATENATED MODULE: ./src/components/purchase/add-replenish-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_add_replenish_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof add_replenish_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(add_replenish_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var add_replenish_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "fba3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-replenish-contract.vue?vue&type=template&id=6721c9d2&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-card',{staticClass:"margin-top order-edit-page"},[_c('a-form',{attrs:{"form":_vm.form,"labelCol":{ span: 7 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{staticClass:"height50",attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('supplier'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "vendor_id",
                                {
                                    initialValue: _vm.defaultVendor
                                },
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                `vendor_id`,\n                                {\n                                    initialValue: defaultVendor\n                                },\n                                { rules: rules.required }\n                            ]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption}},_vm._l((_vm.vendorList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{staticClass:"height50",attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('order_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "order_date",
                                {
                                    initialValue: _vm.moment(Date.now())
                                }
                            ]),expression:"[\n                                `order_date`,\n                                {\n                                    initialValue: moment(Date.now())\n                                }\n                            ]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"},on:{"change":function (e) { return _vm.onCreateDateChange(e); }}})],1)],1),_c('a-col',{staticClass:"height50",attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('company_id'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'order_company_id',
                                {
                                    rules: _vm.rules.required
                                }
                            ]),expression:"[\n                                'order_company_id',\n                                {\n                                    rules: rules.required\n                                }\n                            ]"}],style:({
                                width: '100%',
                                'max-width': '240px'
                            }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select"}},[_c('a-select-option',{key:"woltu",attrs:{"value":"woltu"}},[_vm._v(" Woltu ")]),_c('a-select-option',{key:"eugad",attrs:{"value":"eugad"}},[_vm._v(" EUGAD ")])],1)],1)],1),_c('a-col',{staticClass:"height50",attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('give_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "give_date",
                                {
                                    initialValue: _vm.moment(_vm.giveDate)
                                }
                            ]),expression:"[\n                                `give_date`,\n                                {\n                                    initialValue: moment(giveDate)\n                                }\n                            ]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"},on:{"change":function (e) { return _vm.onGiveDateChange(e); }}})],1)],1)],1)],1)],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"id","customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.id
                    }
                }
            }); },"bordered":""}},[_c('a-table-column',{key:"req_name",attrs:{"title":_vm.$t('req_name'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.req_name))])]}}])}),_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('default_code'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.default_code))])]}}])}),_c('a-table-column',{key:"product_qty",attrs:{"title":_vm.$t('product_qty'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.id && _vm.editable)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_qty']),expression:"['product_qty']"}],style:({ width: '100%', background: '#ecc5e9' }),attrs:{"decimalSeparator":",","value":row.product_qty,"min":0,"max":row.maxQty,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_qty', e); }}}):_c('span',[_vm._v(_vm._s(row.product_qty))])]}}])}),_c('a-table-column',{key:"product_uom",attrs:{"title":_vm.$t('product_uom'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.id && row.id != 'summary' ? 'Units' : ''))])]}}])}),_c('a-table-column',{key:"product_purchase_price",attrs:{"title":_vm.$t('product_purchase_price'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(row.product_purchase_price)+" ")])]}}])}),_c('a-table-column',{key:"sales_expected_give_date",attrs:{"title":_vm.$t('sales_expected_give_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(row.sales_expected_give_date)+" ")])]}}])}),_c('a-table-column',{key:"date_expected",attrs:{"title":_vm.$t('date_expected'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(row.date_expected)+" ")])]}}])}),_c('a-table-column',{key:"contract_give_date",attrs:{"title":_vm.$t('contract_give_date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.id && _vm.editable)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['contract_give_date']),expression:"['contract_give_date']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"default-value":row.contract_give_date
                            ? _vm.moment(row.contract_give_date, 'YYYY-MM-DD')
                            : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.onRowChange(row, 'contract_give_date', e); }}}):_c('span',[_vm._v(_vm._s(row.contract_give_date ? row.contract_give_date.format('YYYY-MM-DD') : ''))])]}}])}),_c('a-table-column',{key:"user_require",attrs:{"title":_vm.$t('user_require'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.user_require,_vm.systemUsers))+" ")])]}}])}),_c('a-table-column',{key:"action",attrs:{"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.id && row.id != 'summary')?_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('actions.ok'),"cancelText":_vm.$t('actions.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDel(row)}}},[_c('a',{staticClass:"btnDel"},[_c('a-icon',{attrs:{"type":"delete"}})],1)]):_vm._e()]}}])})],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/add-replenish-contract.vue?vue&type=template&id=6721c9d2&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/cs_email_return/chat-modify-memo.vue + 4 modules
var chat_modify_memo = __webpack_require__("439a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/add-replenish-contract.vue?vue&type=script&lang=ts&




















var add_replenish_contractvue_type_script_lang_ts_AddReplenishContract =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AddReplenishContract, _super);

  function AddReplenishContract() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.operateCnt = 0;
    _this.giveDate = null;
    _this.defaultVendor = '';
    _this.moment = moment_default.a;
    _this.summaryList = ['product_qty'];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  AddReplenishContract.prototype.submit = function () {
    return true;
  };

  AddReplenishContract.prototype.cancel = function () {
    return;
  };

  AddReplenishContract.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  AddReplenishContract.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.info);
  };

  AddReplenishContract.prototype.mounted = function () {
    this.giveDate = this.getDay(20);

    if (this.info) {
      this.data = this.info.map(function (x) {
        x['maxQty'] = x.product_qty;
        return x;
      });

      if (this.summaryList != undefined && this.summaryList.length && this.data.length) {
        var ret = common_service["a" /* CommonService */].getSummaryData(this.data, this.summaryList);
        ret['id'] = 'summary';
        this.data.push(ret);
      }

      this.defaultVendor = this.data[0].vendor_id;
      this.setFormValues();
    }

    this.$nextTick(function () {
      var querySelector = 'tr[data-row-key="summary"]';
      var tr = document.querySelector(querySelector);
      tr.style.background = '#fdfdfd';
    });
  };

  AddReplenishContract.prototype.onInfoChange = function () {
    if (this.info) {
      this.data = this.info.map(function (x) {
        if (!x.maxQty) {
          x['maxQty'] = x.product_qty;
        }

        return x;
      });
      this.defaultVendor = this.data[0].vendor_id;

      if (this.summaryList != undefined && this.summaryList.length && this.data.length) {
        var ret = common_service["a" /* CommonService */].getSummaryData(this.data, this.summaryList);
        ret['id'] = 'summary';
        this.data.push(ret);
      }

      this.setFormValues();
    }
  };

  AddReplenishContract.prototype.onDataChange = function () {
    if (this.data.length) {
      var sm = this.data.find(function (x) {
        return x.id == 'summary';
      });

      if (sm) {
        var ret = common_service["a" /* CommonService */].getSummaryData(this.data, this.summaryList);

        for (var _i = 0, _a = this.summaryList; _i < _a.length; _i++) {
          var i = _a[_i];
          sm[i] = ret[i];
        }
      }
    }
  };

  AddReplenishContract.prototype.addBtn = function () {
    this.data.push({
      index: uuid_default.a.generate(),
      product: '',
      finish_qty: 0,
      is_finish: false,
      quantity: 0,
      warehouse_id: ''
    });
    this.$emit('change', this.data);
    this.currentRow = this.data.length;
  };

  AddReplenishContract.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  AddReplenishContract.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target != undefined && value.target.value != undefined) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }

    if (this.summaryList.includes(column)) {
      this.onDataChange();
    }

    this.$emit('change', this.data);
  };

  AddReplenishContract.prototype.cancelBtn = function (e) {
    e.stopPropagation();
    this.currentRow = -1;
  };

  AddReplenishContract.prototype.onDel = function (row) {
    this.currentRow = -1;
    var item = this.data.find(function (x) {
      return x.id === row.id;
    });
    item['save_flag'] = 2;
    this.data = this.data.filter(function (x) {
      return !x.save_flag || x.save_flag < 2;
    });
    this.$emit('change', this.data);
  };

  AddReplenishContract.prototype.onSubmit = function () {
    //save
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        if (!_this.data.length) {
          _this.$message.error('至少添加一条明细信息');

          return;
        }

        if (values['order_date']) {
          values['order_date'] = values['order_date'].format('YYYY-MM-DD').toString();
        }

        if (values['give_date']) {
          values['give_date'] = values['give_date'].format('YYYY-MM-DD').toString(); //判断交期是否一致

          var item_1 = _this.data.filter(function (x) {
            return x.id != 'summary' && x.sales_expected_give_date != values['give_date'];
          });

          if (item_1.length) {
            _this.$modal.open(chat_modify_memo["a" /* default */], {
              memo: ''
            }, {
              title: '合同交期和运营期望交期不一致的原因',
              width: '800px'
            }).subscribe(function (data) {
              for (var i in item_1) {
                item_1[i].import_memo = data;
              }

              values['order_lines'] = _this.data.filter(function (y) {
                return y.id != 'summary';
              }).map(function (x) {
                return {
                  line_id: x.id,
                  product_id: x.product_id,
                  default_code: x.default_code,
                  qty: x.product_qty,
                  give_date: x.contract_give_date,
                  import_memo: x.import_memo ? x.import_memo : ''
                };
              });

              _this.subData(values);
            });
          } else {
            values['order_lines'] = _this.data.filter(function (y) {
              return y.id != 'summary';
            }).map(function (x) {
              return {
                line_id: x.id,
                product_id: x.product_id,
                default_code: x.default_code,
                qty: x.product_qty,
                give_date: x.contract_give_date,
                import_memo: ''
              };
            });

            _this.subData(values);
          }
        }
      }
    });
  };

  AddReplenishContract.prototype.subData = function (values) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_requirement/save_pre_make_order', common_service["a" /* CommonService */].getMenuCode('purchase-pre-make-order'));
    this.publicService.modify(new http["RequestParams"](values, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AddReplenishContract.prototype.getDay = function (day, from) {
    if (from === void 0) {
      from = new Date();
    }

    var targetday_milliseconds = from.getTime() + 1000 * 60 * 60 * 24 * day;
    from.setTime(targetday_milliseconds); //注意，这行是关键代码

    var tYear = from.getFullYear();
    var tMonth = from.getMonth();
    var tDate = from.getDate();
    tMonth = this.doHandleMonth(tMonth + 1);
    tDate = this.doHandleMonth(tDate);
    return tYear + '-' + tMonth + '-' + tDate;
  };

  AddReplenishContract.prototype.doHandleMonth = function (month) {
    var m = month;

    if (month.toString().length == 1) {
      m = '0' + month;
    }

    return m;
  };

  AddReplenishContract.prototype.onCreateDateChange = function (e) {
    var date = e.format('YYYY-MM-DD').toString();
    var from = new Date(date);
    this.giveDate = this.getDay(20, from);
  };

  AddReplenishContract.prototype.onGiveDateChange = function (e) {
    for (var i in this.data) {
      if (this.data[i].id != 'summary') {
        this.data[i]['contract_give_date'] = e;
      }
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddReplenishContract.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddReplenishContract.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishContract.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishContract.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AddReplenishContract.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddReplenishContract.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('data'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AddReplenishContract.prototype, "onDataChange", null);

  AddReplenishContract = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      ModifyMemo: chat_modify_memo["a" /* default */]
    }
  })], AddReplenishContract);
  return AddReplenishContract;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var add_replenish_contractvue_type_script_lang_ts_ = (add_replenish_contractvue_type_script_lang_ts_AddReplenishContract);
// CONCATENATED MODULE: ./src/components/purchase/add-replenish-contract.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_add_replenish_contractvue_type_script_lang_ts_ = (add_replenish_contractvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/add-replenish-contract.vue?vue&type=style&index=0&lang=css&
var add_replenish_contractvue_type_style_index_0_lang_css_ = __webpack_require__("958f");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-contract.vue?vue&type=custom&index=0&blockType=i18n
var add_replenish_contractvue_type_custom_index_0_blockType_i18n = __webpack_require__("e29e");

// CONCATENATED MODULE: ./src/components/purchase/add-replenish-contract.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_add_replenish_contractvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof add_replenish_contractvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(add_replenish_contractvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var add_replenish_contract = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "fd17":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

}]);