(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["chunk-vendors~6e8b5f81"],{

/***/ "1d73":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var generate_1 = __importDefault(__webpack_require__("7746"));
exports.generate = generate_1.default;
var presetPrimaryColors = {
    red: '#F5222D',
    volcano: '#FA541C',
    orange: '#FA8C16',
    gold: '#FAAD14',
    yellow: '#FADB14',
    lime: '#A0D911',
    green: '#52C41A',
    cyan: '#13C2C2',
    blue: '#1890FF',
    geekblue: '#2F54EB',
    purple: '#722ED1',
    magenta: '#EB2F96',
    grey: '#666666',
};
exports.presetPrimaryColors = presetPrimaryColors;
var presetPalettes = {};
exports.presetPalettes = presetPalettes;
Object.keys(presetPrimaryColors).forEach(function (key) {
    presetPalettes[key] = generate_1.default(presetPrimaryColors[key]);
    presetPalettes[key].primary = presetPalettes[key][5];
});
var red = presetPalettes.red;
exports.red = red;
var volcano = presetPalettes.volcano;
exports.volcano = volcano;
var gold = presetPalettes.gold;
exports.gold = gold;
var orange = presetPalettes.orange;
exports.orange = orange;
var yellow = presetPalettes.yellow;
exports.yellow = yellow;
var lime = presetPalettes.lime;
exports.lime = lime;
var green = presetPalettes.green;
exports.green = green;
var cyan = presetPalettes.cyan;
exports.cyan = cyan;
var blue = presetPalettes.blue;
exports.blue = blue;
var geekblue = presetPalettes.geekblue;
exports.geekblue = geekblue;
var purple = presetPalettes.purple;
exports.purple = purple;
var magenta = presetPalettes.magenta;
exports.magenta = magenta;
var grey = presetPalettes.grey;
exports.grey = grey;


/***/ }),

/***/ "1da1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _asyncToGenerator; });
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d3b7");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);


function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

/***/ }),

/***/ "2adb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(process) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return log; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return isIconDefinition; });
/* unused harmony export normalizeAttrs */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MiniMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return generate; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return getSecondaryColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return withSuffix; });
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("41b2");
/* harmony import */ var babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("8827");
/* harmony import */ var babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("57ba");
/* harmony import */ var babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _ant_design_colors__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("1d73");
/* harmony import */ var _ant_design_colors__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_colors__WEBPACK_IMPORTED_MODULE_3__);





function log(message) {
  if (!(process && Object({"VUE_APP_SERVER":"http://47.244.150.247:48069","VUE_APP_TIMEOUT":"3600000","VUE_APP_MOCK":"false","VUE_APP_GOOGLEMAP_APIKEY":"AIzaSyDaBlQ-7bhO534-a-u32apwYYoQeln-1eg","NODE_ENV":"production","BASE_URL":"","ROUTERS":[{"routePath":"/PurchasePredict/product-pre-sale","componentPath":"PurchasePredict/product-pre-sale.vue"},{"routePath":"/PurchasePredict/product-purchase-approve","componentPath":"PurchasePredict/product-purchase-approve.vue"},{"routePath":"/PurchasePredict/product-purchase-confirm","componentPath":"PurchasePredict/product-purchase-confirm.vue"},{"routePath":"/PurchasePredict/product-purchase-predict","componentPath":"PurchasePredict/product-purchase-predict.vue"},{"routePath":"/PurchasePredict/product-purchase-schedual","componentPath":"PurchasePredict/product-purchase-schedual.vue"},{"routePath":"/PurchasePredict/product-sale-trend","componentPath":"PurchasePredict/product-sale-trend.vue"},{"routePath":"/PurchasePredict/product-sku-sale","componentPath":"PurchasePredict/product-sku-sale.vue"},{"routePath":"/PurchasePredict/requirement-schedule-feedback","componentPath":"PurchasePredict/requirement-schedule-feedback.vue"},{"routePath":"/PurchasePredict/requirement-schedule-reference","componentPath":"PurchasePredict/requirement-schedule-reference.vue"},{"routePath":"/accounts/account-invoice","componentPath":"accounts/account-invoice.vue"},{"routePath":"/accounts/account-page1","componentPath":"accounts/account-page1.vue"},{"routePath":"/accounts/account-page2","componentPath":"accounts/account-page2.vue"},{"routePath":"/accounts/invoice-edit","componentPath":"accounts/invoice-edit.vue"},{"routePath":"/aliexpress/aliexpress-instock-manage","componentPath":"aliexpress/aliexpress-instock-manage.vue"},{"routePath":"/aliexpress/aliexpress-manage","componentPath":"aliexpress/aliexpress-manage.vue"},{"routePath":"/aliexpress/aliexpress-manage1212","componentPath":"aliexpress/aliexpress-manage1212.vue"},{"routePath":"/amazon/amazon-listing-price","componentPath":"amazon/amazon-listing-price.vue"},{"routePath":"/amazon/amazon-listing-stock","componentPath":"amazon/amazon-listing-stock.vue"},{"routePath":"/amazon/amazon-listing-total","componentPath":"amazon/amazon-listing-total.vue"},{"routePath":"/amazon/ebay-listing-stock","componentPath":"amazon/ebay-listing-stock.vue"},{"routePath":"/basic_manage/currency-exchange","componentPath":"basic_manage/currency-exchange.vue"},{"routePath":"/basic_manage/illegal-words","componentPath":"basic_manage/illegal-words.vue"},{"routePath":"/basic_manage/instance-edit","componentPath":"basic_manage/instance-edit.vue"},{"routePath":"/basic_manage/instance-manage","componentPath":"basic_manage/instance-manage.vue"},{"routePath":"/basic_manage/query-condition-manage","componentPath":"basic_manage/query-condition-manage.vue"},{"routePath":"/basic_manage/seller-edit","componentPath":"basic_manage/seller-edit.vue"},{"routePath":"/basic_manage/seller-manage","componentPath":"basic_manage/seller-manage.vue"},{"routePath":"/common/code-manage","componentPath":"common/code-manage.vue"},{"routePath":"/common/list-page-wrapper","componentPath":"common/list-page-wrapper.vue"},{"routePath":"/common/page-wrapper","componentPath":"common/page-wrapper.vue"},{"routePath":"/common/sent-email-wrapper","componentPath":"common/sent-email-wrapper.vue"},{"routePath":"/common/swap-wrapper","componentPath":"common/swap-wrapper.vue"},{"routePath":"/cs_email_return/chat-box","componentPath":"cs_email_return/chat-box.vue"},{"routePath":"/cs_email_return/no-need-reply-customer","componentPath":"cs_email_return/no-need-reply-customer.vue"},{"routePath":"/customer/customer-manage","componentPath":"customer/customer-manage.vue"},{"routePath":"/customer_service/allot-user-map","componentPath":"customer_service/allot-user-map.vue"},{"routePath":"/customer_service/auto-reply-manage","componentPath":"customer_service/auto-reply-manage.vue"},{"routePath":"/customer_service/custom-problem-statistics","componentPath":"customer_service/custom-problem-statistics.vue"},{"routePath":"/customer_service/custom-problem","componentPath":"customer_service/custom-problem.vue"},{"routePath":"/customer_service/customer-auto-reply-manage","componentPath":"customer_service/customer-auto-reply-manage.vue"},{"routePath":"/customer_service/email-template-manage","componentPath":"customer_service/email-template-manage.vue"},{"routePath":"/customer_service/problem-picture","componentPath":"customer_service/problem-picture.vue"},{"routePath":"/customer_service/sent_email","componentPath":"customer_service/sent_email.vue"},{"routePath":"/customer_service/server-customer-map","componentPath":"customer_service/server-customer-map.vue"},{"routePath":"/customer_service/ticket-group-manage","componentPath":"customer_service/ticket-group-manage.vue"},{"routePath":"/customer_service/ticket-manage","componentPath":"customer_service/ticket-manage.vue"},{"routePath":"/dashboard/workspace","componentPath":"dashboard/workspace.vue"},{"routePath":"/demos/calender","componentPath":"demos/calender.vue"},{"routePath":"/demos/chart","componentPath":"demos/chart.vue"},{"routePath":"/demos/data-form","componentPath":"demos/data-form.vue"},{"routePath":"/demos/data-table","componentPath":"demos/data-table.vue"},{"routePath":"/demos/editor","componentPath":"demos/editor.vue"},{"routePath":"/demos/http","componentPath":"demos/http.vue"},{"routePath":"/demos/map","componentPath":"demos/map.vue"},{"routePath":"/demos/order","componentPath":"demos/order.vue"},{"routePath":"/demos/page-header","componentPath":"demos/page-header.vue"},{"routePath":"/exception/404","componentPath":"exception/404.vue"},{"routePath":"/login","componentPath":"login.vue"},{"routePath":"/mobile/dashboard","componentPath":"mobile/dashboard.vue"},{"routePath":"/mobile/login","componentPath":"mobile/login.vue"},{"routePath":"/operation/warehouse-list","componentPath":"operation/warehouse-list.vue"},{"routePath":"/orders/modify-custom-problem","componentPath":"orders/modify-custom-problem.vue"},{"routePath":"/orders/order-aliexpress","componentPath":"orders/order-aliexpress.vue"},{"routePath":"/orders/order-edit","componentPath":"orders/order-edit.vue"},{"routePath":"/orders/order-manage","componentPath":"orders/order-manage.vue"},{"routePath":"/orders/order-test","componentPath":"orders/order-test.vue"},{"routePath":"/orders/order-wrapper","componentPath":"orders/order-wrapper.vue"},{"routePath":"/picking/modify-address","componentPath":"picking/modify-address.vue"},{"routePath":"/picking/picking-manage-aliexpress","componentPath":"picking/picking-manage-aliexpress.vue"},{"routePath":"/picking/picking-manage","componentPath":"picking/picking-manage.vue"},{"routePath":"/picking/picking-wrapper","componentPath":"picking/picking-wrapper.vue"},{"routePath":"/picking/shipment-list","componentPath":"picking/shipment-list.vue"},{"routePath":"/picking/shipment-type","componentPath":"picking/shipment-type.vue"},{"routePath":"/presale/presale-manage","componentPath":"presale/presale-manage.vue"},{"routePath":"/presale/presale-orders-manage","componentPath":"presale/presale-orders-manage.vue"},{"routePath":"/presale/presale-wrapper","componentPath":"presale/presale-wrapper.vue"},{"routePath":"/product/B2C-product-price-check","componentPath":"product/B2C-product-price-check.vue"},{"routePath":"/product/ES-product-price-check","componentPath":"product/ES-product-price-check.vue"},{"routePath":"/product/FR-product-price-check","componentPath":"product/FR-product-price-check.vue"},{"routePath":"/product/GB-product-price-check","componentPath":"product/GB-product-price-check.vue"},{"routePath":"/product/IT-product-price-check","componentPath":"product/IT-product-price-check.vue"},{"routePath":"/product/Wish-product-price-check","componentPath":"product/Wish-product-price-check.vue"},{"routePath":"/product/ae-product-price-check","componentPath":"product/ae-product-price-check.vue"},{"routePath":"/product/ebay-product-price-check","componentPath":"product/ebay-product-price-check.vue"},{"routePath":"/product/generate-code-manage","componentPath":"product/generate-code-manage.vue"},{"routePath":"/product/inout-record","componentPath":"product/inout-record.vue"},{"routePath":"/product/land-haul-fee","componentPath":"product/land-haul-fee.vue"},{"routePath":"/product/manual-manage","componentPath":"product/manual-manage.vue"},{"routePath":"/product/ocean-shipping-fee","componentPath":"product/ocean-shipping-fee.vue"},{"routePath":"/product/ocean-shipping-monitor","componentPath":"product/ocean-shipping-monitor.vue"},{"routePath":"/product/package-chang-sku-monitor","componentPath":"product/package-chang-sku-monitor.vue"},{"routePath":"/product/pre_product_price_check","componentPath":"product/pre_product_price_check.vue"},{"routePath":"/product/product-cate-attr","componentPath":"product/product-cate-attr.vue"},{"routePath":"/product/product-category-manage","componentPath":"product/product-category-manage.vue"},{"routePath":"/product/product-float-price","componentPath":"product/product-float-price.vue"},{"routePath":"/product/product-history-stock","componentPath":"product/product-history-stock.vue"},{"routePath":"/product/product-manage","componentPath":"product/product-manage.vue"},{"routePath":"/product/product-parts","componentPath":"product/product-parts.vue"},{"routePath":"/product/product-search","componentPath":"product/product-search.vue"},{"routePath":"/product/product-wrapper","componentPath":"product/product-wrapper.vue"},{"routePath":"/product/product_price_check","componentPath":"product/product_price_check.vue"},{"routePath":"/product/product_price_check_history","componentPath":"product/product_price_check_history.vue"},{"routePath":"/product/product_price_check_new","componentPath":"product/product_price_check_new.vue"},{"routePath":"/product/product_price_check_result","componentPath":"product/product_price_check_result.vue"},{"routePath":"/product/specification-manage","componentPath":"product/specification-manage.vue"},{"routePath":"/product/stock-transfer","componentPath":"product/stock-transfer.vue"},{"routePath":"/purchase/create-shipping-plan","componentPath":"purchase/create-shipping-plan.vue"},{"routePath":"/purchase/depo-wrapper","componentPath":"purchase/depo-wrapper.vue"},{"routePath":"/purchase/logistics-providers-detail","componentPath":"purchase/logistics-providers-detail.vue"},{"routePath":"/purchase/logistics-providers-manage","componentPath":"purchase/logistics-providers-manage.vue"},{"routePath":"/purchase/purchase-contract-manage","componentPath":"purchase/purchase-contract-manage.vue"},{"routePath":"/purchase/purchase-cost-report","componentPath":"purchase/purchase-cost-report.vue"},{"routePath":"/purchase/purchase-de-po-manage","componentPath":"purchase/purchase-de-po-manage.vue"},{"routePath":"/purchase/purchase-give-date-report","componentPath":"purchase/purchase-give-date-report.vue"},{"routePath":"/purchase/purchase-package-manage","componentPath":"purchase/purchase-package-manage.vue"},{"routePath":"/purchase/purchase-package","componentPath":"purchase/purchase-package.vue"},{"routePath":"/purchase/purchase-pre-make-order","componentPath":"purchase/purchase-pre-make-order.vue"},{"routePath":"/purchase/purchase-product-plan","componentPath":"purchase/purchase-product-plan.vue"},{"routePath":"/purchase/purchase-product-qty-report","componentPath":"purchase/purchase-product-qty-report.vue"},{"routePath":"/purchase/purchase-product-quality-rate","componentPath":"purchase/purchase-product-quality-rate.vue"},{"routePath":"/purchase/purchase-reduce-cost-report","componentPath":"purchase/purchase-reduce-cost-report.vue"},{"routePath":"/purchase/purchase-ship-order-edit","componentPath":"purchase/purchase-ship-order-edit.vue"},{"routePath":"/purchase/purchase-ship-order","componentPath":"purchase/purchase-ship-order.vue"},{"routePath":"/purchase/replenishment-demand","componentPath":"purchase/replenishment-demand.vue"},{"routePath":"/purchase/replenishment-edit","componentPath":"purchase/replenishment-edit.vue"},{"routePath":"/purchase/shipping-plan-manage","componentPath":"purchase/shipping-plan-manage.vue"},{"routePath":"/purchase/vendor-detail","componentPath":"purchase/vendor-detail.vue"},{"routePath":"/purchase/vendor-manage","componentPath":"purchase/vendor-manage.vue"},{"routePath":"/purchase/vendor-product-detail","componentPath":"purchase/vendor-product-detail.vue"},{"routePath":"/purchase/vendor-product-manage","componentPath":"purchase/vendor-product-manage.vue"},{"routePath":"/purchase/vendor-wrapper","componentPath":"purchase/vendor-wrapper.vue"},{"routePath":"/reports/company-product-stock","componentPath":"reports/company-product-stock.vue"},{"routePath":"/reports/data-pivot-table","componentPath":"reports/data-pivot-table.vue"},{"routePath":"/reports/dept-product-factory-transit-stock-report","componentPath":"reports/dept-product-factory-transit-stock-report.vue"},{"routePath":"/reports/dept-sku-month-sales-report","componentPath":"reports/dept-sku-month-sales-report.vue"},{"routePath":"/reports/head-logistics-report","componentPath":"reports/head-logistics-report.vue"},{"routePath":"/reports/product-sale-state-change-report","componentPath":"reports/product-sale-state-change-report.vue"},{"routePath":"/reports/product-unsalable-report-leader","componentPath":"reports/product-unsalable-report-leader.vue"},{"routePath":"/reports/product-unsalable-report","componentPath":"reports/product-unsalable-report.vue"},{"routePath":"/reports/product-user-purchase-vendor-report","componentPath":"reports/product-user-purchase-vendor-report.vue"},{"routePath":"/reports/product-vendor-report","componentPath":"reports/product-vendor-report.vue"},{"routePath":"/reports/profit-detail","componentPath":"reports/profit-detail.vue"},{"routePath":"/reports/purchase-order-daily-report","componentPath":"reports/purchase-order-daily-report.vue"},{"routePath":"/reports/purchase-price-change-report","componentPath":"reports/purchase-price-change-report.vue"},{"routePath":"/reports/purchase-requirement-history-report","componentPath":"reports/purchase-requirement-history-report.vue"},{"routePath":"/reports/reissue-detail","componentPath":"reports/reissue-detail.vue"},{"routePath":"/reports/ship-order-daily-report","componentPath":"reports/ship-order-daily-report.vue"},{"routePath":"/schedule/schedule-list","componentPath":"schedule/schedule-list.vue"},{"routePath":"/schedule/schedule-manage","componentPath":"schedule/schedule-manage.vue"},{"routePath":"/schedule/weekly-manage","componentPath":"schedule/weekly-manage.vue"},{"routePath":"/settings/api-url-manage","componentPath":"settings/api-url-manage.vue"},{"routePath":"/settings/change-log","componentPath":"settings/change-log.vue"},{"routePath":"/settings/data-access-rule","componentPath":"settings/data-access-rule.vue"},{"routePath":"/settings/department-management","componentPath":"settings/department-management.vue"},{"routePath":"/settings/host-data-access-rule","componentPath":"settings/host-data-access-rule.vue"},{"routePath":"/settings/menu-access-manage","componentPath":"settings/menu-access-manage.vue"},{"routePath":"/settings/menu-manage","componentPath":"settings/menu-manage.vue"},{"routePath":"/settings/module-manage","componentPath":"settings/module-manage.vue"},{"routePath":"/settings/role-manage","componentPath":"settings/role-manage.vue"},{"routePath":"/settings/user-manage","componentPath":"settings/user-manage.vue"},{"routePath":"/settings/user-setting","componentPath":"settings/user-setting.vue"},{"routePath":"/shipment/final-shipping-de","componentPath":"shipment/final-shipping-de.vue"},{"routePath":"/shipment/final-shipping-uk","componentPath":"shipment/final-shipping-uk.vue"}]}) && "production" === 'production')) {
    console.error('[@ant-design/icons-vue]: ' + message + '.');
  }
}

function isIconDefinition(target) {
  return typeof target === 'object' && typeof target.name === 'string' && typeof target.theme === 'string' && (typeof target.icon === 'object' || typeof target.icon === 'function');
}

function normalizeAttrs() {
  var attrs = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  return Object.keys(attrs).reduce(function (acc, key) {
    var val = attrs[key];
    switch (key) {
      case 'class':
        acc.className = val;
        delete acc['class'];
        break;
      default:
        acc[key] = val;
    }
    return acc;
  }, {});
}

var MiniMap = function () {
  function MiniMap() {
    babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_1___default()(this, MiniMap);

    this.collection = {};
  }

  babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_2___default()(MiniMap, [{
    key: 'clear',
    value: function clear() {
      this.collection = {};
    }
  }, {
    key: 'delete',
    value: function _delete(key) {
      return delete this.collection[key];
    }
  }, {
    key: 'get',
    value: function get(key) {
      return this.collection[key];
    }
  }, {
    key: 'has',
    value: function has(key) {
      return Boolean(this.collection[key]);
    }
  }, {
    key: 'set',
    value: function set(key, value) {
      this.collection[key] = value;
      return this;
    }
  }, {
    key: 'size',
    get: function get() {
      return Object.keys(this.collection).length;
    }
  }]);

  return MiniMap;
}();

function generate(h, node, key, rootProps) {
  if (!rootProps) {
    return h(node.tag, { key: key, attrs: babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, normalizeAttrs(node.attrs)) }, (node.children || []).map(function (child, index) {
      return generate(h, child, key + '-' + node.tag + '-' + index);
    }));
  }
  return h(node.tag, babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({
    key: key
  }, rootProps, {
    attrs: babel_runtime_helpers_extends__WEBPACK_IMPORTED_MODULE_0___default()({}, normalizeAttrs(node.attrs), rootProps.attrs)
  }), (node.children || []).map(function (child, index) {
    return generate(h, child, key + '-' + node.tag + '-' + index);
  }));
}

function getSecondaryColor(primaryColor) {
  // choose the second color
  return Object(_ant_design_colors__WEBPACK_IMPORTED_MODULE_3__["generate"])(primaryColor)[0];
}

function withSuffix(name, theme) {
  switch (theme) {
    case 'fill':
      return name + '-fill';
    case 'outline':
      return name + '-o';
    case 'twotone':
      return name + '-twotone';
    default:
      throw new TypeError('Unknown theme type: ' + theme + ', name: ' + name);
  }
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__("4362")))

/***/ }),

/***/ "53ca":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return _typeof; });
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a4d3");
/* harmony import */ var core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("e01a");
/* harmony import */ var core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_description_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("d3b7");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("d28b");
/* harmony import */ var core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_symbol_iterator_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("3ca3");
/* harmony import */ var core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_iterator_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("ddb0");
/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_5__);






function _typeof(obj) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) {
    return typeof obj;
  } : function (obj) {
    return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
  }, _typeof(obj);
}

/***/ }),

/***/ "5530":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ _objectSpread2; });

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.keys.js
var es_object_keys = __webpack_require__("b64b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__("a4d3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.get-own-property-descriptor.js
var es_object_get_own_property_descriptor = __webpack_require__("e439");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__("159b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.get-own-property-descriptors.js
var es_object_get_own_property_descriptors = __webpack_require__("dbb4");

// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/defineProperty.js
function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/objectSpread2.js









function ownKeys(object, enumerableOnly) {
  var keys = Object.keys(object);

  if (Object.getOwnPropertySymbols) {
    var symbols = Object.getOwnPropertySymbols(object);
    enumerableOnly && (symbols = symbols.filter(function (sym) {
      return Object.getOwnPropertyDescriptor(object, sym).enumerable;
    })), keys.push.apply(keys, symbols);
  }

  return keys;
}

function _objectSpread2(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = null != arguments[i] ? arguments[i] : {};
    i % 2 ? ownKeys(Object(source), !0).forEach(function (key) {
      _defineProperty(target, key, source[key]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function (key) {
      Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
    });
  }

  return target;
}

/***/ }),

/***/ "7746":
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var tinycolor2_1 = __importDefault(__webpack_require__("66cb"));
var hueStep = 2; // 色相阶梯
var saturationStep = 16; // 饱和度阶梯，浅色部分
var saturationStep2 = 5; // 饱和度阶梯，深色部分
var brightnessStep1 = 5; // 亮度阶梯，浅色部分
var brightnessStep2 = 15; // 亮度阶梯，深色部分
var lightColorCount = 5; // 浅色数量，主色上
var darkColorCount = 4; // 深色数量，主色下
function getHue(hsv, i, light) {
    var hue;
    // 根据色相不同，色相转向不同
    if (Math.round(hsv.h) >= 60 && Math.round(hsv.h) <= 240) {
        hue = light ? Math.round(hsv.h) - hueStep * i : Math.round(hsv.h) + hueStep * i;
    }
    else {
        hue = light ? Math.round(hsv.h) + hueStep * i : Math.round(hsv.h) - hueStep * i;
    }
    if (hue < 0) {
        hue += 360;
    }
    else if (hue >= 360) {
        hue -= 360;
    }
    return hue;
}
function getSaturation(hsv, i, light) {
    // grey color don't change saturation
    if (hsv.h === 0 && hsv.s === 0) {
        return hsv.s;
    }
    var saturation;
    if (light) {
        saturation = Math.round(hsv.s * 100) - saturationStep * i;
    }
    else if (i === darkColorCount) {
        saturation = Math.round(hsv.s * 100) + saturationStep;
    }
    else {
        saturation = Math.round(hsv.s * 100) + saturationStep2 * i;
    }
    // 边界值修正
    if (saturation > 100) {
        saturation = 100;
    }
    // 第一格的 s 限制在 6-10 之间
    if (light && i === lightColorCount && saturation > 10) {
        saturation = 10;
    }
    if (saturation < 6) {
        saturation = 6;
    }
    return saturation;
}
function getValue(hsv, i, light) {
    if (light) {
        return Math.round(hsv.v * 100) + brightnessStep1 * i;
    }
    return Math.round(hsv.v * 100) - brightnessStep2 * i;
}
function generate(color) {
    var patterns = [];
    var pColor = tinycolor2_1.default(color);
    for (var i = lightColorCount; i > 0; i -= 1) {
        var hsv = pColor.toHsv();
        var colorString = tinycolor2_1.default({
            h: getHue(hsv, i, true),
            s: getSaturation(hsv, i, true),
            v: getValue(hsv, i, true),
        }).toHexString();
        patterns.push(colorString);
    }
    patterns.push(pColor.toHexString());
    for (var i = 1; i <= darkColorCount; i += 1) {
        var hsv = pColor.toHsv();
        var colorString = tinycolor2_1.default({
            h: getHue(hsv, i),
            s: getSaturation(hsv, i),
            v: getValue(hsv, i),
        }).toHexString();
        patterns.push(colorString);
    }
    return patterns;
}
exports.default = generate;


/***/ }),

/***/ "8520":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/babel-runtime/helpers/extends.js
var helpers_extends = __webpack_require__("41b2");
var extends_default = /*#__PURE__*/__webpack_require__.n(helpers_extends);

// EXTERNAL MODULE: ./node_modules/@ant-design/icons-vue/es/utils.js
var utils = __webpack_require__("2adb");

// CONCATENATED MODULE: ./node_modules/@ant-design/icons-vue/es/components/Icon.js



var twoToneColorPalette = {
  primaryColor: '#333',
  secondaryColor: '#E6E6E6'
};

var Icon = {
  name: 'AntdIcon',
  props: ['type', 'primaryColor', 'secondaryColor'],
  displayName: 'IconVue',
  definitions: new utils["a" /* MiniMap */](),
  data: function data() {
    return {
      twoToneColorPalette: twoToneColorPalette
    };
  },
  add: function add() {
    for (var _len = arguments.length, icons = Array(_len), _key = 0; _key < _len; _key++) {
      icons[_key] = arguments[_key];
    }

    icons.forEach(function (icon) {
      Icon.definitions.set(Object(utils["f" /* withSuffix */])(icon.name, icon.theme), icon);
    });
  },
  clear: function clear() {
    Icon.definitions.clear();
  },
  get: function get(key) {
    var colors = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : twoToneColorPalette;

    if (key) {
      var target = Icon.definitions.get(key);
      if (target && typeof target.icon === 'function') {
        target = extends_default()({}, target, {
          icon: target.icon(colors.primaryColor, colors.secondaryColor)
        });
      }
      return target;
    }
  },
  setTwoToneColors: function setTwoToneColors(_ref) {
    var primaryColor = _ref.primaryColor,
        secondaryColor = _ref.secondaryColor;

    twoToneColorPalette.primaryColor = primaryColor;
    twoToneColorPalette.secondaryColor = secondaryColor || Object(utils["c" /* getSecondaryColor */])(primaryColor);
  },
  getTwoToneColors: function getTwoToneColors() {
    return extends_default()({}, twoToneColorPalette);
  },
  render: function render(h) {
    var _$props = this.$props,
        type = _$props.type,
        primaryColor = _$props.primaryColor,
        secondaryColor = _$props.secondaryColor;


    var target = void 0;
    var colors = twoToneColorPalette;
    if (primaryColor) {
      colors = {
        primaryColor: primaryColor,
        secondaryColor: secondaryColor || Object(utils["c" /* getSecondaryColor */])(primaryColor)
      };
    }
    if (Object(utils["d" /* isIconDefinition */])(type)) {
      target = type;
    } else if (typeof type === 'string') {
      target = Icon.get(type, colors);
      if (!target) {
        // log(`Could not find icon: ${type}`);
        return null;
      }
    }
    if (!target) {
      Object(utils["e" /* log */])('type should be string or icon definiton, but got ' + type);
      return null;
    }
    if (target && typeof target.icon === 'function') {
      target = extends_default()({}, target, {
        icon: target.icon(colors.primaryColor, colors.secondaryColor)
      });
    }
    return Object(utils["b" /* generate */])(h, target.icon, 'svg-' + target.name, {
      attrs: {
        'data-icon': target.name,
        width: '1em',
        height: '1em',
        fill: 'currentColor',
        'aria-hidden': 'true'
      },
      on: this.$listeners
    });
  }
};

/* istanbul ignore next */
Icon.install = function (Vue) {
  Vue.component(Icon.name, Icon);
};

/* harmony default export */ var components_Icon = (Icon);
// CONCATENATED MODULE: ./node_modules/@ant-design/icons-vue/es/index.js


/* harmony default export */ var es = __webpack_exports__["a"] = (components_Icon);

/***/ }),

/***/ "b85c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ _createForOfIteratorHelper; });

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.js
var es_symbol = __webpack_require__("a4d3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.description.js
var es_symbol_description = __webpack_require__("e01a");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.symbol.iterator.js
var es_symbol_iterator = __webpack_require__("d28b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__("3ca3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__("ddb0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__("fb6a");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__("a630");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__("00b4");

// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/arrayLikeToArray.js
function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/unsupportedIterableToArray.js








function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return _arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(o);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
// CONCATENATED MODULE: ./node_modules/@babel/runtime/helpers/esm/createForOfIteratorHelper.js







function _createForOfIteratorHelper(o, allowArrayLike) {
  var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];

  if (!it) {
    if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
      if (it) o = it;
      var i = 0;

      var F = function F() {};

      return {
        s: F,
        n: function n() {
          if (i >= o.length) return {
            done: true
          };
          return {
            done: false,
            value: o[i++]
          };
        },
        e: function e(_e) {
          throw _e;
        },
        f: F
      };
    }

    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }

  var normalCompletion = true,
      didErr = false,
      err;
  return {
    s: function s() {
      it = it.call(o);
    },
    n: function n() {
      var step = it.next();
      normalCompletion = step.done;
      return step;
    },
    e: function e(_e2) {
      didErr = true;
      err = _e2;
    },
    f: function f() {
      try {
        if (!normalCompletion && it["return"] != null) it["return"]();
      } finally {
        if (didErr) throw err;
      }
    }
  };
}

/***/ })

}]);