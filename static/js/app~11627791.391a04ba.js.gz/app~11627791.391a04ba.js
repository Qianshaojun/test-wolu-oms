(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~11627791"],{

/***/ "155e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RequestService; });
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d3b7");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("9ab4");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("bc3a");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _request_interceptor__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("9207");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("c1df");
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("afbc");







var RequestService =
/** @class */
function () {
  /**
   * 构造函数
   */
  function RequestService() {
    RequestService.instance = this; // 创建axios实例

    this.axiosInstance = axios__WEBPACK_IMPORTED_MODULE_2___default.a.create({
      baseURL: RequestService.config.server,
      timeout: RequestService.config.timeout,
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json'
      }
    });
  }
  /**
   * 设置网络请求基础配置
   * @param param
   */


  RequestService.setConfig = function (_a) {
    var server = _a.server,
        timeout = _a.timeout;
    RequestService.config.server = server;
    RequestService.config.timeout = timeout;
  };
  /**
   * 安装通讯扩展服务
   * @param service
   */


  RequestService.installExtendService = function (service) {
    RequestService.extendServices.push(service);
  };
  /**
   * 获取服务请求单例
   */


  RequestService.getInstance = function () {
    if (this.instance) {
      return this.instance;
    }

    return new RequestService();
  };
  /**
   * 发送网络请求信息
   * @param param
   */


  RequestService.prototype.send = function (requestOption) {
    // 获取配置对象
    var options = requestOption.getOptions();

    if (options.headers && options.headers.is_expires) {
      _router__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"].push({
        name: 'login'
      });
    }

    if (options.headers && options.headers.hasOwnProperty("is_expires")) {
      delete options.headers['is_expires'];
    } // 发送通讯请求


    return this.axiosInstance.request(tslib__WEBPACK_IMPORTED_MODULE_1__[/* __assign */ "a"]({}, options)).then(function (response) {
      // 网络通讯正常
      // 无状态拦截器的情况下则返回通讯成功
      // 状态拦截器转换通讯状态
      if (response.data && response.data.error && response.data.error.message === 'Odoo Session Expired') {
        throw {
          response: response
        };
      }

      if (response.headers.customer_key) {
        localStorage.setItem('session_id', response.headers.customer_key);
        var now = moment__WEBPACK_IMPORTED_MODULE_4___default()();

        if (!localStorage.getItem('session_expires') || response.config.url == "wms/user_login") {
          localStorage.setItem('session_expires', now.add(7, 'days').format());
        }
      }

      if (!RequestService.interceptors.status.defined || RequestService.interceptors.status.interceptor(response)) {
        // 通讯成功
        return {
          data: RequestService.interceptors.success.defined ? RequestService.interceptors.success.interceptor(response) : response,
          response: response
        };
      } else {
        // 通讯失败ß
        var return_err = {};

        if (RequestService.interceptors.error.defined) {
          try {
            return_err = RequestService.interceptors.error.interceptor(response);
          } catch (error) {
            return_err = response.data.result;
          }
        }

        return {
          error: return_err,
          response: response
        };
      }
    }).catch(function (ex) {
      if (RequestService.requestCatchHandle) {
        RequestService.requestCatchHandle(ex.response);
      }

      return Promise.reject(ex);
    });
  }; // 基础服务配置


  RequestService.config = {
    server: '',
    timeout: 1000 * 60 * 60
  }; // 拦截器

  RequestService.interceptors = {
    // 前置拦截器
    before: [],
    // 后置拦截器
    after: [],
    // 状态拦截器
    status: new _request_interceptor__WEBPACK_IMPORTED_MODULE_3__[/* RequestInterceptor */ "a"](),
    // 成功状态拦截器
    success: new _request_interceptor__WEBPACK_IMPORTED_MODULE_3__[/* RequestInterceptor */ "a"](),
    // 失败状态拦截器
    error: new _request_interceptor__WEBPACK_IMPORTED_MODULE_3__[/* RequestInterceptor */ "a"]()
  }; // 全局扩展服务数组

  RequestService.extendServices = [];
  return RequestService;
}();



/***/ }),

/***/ "16e0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* reexport */ Page; });

// UNUSED EXPORTS: Request

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// CONCATENATED MODULE: ./src/core/decorators/page.decorator.ts


/**
 * 设置布局
 * @param target
 */
function Page(option) {
  return function (target) {
    target['options'].name = option.name;
    Object.defineProperty(target, '$layout', {
      writable: false,
      value: option.layout || 'default'
    });
    Object.defineProperty(target, '$name', {
      writable: false,
      value: option.name
    });
    return target;
  };
}
// EXTERNAL MODULE: ./src/core/decorators/request.decorators.ts
var request_decorators = __webpack_require__("c176");

// CONCATENATED MODULE: ./src/core/decorators/index.ts



/***/ }),

/***/ "34e9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RequestObject; });
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d3b7");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("e9b9");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("1b92");
/* harmony import */ var _request_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("6206");
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("7b17");
/* harmony import */ var _request_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("155e");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("6f7e");
/* harmony import */ var class_transformer__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(class_transformer__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var uuidjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("1f82");
/* harmony import */ var uuidjs__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(uuidjs__WEBPACK_IMPORTED_MODULE_7__);







/**
 * 请求对象
 */

var RequestObject =
/** @class */
function () {
  /**
   * 构造函数
   */
  function RequestObject(requestServer) {
    var _this = this; // 通讯状态


    this.requestState = _enums__WEBPACK_IMPORTED_MODULE_4__[/* RequestState */ "b"].Ready; // 生成请求对象id

    this.id = uuidjs__WEBPACK_IMPORTED_MODULE_7___default.a.generate(); // 设置请求服务对象

    this.requestServer = requestServer; // 设置可观察对象

    this.requestObservable = new rxjs__WEBPACK_IMPORTED_MODULE_1__[/* Observable */ "a"](function (observer) {
      // 设置观察者
      _this.requestObserver = observer;
    });
  }
  /**
   * 设置响应数据模型
   * @param model
   */


  RequestObject.prototype.setResponseModel = function (model) {
    this.responseModel = model;
  };
  /**
   * 发送网络请求
   */


  RequestObject.prototype.request = function (requestParams) {
    var _this = this; // 如果通讯实体未占用则发送通讯数据


    if (this.requestState === _enums__WEBPACK_IMPORTED_MODULE_4__[/* RequestState */ "b"].Ready) {
      // 修改网络通讯状态
      this.requestState = _enums__WEBPACK_IMPORTED_MODULE_4__[/* RequestState */ "b"].Loading; // 生成通讯配置对象

      var requestOption = new _request_option__WEBPACK_IMPORTED_MODULE_3__[/* RequestOption */ "a"](this.requestServer, requestParams); // 发送网络请求

      _request_service__WEBPACK_IMPORTED_MODULE_5__[/* RequestService */ "a"].getInstance().send(requestOption).then(function (_a) {
        var data = _a.data,
            error = _a.error,
            response = _a.response;

        if (error) {
          _this.requestObserver.error(error);

          return;
        } // 转换数据结构


        var result;

        if (_this.responseModel) {
          result = Object(class_transformer__WEBPACK_IMPORTED_MODULE_6__["plainToClass"])(_this.responseModel, data);
        } else {
          result = data;
        } // 应用扩展


        for (var _i = 0, _b = requestParams.getExtendService(); _i < _b.length; _i++) {
          var service = _b[_i];
          service.after && service.after(response, requestParams);
        } // 通讯结果正常


        _this.requestObserver.next(result);

        _this.requestObserver.complete();
      }).finally(function () {
        // 重置通讯状态
        _this.requestState = _enums__WEBPACK_IMPORTED_MODULE_4__[/* RequestState */ "b"].Ready;
      }).catch(function (response) {
        // 通讯结果异常
        _this.requestObserver.error(response.data);
      }); // 返回观察对象

      return this.requestObservable;
    } else {
      // 通讯实体占用中
      // 忽略进入的请求
      return rxjs__WEBPACK_IMPORTED_MODULE_2__[/* EMPTY */ "a"];
    }
  };

  return RequestObject;
}();



/***/ }),

/***/ "4cb7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ExtendService; });
var ExtendService =
/** @class */
function () {
  function ExtendService() {}

  return ExtendService;
}();



/***/ }),

/***/ "5416":
/***/ (function(module, exports) {



/***/ }),

/***/ "6206":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RequestOption; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("99af");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("a15b");
/* harmony import */ var core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_join_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("4de4");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("d3b7");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("d81d");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("4fad");
/* harmony import */ var core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_entries_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("caad");
/* harmony import */ var core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_includes_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("2532");
/* harmony import */ var core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_includes_js__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("159b");
/* harmony import */ var core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_for_each_js__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("9ab4");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("4328");
/* harmony import */ var qs__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(qs__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("7b17");
/* harmony import */ var _request_service__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__("155e");













/**
 * 请求配置对象
 */

var RequestOption =
/** @class */
function () {
  /**
   * 构造函数
   * @param requestServer 请求服务
   * @param params 请求参数
   */
  function RequestOption(requestServer, requestParams) {
    this.requestServer = requestServer;
    this.requestParams = requestParams;
  }
  /**
   * 获取请求选项
   */


  RequestOption.prototype.getOptions = function () {
    // 应用扩展
    for (var _i = 0, _a = this.requestParams.getExtendService(); _i < _a.length; _i++) {
      var service = _a[_i];
      service.before && service.before(this.requestParams);
    }

    return {
      url: _request_service__WEBPACK_IMPORTED_MODULE_12__[/* RequestService */ "a"].getRequestUrl ? _request_service__WEBPACK_IMPORTED_MODULE_12__[/* RequestService */ "a"].getRequestUrl(this) : this.getRequestUrl(),
      headers: _request_service__WEBPACK_IMPORTED_MODULE_12__[/* RequestService */ "a"].getRequestHeader ? _request_service__WEBPACK_IMPORTED_MODULE_12__[/* RequestService */ "a"].getRequestHeader(this) : this.requestParams.options.header,
      method: this.requestServer.type,
      // 获取post请求参数
      data: this.getParamsByMethod(false),
      // 获取get请求参数
      params: this.getParamsByMethod(true),
      // 序列化参数:用于GET请求
      paramsSerializer: function paramsSerializer(params) {
        return qs__WEBPACK_IMPORTED_MODULE_10___default.a.stringify(params, {
          arrayFormat: 'repeat',
          skipNulls: true,
          allowDots: true
        });
      }
    };
  };
  /**
   * 获取目标url地址
   */


  RequestOption.prototype.getRequestUrl = function () {
    if (!this.requestServer) {
      throw new Error('server配置异常,请检查对应server配置');
    } // 服务地址数组
    // 地址组合规则为
    // : baseUrl/service/controller/action/append


    var requestServerArray = [this.requestServer.service || '', this.requestServer.controller || '', this.requestServer.action || ''].concat(this.requestParams.options.append ? this.requestParams.options.append : []);
    var targetUrl = requestServerArray.filter(function (x) {
      return x;
    }).join('/');

    if (this.requestParams.options.query) {
      var query = Object.entries(this.requestParams.options.query).map(function (_a) {
        var key = _a[0],
            value = _a[1];
        return key + "=" + value;
      }).join('&');
      query && (targetUrl += "?" + query);
    } // 组合为url形式


    return targetUrl;
  };
  /**
   * 请求类型返回请求参数
   */


  RequestOption.prototype.getParamsByMethod = function (isGet) {
    // 请求返回非当前请求方式则返回{}
    if (this.isGetMethod() !== isGet) {
      return {};
    } // 根据请求方式返回数据


    if (isGet) {
      return this.filterEmptyData(this.requestParams.data);
    } else {
      return tslib__WEBPACK_IMPORTED_MODULE_9__[/* __assign */ "a"]({}, this.requestParams.data);
    }
  };
  /**
   * 是否是get类型方法
   */


  RequestOption.prototype.isGetMethod = function () {
    return [_enums__WEBPACK_IMPORTED_MODULE_11__[/* RequestMethod */ "a"].Get, _enums__WEBPACK_IMPORTED_MODULE_11__[/* RequestMethod */ "a"].Delete].includes(this.requestServer.type);
  };
  /**
   * 过滤空数据
   * @param data
   */


  RequestOption.prototype.filterEmptyData = function (values) {
    // 初始进行浅拷贝
    var data = tslib__WEBPACK_IMPORTED_MODULE_9__[/* __assign */ "a"]({}, values); // 过滤数据项


    Object.entries(data).filter(function (_a) {
      var key = _a[0],
          value = _a[1]; // 过滤空字符串

      if (value === undefined || value === '') {
        return true;
      } // 过滤空数组


      if (value instanceof Array && (value.length === 0 || value.every(function (x) {
        return x === '';
      }))) {
        return true;
      }
    }).forEach(function (_a) {
      var key = _a[0],
          value = _a[1];
      delete data[key];
    });
    return data;
  };

  return RequestOption;
}();



/***/ }),

/***/ "6916":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Layout; });
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b0c0");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_0__);


/**
 * 设置布局
 * @param target
 */
function Layout(option) {
  return function (target) {
    Object.defineProperty(target, '$name', {
      writable: false,
      value: option.name
    });
    return target;
  };
}

/***/ }),

/***/ "7b17":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RequestMethod; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return RequestState; });
/**
 * 请求方法类型
 */
var RequestMethod;

(function (RequestMethod) {
  RequestMethod["Get"] = "GET";
  RequestMethod["Post"] = "POST";
  RequestMethod["Put"] = "PUT";
  RequestMethod["Delete"] = "DELETE";
  RequestMethod["Options"] = "OPTIONS";
  RequestMethod["Head"] = "HEAD";
  RequestMethod["Patch"] = "PATCH";
})(RequestMethod || (RequestMethod = {}));
/**
 * 通讯状态
 */


var RequestState;

(function (RequestState) {
  RequestState[RequestState["Ready"] = 0] = "Ready";
  RequestState[RequestState["Loading"] = 1] = "Loading"; // 请求发送中
})(RequestState || (RequestState = {}));

/***/ }),

/***/ "9207":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return RequestInterceptor; });
/**
 * 请求拦截器
 */
var RequestInterceptor =
/** @class */
function () {
  function RequestInterceptor() {
    /**
     * 拦截器状态
     */
    this.defined = false;
  }
  /**
   * 注册拦截器
   * @param callback
   */


  RequestInterceptor.prototype.use = function (callback) {
    this.defined = true;
    this.interceptor = callback;
  };

  return RequestInterceptor;
}();



/***/ }),

/***/ "ae78":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__("159b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.entries.js
var es_object_entries = __webpack_require__("4fad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.runtime.esm.js
var vue_runtime_esm = __webpack_require__("2b0e");

// EXTERNAL MODULE: ./node_modules/vue-router/dist/vue-router.esm.js
var vue_router_esm = __webpack_require__("8c4f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__("ddb0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-class-component/dist/vue-class-component.esm.js
var vue_class_component_esm = __webpack_require__("2fe1");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/assets/locale/index.js
var locale = __webpack_require__("a060");

// CONCATENATED MODULE: ./src/core/app.ts





 // 实现动态入口






var app_App =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](App, _super);

  function App() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  App.prototype.render = function (h, props) {
    // 创建布局元素
    var layoutEl = h(this.$app.store.getters.layout); // 创建模板元素

    var templateEl = h('div', {
      domProps: {
        id: '__layout'
      },
      style: {
        width: '100%',
        height: '100%'
      },
      key: this.$app.state.layout
    }, [layoutEl]); // 创建过渡元素

    var transitionEl = h('transition', {
      props: {
        name: 'layout',
        mode: 'out-in'
      }
    }, [templateEl]); // 设置多语言

    moment_default.a.locale(locale["a" /* antdLocale */][this.$app.state.locale].monent);
    this.$i18n.locale = this.$app.state.locale;
    return h('div', {
      domProps: {
        id: 'app' // for check root #app

      },
      class: ["theme-" + this.$app.state.theme]
    }, [transitionEl]);
  };

  App.prototype.created = function () {// // Add this.$nuxt in child instances
    // Vue.prototype.$nuxt = this
    // // add to window so we can listen when ready
    // if (typeof window !== 'undefined') {
    //   window.$nuxt = this
    // }
    // // Add $nuxt.error()
    // this.error = this.nuxt.error
  };

  App.prototype.mounted = function () {
    return;
  };

  App.prototype.errorChanged = function () {// if (this.nuxt.err && this.$loading) {
    //   if (this.$loading.fail) this.$loading.fail()
    //   if (this.$loading.finish) this.$loading.finish()
    // }
  };

  App = tslib_es6["c" /* __decorate */]([Object(vue_class_component_esm["b" /* default */])({
    components: {},
    beforeCreate: function beforeCreate() {
      var _this = this; // 动态加载布局文件


      var requireLayout = function requireLayout() {
        var result;

        try {
          var req = __webpack_require__("4423");

          result = function (requireContext) {
            return requireContext.keys().map(requireContext);
          }(req).map(function (layout) {
            return {
              name: layout.default.$name,
              component: layout.default
            };
          });
        } catch (ex) {// console.error(ex, 'load layout has error')
        }

        return result;
      }; // 导入动态组件


      var importComponents = function importComponents(_a) {
        var name = _a.name,
            component = _a.component;
        var components = _this.$options.components;

        if (components) {
          components[name] = component;
        }
      }; // 导入布局


      requireLayout().forEach(importComponents);
    }
  })], App);
  return App;
}(vue_runtime_esm["a" /* default */]);

/* harmony default export */ var app = (app_App);
// EXTERNAL MODULE: ./src/core/application_router.ts
var application_router = __webpack_require__("f303");

// EXTERNAL MODULE: ./src/core/application_store.ts
var application_store = __webpack_require__("d19e");

// EXTERNAL MODULE: ./node_modules/vue-i18n/dist/vue-i18n.esm.js
var vue_i18n_esm = __webpack_require__("a925");

// CONCATENATED MODULE: ./src/core/application.ts







vue_runtime_esm["a" /* default */].use(vue_router_esm["a" /* default */]);





var application_Application =
/** @class */
function () {
  /**
   * 构造函数
   * @param options
   */
  function Application(options) {
    // 进行全局混入
    this.mixins(); // 安装基础插件

    vue_runtime_esm["a" /* default */].use(vue_router_esm["a" /* default */]);
    vue_runtime_esm["a" /* default */].use(vue_i18n_esm["a" /* default */]); // application store

    var store = application_store["a" /* ApplicationStore */].getStore(); // 注册路由扩展

    this.router = new application_router["a" /* ApplicationRouter */](options, store);
    var i18n = new vue_i18n_esm["a" /* default */]({
      locale: store.state.locale,
      messages: locale["b" /* i18nLocale */],
      silentTranslationWarn: true
    });
    Application.i18n = i18n; // 初始化框架

    this.bootstrap(options, function () {
      new vue_runtime_esm["a" /* default */]({
        router: options.router,
        store: options.store,
        i18n: i18n,
        render: function render(h) {
          return h(options.app, {}, [h(app)]);
        }
      }).$mount('#app');
    });
  }
  /**
   * 全局混入
   */


  Application.prototype.mixins = function () {
    // var Component = Vue.extend({
    //   mixins: [validationMixin]
    // })
    var _this = this; // 添加插件


    vue_runtime_esm["a" /* default */].use({
      install: function install() {
        vue_runtime_esm["a" /* default */].prototype.$app = {
          router: _this.router,
          store: application_store["a" /* ApplicationStore */].getStore(),
          state: application_store["a" /* ApplicationStore */].getStore().state
        };
      }
    });
  };
  /**
   * 初始化配置
   * @param options 配置选项
   * @param callback
   */


  Application.prototype.bootstrap = function (_a, applicationInit) {
    var store = _a.store,
        bootstrap = _a.bootstrap; // 安装过滤器

    if (bootstrap.filters) {
      Object.entries(bootstrap.filters(store)).forEach(function (_a) {
        var key = _a[0],
            fun = _a[1];
        vue_runtime_esm["a" /* default */].filter(key, fun);
      });
    } // 安装指令


    if (bootstrap.directives) {
      Object.entries(bootstrap.directives(store)).forEach(function (_a) {
        var key = _a[0],
            fun = _a[1];
        vue_runtime_esm["a" /* default */].directive(key, fun);
      });
    } // 安装插件


    if (bootstrap.plugins) {
      Object.entries(bootstrap.plugins(store)).forEach(function (_a) {
        var key = _a[0],
            plugin = _a[1];
        vue_runtime_esm["a" /* default */].use(plugin);
      });
    } //vue原型挂载公用方法


    if (bootstrap.provides) {
      Object.entries(bootstrap.provides(store)).forEach(function (_a) {
        var key = _a[0],
            provides = _a[1];
        vue_runtime_esm["a" /* default */].prototype[key] = provides;
      });
    } // UI实例化


    applicationInit();
  };

  return Application;
}();

/* harmony default export */ var application = __webpack_exports__["a"] = (application_Application);

/***/ }),

/***/ "be7c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ request_params_RequestParams; });

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.values.js
var es_object_values = __webpack_require__("07ac");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__("99af");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// CONCATENATED MODULE: ./src/core/model/model.ts
var Model =
/** @class */
function () {
  function Model() {}

  return Model;
}();


// CONCATENATED MODULE: ./src/core/model/index.ts

// EXTERNAL MODULE: ./src/core/http/request-service.ts
var request_service = __webpack_require__("155e");

// EXTERNAL MODULE: ./src/core/http/extend-service.ts
var extend_service = __webpack_require__("4cb7");

// EXTERNAL MODULE: ./node_modules/class-transformer/index.js
var class_transformer = __webpack_require__("6f7e");

// CONCATENATED MODULE: ./src/core/http/request-params.ts









/**
 * 请求参数对象
 */

var request_params_RequestParams =
/** @class */
function () {
  /**
   * 构造函数
   * @param data
   * @param options
   */
  function RequestParams(data, options) {
    this.data = data instanceof Model ? Object(class_transformer["classToPlain"])(data) : data || {};
    this.options = options || {};
  }
  /**
   * 设置请求对象
   * @param requestObject
   */


  RequestParams.prototype.setRequestObject = function (requestObject) {
    this.requestObject = requestObject;
  };
  /**
   * 获取扩展服务
   */


  RequestParams.prototype.getExtendService = function () {
    var extendServices = this.options ? Object.values(this.options).filter(function (service) {
      return service instanceof extend_service["a" /* ExtendService */];
    }) : [];
    return extendServices.concat(request_service["a" /* RequestService */].extendServices);
  };
  /**
   * 对数据进行转换
   * @param callback
   */


  RequestParams.prototype.map = function (callback) {
    this.data = callback(this.data);
  };
  /**
   * 发送网络请求
   */


  RequestParams.prototype.request = function () {
    return this.requestObject.request(this);
  };

  return RequestParams;
}();



/***/ }),

/***/ "c176":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Request; });
/* harmony import */ var _http_request_object__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("34e9");

/**
 * 网络请求行为装饰器
 */

function Request(_a) {
  var server = _a.server,
      model = _a.model,
      force = _a.force;
  return function (target, name, descriptor) {
    var generateRequestObject = function generateRequestObject() {
      // 请求对象
      var object = new _http_request_object__WEBPACK_IMPORTED_MODULE_0__[/* RequestObject */ "a"](server); // 设置响应数据模型

      if (model) {
        object.setResponseModel(model);
      }

      return object;
    };

    var requestObject = generateRequestObject(); // 存储历史方法

    var _value = descriptor.value; // 传入请求方法

    descriptor.value = function (requestParams) {
      if (force) {
        requestParams.setRequestObject(generateRequestObject());
      } else {
        // 设置请求对象
        requestParams.setRequestObject(requestObject);
      } // 传入更新后的请求对象


      return _value.call(target, requestParams);
    };

    return descriptor;
  };
}

/***/ }),

/***/ "c4d0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _enums__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7b17");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RequestMethod", function() { return _enums__WEBPACK_IMPORTED_MODULE_0__["a"]; });

/* harmony import */ var _interfaces__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("5416");
/* harmony import */ var _interfaces__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_interfaces__WEBPACK_IMPORTED_MODULE_1__);
/* harmony reexport (checked) */ if(__webpack_require__.o(_interfaces__WEBPACK_IMPORTED_MODULE_1__, "ExtendService")) __webpack_require__.d(__webpack_exports__, "ExtendService", function() { return _interfaces__WEBPACK_IMPORTED_MODULE_1__["ExtendService"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_interfaces__WEBPACK_IMPORTED_MODULE_1__, "Request")) __webpack_require__.d(__webpack_exports__, "Request", function() { return _interfaces__WEBPACK_IMPORTED_MODULE_1__["Request"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_interfaces__WEBPACK_IMPORTED_MODULE_1__, "RequestParams")) __webpack_require__.d(__webpack_exports__, "RequestParams", function() { return _interfaces__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]; });

/* harmony reexport (checked) */ if(__webpack_require__.o(_interfaces__WEBPACK_IMPORTED_MODULE_1__, "RequestService")) __webpack_require__.d(__webpack_exports__, "RequestService", function() { return _interfaces__WEBPACK_IMPORTED_MODULE_1__["RequestService"]; });

/* harmony import */ var _request_object__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("34e9");
/* harmony import */ var _request_params__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("be7c");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RequestParams", function() { return _request_params__WEBPACK_IMPORTED_MODULE_3__["a"]; });

/* harmony import */ var _request_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("155e");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "RequestService", function() { return _request_service__WEBPACK_IMPORTED_MODULE_4__["a"]; });

/* harmony import */ var _request_interceptor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("9207");
/* harmony import */ var _request_option__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("6206");
/* harmony import */ var _extend_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("4cb7");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ExtendService", function() { return _extend_service__WEBPACK_IMPORTED_MODULE_7__["a"]; });

/* harmony import */ var _decorators_request_decorators__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("c176");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Request", function() { return _decorators_request_decorators__WEBPACK_IMPORTED_MODULE_8__["a"]; });











/***/ }),

/***/ "d19e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export RedirectMethod */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ApplicationStore; });
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ac1f");
/* harmony import */ var core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_exec_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("5319");
/* harmony import */ var core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_string_replace_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("b0c0");
/* harmony import */ var core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_function_name_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("c740");
/* harmony import */ var core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_index_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("4de4");
/* harmony import */ var core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_filter_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("d3b7");
/* harmony import */ var core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_object_to_string_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__("7db0");
/* harmony import */ var core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_find_js__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var vuex__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__("2f62");
/* harmony import */ var vuex_persistedstate__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__("0e44");
/* harmony import */ var mobile_detect__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__("c6c6");
/* harmony import */ var mobile_detect__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(mobile_detect__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__("afbc");
/* harmony import */ var ant_design_vue__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__("f64c");












var detect = new mobile_detect__WEBPACK_IMPORTED_MODULE_9___default.a(navigator.userAgent);
var RedirectMethod;

(function (RedirectMethod) {
  RedirectMethod["Auto"] = "auto";
  RedirectMethod["Redirect"] = "redirect";
  RedirectMethod["Router"] = "router";
})(RedirectMethod || (RedirectMethod = {}));
/**
 * 应用内部数据存储
 */


var ApplicationStore =
/** @class */
function () {
  function ApplicationStore() {}

  ApplicationStore.getStore = function () {
    if (!this._store) {
      this._store = this.createStore();

      this._store.commit('updateReady', false);
    }

    return this._store;
  };

  ApplicationStore.createStore = function () {
    return new vuex__WEBPACK_IMPORTED_MODULE_7__[/* default */ "a"].Store({
      plugins: [// 持久化存储插件
      Object(vuex_persistedstate__WEBPACK_IMPORTED_MODULE_8__[/* default */ "a"])({
        key: 'core-vuex',
        storage: localStorage
      })],
      state: {
        // 初始化状态
        ready: false,
        // 选项卡标签
        tabs: [],
        currentTab: '',
        // 当前布局
        layout: 'loading',
        // 当前主题
        theme: 'default',
        // 当前语言
        locale: 'zh-cn',
        // 菜单折叠状态
        collapsed: false,
        // 页面全屏标识
        fullscreen: false,
        // 移动端标识
        mobile: !!detect.mobile()
      },
      getters: {
        layout: function layout(state) {
          return state.layout.replace(/^\S/, function (s) {
            return s.toUpperCase();
          }) + "Layout";
        }
      },
      mutations: {
        /**
         * 更新系统准备状态
         * @param state
         *
         */
        updateReady: function updateReady(state, value) {
          state.ready = value;
        },
        closeTab: function closeTab(state, _a) {
          var name = _a.name,
              _b = _a.method,
              method = _b === void 0 ? RedirectMethod.Auto : _b,
              redirectName = _a.redirectName;

          if (state.tabs.length === 1) {
            ant_design_vue__WEBPACK_IMPORTED_MODULE_11__[/* default */ "a"].warning('这是最后一页，不能再关闭了');
            return;
          }

          if (name === 'workspace') {
            return;
          } // 获取需要关闭的页面名称


          name = name || state.currentTab.name; // 获取需要关闭的页面Index

          var index = state.tabs.findIndex(function (item) {
            return item.name === name || item.title === name;
          }); // 修改页面tabs

          var tabs = state.tabs.filter(function (item) {
            return !item.title && item != name && item.name !== name || item.title && item.title !== name;
          });

          switch (method) {
            case RedirectMethod.Auto:
              index = index >= tabs.length ? tabs.length - 1 : index;
              state.currentTab = tabs[index];
              break;

            case RedirectMethod.Router:
              _router__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"].back();
              break;

            case RedirectMethod.Redirect:
              {
                var tab = state.tabs.find(function (x) {
                  return x.name === x.redirectName;
                });

                if (tab) {
                  state.currentTab = tabs[index];
                } else {
                  _router__WEBPACK_IMPORTED_MODULE_10__[/* default */ "a"].push({
                    name: redirectName
                  });
                }

                break;
              }

            default:
              break;
          }

          state.tabs = tabs;
        },

        /**
         * 更新Tabs列表
         * @param state
         * @param tabs
         */
        updateTabs: function updateTabs(state, tabs) {
          state.tabs = tabs;
        },

        /**
         * 更新Tabs列表
         * @param state
         * @param tabs
         */
        pushTab: function pushTab(state, tab) {
          var tabs = state.tabs;

          if (!tab.name) {
            return;
          }

          if (!tabs.find(function (x) {
            return x.name === tab.name;
          })) {
            tabs.push(tab);
          }

          state.currentTab = tab;
        },

        /**
         * 更新激活tab
         * @param state
         * @param tab
         */
        updateCurrentTab: function updateCurrentTab(state, tab) {
          state.currentTab = tab;
        },

        /**
         * 更新当前布局
         * @param state
         * @param layout
         */
        updateLayout: function updateLayout(state, layout) {
          state.layout = layout;
        },

        /**
         * 更新当前主题
         * @param state
         * @param theme
         */
        updateTheme: function updateTheme(state, theme) {
          state.theme = theme;
        },

        /**
         * 更新当前语言
         * @param state
         * @param locale
         */
        updateLocale: function updateLocale(state, locale) {
          state.locale = locale;
        },

        /**
         * 更新菜单折叠状态
         * @param state
         */
        updateCollapsed: function updateCollapsed(state) {
          state.collapsed = !state.collapsed;
        },

        /**
         * 更新菜单全屏状态
         * @param state
         *
         */
        updateFullscreen: function updateFullscreen(state) {
          state.fullscreen = !state.fullscreen;
        }
      }
    });
  };

  return ApplicationStore;
}();



/***/ }),

/***/ "f303":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ApplicationRouter; });
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("99af");
/* harmony import */ var core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_concat_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("d81d");
/* harmony import */ var core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_map_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("9ab4");




var ApplicationRouter =
/** @class */
function () {
  /**
   * 构造函数
   * @param router
   * @param store
   * @param launch
   */
  function ApplicationRouter(_a, applicationStore) {
    var router = _a.router,
        store = _a.store,
        launch = _a.launch; // 系统存储

    this.applicationStore = applicationStore; // 应用存储

    this.store = store;
    this.router = router;
    this.launch = launch; // 注册路由守卫

    this.router.beforeEach(this.routerBeforeEach.bind(this));
    this.router.beforeResolve(this.routerBeforeResolve.bind(this));
    this.router.afterEach(this.routerAfterEach.bind(this)); // 添加自动路由

    this.importAutoRoutes();
  }
  /**
   * 注册路由守卫
   * @param guards
   */


  ApplicationRouter.registerGuard = function (guards) {
    ApplicationRouter.guards = ApplicationRouter.guards.concat(guards);
  };
  /**
   * 前置路由守卫
   * 负责系统初始化检测
   * 负责登陆认证检测
   */


  ApplicationRouter.prototype.routerBeforeEach = function (to, from, next) {
    return tslib__WEBPACK_IMPORTED_MODULE_2__[/* __awaiter */ "b"](this, void 0, void 0, function () {
      var _a;

      return tslib__WEBPACK_IMPORTED_MODULE_2__[/* __generator */ "e"](this, function (_b) {
        switch (_b.label) {
          case 0:
            if (!(this.applicationStore.state.ready !== true)) return [3
            /*break*/
            , 3];
            _a = this.launch;
            if (!_a) return [3
            /*break*/
            , 2];
            return [4
            /*yield*/
            , this.launch({
              store: this.store,
              router: this.router
            })];

          case 1:
            _a = _b.sent();
            _b.label = 2;

          case 2:
            _a;
            this.applicationStore.commit('updateReady', true);
            _b.label = 3;

          case 3:
            next();
            return [2
            /*return*/
            ];
        }
      });
    });
  };
  /**
   * 前置路由解析守卫
   */


  ApplicationRouter.prototype.routerBeforeResolve = function (to, from, next) {
    return tslib__WEBPACK_IMPORTED_MODULE_2__[/* __awaiter */ "b"](this, void 0, void 0, function () {
      var guards, _i, guards_1, guard, result, path_1;

      return tslib__WEBPACK_IMPORTED_MODULE_2__[/* __generator */ "e"](this, function (_a) {
        switch (_a.label) {
          case 0:
            guards = ApplicationRouter.guards; // 无路由守卫直接通过

            if (!guards && ApplicationRouter.guards.length === 0) {
              return [2
              /*return*/
              , next()];
            }

            _a.label = 1;

          case 1:
            _a.trys.push([1, 6,, 7]);

            _i = 0, guards_1 = guards;
            _a.label = 2;

          case 2:
            if (!(_i < guards_1.length)) return [3
            /*break*/
            , 5];
            guard = guards_1[_i];
            return [4
            /*yield*/
            , guard({
              store: this.store,
              router: this.router
            }, {
              to: to,
              from: from,
              next: next
            }) // 检测守卫执行状态
            ];

          case 3:
            result = _a.sent(); // 检测守卫执行状态

            if (result !== undefined || result !== true) {
              throw result;
            }

            _a.label = 4;

          case 4:
            _i++;
            return [3
            /*break*/
            , 2];

          case 5:
            return [2
            /*return*/
            , next()];

          case 6:
            path_1 = _a.sent(); // 被守卫拦截执行守卫返回地址

            next(path_1);
            return [3
            /*break*/
            , 7];

          case 7:
            return [2
            /*return*/
            ];
        }
      });
    });
  };
  /**
   * 后置路由守卫
   */


  ApplicationRouter.prototype.routerAfterEach = function (to, from) {
    if (to.matched) {
      var component = this.getComponent(to.matched); //  布局检测

      this.layoutCheck(component);
    }
  };
  /**
   * 获取组件
   * @param matched
   */


  ApplicationRouter.prototype.getComponent = function (matched) {
    if (matched && matched.length > 0) {
      var components = matched[0].components;
      return components.default;
    }
  };
  /**
   * 布局监测
   * @param component
   */


  ApplicationRouter.prototype.layoutCheck = function (component) {
    if (component) {
      var targetLayout = component['$layout'] || 'loading';

      if (this.applicationStore.state.layout !== targetLayout) {
        this.applicationStore.commit('updateLayout', targetLayout);
      }
    }
  };
  /**
   * 布局监测
   * @param component
   */


  ApplicationRouter.prototype.authCheck = function (component) {
    return true;
  };

  ApplicationRouter.prototype.importAutoRoutes = function () {
    var _this = this;

    if (true) {
      var routes = [{"routePath":"/PurchasePredict/product-pre-sale","componentPath":"PurchasePredict/product-pre-sale.vue"},{"routePath":"/PurchasePredict/product-purchase-approve","componentPath":"PurchasePredict/product-purchase-approve.vue"},{"routePath":"/PurchasePredict/product-purchase-confirm","componentPath":"PurchasePredict/product-purchase-confirm.vue"},{"routePath":"/PurchasePredict/product-purchase-predict","componentPath":"PurchasePredict/product-purchase-predict.vue"},{"routePath":"/PurchasePredict/product-purchase-schedual","componentPath":"PurchasePredict/product-purchase-schedual.vue"},{"routePath":"/PurchasePredict/product-sale-trend","componentPath":"PurchasePredict/product-sale-trend.vue"},{"routePath":"/PurchasePredict/product-sku-sale","componentPath":"PurchasePredict/product-sku-sale.vue"},{"routePath":"/PurchasePredict/requirement-schedule-feedback","componentPath":"PurchasePredict/requirement-schedule-feedback.vue"},{"routePath":"/PurchasePredict/requirement-schedule-reference","componentPath":"PurchasePredict/requirement-schedule-reference.vue"},{"routePath":"/accounts/account-invoice","componentPath":"accounts/account-invoice.vue"},{"routePath":"/accounts/account-page1","componentPath":"accounts/account-page1.vue"},{"routePath":"/accounts/account-page2","componentPath":"accounts/account-page2.vue"},{"routePath":"/accounts/invoice-edit","componentPath":"accounts/invoice-edit.vue"},{"routePath":"/aliexpress/aliexpress-instock-manage","componentPath":"aliexpress/aliexpress-instock-manage.vue"},{"routePath":"/aliexpress/aliexpress-manage","componentPath":"aliexpress/aliexpress-manage.vue"},{"routePath":"/aliexpress/aliexpress-manage1212","componentPath":"aliexpress/aliexpress-manage1212.vue"},{"routePath":"/amazon/amazon-listing-price","componentPath":"amazon/amazon-listing-price.vue"},{"routePath":"/amazon/amazon-listing-stock","componentPath":"amazon/amazon-listing-stock.vue"},{"routePath":"/amazon/amazon-listing-total","componentPath":"amazon/amazon-listing-total.vue"},{"routePath":"/amazon/ebay-listing-stock","componentPath":"amazon/ebay-listing-stock.vue"},{"routePath":"/basic_manage/currency-exchange","componentPath":"basic_manage/currency-exchange.vue"},{"routePath":"/basic_manage/illegal-words","componentPath":"basic_manage/illegal-words.vue"},{"routePath":"/basic_manage/instance-edit","componentPath":"basic_manage/instance-edit.vue"},{"routePath":"/basic_manage/instance-manage","componentPath":"basic_manage/instance-manage.vue"},{"routePath":"/basic_manage/query-condition-manage","componentPath":"basic_manage/query-condition-manage.vue"},{"routePath":"/basic_manage/seller-edit","componentPath":"basic_manage/seller-edit.vue"},{"routePath":"/basic_manage/seller-manage","componentPath":"basic_manage/seller-manage.vue"},{"routePath":"/common/code-manage","componentPath":"common/code-manage.vue"},{"routePath":"/common/list-page-wrapper","componentPath":"common/list-page-wrapper.vue"},{"routePath":"/common/page-wrapper","componentPath":"common/page-wrapper.vue"},{"routePath":"/common/sent-email-wrapper","componentPath":"common/sent-email-wrapper.vue"},{"routePath":"/common/swap-wrapper","componentPath":"common/swap-wrapper.vue"},{"routePath":"/cs_email_return/chat-box","componentPath":"cs_email_return/chat-box.vue"},{"routePath":"/cs_email_return/no-need-reply-customer","componentPath":"cs_email_return/no-need-reply-customer.vue"},{"routePath":"/customer/customer-manage","componentPath":"customer/customer-manage.vue"},{"routePath":"/customer_service/allot-user-map","componentPath":"customer_service/allot-user-map.vue"},{"routePath":"/customer_service/auto-reply-manage","componentPath":"customer_service/auto-reply-manage.vue"},{"routePath":"/customer_service/custom-problem-statistics","componentPath":"customer_service/custom-problem-statistics.vue"},{"routePath":"/customer_service/custom-problem","componentPath":"customer_service/custom-problem.vue"},{"routePath":"/customer_service/customer-auto-reply-manage","componentPath":"customer_service/customer-auto-reply-manage.vue"},{"routePath":"/customer_service/email-template-manage","componentPath":"customer_service/email-template-manage.vue"},{"routePath":"/customer_service/problem-picture","componentPath":"customer_service/problem-picture.vue"},{"routePath":"/customer_service/sent_email","componentPath":"customer_service/sent_email.vue"},{"routePath":"/customer_service/server-customer-map","componentPath":"customer_service/server-customer-map.vue"},{"routePath":"/customer_service/ticket-group-manage","componentPath":"customer_service/ticket-group-manage.vue"},{"routePath":"/customer_service/ticket-manage","componentPath":"customer_service/ticket-manage.vue"},{"routePath":"/dashboard/workspace","componentPath":"dashboard/workspace.vue"},{"routePath":"/demos/calender","componentPath":"demos/calender.vue"},{"routePath":"/demos/chart","componentPath":"demos/chart.vue"},{"routePath":"/demos/data-form","componentPath":"demos/data-form.vue"},{"routePath":"/demos/data-table","componentPath":"demos/data-table.vue"},{"routePath":"/demos/editor","componentPath":"demos/editor.vue"},{"routePath":"/demos/http","componentPath":"demos/http.vue"},{"routePath":"/demos/map","componentPath":"demos/map.vue"},{"routePath":"/demos/order","componentPath":"demos/order.vue"},{"routePath":"/demos/page-header","componentPath":"demos/page-header.vue"},{"routePath":"/exception/404","componentPath":"exception/404.vue"},{"routePath":"/login","componentPath":"login.vue"},{"routePath":"/mobile/dashboard","componentPath":"mobile/dashboard.vue"},{"routePath":"/mobile/login","componentPath":"mobile/login.vue"},{"routePath":"/operation/warehouse-list","componentPath":"operation/warehouse-list.vue"},{"routePath":"/orders/modify-custom-problem","componentPath":"orders/modify-custom-problem.vue"},{"routePath":"/orders/order-aliexpress","componentPath":"orders/order-aliexpress.vue"},{"routePath":"/orders/order-edit","componentPath":"orders/order-edit.vue"},{"routePath":"/orders/order-manage","componentPath":"orders/order-manage.vue"},{"routePath":"/orders/order-test","componentPath":"orders/order-test.vue"},{"routePath":"/orders/order-wrapper","componentPath":"orders/order-wrapper.vue"},{"routePath":"/picking/modify-address","componentPath":"picking/modify-address.vue"},{"routePath":"/picking/picking-manage-aliexpress","componentPath":"picking/picking-manage-aliexpress.vue"},{"routePath":"/picking/picking-manage","componentPath":"picking/picking-manage.vue"},{"routePath":"/picking/picking-wrapper","componentPath":"picking/picking-wrapper.vue"},{"routePath":"/picking/shipment-list","componentPath":"picking/shipment-list.vue"},{"routePath":"/picking/shipment-type","componentPath":"picking/shipment-type.vue"},{"routePath":"/presale/presale-manage","componentPath":"presale/presale-manage.vue"},{"routePath":"/presale/presale-orders-manage","componentPath":"presale/presale-orders-manage.vue"},{"routePath":"/presale/presale-wrapper","componentPath":"presale/presale-wrapper.vue"},{"routePath":"/product/B2C-product-price-check","componentPath":"product/B2C-product-price-check.vue"},{"routePath":"/product/ES-product-price-check","componentPath":"product/ES-product-price-check.vue"},{"routePath":"/product/FR-product-price-check","componentPath":"product/FR-product-price-check.vue"},{"routePath":"/product/GB-product-price-check","componentPath":"product/GB-product-price-check.vue"},{"routePath":"/product/IT-product-price-check","componentPath":"product/IT-product-price-check.vue"},{"routePath":"/product/Wish-product-price-check","componentPath":"product/Wish-product-price-check.vue"},{"routePath":"/product/ae-product-price-check","componentPath":"product/ae-product-price-check.vue"},{"routePath":"/product/ebay-product-price-check","componentPath":"product/ebay-product-price-check.vue"},{"routePath":"/product/generate-code-manage","componentPath":"product/generate-code-manage.vue"},{"routePath":"/product/inout-record","componentPath":"product/inout-record.vue"},{"routePath":"/product/land-haul-fee","componentPath":"product/land-haul-fee.vue"},{"routePath":"/product/manual-manage","componentPath":"product/manual-manage.vue"},{"routePath":"/product/ocean-shipping-fee","componentPath":"product/ocean-shipping-fee.vue"},{"routePath":"/product/ocean-shipping-monitor","componentPath":"product/ocean-shipping-monitor.vue"},{"routePath":"/product/package-chang-sku-monitor","componentPath":"product/package-chang-sku-monitor.vue"},{"routePath":"/product/pre_product_price_check","componentPath":"product/pre_product_price_check.vue"},{"routePath":"/product/product-cate-attr","componentPath":"product/product-cate-attr.vue"},{"routePath":"/product/product-category-manage","componentPath":"product/product-category-manage.vue"},{"routePath":"/product/product-float-price","componentPath":"product/product-float-price.vue"},{"routePath":"/product/product-history-stock","componentPath":"product/product-history-stock.vue"},{"routePath":"/product/product-manage","componentPath":"product/product-manage.vue"},{"routePath":"/product/product-parts","componentPath":"product/product-parts.vue"},{"routePath":"/product/product-search","componentPath":"product/product-search.vue"},{"routePath":"/product/product-wrapper","componentPath":"product/product-wrapper.vue"},{"routePath":"/product/product_price_check","componentPath":"product/product_price_check.vue"},{"routePath":"/product/product_price_check_history","componentPath":"product/product_price_check_history.vue"},{"routePath":"/product/product_price_check_new","componentPath":"product/product_price_check_new.vue"},{"routePath":"/product/product_price_check_result","componentPath":"product/product_price_check_result.vue"},{"routePath":"/product/specification-manage","componentPath":"product/specification-manage.vue"},{"routePath":"/product/stock-transfer","componentPath":"product/stock-transfer.vue"},{"routePath":"/purchase/create-shipping-plan","componentPath":"purchase/create-shipping-plan.vue"},{"routePath":"/purchase/depo-wrapper","componentPath":"purchase/depo-wrapper.vue"},{"routePath":"/purchase/logistics-providers-detail","componentPath":"purchase/logistics-providers-detail.vue"},{"routePath":"/purchase/logistics-providers-manage","componentPath":"purchase/logistics-providers-manage.vue"},{"routePath":"/purchase/purchase-contract-manage","componentPath":"purchase/purchase-contract-manage.vue"},{"routePath":"/purchase/purchase-cost-report","componentPath":"purchase/purchase-cost-report.vue"},{"routePath":"/purchase/purchase-de-po-manage","componentPath":"purchase/purchase-de-po-manage.vue"},{"routePath":"/purchase/purchase-give-date-report","componentPath":"purchase/purchase-give-date-report.vue"},{"routePath":"/purchase/purchase-package-manage","componentPath":"purchase/purchase-package-manage.vue"},{"routePath":"/purchase/purchase-package","componentPath":"purchase/purchase-package.vue"},{"routePath":"/purchase/purchase-pre-make-order","componentPath":"purchase/purchase-pre-make-order.vue"},{"routePath":"/purchase/purchase-product-plan","componentPath":"purchase/purchase-product-plan.vue"},{"routePath":"/purchase/purchase-product-qty-report","componentPath":"purchase/purchase-product-qty-report.vue"},{"routePath":"/purchase/purchase-product-quality-rate","componentPath":"purchase/purchase-product-quality-rate.vue"},{"routePath":"/purchase/purchase-reduce-cost-report","componentPath":"purchase/purchase-reduce-cost-report.vue"},{"routePath":"/purchase/purchase-ship-order-edit","componentPath":"purchase/purchase-ship-order-edit.vue"},{"routePath":"/purchase/purchase-ship-order","componentPath":"purchase/purchase-ship-order.vue"},{"routePath":"/purchase/replenishment-demand","componentPath":"purchase/replenishment-demand.vue"},{"routePath":"/purchase/replenishment-edit","componentPath":"purchase/replenishment-edit.vue"},{"routePath":"/purchase/shipping-plan-manage","componentPath":"purchase/shipping-plan-manage.vue"},{"routePath":"/purchase/vendor-detail","componentPath":"purchase/vendor-detail.vue"},{"routePath":"/purchase/vendor-manage","componentPath":"purchase/vendor-manage.vue"},{"routePath":"/purchase/vendor-product-detail","componentPath":"purchase/vendor-product-detail.vue"},{"routePath":"/purchase/vendor-product-manage","componentPath":"purchase/vendor-product-manage.vue"},{"routePath":"/purchase/vendor-wrapper","componentPath":"purchase/vendor-wrapper.vue"},{"routePath":"/reports/company-product-stock","componentPath":"reports/company-product-stock.vue"},{"routePath":"/reports/data-pivot-table","componentPath":"reports/data-pivot-table.vue"},{"routePath":"/reports/dept-product-factory-transit-stock-report","componentPath":"reports/dept-product-factory-transit-stock-report.vue"},{"routePath":"/reports/dept-sku-month-sales-report","componentPath":"reports/dept-sku-month-sales-report.vue"},{"routePath":"/reports/head-logistics-report","componentPath":"reports/head-logistics-report.vue"},{"routePath":"/reports/product-sale-state-change-report","componentPath":"reports/product-sale-state-change-report.vue"},{"routePath":"/reports/product-unsalable-report-leader","componentPath":"reports/product-unsalable-report-leader.vue"},{"routePath":"/reports/product-unsalable-report","componentPath":"reports/product-unsalable-report.vue"},{"routePath":"/reports/product-user-purchase-vendor-report","componentPath":"reports/product-user-purchase-vendor-report.vue"},{"routePath":"/reports/product-vendor-report","componentPath":"reports/product-vendor-report.vue"},{"routePath":"/reports/profit-detail","componentPath":"reports/profit-detail.vue"},{"routePath":"/reports/purchase-order-daily-report","componentPath":"reports/purchase-order-daily-report.vue"},{"routePath":"/reports/purchase-price-change-report","componentPath":"reports/purchase-price-change-report.vue"},{"routePath":"/reports/purchase-requirement-history-report","componentPath":"reports/purchase-requirement-history-report.vue"},{"routePath":"/reports/reissue-detail","componentPath":"reports/reissue-detail.vue"},{"routePath":"/reports/ship-order-daily-report","componentPath":"reports/ship-order-daily-report.vue"},{"routePath":"/schedule/schedule-list","componentPath":"schedule/schedule-list.vue"},{"routePath":"/schedule/schedule-manage","componentPath":"schedule/schedule-manage.vue"},{"routePath":"/schedule/weekly-manage","componentPath":"schedule/weekly-manage.vue"},{"routePath":"/settings/api-url-manage","componentPath":"settings/api-url-manage.vue"},{"routePath":"/settings/change-log","componentPath":"settings/change-log.vue"},{"routePath":"/settings/data-access-rule","componentPath":"settings/data-access-rule.vue"},{"routePath":"/settings/department-management","componentPath":"settings/department-management.vue"},{"routePath":"/settings/host-data-access-rule","componentPath":"settings/host-data-access-rule.vue"},{"routePath":"/settings/menu-access-manage","componentPath":"settings/menu-access-manage.vue"},{"routePath":"/settings/menu-manage","componentPath":"settings/menu-manage.vue"},{"routePath":"/settings/module-manage","componentPath":"settings/module-manage.vue"},{"routePath":"/settings/role-manage","componentPath":"settings/role-manage.vue"},{"routePath":"/settings/user-manage","componentPath":"settings/user-manage.vue"},{"routePath":"/settings/user-setting","componentPath":"settings/user-setting.vue"},{"routePath":"/shipment/final-shipping-de","componentPath":"shipment/final-shipping-de.vue"},{"routePath":"/shipment/final-shipping-uk","componentPath":"shipment/final-shipping-uk.vue"}];
      routes.map(function (route) {
        var component = __webpack_require__("9d9d")("./" + route.componentPath).default;

        var name = component.$name,
            meta = component.$meta;

        _this.router.addRoutes([{
          name: name,
          meta: meta,
          path: route.routePath,
          component: function component(resolve) {
            return Promise.resolve(/* AMD require */).then(function() { var __WEBPACK_AMD_REQUIRE_ARRAY__ = [__webpack_require__("9d9d")("./" + route.componentPath)]; (resolve).apply(null, __WEBPACK_AMD_REQUIRE_ARRAY__);}.bind(this)).catch(__webpack_require__.oe);
          }
        }]);
      });
    }
  };

  ApplicationRouter.guards = [];
  return ApplicationRouter;
}();



/***/ })

}]);