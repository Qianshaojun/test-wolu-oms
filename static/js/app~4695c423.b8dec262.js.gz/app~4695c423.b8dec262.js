(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~4695c423"],{

/***/ "1b27f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

      /* harmony default export */ __webpack_exports__["default"] = ({
        functional: true,
        render(_h, _vm) {
          const { _c, _v, data, children = [] } = _vm;

          const {
            class: classNames,
            staticClass,
            style,
            staticStyle,
            attrs = {},
            ...rest
          } = data;

          return _c(
            'svg',
            {
              class: ["icon",classNames,staticClass],
              style: [style,staticStyle],
              attrs: Object.assign({"viewBox":"0 0 1024 1024","xmlns":"http://www.w3.org/2000/svg","width":"200","height":"200"}, attrs),
              ...rest,
            },
            children.concat([_c('defs'),_c('path',{attrs:{"d":"M1024 512c0 114.02-37.282 219.344-100.31 304.442a515.074 515.074 0 01-79.412 85.096C754.856 977.9 638.83 1024 512 1024c-73.456 0-143.276-15.464-206.41-43.322a508.586 508.586 0 01-77.804-42.758 509.966 509.966 0 01-48.066-36.384 515.074 515.074 0 01-79.412-85.096C37.282 731.344 0 626.02 0 512s37.282-219.344 100.31-304.442A514.73 514.73 0 01247.202 73.706C324.462 26.916 415.076 0 512 0c.668 0 1.338 0 2.006.02 96.172.356 186.076 27.21 262.792 73.686A514.73 514.73 0 01923.69 207.558C986.718 292.654 1024 397.98 1024 512z","fill":"#EF487D"}}),_c('path',{attrs:{"d":"M953.23 441.23c0 98.258-32.128 189.026-86.444 262.36a444.018 444.018 0 01-68.434 73.336C721.29 842.732 621.302 882.46 512.004 882.46c-63.302 0-123.472-13.326-177.88-37.334a438.26 438.26 0 01-67.05-36.848 439.428 439.428 0 01-41.422-31.354 443.78 443.78 0 01-68.434-73.336c-54.316-73.334-86.444-164.102-86.444-262.36s32.126-189.026 86.442-262.36a443.614 443.614 0 01126.588-115.35C350.384 23.196 428.472 0 512 0c.576 0 1.154 0 1.728.018 82.88.306 160.356 23.448 226.468 63.5a443.56 443.56 0 01126.588 115.35C921.1 252.202 953.23 342.972 953.23 441.23z","fill":"#FF668C"}}),_c('path',{attrs:{"d":"M923.69 149.796V816.44a515.074 515.074 0 01-79.412 85.096C754.856 977.9 638.83 1024 512 1024c-73.456 0-143.276-15.464-206.41-43.322a508.586 508.586 0 01-77.804-42.758 509.966 509.966 0 01-48.066-36.384 515.074 515.074 0 01-79.412-85.096V149.796c0-42.026 34.064-76.09 76.09-76.09h671.2c42.028.002 76.092 34.064 76.092 76.09z","fill":"#343A6E"}}),_c('path',{attrs:{"d":"M844.278 293.032v608.506C754.856 977.9 638.83 1024 512 1024c-73.456 0-143.276-15.464-206.41-43.322a508.586 508.586 0 01-77.804-42.758 509.966 509.966 0 01-48.066-36.384V293.032c0-26.498 21.462-47.96 47.94-47.96h568.654c26.48-.002 47.964 21.46 47.964 47.96z","fill":"#F0F0F0"}}),_c('path',{attrs:{"d":"M715.748 94.168v134.624c0 25.162-20.376 45.536-45.536 45.536H353.776c-25.162 0-45.536-20.376-45.536-45.536V94.168c0-25.162 20.376-45.536 45.536-45.536h79.664C447.818 19.814 477.598.002 511.996.002c5.35 0 10.596.48 15.674 1.4 24.074 4.326 44.722 18.494 57.658 38.16.168.25.314.48.46.732a79.226 79.226 0 013.47 5.872c.48.878.92 1.714 1.296 2.466h79.664c25.156 0 45.53 20.376 45.53 45.536z","fill":"#F2AE5A"}}),_c('path',{attrs:{"d":"M715.748 94.168v134.624c0 25.162-20.376 45.536-45.536 45.536h-285.09c-25.162 0-45.536-20.376-45.536-45.536V94.168c0-25.162 20.376-45.536 45.536-45.536h48.316C447.816 19.814 477.596.002 511.994.002c5.35 0 10.596.48 15.674 1.4 24.074 4.326 44.722 18.494 57.658 38.16.168.25.314.48.46.732a139.152 139.152 0 013.47 5.872c.48.878.92 1.714 1.296 2.466h79.664c25.158 0 45.532 20.376 45.532 45.536z","fill":"#F9DF73"}}),_c('path',{attrs:{"d":"M481.698 71.618a30.302 30.302 0 1060.604 0 30.302 30.302 0 10-60.604 0z","fill":"#343A6E"}}),_c('path',{attrs:{"d":"M624.842 207.456H399.144c-12.118 0-21.942-9.824-21.942-21.942s9.824-21.942 21.942-21.942h225.698c12.118 0 21.942 9.824 21.942 21.942.002 12.118-9.822 21.942-21.942 21.942z","fill":"#F2AE5A"}}),_c('path',{attrs:{"d":"M380.342 529.282H248.684c-11.54 0-20.898-9.356-20.898-20.898V376.726c0-11.542 9.358-20.898 20.898-20.898h131.658c11.54 0 20.898 9.356 20.898 20.898v131.658c0 11.542-9.358 20.898-20.898 20.898zm-110.758-41.796h89.862v-89.862h-89.862v89.862z","fill":"#5897D1"}}),_c('path',{attrs:{"d":"M591.412 422.704H459.754c-11.54 0-20.898-9.356-20.898-20.898s9.358-20.898 20.898-20.898h131.658c11.54 0 20.898 9.356 20.898 20.898s-9.358 20.898-20.898 20.898zm163.004 81.502h-294.66c-11.54 0-20.898-9.356-20.898-20.898s9.358-20.898 20.898-20.898h294.662c11.54 0 20.898 9.356 20.898 20.898s-9.36 20.898-20.9 20.898z","fill":"#484B7F"}}),_c('path',{attrs:{"d":"M380.342 754.98H248.684c-11.54 0-20.898-9.356-20.898-20.898V602.424c0-11.542 9.358-20.898 20.898-20.898h131.658c11.54 0 20.898 9.356 20.898 20.898v131.658c0 11.542-9.358 20.898-20.898 20.898zm-110.758-41.796h89.862v-89.862h-89.862v89.862z","fill":"#5897D1"}}),_c('path',{attrs:{"d":"M591.412 648.4H459.754c-11.54 0-20.898-9.356-20.898-20.898s9.358-20.898 20.898-20.898h131.658c11.54 0 20.898 9.356 20.898 20.898s-9.358 20.898-20.898 20.898zm163.004 81.502h-294.66c-11.54 0-20.898-9.356-20.898-20.898s9.358-20.898 20.898-20.898h294.662c11.54 0 20.898 9.356 20.898 20.898-.002 11.542-9.36 20.898-20.9 20.898z","fill":"#484B7F"}}),_c('path',{attrs:{"d":"M380.342 807.226H248.684c-11.536 0-20.898 9.362-20.898 20.898v109.798a508.928 508.928 0 0077.804 42.758h74.752c11.536 0 20.898-9.362 20.898-20.898V828.124c0-11.536-9.362-20.898-20.898-20.898zm-20.898 131.656h-89.862V849.02h89.862v89.862z","fill":"#5897D1"}}),_c('path',{attrs:{"d":"M591.412 874.098H459.754c-11.54 0-20.898-9.356-20.898-20.898s9.358-20.898 20.898-20.898h131.658c11.54 0 20.898 9.356 20.898 20.898s-9.358 20.898-20.898 20.898zM754.416 955.6h-294.66c-11.54 0-20.898-9.356-20.898-20.898s9.358-20.898 20.898-20.898h294.662c11.54 0 20.898 9.356 20.898 20.898-.002 11.542-9.36 20.898-20.9 20.898z","fill":"#484B7F"}}),_c('path',{attrs:{"d":"M313.466 736.17a20.89 20.89 0 01-17.382-9.306l-66.874-100.31c-6.402-9.602-3.808-22.578 5.796-28.98 9.604-6.402 22.578-3.808 28.98 5.798l46.4 69.598 59.432-125.468c4.938-10.43 17.4-14.882 27.832-9.94 10.43 4.94 14.88 17.402 9.94 27.832l-75.232 158.822a20.904 20.904 0 01-18.892 11.954z","fill":"#EF487D"}})])
          )
        }
      });
    

/***/ }),

/***/ "1fb6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c0e9");
/* harmony import */ var html2canvas__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(html2canvas__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("e511");
/* harmony import */ var jspdf__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jspdf__WEBPACK_IMPORTED_MODULE_1__);


/**
 * @param  ele          要生成 pdf 的DOM元素（容器）
 * @param  padfName     PDF文件生成后的文件名字
 * */

function downloadPDF(ele, pdfName, size) {
  var eleW = ele.offsetWidth; // 获得该容器的宽

  var eleH = ele.offsetHeight; // 获得该容器的高

  var eleOffsetTop = ele.offsetTop; // 获得该容器到文档顶部的距离

  var eleOffsetLeft = ele.offsetLeft; // 获得该容器到文档最左的距离

  var canvas = document.createElement('canvas');
  var abs = 0;
  var win_in = document.documentElement.clientWidth || document.body.clientWidth; // 获得当前可视窗口的宽度（不包含滚动条）

  var win_out = window.innerWidth; // 获得当前窗口的宽度（包含滚动条）

  if (win_out > win_in) {
    // abs = (win_o - win_i)/2;    // 获得滚动条长度的一半
    abs = (win_out - win_in) / 2; // 获得滚动条宽度的一半
    // console.log(a, '新abs');
  }

  canvas.width = eleW * 2; // 将画布宽&&高放大两倍

  canvas.height = eleH * 2;
  var context = canvas.getContext('2d');
  context.scale(2, 2);
  context.translate(-eleOffsetLeft - abs, -eleOffsetTop); // 这里默认横向没有滚动条的情况，因为offset.left(),有无滚动条的时候存在差值，因此
  // translate的时候，要把这个差值去掉
  // html2canvas(element).then( (canvas)=>{ //报错
  // html2canvas(element[0]).then( (canvas)=>{

  html2canvas__WEBPACK_IMPORTED_MODULE_0___default()(ele, {
    dpi: 300,
    // allowTaint: true,  //允许 canvas 污染， allowTaint参数要去掉，否则是无法通过toDataURL导出canvas数据的
    useCORS: true //允许canvas画布内 可以跨域请求外部链接图片, 允许跨域请求。

  }).then(function (canvas) {
    var contentWidth = canvas.width;
    var contentHeight = canvas.height; //一页pdf显示html页面生成的canvas高度;

    var pageHeight = contentWidth / 592.28 * 841.89; //未生成pdf的html页面高度

    var leftHeight = contentHeight; //页面偏移

    var position = 0; //a4纸的尺寸[595.28,841.89]，html页面生成的canvas在pdf中图片的宽高
    //基数2.835

    var imgWidth = 595.28;
    var imgHeight = 595.28 / contentWidth * contentHeight;

    if (size === '70*30') {
      imgWidth = 198.45; //var imgHeight = (198.45 / contentWidth) * contentHeight

      imgHeight = 85.05;
    } else if (size === '80*40') {
      imgWidth = 226.8;
      imgHeight = 113.4;
    } else {
      imgWidth = 595.28;
      imgHeight = 595.28 / contentWidth * contentHeight;
    }

    var pageData = canvas.toDataURL('image/jpeg', 1.0);
    var pdf = new jspdf__WEBPACK_IMPORTED_MODULE_1___default.a('', 'pt', 'a4'); //有两个高度需要区分，一个是html页面的实际高度，和生成pdf的页面高度(841.89)
    //当内容未超过pdf一页显示的范围，无需分页

    if (leftHeight < pageHeight) {
      //在pdf.addImage(pageData, 'JPEG', 左，上，宽度，高度)设置在pdf中显示；
      pdf.addImage(pageData, 'JPEG', 0, 0, imgWidth, imgHeight); // pdf.addImage(pageData, 'JPEG', 20, 40, imgWidth, imgHeight);
    } else {
      // 分页
      while (leftHeight > 0) {
        pdf.addImage(pageData, 'JPEG', 0, position, imgWidth, imgHeight);
        leftHeight -= pageHeight;
        position -= 841.89; //避免添加空白页

        if (leftHeight > 0) {
          pdf.addPage();
        }
      }
    } //可动态生成


    pdf.save(pdfName);
  });
}

/* harmony default export */ __webpack_exports__["a"] = ({
  downloadPDF: downloadPDF
});

/***/ }),

/***/ "2195":
/***/ (function(module) {

module.exports = JSON.parse("{\"menu\":{\"home\":\"Home\",\"dashboard\":\"Dashboard\",\"dashboard-mobile\":\"Dashboard\",\"workspace\":\"Workspace\",\"orders\":\"Order\",\"order-manage\":\"Order Manage\",\"presale-orders-manage\":\"presale-orders-manage\",\"presale-manage\":\"presale-manage\",\"amazon-listing-stock\":\"Amazon Listing Stock\",\"amazon\":\"Platform\",\"report\":\"Report\",\"reports\":\"Reports\",\"product\":\"Product\",\"account-invoice\":\"Account Invoice\",\"user-order\":\"OrderDetail\",\"order-wrapper\":\"OrderDetail\",\"account\":\"Account Invoice\",\"account-page1\":\"Account Page1\",\"account-page2\":\"Account Page2\",\"demos\":\"Demos\",\"calender\":\"Calender\",\"chart\":\"Charts\",\"order\":\"Order\",\"map\":\"Map\",\"page-header\":\"PageHeader\",\"data-form\":\"DataForm\",\"data-table\":\"DataTable\",\"editor\":\"Editor\",\"http\":\"Http Request\",\"settings\":\"Setting\",\"user-setting\":\"User Setting\",\"change-log\":\"Change Log\",\"demo-mobile\":\"Demo\",\"customer\":\" Customer\",\"customer-manage\":\"Customer Manage\",\"chat-box\":\"Chat Box\",\"basic_manage\":\"Basic Manage\",\"BasicManage\":\"Basic Manage\",\"PreSale Management\":\"PreSale Management\",\"instance-manage\":\"Instance\",\"instance-edit\":\"Instance Edit\",\"seller-edit\":\"Seller Edit\",\"seller-manage\":\"Seller\",\"seller_instance\":\"Seller-Instance\",\"query-condition-manage\":\"QueryCondition Manage\",\"illegal-words\":\"illegal-words\",\"PurchasePredict\":\"Purchase\",\"purchase\":\"Purchase\",\"product-pre-sale\":\"Product Presale Settings\",\"product-purchase-predict\":\"Product Purchase Predict\",\"product-sale-trend\":\"Product Sales Trend\",\"product-sku-sale\":\"SKU Daily Sales\",\"picking\":\"Picking\",\"picking-manage\":\"Picking Manage\",\"picking-detail\":\"PickDetail\",\"picking-wrapper\":\"PickDetail\",\"modify-address\":\"Modify Address\",\"shipment-type\":\"Shipment Type\",\"user-manage\":\"User Manage\",\"role-manage\":\"Role Manage\",\"module-manage\":\"Module Manage\",\"menu-manage\":\"Menu Manage\",\"cs_email_return\":\"Email Return\",\"customer_service\":\"Customer Service\",\"problem-picture\":\"Problem Picture\",\"schedule\":\"Schedule\",\"schedule-management\":\"Schedule Management\",\"product-detail\":\"Product Detail\",\"vendor-detail-multi\":\"Vendor Detail\",\"shipment\":\"Shipment\",\"purchase-contract-edit\":\"Purchase Contract Edit\",\"purchase-package-edit\":\"Purchase Package Edit\",\"operation\":\"Operation\",\"wms_management\":\"wms_management\"},\"dict\":{\"all\":\"ALL\",\"yes\":\"Yes\",\"no\":\"No\",\"customer-status\":{\"pending\":\"Pending\",\"reject\":\"Reject\",\"accept\":\"Accept\",\"suspend\":\"Suspend\"},\"seller-instance-status\":{\"draft\":\"Draft\",\"active\":\"Active\",\"cancel\":\"Cancel\",\"suspend\":\"Suspend\",\"inactive\":\"iIactive\"},\"seller-platform\":{\"b2c\":\"B2C\",\"cd\":\"Cdiscount\",\"amz\":\"AMZ\",\"eBay\":\"eBay\",\"wish\":\"Wish\",\"aliexpress\":\"Aliexpress\",\"wayfair\":\"Wayfair\"},\"warehouse_id\":{\"de\":\"DE Warehouse\",\"uk\":\"UK Warehouse\",\"us\":\"US Warehouse\"},\"presale_type\":{\"type_category\":\"Category\",\"type_sku\":\"SKU\"},\"is_presale\":{\"type_true\":\"√\",\"type_false\":\"\"},\"purchase_status\":{\"not\":\"Not Purchase\",\"need\":\"Need Purchase\",\"purchased\":\"Purchased\",\"cancel\":\"Cancelled\"},\"predict_status\":{\"new\":\"New\",\"active\":\"Active\",\"confirmed\":\"Confirmed\",\"completed\":\"Completed\",\"returned\":\"Returned\",\"refused\":\"Refused\"},\"search_type\":{\"normal\":\"Filter\",\"favourite\":\"Favourite\"},\"state\":{\"draft\":\"Quotation\",\"sale\":\"Sale\",\"done\":\"Done\",\"cancel\":\"Cancel\"},\"package_size\":{\"small\":\"Small\",\"medium\":\"Medium\",\"large\":\"Large\"},\"warehouse_list\":{\"de\":\"DE Warehouse\",\"uk\":\"UK GoodCang\",\"uk_own\":\"UK Own Warehouse\",\"fr\":\"FR Warehouse\",\"zqlc\":\"ZQLC Warehouse\"},\"order_type\":{\"a\":\"Normal\",\"r\":\"Resend\",\"g\":\"Marketing\",\"service\":\"Service\"},\"shipping_policy\":{\"direct\":\"Deliver each product when available\",\"one\":\"Deliver all products at once\"},\"invoice_policy\":{\"order\":\"Ordered quantities\",\"delivery\":\"Delivered quantities\"},\"illegal_words\":{\"active\":\"Active\",\"cancel\":\"Cancel\"},\"picking_state\":{\"draft\":\"Draft\",\"waiting\":\"Waiting\",\"confirmed\":\"Waiting Availability\",\"partially_available\":\"Partially Available\",\"assigned\":\"Available\",\"done\":\"Done\",\"cancel\":\"Cancel\"},\"picking_validate_status\":{\"no_validate\":\"No Validate\",\"error\":\"Validate Error\",\"ok\":\"Validate Ok\"},\"invoice_send_status\":{\"waiting\":\"Waiting\",\"done\":\"Done\",\"query\":\"Query\",\"create_invoice\":\"Create Invoice\",\"partner_email\":\"Partner Email\",\"no_order\":\"No Order\",\"no_template\":\"No Template\",\"other\":\"Other\"},\"email_group_status\":{\"active\":\"Active\",\"stop\":\"Stop\"},\"product_type\":{\"consu\":\"Consumable\",\"product\":\"Stockable Product\",\"service\":\"Service\"},\"ocean_ship_status\":{\"ship\":\"Ship\",\"process\":\"Process\",\"waiting\":\"Waiting\",\"wait\":\"Wait\",\"land\":\"Land\"},\"ship_status\":{\"draft\":\"Draft\",\"confirm\":\"Confirm\",\"approved\":\"Approved\",\"cancel\":\"Cancel\",\"ship\":\"Ship\",\"process\":\"Process Clearance\",\"waiting\":\"Waiting Arrange In\",\"wait\":\"Waiting In\",\"land\":\"Land\"},\"reissue_type\":{\"complete\":\"Complete\",\"part\":\"Part\"},\"replenishment_type\":{\"operational\":\"Operational\",\"development\":\"Development\",\"abnormal_purchase\":\"Abnormal Purchase\"},\"replenishment_state\":{\"draft\":\"RFQ\",\"to_approve\":\"To Approve\",\"approved\":\"Approved\",\"order\":\"Order Plan\",\"order2\":\"Order End\",\"approved_order\":\"Approved/Order Plan\",\"approved_order2\":\"Approved/Order End\",\"package\":\"Package\",\"ship\":\"Ship\",\"process\":\"Process Clearance\",\"waiting\":\"Waiting Arrange In\",\"wait\":\"Waiting In\",\"land\":\"Land\",\"done\":\"Done\",\"cancel\":\"Cancelled\",\"refuse\":\"Refuse\",\"confirmed\":\"Confirm\",\"done2\":\"Done2\"},\"package_order_state\":{\"ship\":\"Ship\",\"process\":\"Process Clearance\",\"waiting\":\"Waiting Arrange In\",\"wait\":\"Waiting In\",\"land\":\"Land\",\"confirm\":\"Confirm\",\"draft\":\"Draft\",\"cancel\":\"Cancel\",\"approved\":\"Approved\"},\"purchase_contract_state\":{\"done\":\"Done\",\"confirm\":\"Confirm\",\"draft\":\"Draft\",\"cancel\":\"Cancel\",\"approved\":\"Approved\",\"refuse\":\"Refuse\"},\"final_ship_site\":{\"de\":\"DE\",\"fr\":\"FR\",\"es\":\"ES\",\"it\":\"IT\",\"nl\":\"NL\",\"se\":\"SE\",\"pl\":\"PL\",\"at\":\"AT\",\"be\":\"BE\",\"lu\":\"LU\"},\"sku_replenish_state\":{\"no\":\"Cannot replenishment\",\"merge\":\"Merge replenishment\",\"single\":\"Single replenishment\"},\"sale_state\":{\"normal\":\"Normal\",\"weed_out\":\"Weed out\",\"infringement\":\"Infringement\",\"to_be_seen\":\"To be seen\"},\"logistics_provider_state\":{\"active\":\"Active\",\"inactive\":\"Inactive\"},\"logistics_provider_aging\":{\"air\":\"Air\",\"truck\":\"Truck\",\"rail\":\"Rail\",\"sea\":\"Sea\",\"delivery\":\"Delivery\"},\"unsalable_approve_state\":{\"approved\":\"Approved\",\"wait_approve\":\"Wait Approve\"},\"pre_prod_price_approve_state\":{\"pre_approve\":\"Pre Approve\",\"passed\":\"Passed\",\"not_passed\":\"Not Passed\",\"time_out\":\"Time Out\"},\"prod_status\":{\"sale\":\"Sale\",\"stop\":\"Stop\",\"waiting\":\"Waiting\",\"sz_prod\":\"SZ Product\",\"uk_sale\":\"UK Sale\",\"tort_stop\":\"Tort Stop\"},\"shipping_plan_state\":{\"draft\":\"Draft\",\"confirm\":\"Confirm\",\"assigned\":\"Assigned\"},\"price_check_prod_status\":{\"sale\":\"Sale\",\"stop\":\"Stop\",\"waiting\":\"Waiting\",\"tort_stop\":\"Tort Stop\"},\"check_prod_status\":{\"sale\":\"Sale\",\"stop\":\"Stop\",\"waiting\":\"Waiting\",\"tort_stop\":\"Tort Stop\",\"no_stop\":\"No Stop\",\"not_onshelf\":\"Not Onshelf\"},\"sent_email_state\":{\"outgoing\":\"待发送\",\"sent\":\"已发送\",\"received\":\"已接收\",\"exception\":\"异常\",\"cancel\":\"取消\"},\"purchase_price_change_report_status\":{\"pre_handled\":\"Pre Handled\",\"handled\":\"Handled\",\"price_adjusted\":\"Price Adjusted\",\"no_handled\":\"No Handled\"},\"de_po_state\":{\"draft\":\"Draft\",\"confirmed\":\"Confirmed\",\"cancel\":\"Cancel\"}},\"columns\":{\"instance_code\":\"Instance Code\",\"instance_name\":\"Instance Name\",\"instance_full_name\":\"Full Name\",\"who_responsible\":\"Responsible User\",\"write_uid\":\"Write User\",\"write_date\":\"Write Date\",\"seller_code\":\"Seller Code\",\"seller_name\":\"Seller Name\",\"seller_full_name\":\"Full Name\",\"create_date\":\"Create Date\",\"platform\":\"Platform\",\"status\":\"Status\",\"seller_info\":\"Seller Info\",\"instance_info\":\"Instance Info\",\"instances_list\":\"Instances List\",\"detail\":\"Detail\",\"create_time\":\"Create Time\",\"write_time\":\"Write Time\",\"operator\":\"Operator\",\"department\":\"Department\",\"z_category\":\"Z Category\",\"z_sub_category\":\"Z Sub Category\",\"actions\":\"Actions\",\"edit\":\"Edit\",\"export_excel\":\"Export Excel\",\"operate_log\":\"Log\",\"log\":\"Log\",\"type\":\"Type\",\"operate_user\":\"Operate User\",\"date\":\"Date\"},\"action\":{\"create\":\"Create\",\"action\":\"Action\",\"submit\":\"Submit\",\"cancel\":\"Cancel\",\"discard\":\"Discard\",\"downLoadTemplate\":\"Download Template\"},\"tips\":{\"save_success\":\"Save Success\",\"update_success\":\"Update Success\",\"delete_success\":\"Delete Success\"},\"split_query_condition\":\"multi query use comma\",\"fuzzy_search\":\"Fuzzy Search\",\"plzInput\":\"Please Input\",\"plzSelect\":\"Please Select\"}");

/***/ }),

/***/ "242e":
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/img/company_logo.a88e372e.png";

/***/ }),

/***/ "3669":
/***/ (function(module) {

module.exports = JSON.parse("{\"fieldsList\":{\"flatHierarchyBox\":\"选择和重排列\",\"hierarchyBox\":\"拖拽大小\",\"filterBox\":\"删除并重排报表筛选\",\"rowBox\":\"删除并重排行\",\"columnBox\":\"删除并重排列\",\"measureBox\":\"删除并重排值\",\"values\":\"值\",\"addCalculatedMeasure\":\"增加计算值\",\"expandAll\":\"展开所有\",\"collapseAll\":\"折叠所有\",\"formulasGroupName\":\"计算后的值\",\"allFields\":\"所有字段\",\"rows\":\"行\",\"columns\":\"列\",\"filters\":\"报表筛选\",\"dropField\":\"从这里移除字段\",\"title\":\"字段\",\"subtitle\":\"拖拽和移除字段来重排\"},\"filter\":{\"all\":\"所有\",\"multipleItems\":\"多项\",\"selectAll\":\"选择所有\",\"selectAllResults\":\"选择所有结果\",\"top\":\"顶部\",\"bottom\":\"底部\",\"ascSort\":\"A-Z升序\",\"descSort\":\"Z-A降序\",\"topX\":\"前10\",\"clearTopX\":\"清除\",\"measuresPrompt\":\"选择值\",\"search\":\"搜索\",\"amountSelected\":\"{1}中已选择{0}项\",\"amountFound\":\"{1}中发现{0}项已选择\",\"sort\":\"排序:\",\"addGroup\":\"增加组\",\"groupName\":\"组1\",\"ungroup\":\"取消组\"},\"drillThrough\":{\"title\":\"详情\",\"row\":\"行: <b>{0}</b>\",\"column\":\"列: <b>{0}</b>\",\"value\":\"{0}: <b>{1}</b>\"},\"calculatedView\":{\"title\":\"已计算值\",\"measureBox\":\"拖拽值到公式\",\"measureName\":\"值名称\",\"formula\":\"公式\",\"formulaPrompt\":\"拖拽值并在此编辑公式\",\"calculateIndividualValues\":\"计算自定义值\",\"removeValue\":\"移除\",\"removeValueTitle\":\"移除 {0}?\",\"removeValueMessage\":\"您确定要移除该已计算值吗?\",\"header\":\"增加已计算值\",\"allValues\":\"所有值\"},\"grid\":{\"total\":\"小计\",\"totals\":\"合计\",\"grandTotal\":\"总计\",\"blankMember\":\"(空)\",\"dateInvalidCaption\":\"无效日期\",\"reportInformation\":\"报表信息\"},\"tooltips\":{\"row\":\"行:\",\"column\":\"列:\",\"headerResize\":\"拖拽调整\",\"headerFit\":\"双击适应\",\"filterIcon\":\"单击筛选\",\"filtered\":\"已筛选\",\"expandIcon\":\"单击展开\",\"collapseIcon\":\"单击折叠\",\"drillDown\":\"单击向下钻取\",\"drillUp\":\"单击向上钻取\",\"sortIcon\":\"单击降序\",\"sortedDescIcon\":\"单击升序\",\"sortedAscIcon\":\"单击降序\",\"close\":\"单击关闭\"},\"aggregations\":{\"sum\":{\"caption\":\"求和\",\"totalCaption\":\"{0}求和\",\"grandTotalCaption\":\"{0}求和总计\"},\"count\":{\"caption\":\"计数\",\"totalCaption\":\"{0}计数\",\"grandTotalCaption\":\"{0}计数总计\"},\"distinctCount\":{\"caption\":\"计数(去重)\",\"totalCaption\":\"{0}计数(去重)\",\"grandTotalCaption\":\"{0}计数(去重)总计\"},\"difference\":{\"caption\":\"差值\",\"totalCaption\":\"{0}差值\",\"grandTotalCaption\":\"{0}差值总计\"},\"percentDifference\":{\"caption\":\"%差值\",\"totalCaption\":\"{0}%差值\",\"grandTotalCaption\":\"{0}%差值总计\"},\"average\":{\"caption\":\"平均值\",\"totalCaption\":\"{0}平均值\",\"grandTotalCaption\":\"{0}平均值总计\"},\"product\":{\"caption\":\"乘积\",\"totalCaption\":\"{0}乘积\",\"grandTotalCaption\":\"{0}乘积总计\"},\"min\":{\"caption\":\"最小值\",\"totalCaption\":\"{0}最小值\",\"grandTotalCaption\":\"{0}最小值总计\"},\"max\":{\"caption\":\"最大值\",\"totalCaption\":\"{0}最大值\",\"grandTotalCaption\":\"{0}最大值总计\"},\"percent\":{\"caption\":\"总计(%)\",\"totalCaption\":\"{0}总计(%)\",\"grandTotalCaption\":\"{0}总计(%)和\"},\"percentOfColumn\":{\"caption\":\"列(%)\",\"totalCaption\":\"{0}列(%)\",\"grandTotalCaption\":\"{0}列(%)总计\"},\"percentOfRow\":{\"caption\":\"行(%)\",\"totalCaption\":\"{0}行(%)\",\"grandTotalCaption\":\"{0}行(%)总计\"},\"index\":{\"caption\":\"指数\",\"totalCaption\":\"{0}指数\",\"grandTotalCaption\":\"{0}指数总计\"},\"none\":{\"caption\":\"不计算\"}},\"messages\":{\"error\":\"错误!\",\"warning\":\"警告!\",\"limitation\":\"有限制!\",\"browse\":\"浏览\",\"confirmation\":\"确认\",\"reportFileType\":\"Flexmonster报表文件\",\"loading\":\"正在加载...\",\"loadingConfiguration\":\"\",\"loadingData\":\"正在加载数据...\",\"waiting\":\"响应中请等待{0}秒.\",\"progress\":\"{0}K\",\"progressUnknown\":\"已加载{0}K\",\"analyzing\":\"分析数据中...\",\"analyzingProgress\":\"{0} records of {1} ({2}%)\",\"analyzingRecords\":\"{0}% 记录\",\"saving\":\"保存中...\",\"loadingDimensions\":\"维度加载中...\",\"loadingHierarchies\":\"层级加载中...\",\"loadingMeasures\":\"度量加载中...\",\"loadingKPIs\":\"KPI加载中...\",\"loadingMembers\":\"成员加载中...\",\"loadingLevels\":\"等级加载中...\",\"loadingProperties\":\"属性加载中...\",\"fullscreen\":\"在全屏模式下打开报表?\",\"exportComplete\":\"导出数据已创建,请单击\\\"保存\\\"按钮保存数据.\",\"exportProgress\":\"导出正在处理中...\",\"exportError\":\"导出失败,发生意外错误.\",\"generatingPDF\":\"正在生成PDF\",\"pleaseWait\":\"请稍等.\",\"pagesWereGenerated\":\"页面已生成.\",\"uploading\":\"上传中...\",\"cantSaveFile\":\"不能保存文件.\",\"cantSaveToClipboard\":\"错误:无法写入剪切板.\",\"saveReportToFile\":\"报告已准备保存到文件,请单击\\\"保存\\\"按钮保存报表.\",\"loadReportFromFile\":\"选择报表文件加载.\",\"inputNewName\":\"输入新名称\",\"inputReportName\":\"输入新报表名称\",\"invalidDataSource\":\"无效的数据源或目录.请检查. <br/><br/><u><a href='https://www.flexmonster.com/doc/typical-errors/#invalid-datasource' target='_blank'>阅读关于这个错误的更多信息</a></u>\",\"dataStreamError\":\"加载'{0}'时发生数据流错误.<br/><br/><u><a href='https://www.flexmonster.com/doc/typical-errors/#stream-error' target='_blank'>阅读关于这个错误的更多信息</a></u>\",\"unableToOpenFile\":\"不能打开文件:{0}.<br/><br/>似乎这个文件不存在或资源中缺少'Access-Control-Allow-Origin'请求头.<br/><br/><u><a href='https://www.flexmonster.com/doc/typical-errors/#unable-to-open-file' target='_blank'>阅读关于这个错误的更多信息</a></u>\",\"unableTwoFileBrowsingSessions\":\"浏览文件的面板已打开.\",\"inappropriateFileFormat\":\"数据文件格式不匹配.\",\"invalidJSONdata\":\"JSON数据无效.\",\"wrongFormulaFormat\":\"错误的公式格式,请检查.\",\"excelCsvChartsExportError\":\"图表无法导出到Microsoft Excel或CSV.\",\"excelPdfExportLimitation\":\"当前版本无法导出到Microsoft Excel或PDF.\",\"excelExportLimitation\":\"当前版本无法导出.\",\"noDataAvailable\":\"数据源为空,请检查CSV文件.\",\"saveDataToFile\":\"数据已准备保存到文件,请单击\\\"保存\\\"按钮保存文件.\",\"dataWasUpdated\":\"数据源已在服务器上更新。要刷新报表吗?\",\"ocsvIncompatible\":\"不能读取数据源.似乎OCSV文件使用新版本压缩过,请更正{0}或更新的版本的组件.\",\"unknownError\":\"发生未知错误.\",\"invalidReportFormat\":\"无效的报表格式或文件拒绝访问.\",\"csvHeaderParsingError\":\"CSV页眉解析错误.\",\"tooManyColumnsInClassicMode\":\"经典方式下列太多.请把视图切换到简洁方式.\",\"cantExpand\":\"有些字段无法展开.请缩小数据范围.\",\"cantExpandTitle\":\"数据集太大.\"},\"buttons\":{\"ok\":\"好\",\"apply\":\"应用\",\"cancel\":\"取消\",\"save\":\"保存\",\"clear\":\"清除\",\"select\":\"选择\",\"yes\":\"是\",\"no\":\"否\"},\"contextMenu\":{\"clearSorting\":\"清除排序\",\"collapse\":\"折叠\",\"drillThrough\":\"钻取\",\"expand\":\"展开\",\"openFilter\":\"打开筛选\",\"sortColumnAsc\":\"列升序\",\"sortColumnDesc\":\"列降序\",\"sortRowAsc\":\"行升序\",\"sortRowDesc\":\"行降序\"},\"date\":{\"year\":\"年\",\"quarter\":\"季\",\"month\":\"月\",\"day\":\"天\"},\"quarters\":{\"q1\":\"一季度\",\"q2\":\"二季度\",\"q3\":\"三季度\",\"q4\":\"四季度\"},\"months\":{\"january\":\"一月\",\"february\":\"二月\",\"march\":\"三月\",\"april\":\"四月\",\"may\":\"五月\",\"june\":\"六月\",\"july\":\"七月\",\"august\":\"八月\",\"september\":\"九月\",\"october\":\"十月\",\"november\":\"十一月\",\"december\":\"十二月\"},\"monthsShort\":{\"january\":\"Jan\",\"february\":\"Feb\",\"march\":\"Mar\",\"april\":\"Apr\",\"may\":\"May\",\"june\":\"Jun\",\"july\":\"Jul\",\"august\":\"Aug\",\"september\":\"Sep\",\"october\":\"Oct\",\"november\":\"Nov\",\"december\":\"Dec\"},\"weekdays\":{\"first\":\"周日\",\"second\":\"周一\",\"third\":\"周二\",\"fourth\":\"周三\",\"fifth\":\"周四\",\"sixth\":\"周五\",\"seventh\":\"周六\"},\"weekdaysShort\":{\"first\":\"Sun\",\"second\":\"Mon\",\"third\":\"Tue\",\"fourth\":\"Wed\",\"fifth\":\"Thu\",\"sixth\":\"Fri\",\"seventh\":\"Sat\"},\"toolbar\":{\"connect\":\"连接\",\"connect_local_csv\":\"连接本地CSV文件\",\"connect_local_ocsv\":\"连接本地OCSV文件\",\"connect_local_json\":\"连接本地JSON文件\",\"connect_remote_csv\":\"连接远程CSV文件\",\"connect_remote_csv_mobile\":\"CSV\",\"connect_remote_json\":\"连接远程JSON文件\",\"connect_remote_json_mobile\":\"JSON\",\"open\":\"打开\",\"local_report\":\"本地报表\",\"remote_report\":\"远程报表\",\"remote_report_mobile\":\"报表\",\"save\":\"保存\",\"save_json\":null,\"load_json\":\"JSON报表\",\"grid\":\"网格\",\"grid_flat\":\"扁平\",\"grid_classic\":\"经典\",\"grid_compact\":\"简洁\",\"format\":\"格式化\",\"format_cells\":\"格式化单元格\",\"format_cells_mobile\":\"格式化\",\"conditional_formatting\":\"条件格式化\",\"conditional_formatting_mobile\":\"条件\",\"options\":\"选项\",\"fullscreen\":\"全屏显示\",\"minimize\":\"最小化\",\"export\":\"导出\",\"export_print\":\"打印\",\"export_html\":\"按HTML导出\",\"export_excel\":\"按Excel导出\",\"export_pdf\":\"按PDF导出\",\"fields\":\"字段\",\"ok\":\"好\",\"apply\":\"应用\",\"done\":\"完成\",\"cancel\":\"取消\",\"value\":\"值\",\"delete\":\"删除\",\"if\":\"如果\",\"then\":\"那么\",\"open_remote_csv\":\"打开远程CSV文件\",\"open_remote_json\":\"打开远程JSON文件\",\"csv\":\"CSV\",\"open_remote_report\":\"打开远程报表\",\"choose_value\":\"选择值\",\"text_align\":\"文字居中\",\"align_left\":\"居左\",\"align_right\":\"居右\",\"none\":\"不设置\",\"space\":\"(空格)\",\"thousand_separator\":\"千位分隔符\",\"decimal_separator\":\"小数分隔符\",\"decimal_places\":\"小数位数\",\"currency_symbol\":\"货币符号\",\"currency_align\":\"货币对齐\",\"null_value\":\"空值\",\"is_percent\":\"百分比格式\",\"true_value\":\"是\",\"false_value\":\"否\",\"conditional\":\"条件\",\"add_condition\":\"增加条件\",\"less_than\":\"小于\",\"less_than_or_equal\":\"小于等于\",\"greater_than\":\"大于\",\"greater_than_or_equal\":\"大于等于\",\"equal_to\":\"等于\",\"not_equal_to\":\"不等于\",\"between\":\"介于两者之间\",\"is_empty\":\"空值\",\"all_values\":\"所有值\",\"and\":\"和\",\"and_symbole\":\"&\",\"cp_text\":\"文本\",\"cp_highlight\":\"高亮\",\"layout_options\":\"布局项\",\"layout\":\"布局\",\"compact_view\":\"简洁方式\",\"classic_view\":\"经典方式\",\"flat_view\":\"扁平方式\",\"grand_totals\":\"总计\",\"grand_totals_off\":\"不显示总计\",\"grand_totals_on\":\"显示总计\",\"grand_totals_on_rows\":\"仅在行显示总计\",\"grand_totals_on_columns\":\"仅在列显示总计\",\"subtotals\":\"小计\",\"subtotals_off\":\"不显示小计\",\"subtotals_on\":\"显示小计\",\"subtotals_on_rows\":\"仅在行显示小计\",\"subtotals_on_columns\":\"仅在列显示小计\",\"choose_page_orientation\":\"选择页面方向\",\"landscape\":\"横向\",\"portrait\":\"纵向\"}}");

/***/ }),

/***/ "5b1c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

      /* harmony default export */ __webpack_exports__["default"] = ({
        functional: true,
        render(_h, _vm) {
          const { _c, _v, data, children = [] } = _vm;

          const {
            class: classNames,
            staticClass,
            style,
            staticStyle,
            attrs = {},
            ...rest
          } = data;

          return _c(
            'svg',
            {
              class: [classNames,staticClass],
              style: [style,staticStyle],
              attrs: Object.assign({"xmlns":"http://www.w3.org/2000/svg","viewBox":"0 0 661.56 661.56"}, attrs),
              ...rest,
            },
            children.concat([_c('defs',[_c('linearGradient',{attrs:{"id":"linear-gradient","x1":"596.65","y1":"19.66","x2":"15.1","y2":"700.2","gradientUnits":"userSpaceOnUse"}},[_c('stop',{attrs:{"offset":"0","stop-color":"#ff82fd"}}),_c('stop',{attrs:{"offset":"1","stop-color":"#4a0e88"}})]),_c('linearGradient',{attrs:{"id":"linear-gradient-2","x1":"126.41","y1":"538.24","x2":"636.91","y2":"20.04","gradientUnits":"userSpaceOnUse"}},[_c('stop',{attrs:{"offset":"0","stop-color":"#fff"}}),_c('stop',{attrs:{"offset":".37","stop-color":"#fdfdfd"}}),_c('stop',{attrs:{"offset":".51","stop-color":"#f6f6f6"}}),_c('stop',{attrs:{"offset":".6","stop-color":"#ebebeb"}}),_c('stop',{attrs:{"offset":".68","stop-color":"#dadada"}}),_c('stop',{attrs:{"offset":".75","stop-color":"#c4c4c4"}}),_c('stop',{attrs:{"offset":".8","stop-color":"#a8a8a8"}}),_c('stop',{attrs:{"offset":".86","stop-color":"#888"}}),_c('stop',{attrs:{"offset":".91","stop-color":"#626262"}}),_c('stop',{attrs:{"offset":".95","stop-color":"#373737"}}),_c('stop',{attrs:{"offset":".99","stop-color":"#090909"}}),_c('stop',{attrs:{"offset":"1"}})])]),_c('g',{staticStyle:{"isolation":"isolate"}},[_c('g',{attrs:{"id":"Layer_2","data-name":"Layer 2"}},[_c('g',{attrs:{"id":"Layer_2-2","data-name":"Layer 2"}},[_c('path',{attrs:{"d":"M661.56 330.75c0 5.63-.13 11.27-.46 16.84a319.47 319.47 0 01-9.64 64.19 330.81 330.81 0 01-320.65 249.78c-135.77 0-252.4-81.82-303.34-198.78a331.13 331.13 0 013-270.69 330.81 330.81 0 01468.75-146c97.17 57.56 162.34 163.5 162.34 284.66z","fill":"url(#linear-gradient)"}}),_c('path',{staticClass:"cls-3",attrs:{"d":"M661.56 330.75a331.08 331.08 0 01-69.5 202.83C625 354.73 495.34 89 207.43 23.86a330.7 330.7 0 01291.74 22.23c97.22 57.56 162.39 163.5 162.39 284.66z"}}),_c('path',{staticClass:"cls-3",attrs:{"d":"M661.56 330.75c0 5.63-.13 11.27-.46 16.84-161.21-117.87-348.8-242.38-630.68-155.5a330.81 330.81 0 01468.75-146c97.22 57.56 162.39 163.5 162.39 284.66z"}}),_c('path',{staticStyle:{"mix-blend-mode":"multiply"},attrs:{"d":"M522.32 267.69a52.58 52.58 0 00-46.52-47.39 1179.75 1179.75 0 00-254.08 0 52.45 52.45 0 00-46.5 47.08c-2.7 28.68-4.14 58.48-4.14 89 0 28.49 1.3 56.27 3.67 83.16h-.07c.14 1.53.31 3 .45 4.55 0 .37.05.75.09 1.12 0 .13 0 .26.05.39a802.07 802.07 0 0020.59 121.6l39.64-60.82a23.42 23.42 0 0121.5-10.51c29.52 2.33 60.19 3.6 91.72 3.6a1149.64 1149.64 0 00127.05-6.86 52.59 52.59 0 0046.53-47.4c2.69-28.61 4.09-58.32 4.09-88.79s-1.39-60.14-4.07-88.73z","opacity":".2"}}),_c('path',{staticClass:"cls-5",attrs:{"d":"M504.36 242a52.56 52.56 0 00-46.52-47.39 1178 1178 0 00-254.08 0 52.42 52.42 0 00-46.49 47.08c-2.71 28.68-4.15 58.48-4.15 89 0 28.48 1.3 56.27 3.67 83.16h-.06c.13 1.53.3 3 .44 4.55l.09 1.12c0 .13 0 .25.06.39a800.94 800.94 0 0020.58 121.63l39.65-60.81a23.41 23.41 0 0121.51-10.52c29.52 2.33 60.19 3.61 91.73 3.61a1149.46 1149.46 0 00127-6.86 52.58 52.58 0 0046.53-47.4c2.69-28.62 4.09-58.32 4.09-88.79s-1.36-60.15-4.05-88.77z"}}),_c('path',{staticClass:"cls-5",attrs:{"d":"M183.75 508.57a817.68 817.68 0 01-13.38-89.85l-.51-6a933.713 933.713 0 01-3.63-82c0-29.52 1.38-59.06 4.09-87.81a39.48 39.48 0 0134.9-35.28 1164.78 1164.78 0 01251.17 0 39.66 39.66 0 0134.92 35.58c2.67 28.44 4 57.88 4 87.51s-1.36 59.06-4 87.56a39.67 39.67 0 01-34.93 35.59 1134.14 1134.14 0 01-125.59 6.79c-30.2 0-60.71-1.2-90.7-3.57-1-.07-1.94-.11-2.91-.11a36.41 36.41 0 00-30.62 16.54z"}}),_c('path',{staticStyle:{"mix-blend-mode":"multiply"},attrs:{"d":"M180.7 525.25a811.68 811.68 0 01-16.86-105.91l-.51-6c-2.43-27.41-3.65-55.2-3.65-82.58 0-29.72 1.38-59.47 4.11-88.43a46.08 46.08 0 0140.7-41.18 1173.07 1173.07 0 01252.62 0 46.25 46.25 0 0140.72 41.49c2.7 28.64 4.07 58.29 4.07 88.12s-1.37 59.47-4.07 88.18a46.25 46.25 0 01-40.72 41.49 1142.62 1142.62 0 01-126.32 6.82c-30.37 0-61.06-1.2-91.21-3.58-.8-.07-1.6-.1-2.4-.1a29.85 29.85 0 00-25.12 13.57z","fill":"url(#linear-gradient-2)"}}),_c('circle',{staticClass:"cls-7",attrs:{"cx":"257.24","cy":"330.77","r":"18.48"}}),_c('circle',{staticClass:"cls-7",attrs:{"cx":"330.79","cy":"330.77","r":"18.48"}}),_c('circle',{staticClass:"cls-7",attrs:{"cx":"404.33","cy":"330.77","r":"18.48"}}),_c('path',{staticStyle:{"mix-blend-mode":"multiply"},attrs:{"d":"M296.2 460.16c-18.75-.53-37.57-1.57-56.12-3-1-.06-1.9-.13-2.89-.13a36.39 36.39 0 00-30.61 16.59l-22.82 34.94a819.73 819.73 0 01-13.37-89.81l-.53-6c-.85-9.9-1.57-19.8-2.09-29.76 23.04 45.01 81.61 68.75 128.43 77.17z","fill":"#e6e6e6"}})])])])])
          )
        }
      });
    

/***/ }),

/***/ "6e0c":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "6f32":
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./logo.svg": "5b1c",
	"./test1.svg": "1b27f"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "6f32";

/***/ }),

/***/ "8da8":
/***/ (function(module, exports) {

module.exports = "<h2 id=\"待完成\">待完成</h2>\n<hr>\n<ul>\n<li><input disabled=\"\" type=\"checkbox\"> vue-web-service - 添加项目文档</li>\n<li><input disabled=\"\" type=\"checkbox\"> vue-web-service - 添加权限控制</li>\n<li><input disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 PageService 支持</li>\n<li><input disabled=\"\" type=\"checkbox\"> vue-web-service - 重构依赖注入功能</li>\n<li><input disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 PageHeader 锚定支持</li>\n<li><input disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 ModelService 模块</li>\n<li><input disabled=\"\" type=\"checkbox\"> vue-web-service - 添加系统常量配置</li>\n</ul>\n<h2 id=\"已完成\">已完成</h2>\n<hr>\n<ul>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-serivce - 添加日志服务</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加复制粘贴功能</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加google-map实例</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加导出 excel 功能</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加富文本编辑器 quill-editor</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加地图支持示例</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加工作台示例页面</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 v-chart 示例</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加登录模块</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加日历示例</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 Loading 服务</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加代码提交自动验证</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加列表详情示例页面</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加更新日志文档</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 data-form 组件</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 data-table 组件</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 Markdown 文档支持</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 vuepress 文档支持</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加布局模块支持</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加通信服务支持</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 mock 支持</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 svg-icon 组件</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加页面缓存功能</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 content 添加过渡动画</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加主题切换功能</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 pagecontainer 组件</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 pageheader 组件</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加 github action 部署功能</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 整理已有基础模块结构</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加页面名称支持</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加多语言模块</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加全屏支持</li>\n<li><input checked=\"\" disabled=\"\" type=\"checkbox\"> vue-web-service - 添加菜单模块</li>\n</ul>\n";

/***/ }),

/***/ "a060":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return i18nLocale; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return antdLocale; });
/* harmony import */ var ant_design_vue_lib_locale_provider_zh_CN__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("677e");
/* harmony import */ var ant_design_vue_lib_locale_provider_zh_CN__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ant_design_vue_lib_locale_provider_zh_CN__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var ant_design_vue_lib_locale_provider_en_US__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("766a");
/* harmony import */ var ant_design_vue_lib_locale_provider_en_US__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(ant_design_vue_lib_locale_provider_en_US__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _zh_cn_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("bf9c");
var _zh_cn_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t("bf9c", 1);
/* harmony import */ var _en_us_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("2195");
var _en_us_json__WEBPACK_IMPORTED_MODULE_3___namespace = /*#__PURE__*/__webpack_require__.t("2195", 1);
// andt语言包

 // 本地语言包



var i18nLocale = {
  'zh-cn': _zh_cn_json__WEBPACK_IMPORTED_MODULE_2__,
  'en-us': _en_us_json__WEBPACK_IMPORTED_MODULE_3__
};
var antdLocale = {
  'zh-cn': {
    antd: ant_design_vue_lib_locale_provider_zh_CN__WEBPACK_IMPORTED_MODULE_0___default.a,
    moment: 'zh-cn'
  },
  'en-us': {
    antd: ant_design_vue_lib_locale_provider_en_US__WEBPACK_IMPORTED_MODULE_1___default.a,
    moment: 'en'
  }
};

/***/ }),

/***/ "bf9c":
/***/ (function(module) {

module.exports = JSON.parse("{\"menu\":{\"home\":\"首页\",\"dashboard\":\"任务面板\",\"dashboard-mobile\":\"仪表盘\",\"workspace\":\"工作区\",\"orders\":\"订单\",\"order-manage\":\"订单管理\",\"presale-orders-manage\":\"预售订单管理\",\"amazon-listing-stock\":\"Amazon库存管理\",\"amazon\":\"平台\",\"report\":\"报表\",\"reports\":\"报表\",\"product\":\"产品\",\"account\":\"发票管理\",\"aliexpress\":\"速卖通\",\"wayfair\":\"Wayfair\",\"account-invoice\":\"客户发票\",\"presale-manage\":\"预售管理\",\"user-order\":\"订单详情\",\"order-wrapper\":\"订单详情\",\"accounts\":\"账户\",\"account-page1\":\"账户页面1\",\"account-page2\":\"账户页面2\",\"demos\":\"示例\",\"calender\":\"日历\",\"chart\":\"图表\",\"order\":\"订单\",\"map\":\"地图\",\"page-header\":\"页面头部\",\"data-form\":\"搜索表单\",\"data-table\":\"数据表格\",\"editor\":\"编辑器\",\"http\":\"网络请求\",\"settings\":\"设置\",\"user-setting\":\"用户设置\",\"change-log\":\"更新日志\",\"demo-mobile\":\"示例\",\"customer\":\"客户\",\"customer-manage\":\"客户管理\",\"chat-box\":\"聊天\",\"basic_manage\":\"基础管理\",\"BasicManage\":\"基础管理\",\"PreSale Management\":\"预售管理\",\"instance-manage\":\"店铺实例管理\",\"instance-edit\":\"店铺实例编辑\",\"seller-edit\":\"店铺编辑\",\"seller-manage\":\"店铺管理\",\"seller_instance\":\"店铺与实例\",\"query-condition-manage\":\"查询条件管理\",\"illegal-words\":\"违规词管理\",\"PurchasePredict\":\"采购\",\"purchase\":\"采购\",\"product-pre-sale\":\"解除预售管理\",\"product-purchase-predict\":\"产品采购预测\",\"product-sale-trend\":\"产品销售趋势\",\"product-sku-sale\":\"sku每日销量\",\"picking\":\"仓储\",\"picking-manage\":\"发货管理\",\"picking-detail\":\"发货详情\",\"picking-wrapper\":\"发货详情\",\"modify-address\":\"修改地址\",\"shipment-type\":\"物流编码关系维护\",\"user-manage\":\"用户管理\",\"role-manage\":\"角色管理\",\"module-manage\":\"模块管理\",\"menu-manage\":\"菜单管理\",\"cs_email_return\":\"邮件回复\",\"customer_service\":\"客服\",\"problem-picture\":\"问题图片\",\"schedule\":\"日程\",\"schedule-management\":\"日程管理\",\"product-detail\":\"产品详情\",\"vendor-detail-multi\":\"供应商详情\",\"shipment\":\"物流\",\"purchase-contract-edit\":\"采购合同编辑\",\"purchase-package-edit\":\"货柜信息编辑\",\"operation\":\"运营\",\"wms_management\":\"wms管理\"},\"dict\":{\"all\":\"全部\",\"yes\":\"是\",\"no\":\"否\",\"customer-status\":{\"pending\":\"待审核\",\"reject\":\"未通过\",\"accept\":\"已通过\",\"suspend\":\"已停用\"},\"seller-instance-status\":{\"draft\":\"草稿\",\"active\":\"活动\",\"cancel\":\"取消\",\"suspend\":\"已停用\",\"inactive\":\"已失效\"},\"seller-platform\":{\"b2c\":\"B2C\",\"cd\":\"Cdiscount\",\"amz\":\"AMZ\",\"eBay\":\"eBay\",\"wish\":\"Wish\",\"aliexpress\":\"Aliexpress\",\"wayfair\":\"Wayfair\"},\"warehouse_id\":{\"de\":\"DE仓\",\"uk\":\"UK仓\",\"us\":\"US仓\"},\"presale_type\":{\"type_category\":\"品类\",\"type_sku\":\"SKU\"},\"is_presale\":{\"type_true\":\"√\",\"type_false\":\"\"},\"purchase_status\":{\"not\":\"不补货\",\"need\":\"待补货\",\"purchased\":\"已补货\",\"cancel\":\"取消补货\"},\"predict_status\":{\"new\":\"草稿\",\"active\":\"活动\",\"confirmed\":\"确认\",\"completed\":\"完成\",\"returned\":\"退回\",\"refused\":\"拒绝\"},\"search_type\":{\"normal\":\"过滤\",\"favourite\":\"收藏\"},\"state\":{\"draft\":\"草稿\",\"sale\":\"销售\",\"done\":\"完成\",\"cancel\":\"取消\"},\"package_size\":{\"small\":\"小包裹\",\"medium\":\"中包裹\",\"large\":\"大包裹\"},\"warehouse_list\":{\"de\":\"DE Warehouse\",\"uk\":\"UK GoodCang\",\"uk_own\":\"UK Own Warehouse\",\"fr\":\"FR Warehouse\",\"zqlc\":\"ZQLC Warehouse\"},\"order_type\":{\"a\":\"Normal\",\"r\":\"Resend\",\"g\":\"Marketing\",\"service\":\"Service\"},\"shipping_policy\":{\"direct\":\"Deliver each product when available\",\"one\":\"Deliver all products at once\"},\"invoice_policy\":{\"order\":\"Ordered quantities\",\"delivery\":\"Delivered quantities\"},\"illegal_words\":{\"active\":\"激活\",\"cancel\":\"取消\"},\"picking_state\":{\"draft\":\"草稿\",\"waiting\":\"等待\",\"confirmed\":\"等待可用\",\"partially_available\":\"部分可用\",\"assigned\":\"可用\",\"done\":\"完成\",\"cancel\":\"取消\"},\"picking_validate_status\":{\"no_validate\":\"未验证\",\"error\":\"验证出错\",\"ok\":\"已验证\"},\"invoice_send_status\":{\"waiting\":\"Waiting\",\"done\":\"Done\",\"query\":\"Query\",\"create_invoice\":\"Create Invoice\",\"partner_email\":\"Partner Email\",\"no_order\":\"No Order\",\"no_template\":\"No Template\",\"other\":\"Other\"},\"email_group_status\":{\"active\":\"启用\",\"stop\":\"停用\"},\"product_type\":{\"consu\":\"消耗品\",\"product\":\"库存产品\",\"service\":\"Service\"},\"ocean_ship_status\":{\"ship\":\"Ship\",\"process\":\"Process\",\"waiting\":\"Waiting\",\"wait\":\"Wait\",\"land\":\"Land\"},\"ship_status\":{\"draft\":\"Draft\",\"confirm\":\"Confirm\",\"approved\":\"Approved\",\"cancel\":\"Cancel\",\"ship\":\"Ship\",\"process\":\"Process Clearance\",\"waiting\":\"Waiting Arrange In\",\"wait\":\"Waiting In\",\"land\":\"Land\"},\"reissue_type\":{\"complete\":\"整品\",\"part\":\"配件\"},\"replenishment_type\":{\"operational\":\"Operational\",\"development\":\"Development\",\"abnormal_purchase\":\"Abnormal Purchase\"},\"replenishment_state\":{\"draft\":\"RFQ\",\"to_approve\":\"To Approve\",\"approved\":\"Approved\",\"order\":\"Order Plan\",\"order2\":\"Order End\",\"approved_order\":\"Approved/Order Plan\",\"approved_order2\":\"Approved/Order End\",\"package\":\"Package\",\"ship\":\"Ship\",\"process\":\"Process Clearance\",\"waiting\":\"Waiting Arrange In\",\"wait\":\"Waiting In\",\"land\":\"Land\",\"done\":\"Done\",\"cancel\":\"Cancelled\",\"refuse\":\"Refuse\",\"confirmed\":\"Confirm\",\"done2\":\"Done2\"},\"package_order_state\":{\"ship\":\"Ship\",\"process\":\"Process Clearance\",\"waiting\":\"Waiting Arrange In\",\"wait\":\"Waiting In\",\"land\":\"Land\",\"confirm\":\"Confirm\",\"draft\":\"Draft\",\"cancel\":\"Cancel\",\"approved\":\"Approved\"},\"purchase_contract_state\":{\"done\":\"Done\",\"confirm\":\"Confirm\",\"draft\":\"Draft\",\"cancel\":\"Cancel\",\"approved\":\"Approved\",\"refuse\":\"Refuse\"},\"final_ship_site\":{\"de\":\"DE\",\"fr\":\"FR\",\"es\":\"ES\",\"it\":\"IT\",\"nl\":\"NL\",\"se\":\"SE\",\"pl\":\"PL\",\"at\":\"AT\",\"be\":\"BE\",\"lu\":\"LU\"},\"sku_replenish_state\":{\"no\":\"不独立补货\",\"merge\":\"SKU独立补货\",\"single\":\"供应商独立补货\"},\"sale_state\":{\"normal\":\"正常在售\",\"weed_out\":\"淘汰停售\",\"infringement\":\"侵权停售\",\"to_be_seen\":\"待观察\"},\"logistics_provider_state\":{\"active\":\"有效\",\"inactive\":\"失效\"},\"logistics_provider_aging\":{\"air\":\"空运\",\"truck\":\"卡车\",\"rail\":\"铁路\",\"sea\":\"海运\",\"delivery\":\"快递\"},\"unsalable_approve_state\":{\"approved\":\"已审核\",\"wait_approve\":\"等待审核\"},\"pre_prod_price_approve_state\":{\"pre_approve\":\"待审核\",\"passed\":\"已通过\",\"not_passed\":\"未通过\",\"time_out\":\"已逾期\"},\"prod_status\":{\"sale\":\"正常在售\",\"stop\":\"淘汰停售\",\"waiting\":\"待观察\",\"sz_prod\":\"深圳产品\",\"uk_sale\":\"UK正常在售\",\"tort_stop\":\"侵权停售\"},\"shipping_plan_state\":{\"draft\":\"待确认\",\"confirm\":\"已确认\",\"assigned\":\"已分配\"},\"price_check_prod_status\":{\"sale\":\"正常在售\",\"stop\":\"淘汰停售\",\"waiting\":\"待观察\",\"tort_stop\":\"侵权停售\"},\"check_prod_status\":{\"sale\":\"正常在售\",\"stop\":\"淘汰停售\",\"waiting\":\"待观察\",\"tort_stop\":\"侵权停售\",\"no_stop\":\"非停售\",\"not_onshelf\":\"暂不上架\"},\"sent_email_state\":{\"outgoing\":\"待发送\",\"sent\":\"已发送\",\"received\":\"已接收\",\"exception\":\"异常\",\"cancel\":\"取消\"},\"purchase_price_change_report_status\":{\"pre_handled\":\"未处理\",\"handled\":\"已处理\",\"price_adjusted\":\"已调价\",\"no_handled\":\"已忽略\"},\"de_po_state\":{\"draft\":\"草稿\",\"confirmed\":\"确认\",\"cancel\":\"取消\"}},\"columns\":{\"instance_code\":\"实例编码\",\"instance_name\":\"实例名称\",\"instance_full_name\":\"全称\",\"who_responsible\":\"负责人\",\"write_uid\":\"修改人\",\"write_date\":\"修改日期\",\"seller_code\":\"店铺编码\",\"seller_name\":\"店铺名称\",\"seller_full_name\":\"全称\",\"create_date\":\"创建时间\",\"platform\":\"平台\",\"status\":\"状态\",\"seller_info\":\"店铺信息\",\"instance_info\":\"店铺实例信息\",\"instances_list\":\"店铺实例列表\",\"detail\":\"详情\",\"create_time\":\"创建时间\",\"write_time\":\"修改时间\",\"operator\":\"运营\",\"department\":\"部门\",\"z_category\":\"中文分类\",\"z_sub_category\":\"中文子类\",\"actions\":\"操作\",\"edit\":\"编辑\",\"export_excel\":\"导出Excel\",\"operate_log\":\"操作日志\",\"log\":\"日志\",\"type\":\"类型\",\"operate_user\":\"操作人\",\"date\":\"日期\"},\"action\":{\"create\":\"新建\",\"action\":\"操作\",\"submit\":\"提交\",\"cancel\":\"取消\",\"discard\":\"丢弃\",\"downLoadTemplate\":\"下载模板\"},\"tips\":{\"save_success\":\"操作成功\",\"update_success\":\"更新成功\",\"delete_success\":\"删除成功\"},\"split_query_condition\":\"多个查询逗号分隔\",\"fuzzy_search\":\"模糊搜索\",\"plzInput\":\"请输入\",\"plzSelect\":\"请选择\"}");

/***/ }),

/***/ "d4db":
/***/ (function(module) {

module.exports = JSON.parse("[{\"id\":1,\"name\":\"dashboard\",\"children\":[{\"id\":2,\"icon\":\"code\",\"name\":\"workspace\"}]},{\"id\":20,\"name\":\"BasicManage\",\"children\":[{\"id\":210,\"icon\":\"mobile\",\"name\":\"seller-manage\"},{\"id\":220,\"icon\":\"mobile\",\"name\":\"seller-edit\"},{\"id\":230,\"icon\":\"mobile\",\"name\":\"instance-manage\"},{\"id\":240,\"icon\":\"mobile\",\"name\":\"instance-edit\"},{\"id\":250,\"icon\":\"mobile\",\"name\":\"query-condition-manage\"},{\"id\":260,\"icon\":\"mobile\",\"name\":\"illegal-words\"}]},{\"id\":30,\"name\":\"PurchasePredict\",\"children\":[{\"id\":310,\"icon\":\"mobile\",\"name\":\"product-sale-trend\"},{\"id\":320,\"icon\":\"mobile\",\"name\":\"product-pre-sale\"},{\"id\":330,\"icon\":\"info-circle\",\"name\":\"product-sku-sale\"},{\"id\":340,\"icon\":\"info-circle\",\"name\":\"product-purchase-predict\"}]},{\"id\":13,\"name\":\"orders\",\"children\":[{\"id\":14,\"icon\":\"gold\",\"name\":\"order-manage\"},{\"id\":131,\"icon\":\"gold\",\"name\":\"modify-custom-problem\"},{\"id\":141,\"icon\":\"gold\",\"name\":\"user-order\"},{\"id\":142,\"icon\":\"gold\",\"name\":\"order-wrapper\"}]},{\"id\":15,\"name\":\"picking\",\"children\":[{\"id\":16,\"icon\":\"hdd\",\"name\":\"picking-manage\"},{\"id\":17,\"icon\":\"hdd\",\"name\":\"modify-address\"},{\"id\":18,\"icon\":\"hdd\",\"name\":\"shipment-type\"},{\"id\":19,\"icon\":\"hdd\",\"name\":\"picking-detail\"},{\"id\":151,\"icon\":\"hdd\",\"name\":\"picking-wrapper\"}]},{\"id\":10,\"name\":\"settings\",\"children\":[{\"id\":11,\"icon\":\"team\",\"name\":\"user-manage\"},{\"id\":65,\"icon\":\"bars\",\"name\":\"role-manage\"},{\"id\":66,\"icon\":\"bars\",\"name\":\"module-manage\"},{\"id\":67,\"icon\":\"menu\",\"name\":\"menu-manage\"},{\"id\":151,\"icon\":\"mail\",\"name\":\"chat-box\"}]},{\"id\":50,\"name\":\"PreSale Management\",\"children\":[{\"id\":500,\"icon\":\"mobile\",\"name\":\"presale-manage\"},{\"id\":510,\"icon\":\"mobile\",\"name\":\"presale-orders-manage\"}]},{\"id\":60,\"name\":\"amazon\",\"children\":[{\"id\":10,\"icon\":\"mobile\",\"name\":\"amazon-listing-stock\"}]},{\"id\":70,\"name\":\"account\",\"children\":[{\"id\":1,\"icon\":\"mobile\",\"name\":\"account-invoice\"}]},{\"id\":71,\"name\":\"aliexpress\",\"children\":[{\"id\":1,\"icon\":\"mobile\",\"name\":\"aliexpress-manage\"}]},{\"id\":72,\"name\":\"report\",\"children\":[{\"id\":1,\"icon\":\"mobile\",\"name\":\"profit-report\"},{\"id\":2,\"icon\":\"mobile\",\"name\":\"profit-detail\"}]},{\"id\":73,\"name\":\"product\",\"children\":[{\"id\":1,\"icon\":\"mobile\",\"name\":\"product-manage\"}]},{\"id\":80,\"name\":\"customer_service\",\"children\":[{\"id\":800,\"icon\":\"mobile\",\"name\":\"problem-picture\"}]}]");

/***/ })

}]);