(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~72357a4e"],{

/***/ "1688":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/company-product-stock.vue?vue&type=template&id=76e3ac16&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer"},[_c('data-form',{ref:"dataForm",attrs:{"column":1},scopedSlots:_vm._u([{key:"default",fn:function(){return undefined},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.downloadStockReport}},[_vm._v(" "+_vm._s(_vm.$t('action.download_excel_stock_file'))+" ")])]},proxy:true}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/company-product-stock.vue?vue&type=template&id=76e3ac16&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/company-product-stock.vue?vue&type=script&lang=ts&










var company_product_stockvue_type_script_lang_ts_CompanyProductStock =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](CompanyProductStock, _super);

  function CompanyProductStock() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.productService = new product_service["a" /* ProductService */]();
    _this.isShow = true;
    _this.rules = {
      required: [{
        required: true
      }]
    };
    _this.url_pre = app_config["a" /* default */].server;
    return _this;
  }

  CompanyProductStock.prototype.created = function () {};

  CompanyProductStock.prototype.handleFatherCateChange = function (value) {};

  CompanyProductStock.prototype.downloadStockReport = function () {
    var url = app_config["a" /* default */].server + '/product/export_multi_company_stock';
    window.open(url);
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], CompanyProductStock.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], CompanyProductStock.prototype, "pageContainer", void 0);

  CompanyProductStock = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'company-product-stock'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], CompanyProductStock);
  return CompanyProductStock;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var company_product_stockvue_type_script_lang_ts_ = (company_product_stockvue_type_script_lang_ts_CompanyProductStock);
// CONCATENATED MODULE: ./src/pages/reports/company-product-stock.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_company_product_stockvue_type_script_lang_ts_ = (company_product_stockvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/company-product-stock.vue?vue&type=custom&index=0&blockType=i18n
var company_product_stockvue_type_custom_index_0_blockType_i18n = __webpack_require__("7951");

// CONCATENATED MODULE: ./src/pages/reports/company-product-stock.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_company_product_stockvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof company_product_stockvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(company_product_stockvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var company_product_stock = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "1754":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_sku_month_sales_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("48a4");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_sku_month_sales_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_sku_month_sales_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_sku_month_sales_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1a6b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/head-logistics-report.vue?vue&type=template&id=6e0569ba&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 10 }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 10 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('columns.name'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('columns.common_sku'))+" ")]),_c('a-select-option',{attrs:{"value":30}},[_vm._v(" "+_vm._s(_vm.$t('columns.fba_shipment_id'))+" ")]),_c('a-select-option',{attrs:{"value":40}},[_vm._v(" "+_vm._s(_vm.$t('columns.purchase_number'))+" ")]),_c('a-select-option',{attrs:{"value":50}},[_vm._v(" "+_vm._s(_vm.$t('columns.shipment_number'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.from_warehouse')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['from_warehouse', { initialValue: '' }]),expression:"['from_warehouse', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.warehouseList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.to_warehouse')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['to_warehouse']),expression:"['to_warehouse']"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.ship_aging')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_aging', { initialValue: '' }]),expression:"['ship_aging', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.LogisticsProviderAging),function(i){return _c('a-select-option',{key:i.value,attrs:{"value":i.value}},[_vm._v(" "+_vm._s(_vm.$t(i.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.payment_state')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['payment_state']),expression:"['payment_state']"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.importLogisticsInfo()}}},[_vm._v(_vm._s(_vm.$t('action.importLogisticsInfo'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":_vm.selectedRowKeys.length != 1},on:{"click":function($event){return _vm.showLogisticsInfo()}}},[_vm._v(_vm._s(_vm.$t('action.showLogisticsInfo'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.needSaveNotes.length},on:{"click":function($event){return _vm.changeNote()}}},[_vm._v(" "+_vm._s(_vm.$t('action.save'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"abnormal_situation",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"2","cols":"40","value":row.abnormal_situation
                                ? row.abnormal_situation
                                : ''},on:{"change":function (e) { return _vm.handleChange(
                                    e.target.value,
                                    row,
                                    'abnormal_situation'
                                ); }}}):_c('span',{attrs:{"title":row.abnormal_situation}},[_vm._v(_vm._s(row.abnormal_situation ? row.abnormal_situation.length > 24 ? row.abnormal_situation.substr(0, 27) + '...' : row.abnormal_situation : ''))])]}},{key:"shipment_number",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"2","cols":"40","value":row.shipment_number ? row.shipment_number : ''},on:{"change":function (e) { return _vm.handleChange(
                                    e.target.value,
                                    row,
                                    'shipment_number'
                                ); }}}):_c('span',{attrs:{"title":row.shipment_number}},[_vm._v(_vm._s(row.shipment_number))])]}},{key:"assigned_qty",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-input-number',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"2","cols":"40","value":row.assigned_qty ? row.assigned_qty : 0},on:{"change":function (e) { return _vm.handleChange(
                                    e.target.value,
                                    row,
                                    'assigned_qty'
                                ); }}}):_c('span',{attrs:{"title":row.assigned_qty}},[_vm._v(_vm._s(row.assigned_qty))])]}},{key:"except_date",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-date-picker',{attrs:{"showTime":"","valueFormat":"YYYY-MM-DD HH:mm:ss","value":_vm._f("datetolocal")(row.except_date)},on:{"change":function (e) { return _vm.handleChange(e, row, 'except_date'); }}}):_c('span',[_vm._v(_vm._s(_vm._f("datetolocal")(text)))])]}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"ship_aging",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'LogisticsProviderAging')))+" ")])}}],null,false,2956933140)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"ship_aging",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'LogisticsProviderAging')))+" ")])}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/head-logistics-report.vue?vue&type=template&id=6e0569ba&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/components/purchase/modify-head-logistics-info.vue + 4 modules
var modify_head_logistics_info = __webpack_require__("124a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/head-logistics-report.vue?vue&type=script&lang=ts&























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var head_logistics_reportvue_type_script_lang_ts_HeadLogisticsReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](HeadLogisticsReport, _super);

  function HeadLogisticsReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.queryUrl = '/report/query_head_logistics_report';
    _this.warehouseList = [{
      code: 'de',
      name: 'de'
    }, {
      code: 'uk',
      name: 'uk'
    }, {
      code: 'uk_own',
      name: 'uk_own'
    }, {
      code: 'zqlc',
      name: 'zqlc'
    }];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.editRow = {
      id: null
    };
    _this.needSaveNotes = [];
    return _this;
  }

  Object.defineProperty(HeadLogisticsReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  HeadLogisticsReport.prototype.created = function () {
    this.getSystemuser();
  };

  HeadLogisticsReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  HeadLogisticsReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  HeadLogisticsReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var fuzzy_search_value = values['fuzzy_search_value'];

      if (fuzzy_search_value) {
        var fuzzy_search_code = values['fuzzy_search_code'];
        var search_field_name = 'name';

        switch (fuzzy_search_code) {
          case 10:
            search_field_name = 'name';
            break;

          case 20:
            search_field_name = 'common_sku';
            break;

          case 30:
            search_field_name = 'fba_shipment_id';
            break;

          case 40:
            search_field_name = 'purchase_number';
            break;

          case 50:
            search_field_name = 'shipment_number';
            break;

          default:
            search_field_name = 'name';
        }

        values[search_field_name] = fuzzy_search_value;
      }

      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        name: '=',
        common_sku: '=',
        fba_shipment_id: '=',
        purchase_number: 'ilike',
        shipment_number: 'ilike'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  HeadLogisticsReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  HeadLogisticsReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  HeadLogisticsReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  HeadLogisticsReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  HeadLogisticsReport.prototype.onRowClick = function (row) {
    this.editRow = {
      id: row
    };
  };

  HeadLogisticsReport.prototype.handleChange = function (e, row, column) {
    row[column] = e;
    var item = this.needSaveNotes.find(function (x) {
      return x.id == row.id;
    });

    if (item) {
      item[column] = e;
    } else {
      var param = {
        id: row.id
      };
      param[column] = e;
      this.needSaveNotes.push(param);
    }
  };

  HeadLogisticsReport.prototype.changeNote = function () {
    var _this = this;

    this.innerAction.setActionAPI('/report/modify_head_logistics_report', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      update_data: this.needSaveNotes
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  HeadLogisticsReport.prototype.importLogisticsInfo = function () {};

  HeadLogisticsReport.prototype.showLogisticsInfo = function () {
    var _this = this;

    this.$modal.open(modify_head_logistics_info["a" /* default */], {
      inbound_line_id: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showLogisticsInfo'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('Update Success');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], HeadLogisticsReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], HeadLogisticsReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], HeadLogisticsReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], HeadLogisticsReport.prototype, "getSystemuser", void 0);

  HeadLogisticsReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'head-logistics-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], HeadLogisticsReport);
  return HeadLogisticsReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var head_logistics_reportvue_type_script_lang_ts_ = (head_logistics_reportvue_type_script_lang_ts_HeadLogisticsReport);
// CONCATENATED MODULE: ./src/pages/reports/head-logistics-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_head_logistics_reportvue_type_script_lang_ts_ = (head_logistics_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/head-logistics-report.vue?vue&type=custom&index=0&blockType=i18n
var head_logistics_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("2324");

// CONCATENATED MODULE: ./src/pages/reports/head-logistics-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_head_logistics_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof head_logistics_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(head_logistics_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var head_logistics_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "21c1":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","importLogisticsInfo":"importLogisticsInfo","showLogisticsInfo":"showLogisticsInfo","save":"save"},"columns":{"quick_search":"quick_search","name":"name","common_sku":"common_sku","fba_shipment_id":"fba_shipment_id","purchase_number":"purchase_number","shipment_number":"shipment_number","from_warehouse":"from_warehouse","to_warehouse":"to_warehouse","ship_aging":"ship_aging","payment_state":"payment_state"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","importLogisticsInfo":"物流详情导入","showLogisticsInfo":"物流详情查看","save":"保存"},"columns":{"quick_search":"快速查询","name":"调拨单号","common_sku":"通用SKU","fba_shipment_id":"fba_shipment_id","purchase_number":"对应采购订单号","shipment_number":"对应出货合同","from_warehouse":"调出仓库","to_warehouse":"调入仓库","ship_aging":"选择时效","payment_state":"付款状态"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "2324":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_head_logistics_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("21c1");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_head_logistics_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_head_logistics_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_head_logistics_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "48a4":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","updateSKUPurchaseStatus":"Update Purchase Status As Separate Purchase"},"columns":{"z_sub_category":"Sub Category","vendor_id":"Vendor","order_month":"Month","month_sales_more_50":"Month Sale more than 50"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","updateSKUPurchaseStatus":"更新产品补货状态为独立补货"},"columns":{"z_sub_category":"中文子类","vendor_id":"供应商","order_month":"月份","month_sales_more_50":"月销量大于50"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "7951":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_company_product_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c5cb");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_company_product_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_company_product_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_company_product_stock_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7e54":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/dept-sku-month-sales-report.vue?vue&type=template&id=a9288d68&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category', { initialValue: '' }]),expression:"['z_category', { initialValue: '' }]"}],style:({ width: '90px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate,attrs:{"title":cate}},[_vm._v(" "+_vm._s(cate)+" ")])})],2),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category', { initialValue: '' }]),expression:"['z_sub_category', { initialValue: '' }]"}],style:({ width: '180px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate,attrs:{"title":cate}},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_month')}},[_c('a-month-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_month', { rules: _vm.rules.required }]),expression:"['order_month', { rules: rules.required }]"}],attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.month_sales_more_50')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'month_sales_more_50',
                        { initialValue: '' }
                    ]),expression:"[\n                        'month_sales_more_50',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.department')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dept_id']),expression:"['dept_id']"}],style:({ width: '180px' }),attrs:{"showSearch":"","dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""}},_vm._l((_vm.topDepartmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])}),1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.updateSKUPurchaseStatus()}}},[_vm._v(" "+_vm._s(_vm.$t('action.updateSKUPurchaseStatus'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"index","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 800, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"department_render",fn:function(text){return _c('span',{},[_vm._v(" "+_vm._s(_vm.getDepartName(text))+" ")])}}],null,false,4177691708)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"department_render",fn:function(text){return _c('span',{},[_vm._v(" "+_vm._s(_vm.getDepartName(text))+" ")])}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/dept-sku-month-sales-report.vue?vue&type=template&id=a9288d68&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/dept-sku-month-sales-report.vue?vue&type=script&lang=ts&

























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var dept_sku_month_sales_reportvue_type_script_lang_ts_DeptSKUMonthSalesReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](DeptSKUMonthSalesReport, _super);

  function DeptSKUMonthSalesReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.topDepartmentList = [];
    _this.current = null;
    _this.orderBy = 'three_month_sales desc';
    _this.columnList = [];
    _this.queryUrl = 'reports/query_all_dept_sku_month_sale';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  Object.defineProperty(DeptSKUMonthSalesReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  DeptSKUMonthSalesReport.prototype.created = function () {
    var _this = this;

    this.getSystemuser();
    this.getDepartmentList();
    this.topDepartmentList = this.departmentList.filter(function (x) {
      return x.dept_type == 30;
    });
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  DeptSKUMonthSalesReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  DeptSKUMonthSalesReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取数据
   */


  DeptSKUMonthSalesReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (values['z_category']) {
        delete values['z_category'];
      }

      if (_this.selectedList.length > 0) {
        values['z_sub_category'] = _this.selectedList;
      }

      var sale_data_operator = '<';

      if (values['month_sales_more_50'] !== '') {
        values['bp_sale_num'] = 50;

        if (values['month_sales_more_50']) {
          sale_data_operator = '>=';
        }

        delete values['month_sales_more_50'];
      }

      if (values['order_month']) {
        values['order_month'] = values['order_month'].format('YYYY-MM');
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: 'in_or_=',
        z_sub_category: 'in',
        bp_sale_num: sale_data_operator,
        dept_id: 'in'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.data = _this.data.map(function (x) {
            x.index = uuid_default.a.generate();
            return x;
          });
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  DeptSKUMonthSalesReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  DeptSKUMonthSalesReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  DeptSKUMonthSalesReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  DeptSKUMonthSalesReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  DeptSKUMonthSalesReport.prototype.getDepartName = function (department) {
    var ret = department;
    var item = this.departmentList.find(function (x) {
      return x.id == department;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  DeptSKUMonthSalesReport.prototype.updateSKUPurchaseStatus = function () {
    var _this = this;

    if (!this.selectedRowKeys.length) {
      this.$message.info('请选择数据行');
      return;
    }

    var params = [];

    var _loop_1 = function _loop_1(index) {
      var find_data = this_1.data.find(function (x) {
        return x.index == index;
      });

      if (find_data) {
        params.push({
          sku: find_data.default_code,
          dept_id: find_data.dept_id
        });
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var index = _a[_i];

      _loop_1(index);
    }

    if (!params.length) {
      this.$message.info('请选择数据行');
      return;
    }

    this.innerAction.setActionAPI('reports/update_dept_sku_purchase_status', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      purchase_status: params
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], DeptSKUMonthSalesReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], DeptSKUMonthSalesReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptSKUMonthSalesReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptSKUMonthSalesReport.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptSKUMonthSalesReport.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptSKUMonthSalesReport.prototype, "getDepartmentList", void 0);

  DeptSKUMonthSalesReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'dept-sku-month-sales-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], DeptSKUMonthSalesReport);
  return DeptSKUMonthSalesReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var dept_sku_month_sales_reportvue_type_script_lang_ts_ = (dept_sku_month_sales_reportvue_type_script_lang_ts_DeptSKUMonthSalesReport);
// CONCATENATED MODULE: ./src/pages/reports/dept-sku-month-sales-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_dept_sku_month_sales_reportvue_type_script_lang_ts_ = (dept_sku_month_sales_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/dept-sku-month-sales-report.vue?vue&type=custom&index=0&blockType=i18n
var dept_sku_month_sales_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("1754");

// CONCATENATED MODULE: ./src/pages/reports/dept-sku-month-sales-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_dept_sku_month_sales_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof dept_sku_month_sales_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(dept_sku_month_sales_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var dept_sku_month_sales_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "7f1d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"shop_type":"platform","cn_sub_category":"cn sub category","order_date":"Order Date"},"action":{"create_excel_profit_file":"Create Profit Excel Report","download_excel_profit_file":"Download Profit Excel Report"}},"zh-cn":{"columns":{"shop_type":"平台","cn_sub_category":"中文子类","order_date":"订单日期"},"action":{"downloadZip":"批量下载","delete":"删除","detail":"详情","create_excel_profit_file":"生成毛利报告Excel","download_excel_profit_file":"下载毛利报告Excel"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "9a85":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","updateSKUPurchaseStatus":"Update Purchase Status As Separate Purchase"},"columns":{"z_sub_category":"Sub Category","de_prod_status":"DE Sale Status","uk_prod_status":"UK Sale Status"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","updateSKUPurchaseStatus":"更新产品补货状态为独立补货"},"columns":{"z_sub_category":"中文子类","de_prod_status":"德仓销售状态","uk_prod_status":"英仓销售状态"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "c5cb":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"shop_type":"platform","cn_sub_category":"cn sub category","order_date":"Order Date"},"action":{"download_excel_stock_file":"Download Multi Company Product Stock Report Excel"}},"zh-cn":{"columns":{"shop_type":"平台","cn_sub_category":"中文子类","order_date":"订单日期"},"action":{"downloadZip":"批量下载","delete":"删除","detail":"详情","download_excel_stock_file":"下载产品多公司库存统计表Excel"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "d032":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/data-pivot-table.vue?vue&type=template&id=413eeebd&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer"},[_c('data-form',{ref:"dataForm",attrs:{"column":1},on:{"submit":_vm.getdata},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.shop_type'),"required":""}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['shop_type', { initialValue: '' }]),expression:"['shop_type', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.shopType),function(item){return _c('a-radio-button',{key:item,attrs:{"value":item}},[_vm._v(_vm._s(item))])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_date')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_date']),expression:"['order_date']"}],staticStyle:{"width":"100%"},attrs:{"mode":"multiple","placeholder":"Please select"}},_vm._l((_vm.order_date_list),function(order_date){return _c('a-select-option',{key:order_date,attrs:{"value":order_date}},[_vm._v(" "+_vm._s(order_date)+" ")])}),1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_category']),expression:"['cn_category']"}],staticStyle:{"width":"120px"},attrs:{"default-value":_vm.fatherCates[0],"placeholder":"category","allowClear":""},on:{"change":_vm.handleFatherCateChange}},_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1),_c('a-select',{staticStyle:{"width":"80%","margin-left":"25px"},attrs:{"mode":"multiple","placeholder":"sub category"},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.createProfitReport}},[_vm._v(" "+_vm._s(_vm.$t('action.create_excel_profit_file'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.downloadProfitReport}},[_vm._v(" "+_vm._s(_vm.$t('action.download_excel_profit_file'))+" ")])]},proxy:true}])}),_c('a-card',[(_vm.isShow)?_c('WebDataRocks',{attrs:{"report":_vm.report,"toolbar":""}}):_vm._e()],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/data-pivot-table.vue?vue&type=template&id=413eeebd&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/assets/json/zh.json
var zh = __webpack_require__("3669");

// EXTERNAL MODULE: ./src/components/common/WebDataRocks.vue + 4 modules
var WebDataRocks = __webpack_require__("9de5");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/data-pivot-table.vue?vue&type=script&lang=ts&














var data_pivot_tablevue_type_script_lang_ts_DataPivotTable =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](DataPivotTable, _super);

  function DataPivotTable() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.shopType = ['B2C', 'Amazon', 'Ebay', 'Wish', 'Cdiscount', 'Aliexpress'];
    _this.isShow = true;
    _this.rules = {
      required: [{
        required: true
      }]
    };
    _this.cn_sub_category_list = [];
    _this.selectedList = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.report = {
      dataSource: {
        dataSourceType: 'json',
        data: []
      },
      localization: zh,
      slice: {
        rows: [{
          uniqueName: '子类'
        }, {
          uniqueName: 'SKU'
        }, {
          uniqueName: '订单日期'
        }, {
          uniqueName: '国家'
        }, {
          uniqueName: '订单类型'
        }],
        columns: [{
          uniqueName: 'Measures'
        }],
        measures: [{
          uniqueName: '销售数量',
          aggregation: 'sum'
        }, {
          uniqueName: '销售额',
          aggregation: 'sum'
        }, {
          uniqueName: '税费',
          aggregation: 'sum'
        }, {
          uniqueName: '平台费',
          aggregation: 'sum'
        }, {
          uniqueName: '产品成本',
          aggregation: 'sum'
        }, {
          uniqueName: '成本占比',
          aggregation: 'average',
          format: 'product_price_percent'
        }, {
          uniqueName: '退款',
          aggregation: 'sum'
        }, {
          uniqueName: '退款占比',
          aggregation: 'average',
          format: 'refund_percent'
        }, {
          uniqueName: '运费',
          aggregation: 'sum'
        }, {
          uniqueName: '运费占比',
          aggregation: 'average',
          format: 'shipment_fee_percent'
        }, {
          uniqueName: '毛利',
          aggregation: 'sum'
        }, {
          uniqueName: '毛利率',
          aggregation: 'average',
          format: 'profit_percent'
        }, {
          uniqueName: '产品销售单价',
          aggregation: 'average'
        }, {
          uniqueName: '产品最低价',
          aggregation: 'average'
        }, {
          uniqueName: '单品理论运费',
          aggregation: 'average'
        }, {
          uniqueName: '单品实际运费',
          aggregation: 'average'
        }]
      },
      options: {
        grid: {
          type: 'classic',
          showTotals: 'columns',
          showGrandTotals: 'off'
        }
      },
      formats: [{
        name: '',
        thousandsSeparator: ' ',
        decimalSeparator: '.',
        decimalPlaces: 2,
        currencySymbol: '',
        currencySymbolAlign: 'left',
        nullValue: '',
        textAlign: 'right',
        isPercent: false
      }, {
        name: 'product_price_percent',
        thousandsSeparator: ' ',
        decimalSeparator: '.',
        decimalPlaces: 2,
        currencySymbol: '',
        currencySymbolAlign: 'left',
        nullValue: '',
        textAlign: 'right',
        isPercent: true
      }, {
        name: 'refund_percent',
        thousandsSeparator: ' ',
        decimalSeparator: '.',
        decimalPlaces: 2,
        currencySymbol: '',
        currencySymbolAlign: 'left',
        nullValue: '',
        textAlign: 'right',
        isPercent: true
      }, {
        name: 'shipment_fee_percent',
        thousandsSeparator: ' ',
        decimalSeparator: '.',
        decimalPlaces: 2,
        currencySymbol: '',
        currencySymbolAlign: 'left',
        nullValue: '',
        textAlign: 'right',
        isPercent: true
      }, {
        name: 'profit_percent',
        thousandsSeparator: ' ',
        decimalSeparator: '.',
        decimalPlaces: 2,
        currencySymbol: '',
        currencySymbolAlign: 'left',
        nullValue: '',
        textAlign: 'right',
        isPercent: true
      }]
    };
    _this.order_date_list = [];
    _this.url_pre = app_config["a" /* default */].server;
    return _this;
  }

  DataPivotTable.prototype.created = function () {
    this.getCn_cate();
    this.getOrderDateList();
  };

  DataPivotTable.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  DataPivotTable.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  DataPivotTable.prototype.getOrderDateList = function () {
    var _this = this;

    this.reportService.query_order_date_list(new http["RequestParams"]()).subscribe(function (data) {
      _this.order_date_list = data;
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  DataPivotTable.prototype.createProfitReport = function () {
    var url = app_config["a" /* default */].server + '/report/create_excel_profit_file';
    window.open(url);
  };

  DataPivotTable.prototype.downloadProfitReport = function () {
    var url = app_config["a" /* default */].server + '/report/download_excel_profit_file';
    window.open(url);
  };

  DataPivotTable.prototype.getdata = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      // if (!values['shop_type'] || values['shop_type'].length == 0) {
      //     this.$message.error('请选择平台')
      //     return false
      // }
      if (_this.selectedList.length > 0) {
        values['cn_sub_category'] = _this.selectedList;
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        shop_type: 'like',
        cn_sub_category: 'in',
        order_date: 'in'
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];
        nowConditions.push(item);
      }

      params.query_condition = nowConditions;

      _this.reportService.query_all_profit_data(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.report.dataSource.data = data;
        _this.isShow = false;

        _this.$nextTick(function () {
          return _this.isShow = true;
        });
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {
      _this.$message.error('请检查查询条件');
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], DataPivotTable.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], DataPivotTable.prototype, "pageContainer", void 0);

  DataPivotTable = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'profit-pivot'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      WebDataRocks: WebDataRocks["a" /* default */]
    }
  })], DataPivotTable);
  return DataPivotTable;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var data_pivot_tablevue_type_script_lang_ts_ = (data_pivot_tablevue_type_script_lang_ts_DataPivotTable);
// CONCATENATED MODULE: ./src/pages/reports/data-pivot-table.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_data_pivot_tablevue_type_script_lang_ts_ = (data_pivot_tablevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/data-pivot-table.vue?vue&type=custom&index=0&blockType=i18n
var data_pivot_tablevue_type_custom_index_0_blockType_i18n = __webpack_require__("d44ec");

// CONCATENATED MODULE: ./src/pages/reports/data-pivot-table.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_data_pivot_tablevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof data_pivot_tablevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(data_pivot_tablevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var data_pivot_table = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "d042":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/dept-product-factory-transit-stock-report.vue?vue&type=template&id=412d980c&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.department')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dept_id']),expression:"['dept_id']"}],style:({ width: '180px' }),attrs:{"showSearch":"","dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""}},_vm._l((_vm.topDepartmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])}),1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.de_prod_status')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['de_sale_status']),expression:"['de_sale_status']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PriceCheckProdStatus),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.uk_prod_status')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['uk_sale_status']),expression:"['uk_sale_status']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PriceCheckProdStatus),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category', { initialValue: '' }]),expression:"['z_category', { initialValue: '' }]"}],style:({ width: '90px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate,attrs:{"title":cate}},[_vm._v(" "+_vm._s(cate)+" ")])})],2),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category', { initialValue: '' }]),expression:"['z_sub_category', { initialValue: '' }]"}],style:({ width: '180px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate,attrs:{"title":cate}},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"index","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 800, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"department_render",fn:function(text){return _c('span',{},[_vm._v(" "+_vm._s(_vm.getDepartName(text))+" ")])}},{key:"sale_status",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PriceCheckProdStatus')))+" ")]}}],null,false,2268337145)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"department_render",fn:function(text){return _c('span',{},[_vm._v(" "+_vm._s(_vm.getDepartName(text))+" ")])}},{key:"sale_status",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PriceCheckProdStatus')))+" ")]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/dept-product-factory-transit-stock-report.vue?vue&type=template&id=412d980c&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/dept-product-factory-transit-stock-report.vue?vue&type=script&lang=ts&

























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var dept_product_factory_transit_stock_reportvue_type_script_lang_ts_DeptProductFactoryTransitStockReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](DeptProductFactoryTransitStockReport, _super);

  function DeptProductFactoryTransitStockReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.topDepartmentList = [];
    _this.current = null;
    _this.orderBy = 'default_code desc';
    _this.columnList = [];
    _this.queryUrl = 'reports/query_all_product_factory_transit_stock_qty';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  Object.defineProperty(DeptProductFactoryTransitStockReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  DeptProductFactoryTransitStockReport.prototype.created = function () {
    var _this = this;

    this.getSystemuser();
    this.getDepartmentList();
    this.topDepartmentList = this.departmentList.filter(function (x) {
      return x.dept_type == 30;
    });
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  DeptProductFactoryTransitStockReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  DeptProductFactoryTransitStockReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取数据
   */


  DeptProductFactoryTransitStockReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (values['z_category']) {
        delete values['z_category'];
      }

      if (_this.selectedList.length > 0) {
        values['z_sub_category'] = _this.selectedList;
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: 'in_or_=',
        z_sub_category: 'in',
        dept_id: 'in'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.data = _this.data.map(function (x) {
            x.index = uuid_default.a.generate();
            return x;
          });
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  DeptProductFactoryTransitStockReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  DeptProductFactoryTransitStockReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  DeptProductFactoryTransitStockReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  DeptProductFactoryTransitStockReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  DeptProductFactoryTransitStockReport.prototype.getDepartName = function (department) {
    var ret = department;
    var item = this.departmentList.find(function (x) {
      return x.id == department;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], DeptProductFactoryTransitStockReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], DeptProductFactoryTransitStockReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptProductFactoryTransitStockReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptProductFactoryTransitStockReport.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptProductFactoryTransitStockReport.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], DeptProductFactoryTransitStockReport.prototype, "getDepartmentList", void 0);

  DeptProductFactoryTransitStockReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'dept-product-factory-transit-stock-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], DeptProductFactoryTransitStockReport);
  return DeptProductFactoryTransitStockReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var dept_product_factory_transit_stock_reportvue_type_script_lang_ts_ = (dept_product_factory_transit_stock_reportvue_type_script_lang_ts_DeptProductFactoryTransitStockReport);
// CONCATENATED MODULE: ./src/pages/reports/dept-product-factory-transit-stock-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_dept_product_factory_transit_stock_reportvue_type_script_lang_ts_ = (dept_product_factory_transit_stock_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/dept-product-factory-transit-stock-report.vue?vue&type=custom&index=0&blockType=i18n
var dept_product_factory_transit_stock_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("facd");

// CONCATENATED MODULE: ./src/pages/reports/dept-product-factory-transit-stock-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_dept_product_factory_transit_stock_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof dept_product_factory_transit_stock_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(dept_product_factory_transit_stock_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var dept_product_factory_transit_stock_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "d44ec":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_data_pivot_table_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7f1d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_data_pivot_table_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_data_pivot_table_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_data_pivot_table_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "facd":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_product_factory_transit_stock_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9a85");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_product_factory_transit_stock_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_product_factory_transit_stock_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_dept_product_factory_transit_stock_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ })

}]);