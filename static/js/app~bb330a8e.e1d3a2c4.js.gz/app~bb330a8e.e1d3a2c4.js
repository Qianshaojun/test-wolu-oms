(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~bb330a8e"],{

/***/ "0555":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"user_purchase":"Purchase User","merchandiser":"Merchandiser","vendor_id":"Vendor","submit":"Submit","cancel":"Cancel"},"zh-cn":{"user_purchase":"采购员","merchandiser":"跟单员","vendor_id":"供应商","submit":"提交","cancel":"取消"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "0873":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/assign_provider.vue?vue&type=template&id=c48facbe&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save')))]),_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"type":"default","size":"small","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onSplit()}}},[_vm._v(_vm._s(_vm.$t('action.split'))+" ")]),_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.onDelete()}}},[_vm._v(" "+_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.orderDetail,"pagination":false,"rowKey":"index","columns":_vm.detailColumns,"rowSelection":{
            selectedRowKeys: _vm.selectedRowKeys,
            onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
        },"customRow":function (record) { return ({
                on: {
                    click: function () {
                        this$1.selectedRowKeys = [record.index]
                        _vm.onTbRowClick(record)
                    }
                }
            }); },"scroll":{ x: 1300, y: 300 },"bordered":""},scopedSlots:_vm._u([{key:"product_name",fn:function(text, row){return [_c('span',{attrs:{"title":row.product_name}},[_vm._v(_vm._s(row.product_name ? row.product_name.length > 24 ? row.product_name.substr(0, 27) + '...' : row.product_name : ''))])]}},{key:"logistics_id",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['logistics_id']),expression:"['logistics_id']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"showSearch":"","value":row.logistics_id ? row.logistics_id : '',"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small","filterOption":_vm.filterSelectOption},on:{"change":function (e) { return _vm.handleChange(e, row, 'logistics_id'); }}},_vm._l((_vm.providerList),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code}},[_vm._v(" "+_vm._s(i.name)+" ")])}),1):_c('span',[_vm._v(_vm._s(_vm._f("dict2")((row.logistics_id ? row.logistics_id : ''),_vm.providerList)))])]}},{key:"ship_qty",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","value":row.ship_qty,"min":0},on:{"change":function (e) { return _vm.handleChange(e, row, 'ship_qty'); }}}):_c('span',[_vm._v(_vm._s(row.ship_qty))])]}},{key:"date_render",fn:function(text){return [_vm._v(_vm._s(_vm._f("datetolocal")(text)))]}},{key:"ship_aging",fn:function(text, row){return [_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(typeof row.ship_aging == 'object' && row.ship_aging.length == 2 ? row.ship_aging[0] : row.ship_aging,'LogisticsProviderAging'))))])]}},{key:"dest_location_id",fn:function(text, row){return [_c('span',[_vm._v(_vm._s(_vm._f("dict2")(typeof row.dest_location_id == 'object' && row.dest_location_id.length == 2 ? row.dest_location_id[0] : row.dest_location_id,_vm.locationList)))])]}}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/assign_provider.vue?vue&type=template&id=c48facbe&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/services/location.service.ts
var location_service = __webpack_require__("e73b");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/assign_provider.vue?vue&type=script&lang=ts&




















var assign_providervue_type_script_lang_ts_AssignProvider =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AssignProvider, _super);

  function AssignProvider() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.providerList = [];
    _this.moment = moment_default.a; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.locationService = new location_service["a" /* LocationService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.order = [];
    _this.orderDetail = [];
    _this.save_flag = 0;
    _this.originData = [];
    _this.menu_code = '';
    _this.editAble = false;
    _this.currentRow = '';
    _this.detailColumns = [];
    _this.selectedRowKeys = [];
    _this.locationList = [];
    _this.splitArr = [];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  AssignProvider.prototype.onInfoChange = function () {
    if (this.info) {
      this.updateOrder();
    }
  };

  AssignProvider.prototype.created = function () {
    this.getLocationList();
    this.getProviders();
  };

  AssignProvider.prototype.mounted = function () {
    this.detailColumns = [{
      key: 'purchase_num',
      title: this.$t('columns.purchase_num'),
      dataIndex: 'purchase_num',
      width: 100
    }, {
      key: 'common_sku',
      title: this.$t('columns.common_sku'),
      dataIndex: 'common_sku',
      align: 'left',
      width: 100
    }, {
      key: 'product_name',
      title: this.$t('columns.product_name'),
      dataIndex: 'product_name',
      width: 100,
      align: 'right',
      scopedSlots: {
        customRender: 'product_name'
      }
    }, {
      key: 'ship_qty',
      title: this.$t('columns.ship_qty'),
      dataIndex: 'ship_qty',
      align: 'right',
      width: 100,
      scopedSlots: {
        customRender: 'ship_qty'
      }
    }, {
      key: 'ship_date',
      title: this.$t('columns.ship_date'),
      dataIndex: 'ship_date',
      align: 'left',
      width: 120,
      scopedSlots: {
        customRender: 'ship_date'
      }
    }, {
      key: 'ship_aging',
      title: this.$t('columns.ship_aging'),
      dataIndex: 'ship_aging',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'ship_aging'
      }
    }, {
      key: 'dest_location_id',
      title: this.$t('columns.dest_location_id'),
      dataIndex: 'dest_location_id',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'dest_location_id'
      }
    }, {
      key: 'logistics_id',
      title: this.$t('columns.logistics_id'),
      dataIndex: 'logistics_id',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'logistics_id'
      }
    }, {
      key: 'amazon_sku',
      title: this.$t('columns.amazon_sku'),
      dataIndex: 'amazon_sku',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'amazon_sku'
      }
    }, {
      key: 'amazon_asin',
      title: this.$t('columns.amazon_asin'),
      dataIndex: 'amazon_asin',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'amazon_asin'
      }
    }, {
      key: 'fn_sku',
      title: this.$t('columns.fn_sku'),
      dataIndex: 'fn_sku',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'fn_sku'
      }
    }];

    if (this.info) {
      this.updateOrder();
    }
  };

  AssignProvider.prototype.updateOrder = function () {
    if (this.info.length) {
      this.orderDetail = JSON.parse(JSON.stringify(this.info.map(function (x) {
        x['save_flag'] = 1;
        return x;
      })));
    }
  };

  AssignProvider.prototype.getProviders = function () {
    var _this = this;

    this.innerAction.setActionAPI('/logistics_providers/query_logistics_code', common_service["a" /* CommonService */].getMenuCode('shipping-plan-manage'));
    this.publicService.query(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.providerList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AssignProvider.prototype.onSplit = function () {
    var _loop_1 = function _loop_1(i) {
      var item = this_1.orderDetail.find(function (x) {
        return x.index == i;
      });

      if (item) {
        var param = Object.assign({}, item);
        param['index'] = uuid_default.a.generate();
        param['save_flag'] = 0;
        param['origin_id'] = param.id;
        param['id'] = 0;
        this_1.orderDetail.push(param);
        var origin = this_1.splitArr.find(function (x) {
          return x.id == item.id;
        });

        if (!origin) {
          this_1.splitArr.push({
            id: item.id,
            ship_qty: item.ship_qty
          });
        }
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      _loop_1(i);
    }
  };

  AssignProvider.prototype.onSubmit = function () {
    var _this = this;

    var nowDate = new Date().getTime();
    var cur = this.moment(nowDate).format('YYYY-MM-DD');

    for (var _i = 0, _a = this.orderDetail; _i < _a.length; _i++) {
      var i = _a[_i];

      if (!i.ship_qty || !i.logistics_id) {
        this.$message.error('请先完善明细信息，深色背景为必填项');
        return false;
      }
    }

    var params = JSON.parse(JSON.stringify(this.orderDetail));

    var _loop_2 = function _loop_2(i_1) {
      var split = this_2.splitArr.find(function (x) {
        return x.id == params[i_1].id;
      });

      if (split) {
        var qty = params.filter(function (y) {
          return y.id == 0 && y.origin_id == split.id || y.id == split.id;
        }).reduce(function (total, item) {
          return total + parseInt(item.ship_qty);
        }, 0);

        if (qty != split.ship_qty) {
          this_2.$message.error('拆分后的本次发货数量总和和拆分前的不一致(' + params[i_1].purchase_num + ')！');
          return {
            value: void 0
          };
        }
      }
    };

    var this_2 = this;

    for (var i_1 in params) {
      var state_1 = _loop_2(i_1);

      if (Object(esm_typeof["a" /* default */])(state_1) === "object") return state_1.value;
    }

    for (var i_2 in params) {
      delete params[i_2].index;
      delete params[i_2].origin_id;
    }

    this.innerAction.setActionAPI('/shipping_plan/save_shipping_plan', common_service["a" /* CommonService */].getMenuCode('create-shipping-plan'));
    this.publicService.modify(new http["RequestParams"]({
      date_list: params.map(function (x) {
        delete x.index;
        return x;
      }),
      cur_date: cur
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  AssignProvider.prototype.onDelete = function () {
    var _this = this;

    this.$message.success('操作成功');
    this.orderDetail = this.orderDetail.filter(function (x) {
      return !_this.selectedRowKeys.includes(x.index);
    });
  };

  AssignProvider.prototype.onTbRowClick = function (row) {
    this.currentRow = row.index;
  };

  AssignProvider.prototype.handleChange = function (e, row, column) {
    row[column] = e;

    if (column == 'product_qty') {
      row.available_ship_qty = e - row.shipped_qty;
    }
  };

  AssignProvider.prototype.getLocationList = function () {
    var _this = this;

    this.locationService.getLocationList(new http["RequestParams"]()).subscribe(function (data) {
      _this.locationList = data;
    }, function (err) {
      _this.$message.error('获取库位列表失败');
    });
  };

  AssignProvider.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AssignProvider.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AssignProvider.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AssignProvider.prototype, "onInfoChange", null);

  AssignProvider = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AssignProvider);
  return AssignProvider;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var assign_providervue_type_script_lang_ts_ = (assign_providervue_type_script_lang_ts_AssignProvider);
// CONCATENATED MODULE: ./src/components/purchase/assign_provider.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_assign_providervue_type_script_lang_ts_ = (assign_providervue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/assign_provider.vue?vue&type=style&index=0&lang=css&
var assign_providervue_type_style_index_0_lang_css_ = __webpack_require__("b4f6");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/assign_provider.vue?vue&type=custom&index=0&blockType=i18n
var assign_providervue_type_custom_index_0_blockType_i18n = __webpack_require__("cd0a");

// CONCATENATED MODULE: ./src/components/purchase/assign_provider.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_assign_providervue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof assign_providervue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(assign_providervue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var assign_provider = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "0909":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"purchase_num":"purchase_num","common_sku":"common_sku","product_name":"product_name","logistics_id":"logistics_id","ship_qty":"ship_qty","product_qty":"product_qty","available_ship_qty":"available_ship_qty","ship_date":"ship_date","ship_aging":"ship_aging","dest_location_id":"dest_location_id","amazon_sku":"amazon_sku","amazon_asin":"amazon_asin","fn_sku":"fn_sku"},"action":{"split":"Split","edit":"Edit","delete":"Delete","ok":"Yes","more":"More","save":"Save","confirm":"Confirm","cancel":"Cancel"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"purchase_num":"采购订单编号","common_sku":"通用SKU","product_name":"产品名称","logistics_id":"物流商","ship_qty":"本次发货数量","product_qty":"数量","available_ship_qty":"可发货数量","ship_date":"发货日期","ship_aging":"发货时效","dest_location_id":"目的地","amazon_sku":"Amazon SKU","amazon_asin":"ASIN","fn_sku":"FN SKU"},"action":{"split":"拆分","edit":"编辑","delete":"删除","ok":"确定","more":"更多操作","save":"保存","cancel":"取消"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "0ff6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_logistic_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("8519");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_logistic_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_logistic_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_logistic_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "124a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/modify-head-logistics-info.vue?vue&type=template&id=2abba21e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.freight_forwarder_ship_owner')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["freight_forwarder_ship_owner"]),expression:"[`freight_forwarder_ship_owner`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.shipping_company')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["shipping_company"]),expression:"[`shipping_company`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.shipping_channel')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["shipping_channel"]),expression:"[`shipping_channel`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.historical_inquiry')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["historical_inquiry"]),expression:"[`historical_inquiry`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.actual_quotation')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["actual_quotation"]),expression:"[`actual_quotation`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.shipping_amount')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["shipping_amount"]),expression:"[`shipping_amount`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.tax_amount')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["tax_amount"]),expression:"[`tax_amount`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.insurance_amount')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["insurance_amount"]),expression:"[`insurance_amount`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.start_place')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["start_place"]),expression:"[`start_place`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.destination_port')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["destination_port"]),expression:"[`destination_port`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.etd_estimated_domestic')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["etd_estimated_domestic"]),expression:"[`etd_estimated_domestic`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.actual_domestic')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["actual_domestic"]),expression:"[`actual_domestic`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.eta_estimated_arrival')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["eta_estimated_arrival"]),expression:"[`eta_estimated_arrival`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.actual_arrival')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["actual_arrival"]),expression:"[`actual_arrival`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.estimated_delivery')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["estimated_delivery"]),expression:"[`estimated_delivery`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.shipment_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["shipment_number"]),expression:"[`shipment_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.courier_company')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["courier_company"]),expression:"[`courier_company`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.customs_clearance_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["customs_clearance_fee"]),expression:"[`customs_clearance_fee`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.boat_company_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["boat_company_code"]),expression:"[`boat_company_code`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.package_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["package_number"]),expression:"[`package_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.container_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["container_number"]),expression:"[`container_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.invoice_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["invoice_number"]),expression:"[`invoice_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.lading_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["lading_number"]),expression:"[`lading_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/modify-head-logistics-info.vue?vue&type=template&id=2abba21e&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/modify-head-logistics-info.vue?vue&type=script&lang=ts&








var modify_head_logistics_infovue_type_script_lang_ts_ModifyHeadLogisticsInfo =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ModifyHeadLogisticsInfo, _super);

  function ModifyHeadLogisticsInfo() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.saveFlag = 0;
    return _this;
  }

  ModifyHeadLogisticsInfo.prototype.submit = function () {
    return true;
  };

  ModifyHeadLogisticsInfo.prototype.cancel = function () {
    return;
  };

  ModifyHeadLogisticsInfo.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ModifyHeadLogisticsInfo.prototype.mounted = function () {
    this.getHeadLogisticsInfo();
  };

  ModifyHeadLogisticsInfo.prototype.getHeadLogisticsInfo = function () {
    var that = this;
    this.innerAction.setActionAPI('/report/query_head_logistics_info', common_service["a" /* CommonService */].getMenuCode('head-logistics-report'));
    this.publicService.query(new http["RequestParams"]({
      inbound_line_id: this.inbound_line_id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      if (data.length == 1) {
        that.form.setFieldsValue(data[0]);
        that.saveFlag = 1;
      }
    }, function (err) {
      that.$message.error(err.message);
    });
  };

  ModifyHeadLogisticsInfo.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        _this.saveInfo(values);
      }
    });
  };

  ModifyHeadLogisticsInfo.prototype.saveInfo = function (values) {
    var _this = this;

    var flag = true;

    for (var item in values) {
      if (values[item]) {
        flag = false;
      } else {
        delete values[item];
      }
    }

    if (flag) {
      this.$message.error('至少输入一项');
    } else {
      values['inbound_line_id'] = this.inbound_line_id;
      values['save_flag'] = this.saveFlag;
      this.innerAction.setActionAPI('/report/modify_head_logistics', common_service["a" /* CommonService */].getMenuCode('head-logistics-report'));
      this.publicService.modify(new http["RequestParams"](values, {
        loading: this.loadingService,
        innerAction: this.innerAction
      })).subscribe(function (data) {
        _this.submit();
      }, function (err) {
        _this.$message.error(err.message);
      });
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ModifyHeadLogisticsInfo.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ModifyHeadLogisticsInfo.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ModifyHeadLogisticsInfo.prototype, "inbound_line_id", void 0);

  ModifyHeadLogisticsInfo = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ModifyHeadLogisticsInfo);
  return ModifyHeadLogisticsInfo;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var modify_head_logistics_infovue_type_script_lang_ts_ = (modify_head_logistics_infovue_type_script_lang_ts_ModifyHeadLogisticsInfo);
// CONCATENATED MODULE: ./src/components/purchase/modify-head-logistics-info.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_modify_head_logistics_infovue_type_script_lang_ts_ = (modify_head_logistics_infovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/modify-head-logistics-info.vue?vue&type=custom&index=0&blockType=i18n
var modify_head_logistics_infovue_type_custom_index_0_blockType_i18n = __webpack_require__("7f8b");

// CONCATENATED MODULE: ./src/components/purchase/modify-head-logistics-info.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_modify_head_logistics_infovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof modify_head_logistics_infovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(modify_head_logistics_infovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var modify_head_logistics_info = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "13cb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_finish_item_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c58d");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_finish_item_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_finish_item_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "144a":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"purchase_detail":"Purchase Detail","reason":"Reason","name":"Name","quantity":"Quantity","cn_category":"Cn Category","color":"Color","material":"Material"},"return_reason":"Return Reason","submit":"Submit","cancel":"Cancel"},"zh-cn":{"columns":{"purchase_detail":"需求明细","reason":"退回原因","name":"物品","quantity":"数量","cn_category":"中文子类","color":"颜色","material":"材料"},"return_reason":"返回原因","submit":"提交","cancel":"取消"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "1474":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cancel_attention_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("36ff");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cancel_attention_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cancel_attention_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "1b27":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-modify-purchase-info.vue?vue&type=template&id=42c082bb&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('user_purchase')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_purchase']),expression:"['user_purchase']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' }}},_vm._l((_vm.userList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])}),1)],1)],1),_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('merchandiser')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['merchandiser']),expression:"['merchandiser']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' }}},_vm._l((_vm.userList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])}),1)],1)],1),_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id']),expression:"['vendor_id']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' }}},_vm._l((_vm.vendorList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])}),1)],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.submit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-modify-purchase-info.vue?vue&type=template&id=42c082bb&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-modify-purchase-info.vue?vue&type=script&lang=ts&









var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_modify_purchase_infovue_type_script_lang_ts_ChangePurchaseInfo =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ChangePurchaseInfo, _super);

  function ChangePurchaseInfo() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.moment = moment_default.a;
    return _this;
  }

  ChangePurchaseInfo.prototype.cancel = function () {};

  ChangePurchaseInfo.prototype.getVendorList = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('/vendor/get_vendor_list', common_service["a" /* CommonService */].getMenuCode('vendor-product-manage'));
    this.publicService.query(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.vendorList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ChangePurchaseInfo.prototype.mounted = function () {};

  ChangePurchaseInfo.prototype.created = function () {
    this.getVendorList();
    this.form = this.$form.createForm(this);
  };

  ChangePurchaseInfo.prototype.onSubmit = function () {
    return true;
  };

  ChangePurchaseInfo.prototype.submit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        if (values.merchandiser || values.user_purchase || values.vendor_id) {
          values['line_id_list'] = _this.ids;
          var inneraction = new inner_action_service["a" /* InnerActionService */]();
          inneraction.setActionAPI('purchase_requirement/change_purchase_info', common_service["a" /* CommonService */].getMenuCode('purchase-pre-make-order'));

          _this.publicService.modify(new http["RequestParams"](values, {
            loading: _this.loadingService,
            innerAction: inneraction
          })).subscribe(function (data) {
            _this.onSubmit();
          }, function (err) {
            _this.$message.error(err.message);
          });
        } else {
          _this.$message.error('至少输入一项');
        }
      }
    });
  };

  ChangePurchaseInfo.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ChangePurchaseInfo.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ChangePurchaseInfo.prototype, "ids", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ChangePurchaseInfo.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ChangePurchaseInfo.prototype, "userList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ChangePurchaseInfo.prototype, "onSubmit", null);

  ChangePurchaseInfo = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ChangePurchaseInfo);
  return ChangePurchaseInfo;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_modify_purchase_infovue_type_script_lang_ts_ = (purchase_modify_purchase_infovue_type_script_lang_ts_ChangePurchaseInfo);
// CONCATENATED MODULE: ./src/components/purchase/purchase-modify-purchase-info.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_modify_purchase_infovue_type_script_lang_ts_ = (purchase_modify_purchase_infovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/purchase-modify-purchase-info.vue?vue&type=custom&index=0&blockType=i18n
var purchase_modify_purchase_infovue_type_custom_index_0_blockType_i18n = __webpack_require__("241d");

// CONCATENATED MODULE: ./src/components/purchase/purchase-modify-purchase-info.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_modify_purchase_infovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_modify_purchase_infovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_modify_purchase_infovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_modify_purchase_info = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "1ef9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_ship_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f5d9");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_ship_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_ship_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_ship_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1f6d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"ship_date":"Ship Date","company_id":"Company","document_date":"Document Date","eta_date":"Eta Date","receive_date":"Receive Date","ref_no":"Ref No.","boat_company":"Carrier Company","bl_mode":"BL Mode","ship_company_id":"快递公司","bl_no":"BL No.","shipment_no":"快递单号","port_of_origin":"Prot Of Origin","port_of_arrival":"Port Of Arrival","batch_create":"Batch Create","delete":"Are you sure delete?","plzSelect":"Please Select","plzInput":"Please Input","columns":{"prod_name":"Prod Name","out_number":"Out Number","product_qty":"Product Qty","name":"Name","box_qty":"Box Qty","note":"Note","package_qty":"Package Qty","container_group":"Container Group","warehouse_id":"Warehouse","package_code":"Package Code","is_change_sku":"SKU Changed","action":"Action"},"action":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Cancel","ok":"OK"}},"zh-cn":{"ship_date":"发船日期","company_id":"公司","document_date":"Document Date","eta_date":"Eta Date","receive_date":"接收日期","ref_no":"Ref No.","boat_company":"船公司","bl_mode":"BL Mode","ship_company_id":"快递公司","bl_no":"BL No.","shipment_no":"快递单号","port_of_origin":"始发港","port_of_arrival":"到达港","batch_create":"批量创建","delete":"确定要删除吗？","plzSelect":"请选择","plzInput":"请输入","columns":{"prod_name":"产品","out_number":"Out Number","product_qty":"Product Qty","name":"Name","box_qty":"箱数","note":"Note","package_qty":"Package Qty","container_group":"Container Group","warehouse_id":"仓库","package_code":"集装箱号","is_change_sku":"SKU变更","action":"操作"},"action":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"取消","ok":"确定"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "2076":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_edit_vue_vue_type_style_index_0_id_a21480b0_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2161");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_edit_vue_vue_type_style_index_0_id_a21480b0_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_edit_vue_vue_type_style_index_0_id_a21480b0_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "2086":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/change-purchase-info.vue?vue&type=template&id=038f4076&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('user_purchase')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_purchase']),expression:"['user_purchase']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' }}},_vm._l((_vm.userList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])}),1)],1)],1),_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('merchandiser')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['merchandiser']),expression:"['merchandiser']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' }}},_vm._l((_vm.userList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])}),1)],1)],1),_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id']),expression:"['vendor_id']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' }}},_vm._l((_vm.vendorList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])}),1)],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/change-purchase-info.vue?vue&type=template&id=038f4076&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/change-purchase-info.vue?vue&type=script&lang=ts&









var datasModule = Object(lib["c" /* namespace */])('datasModule');

var change_purchase_infovue_type_script_lang_ts_ChangePurchaseInfo =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ChangePurchaseInfo, _super);

  function ChangePurchaseInfo() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.moment = moment_default.a;
    return _this;
  }

  ChangePurchaseInfo.prototype.cancel = function () {};

  ChangePurchaseInfo.prototype.getVendorList = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('/vendor/get_vendor_list', common_service["a" /* CommonService */].getMenuCode('vendor-product-manage'));
    this.publicService.query(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.vendorList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ChangePurchaseInfo.prototype.mounted = function () {};

  ChangePurchaseInfo.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ChangePurchaseInfo.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        var inneraction = new inner_action_service["a" /* InnerActionService */]();
        inneraction.setActionAPI('purchase_order_plan/confirm_change', common_service["a" /* CommonService */].getMenuCode('purchase-product-plan'));

        _this.publicService.modify(new http["RequestParams"]({
          id_list: _this.id_list,
          data: values
        }, {
          loading: _this.loadingService,
          innerAction: inneraction
        })).subscribe(function (data) {
          return true;
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ChangePurchaseInfo.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ChangePurchaseInfo.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ChangePurchaseInfo.prototype, "id_list", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ChangePurchaseInfo.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ChangePurchaseInfo.prototype, "userList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ChangePurchaseInfo.prototype, "onSubmit", null);

  ChangePurchaseInfo = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ChangePurchaseInfo);
  return ChangePurchaseInfo;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var change_purchase_infovue_type_script_lang_ts_ = (change_purchase_infovue_type_script_lang_ts_ChangePurchaseInfo);
// CONCATENATED MODULE: ./src/components/purchase/change-purchase-info.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_change_purchase_infovue_type_script_lang_ts_ = (change_purchase_infovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/change-purchase-info.vue?vue&type=custom&index=0&blockType=i18n
var change_purchase_infovue_type_custom_index_0_blockType_i18n = __webpack_require__("e7bd");

// CONCATENATED MODULE: ./src/components/purchase/change-purchase-info.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_change_purchase_infovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof change_purchase_infovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(change_purchase_infovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var change_purchase_info = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "2161":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "21c6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_depo_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ada3");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_depo_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_depo_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_depo_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "22f3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-package-edit.vue?vue&type=template&id=2c7157d8&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{ref:"customModal",staticClass:"component edit-customer"},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[(_vm.editAble)?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]):_vm._e(),(_vm.order.id && _vm.order.state == 'draft')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"type":"default","size":"small"},on:{"click":_vm.editChange}},[(!_vm.editAble)?_c('span',[_vm._v(_vm._s(_vm.$t('action.edit')))]):_c('span',[_vm._v(_vm._s(_vm.$t('action.discard')))])]):_vm._e(),(_vm.order.state == 'draft')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(_vm.order.state == 'confirm')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(['approved'].includes(_vm.order.state))?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('ship')}}},[_vm._v(" "+_vm._s(_vm.$t('action.ship'))+" ")]):_vm._e(),(['process', 'waiting', 'wait'].includes(_vm.order.state))?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('ship')}}},[_vm._v(" "+_vm._s(_vm.$t('action.set_to_ship'))+" ")]):_vm._e(),(_vm.order.state == 'ship')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('process')}}},[_vm._v(" "+_vm._s(_vm.$t('action.process_clearance'))+" ")]):_vm._e(),(_vm.order.state == 'process')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('waiting')}}},[_vm._v(" "+_vm._s(_vm.$t('action.waiting_arrange_in'))+" ")]):_vm._e(),(_vm.order.state == 'waiting')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('wait')}}},[_vm._v(" "+_vm._s(_vm.$t('action.waiting_in'))+" ")]):_vm._e(),(_vm.order.state == 'wait')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('land')}}},[_vm._v(" "+_vm._s(_vm.$t('action.land'))+" ")]):_vm._e(),(_vm.order.state == 'cancel')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.set_to_draft'))+" ")]):_vm._e(),(['approved', 'confirm', 'ship'].includes(_vm.order.state))?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('cancel')}}},[_vm._v(" "+_vm._s(_vm.$t('action.cancel'))+" ")]):_vm._e(),(_vm.order.state == 'wait')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onLandIn()}}},[_vm._v(" "+_vm._s(_vm.$t('action.land_in'))+" ")]):_vm._e(),(_vm.order.state == 'wait' || _vm.order.state == 'waiting')?_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.inbound()}}},[_vm._v(" "+_vm._s(_vm.$t('action.inbound'))+" ")]):_vm._e(),_c('div',{staticStyle:{"position":"absolute","top":"10px","right":"10px"}},[_c('div',{staticClass:"progress-bar"},_vm._l((_vm.$dict.PackageOrderState),function(item){return _c('li',{key:item.value,class:{ active: _vm.order.state == item.value },staticStyle:{"font-size":"12px"},attrs:{"value":item.value}},[_c('span',[_vm._v(_vm._s(_vm.$t(item.label)))])])}),0)])],1),_c('section',{staticClass:"component edit-customer"},[_c('a-form',{attrs:{"form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-card',{staticClass:"margin-top order-edit-page"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["name"]),expression:"[`name`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('ship_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["ship_date"]),expression:"[`ship_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('de_po')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["de_po"]),expression:"[`de_po`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('land_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["land_date"]),expression:"[`land_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('company_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'company_name',
                                        { initialValue: '' }
                                    ]),expression:"[\n                                        'company_name',\n                                        { initialValue: '' }\n                                    ]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select","disabled":!_vm.editAble}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('none'))+" ")]),_c('a-select-option',{key:"woltu",attrs:{"value":"woltu"}},[_vm._v(" Woltu ")]),_c('a-select-option',{key:"eugad",attrs:{"value":"eugad"}},[_vm._v(" EUGAD ")]),_c('a-select-option',{key:"situ",attrs:{"value":"situ"}},[_vm._v(" Situ ")]),_c('a-select-option',{key:"elight",attrs:{"value":"elight"}},[_vm._v(" Elight ")]),_c('a-select-option',{key:"wowo",attrs:{"value":"wowo"}},[_vm._v(" Wowo ")]),_c('a-select-option',{key:"meteorsrain",attrs:{"value":"meteorsrain"}},[_vm._v(" Meteorsrain ")]),_c('a-select-option',{key:"brichimon",attrs:{"value":"brichimon"}},[_vm._v(" BRICHIMON LIMITED ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('etd_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["etd_date"]),expression:"[`etd_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD hh:mm","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('make_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'make_user',
                                        { initialValue: '' }
                                    ]),expression:"[\n                                        'make_user',\n                                        { initialValue: '' }\n                                    ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption,"disabled":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('none'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('af_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["af_date"]),expression:"[`af_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('approved_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'approved_user',
                                        { initialValue: '' }
                                    ]),expression:"[\n                                        'approved_user',\n                                        { initialValue: '' }\n                                    ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption,"disabled":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('none'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('yd_state')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["yd_state"]),expression:"[`yd_state`]"}],attrs:{"checked":_vm.order.yd_state,"disabled":!_vm.editAble},on:{"change":function (e) { return _vm.onCheckboxChange('yd_state', e); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('doc_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["doc_date"]),expression:"[`doc_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('yd_merge_time')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["yd_merge_time"]),expression:"[`yd_merge_time`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('recv_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["recv_date"]),expression:"[`recv_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('yd_memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["yd_memo"]),expression:"[`yd_memo`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('done_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["done_date"]),expression:"[`done_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('source_doc1')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["source_doc1"]),expression:"[`source_doc1`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('expect_eta'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "expect_eta",
                                        {
                                            rule: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `expect_eta`,\n                                        {\n                                            rule: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('carrier_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["carrier_name"]),expression:"[`carrier_name`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('expect_etd'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "expect_etd",
                                        {
                                            rule: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `expect_etd`,\n                                        {\n                                            rule: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('bl_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["bl_code"]),expression:"[`bl_code`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('predict_eta')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["predict_eta"]),expression:"[`predict_eta`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('package_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["package_code"]),expression:"[`package_code`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('predict_eta_memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["predict_eta_memo"]),expression:"[`predict_eta_memo`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('bl_xingshi')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'bl_xingshi',
                                        { initialValue: '' }
                                    ]),expression:"[\n                                        'bl_xingshi',\n                                        { initialValue: '' }\n                                    ]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select","disabled":!_vm.editAble}},[_c('a-select-option',{key:"zf",attrs:{"value":"zf"}},[_vm._v(" OBL ")]),_c('a-select-option',{key:"df",attrs:{"value":"df"}},[_vm._v(" TR ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('change_etd_memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["change_etd_memo"]),expression:"[`change_etd_memo`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('express_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'express_name',
                                        { initialValue: '' }
                                    ]),expression:"[\n                                        'express_name',\n                                        { initialValue: '' }\n                                    ]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select","disabled":!_vm.editAble}},[_c('a-select-option',{key:"tnt",attrs:{"value":"tnt"}},[_vm._v(" TNT ")]),_c('a-select-option',{key:"dhl",attrs:{"value":"dhl"}},[_vm._v(" DHL ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('pre_status')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["pre_status"]),expression:"[`pre_status`]"}],attrs:{"checked":_vm.order.pre_status,"disabled":!_vm.editAble},on:{"change":function (e) { return _vm.onCheckboxChange(
                                                'pre_status',
                                                e
                                            ); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('shipment_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["shipment_number"]),expression:"[`shipment_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('warehouse_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'warehouse_id',
                                        { initialValue: '' }
                                    ]),expression:"[\n                                        'warehouse_id',\n                                        { initialValue: '' }\n                                    ]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select","disabled":!_vm.editAble}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('none'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('clearance_data_submit_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "clearance_data_submit_date"
                                    ]),expression:"[\n                                        `clearance_data_submit_date`\n                                    ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('real_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["real_date"]),expression:"[`real_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('bl_finish_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["bl_finish_date"]),expression:"[`bl_finish_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('is_pd')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["is_pd"]),expression:"[`is_pd`]"}],attrs:{"checked":_vm.order.is_pd,"disabled":!_vm.editAble},on:{"change":function (e) { return _vm.onCheckboxChange('is_pd', e); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('port_start')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["port_start"]),expression:"[`port_start`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),(!_vm.domain.includes('47.254.148.130:58180'))?_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('ist_aushilfe')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["ist_aushilfe"]),expression:"[`ist_aushilfe`]"}],attrs:{"checked":_vm.order.ist_aushilfe,"disabled":!_vm.editAble},on:{"change":function (e) { return _vm.onCheckboxChange(
                                                'ist_aushilfe',
                                                e
                                            ); }}})],1)],1):_vm._e(),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('port_end')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'port_end',
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        'port_end',\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],style:({
                                        width: '100%',
                                        'max-width': '240px'
                                    }),attrs:{"showSearch":"","size":"small","disabled":!_vm.editAble,"placeholder":"Please Select"}},[_c('a-select-option',{key:"Felix",attrs:{"value":"Felix"}},[_vm._v(" Felix ")]),_c('a-select-option',{key:"Rotterdam",attrs:{"value":"Rotterdam"}},[_vm._v(" Rotterdam ")]),_c('a-select-option',{key:"southampton",attrs:{"value":"southampton"}},[_vm._v(" SOUTHAMPTON ")])],1)],1)],1),(!_vm.domain.includes('47.254.148.130:58180'))?_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('aushilfe_note')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["aushilfe_note"]),expression:"[`aushilfe_note`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1):_vm._e(),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('note_text')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["note_text"]),expression:"[`note_text`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('display_stock_in')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["display_stock_in"]),expression:"[`display_stock_in`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('ist_number_qty')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["ist_number_qty"]),expression:"[`ist_number_qty`]"}],attrs:{"checked":_vm.order.ist_number_qty,"disabled":!_vm.editAble},on:{"change":function (e) { return _vm.onCheckboxChange(
                                                'ist_number_qty',
                                                e
                                            ); }}})],1)],1)],1)],1)],1),_c('div',[_c('a-button',{staticStyle:{"margin-top":"20px"},attrs:{"type":"primary","size":"small"},on:{"click":_vm.addProduct}},[_vm._v(" "+_vm._s(_vm.$t('action.add_product'))+" ")]),_c('a-button',{staticStyle:{"margin":"20px 0 0 10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":_vm.giveAktuValue}},[_vm._v(" "+_vm._s(_vm.$t('action.aktu_value'))+" ")]),_c('a-button',{staticStyle:{"margin":"20px 0 0 10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":_vm.writeF4}},[_vm._v(" "+_vm._s(_vm.$t('action.write_f4'))+" ")]),_c('a-button',{staticStyle:{"margin":"20px 0 0 10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":_vm.rWarehouse}},[_vm._v(" "+_vm._s(_vm.$t('action.r_warehouse'))+" ")]),_c('a-button',{staticStyle:{"margin":"20px 0 0 10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":_vm.tWarehouse}},[_vm._v(" "+_vm._s(_vm.$t('action.t_warehouse'))+" ")]),_c('a-button',{staticStyle:{"margin":"20px 0 0 10px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":_vm.isBoxQty}},[_vm._v(" "+_vm._s(_vm.$t('action.is_box_qty'))+" ")])],1),_c('a-tabs',{staticStyle:{"margin-top":"10px"},attrs:{"defaultActiveKey":"base","type":"card"}},[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('requirement_lines')}},[_c('div',{staticStyle:{"margin":"10px"}},[_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('W-sub1')}}},[_vm._v("Sub1 W ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('M-sub2')}}},[_vm._v("Sub2 M ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('S-sub3')}}},[_vm._v("Sub3 S ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('UK-sub4')}}},[_vm._v("Sub4 UK ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('J-sub5')}}},[_vm._v("Sub5 J ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('E-sub6')}}},[_vm._v("Sub6 E ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('T-sub7')}}},[_vm._v("Sub7 T ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('R-sub8')}}},[_vm._v("Sub8 R ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('F-sub9')}}},[_vm._v("Sub9 F ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('FBA-loc-S')}}},[_vm._v("FBA-S ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('FBA-loc-R')}}},[_vm._v("FBA-R ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('FBA-loc-T')}}},[_vm._v("FBA-T ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('FBA-loc-W')}}},[_vm._v("FBA-W ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.changeLocationId('FBA-loc-UK')}}},[_vm._v("FBA-UK ")])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.orderDetail,"pagination":false,"rowKey":"id","columns":_vm.detailColumns,"rowSelection":{
                            selectedRowKeys: _vm.selectedRowKeys,
                            onChange: function (keys) { return (_vm.selectedRowKeys = keys); },
                            getCheckboxProps: function (record) { return ({
                                props: {
                                    disabled: record.id === 'summary', // Column configuration not to be checked
                                    id: String(record.id)
                                }
                            }); }
                        },"customRow":function (record) { return ({
                                on: {
                                    click: function () {
                                        this$1.selectedRowKeys = [record.id]
                                        _vm.onTbRowClick(record)
                                    }
                                }
                            }); },"scroll":{ x: 2000, y: 300 },"bordered":""},scopedSlots:_vm._u([{key:"aktu_box_qty",fn:function(row){return [(
                                    _vm.editAble &&
                                        row.id == _vm.currentLi &&
                                        row.id != 'summary'
                                )?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["aktu_box_qty"]),expression:"[`aktu_box_qty`]"}],style:({
                                    width: '100%',
                                    background: '#ecc5e9'
                                }),attrs:{"value":row.aktu_box_qty,"size":"small","min":0},on:{"change":function (e) { return _vm.onRowChange(row, 'aktu_box_qty', e); }}}):_c('span',[_vm._v(_vm._s(row.aktu_box_qty))])]}},{key:"aktu_package_qty",fn:function(row){return [(
                                    _vm.editAble &&
                                        row.id == _vm.currentLi &&
                                        row.id != 'summary'
                                )?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["aktu_package_qty"]),expression:"[`aktu_package_qty`]"}],style:({
                                    width: '100%',
                                    background: '#ecc5e9'
                                }),attrs:{"value":row.aktu_package_qty,"size":"small","min":0},on:{"change":function (e) { return _vm.onRowChange(
                                            row,
                                            'aktu_package_qty',
                                            e
                                        ); }}}):_c('span',[_vm._v(_vm._s(row.aktu_package_qty))])]}},{key:"cp_note",fn:function(row){return [(
                                    _vm.editAble &&
                                        row.id == _vm.currentLi &&
                                        row.id != 'summary'
                                )?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["cp_note"]),expression:"[`cp_note`]"}],style:({
                                    width: '100%',
                                    background: '#ecc5e9'
                                }),attrs:{"value":row.cp_note,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'cp_note', e); }}}):_c('span',[_vm._v(_vm._s(row.cp_note))])]}},{key:"import_memo",fn:function(row){return [(
                                    _vm.editAble &&
                                        row.id == _vm.currentLi &&
                                        row.id != 'summary'
                                )?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["import_memo"]),expression:"[`import_memo`]"}],style:({
                                    width: '100%',
                                    background: '#ecc5e9'
                                }),attrs:{"value":row.import_memo,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'import_memo', e); }}}):_c('span',[_vm._v(_vm._s(row.import_memo))])]}},{key:"note",fn:function(row){return [(
                                    _vm.editAble &&
                                        row.id == _vm.currentLi &&
                                        row.id != 'summary'
                                )?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["note"]),expression:"[`note`]"}],style:({
                                    width: '100%',
                                    background: '#ecc5e9'
                                }),attrs:{"value":row.note,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'note', e); }}}):_c('span',[_vm._v(_vm._s(row.note))])]}},{key:"write_product_f4",fn:function(row){return [(
                                    _vm.editAble &&
                                        row.id == _vm.currentLi &&
                                        row.id != 'summary'
                                )?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["write_product_f4"]),expression:"[`write_product_f4`]"}],style:({
                                    width: '100%',
                                    background: '#ecc5e9'
                                }),attrs:{"value":row.write_product_f4,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(
                                            row,
                                            'write_product_f4',
                                            e
                                        ); }}}):_c('span',[_vm._v(_vm._s(row.write_product_f4))])]}},{key:"is_fba",fn:function(row){return [(row.id != 'summary')?_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["is_fba"]),expression:"[`is_fba`]"}],attrs:{"disabled":!_vm.editAble || row.id !== _vm.currentLi,"checked":row.is_fba},on:{"change":function (e) { return _vm.onRowChange(
                                            row,
                                            'is_fba',
                                            e.target.checked
                                        ); }}}):_vm._e()]}},{key:"is_change_sku",fn:function(row){return [(row.id != 'summary')?_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["is_change_sku"]),expression:"[`is_change_sku`]"}],attrs:{"disabled":!_vm.editAble || row.id !== _vm.currentLi,"checked":row.is_change_sku},on:{"change":function (e) { return _vm.onRowChange(
                                            row,
                                            'is_change_sku',
                                            e.target.checked
                                        ); }}}):_vm._e()]}},{key:"ist_box_qty",fn:function(row){return [_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["ist_box_qty"]),expression:"[`ist_box_qty`]"}],attrs:{"disabled":"","checked":row && row.ist_box_qty}})]}},{key:"location_id",fn:function(row){return [(
                                    _vm.editAble &&
                                        row.id == _vm.currentLi &&
                                        row.id != 'summary'
                                )?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["location_id"]),expression:"[`location_id`]"}],style:({
                                    width: '100%',
                                    background: '#ecc5e9'
                                }),attrs:{"value":row.location_id,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'location_id', e); }}}):_c('span',[_vm._v(_vm._s(_vm.locationDict[parseInt(row.location_id)]))])]}},{key:"action",fn:function(row){return [(row.id != 'summary')?_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a',{staticClass:"btnDel"},[_vm._v(_vm._s(_vm.$t('action.delete')))])]):_vm._e()]}}])})],1),_c('a-tab-pane',{key:"info",attrs:{"tab":_vm.$t('logistic_info')}},[_c('a-form',{attrs:{"form":_vm.form2,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('ship_line')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "ship_line",
                                            {
                                                initialValue:
                                                    _vm.order.ship_line
                                            }
                                        ]),expression:"[\n                                            `ship_line`,\n                                            {\n                                                initialValue:\n                                                    order.ship_line\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('seal_num')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "seal_num",
                                            {
                                                initialValue: _vm.order.seal_num
                                            }
                                        ]),expression:"[\n                                            `seal_num`,\n                                            {\n                                                initialValue: order.seal_num\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('thc_invoice')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "thc_invoice",
                                            {
                                                initialValue:
                                                    _vm.order.thc_invoice
                                            }
                                        ]),expression:"[\n                                            `thc_invoice`,\n                                            {\n                                                initialValue:\n                                                    order.thc_invoice\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('size_type')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "size_type",
                                            {
                                                initialValue:
                                                    _vm.order.size_type
                                            }
                                        ]),expression:"[\n                                            `size_type`,\n                                            {\n                                                initialValue:\n                                                    order.size_type\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('vessel')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "vessel",
                                            {
                                                initialValue: _vm.order.vessel
                                            }
                                        ]),expression:"[\n                                            `vessel`,\n                                            {\n                                                initialValue: order.vessel\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('netto_weight')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "netto_weight",
                                            {
                                                initialValue:
                                                    _vm.order.netto_weight
                                            }
                                        ]),expression:"[\n                                            `netto_weight`,\n                                            {\n                                                initialValue:\n                                                    order.netto_weight\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('terminal')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "terminal",
                                            {
                                                initialValue: _vm.order.terminal
                                            }
                                        ]),expression:"[\n                                            `terminal`,\n                                            {\n                                                initialValue: order.terminal\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('goods_description')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "goods_description",
                                            {
                                                initialValue:
                                                    _vm.order.goods_description
                                            }
                                        ]),expression:"[\n                                            `goods_description`,\n                                            {\n                                                initialValue:\n                                                    order.goods_description\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('trans_model')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            'trans_model',
                                            {
                                                initialValue:
                                                    _vm.order.trans_model
                                            }
                                        ]),expression:"[\n                                            'trans_model',\n                                            {\n                                                initialValue:\n                                                    order.trans_model\n                                            }\n                                        ]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select","disabled":!_vm.editAble}},[_c('a-select-option',{key:"Barge",attrs:{"value":"Barge"}},[_vm._v(" Barge ")]),_c('a-select-option',{key:"Rail",attrs:{"value":"Rail"}},[_vm._v(" Rail ")]),_c('a-select-option',{key:"Truck",attrs:{"value":"Truck"}},[_vm._v(" Truck ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('empty_depot')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "empty_depot",
                                            {
                                                initialValue:
                                                    _vm.order.empty_depot
                                            }
                                        ]),expression:"[\n                                            `empty_depot`,\n                                            {\n                                                initialValue:\n                                                    order.empty_depot\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('pick_terminal')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "pick_terminal",
                                            {
                                                initialValue:
                                                    _vm.order.pick_terminal
                                            }
                                        ]),expression:"[\n                                            `pick_terminal`,\n                                            {\n                                                initialValue:\n                                                    order.pick_terminal\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('pick_reference')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "pick_reference",
                                            {
                                                initialValue:
                                                    _vm.order.pick_reference
                                            }
                                        ]),expression:"[\n                                            `pick_reference`,\n                                            {\n                                                initialValue:\n                                                    order.pick_reference\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('demurrage_time')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "demurrage_time",
                                            {
                                                initialValue:
                                                    _vm.order.demurrage_time
                                            }
                                        ]),expression:"[\n                                            `demurrage_time`,\n                                            {\n                                                initialValue:\n                                                    order.demurrage_time\n                                            }\n                                        ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1)],1)],1)],1)],1)],1)])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-package-edit.vue?vue&type=template&id=2c7157d8&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/purchase/change-give-date-form.vue + 4 modules
var change_give_date_form = __webpack_require__("7aba");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// EXTERNAL MODULE: ./src/components/purchase/add-package-order-product.vue + 4 modules
var add_package_order_product = __webpack_require__("3c91");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/inboundPlan.vue?vue&type=template&id=609388a0&
var inboundPlanvue_type_template_id_609388a0_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('a-form-model',{ref:"inboundForm",attrs:{"model":_vm.inboundForm,"rules":_vm.inboundRules,"label-col":{ span: 5 },"wrapper-col":{ span: 14 }}},[_c('a-form-model-item',{attrs:{"label":_vm.$t('whs_id'),"prop":"whs_id"}},[_c('a-select',{staticStyle:{"width":"240px"},attrs:{"size":"small","placeholder":_vm.$t('plzSelectWhs')},model:{value:(_vm.inboundForm.whs_id),callback:function ($$v) {_vm.$set(_vm.inboundForm, "whs_id", $$v)},expression:"inboundForm.whs_id"}},_vm._l((_vm.whsIDList),function(item){return _c('a-select-option',{key:item.id,attrs:{"value":item.id}},[_vm._v(_vm._s(item.whs_name)+" ")])}),1)],1),_c('a-form-model-item',{attrs:{"label":_vm.$t('plan_date'),"prop":"plan_finish_date"}},[_c('a-date-picker',{style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('plzSelectDate')},model:{value:(_vm.inboundForm.plan_finish_date),callback:function ($$v) {_vm.$set(_vm.inboundForm, "plan_finish_date", $$v)},expression:"inboundForm.plan_finish_date"}})],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit'))+" ")])],1)],1)}
var inboundPlanvue_type_template_id_609388a0_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/inboundPlan.vue?vue&type=template&id=609388a0&

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/inboundPlan.vue?vue&type=script&lang=ts&











var inboundPlanvue_type_script_lang_ts_inboundPlan =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](inboundPlan, _super);

  function inboundPlan() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.inboundForm = {
      whs_id: undefined,
      plan_finish_date: ''
    };
    _this.inboundRules = {
      whs_id: [{
        required: true,
        message: _this.$t('plzSelectWhs'),
        trigger: 'change'
      }],
      plan_finish_date: [{
        required: true,
        message: _this.$t('plzSelectDate'),
        trigger: 'change'
      }]
    };
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.moment = moment_default.a;
    _this.whsIDList = [];
    return _this;
  }

  inboundPlan.prototype.submit = function () {
    return true;
  };

  inboundPlan.prototype.cancel = function () {
    return;
  };

  inboundPlan.prototype.created = function () {
    this.getWhsList();
  };

  inboundPlan.prototype.getWhsList = function () {
    var _this = this;

    this.innerAction.setActionAPI('wms/whs/query_whs', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.query(new http["RequestParams"]({}, {
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.whsIDList = data;
    });
  };

  inboundPlan.prototype.onSubmit = function () {
    var _this = this;

    var ref = this.$refs['inboundForm'];
    ref.validate(function (valid) {
      if (valid) {
        _this.innerAction.setActionAPI('wms/purchase/create_product_location_operation_no_items', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));

        _this.inboundForm.package_name = _this.name;
        _this.inboundForm.plan_finish_date = moment_default()(_this.inboundForm.plan_finish_date).format('YYYY-MM-DD');

        _this.publicService.modify(new http["RequestParams"](_this.inboundForm, {
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.submit();
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], inboundPlan.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], inboundPlan.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], inboundPlan.prototype, "name", void 0);

  inboundPlan = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'inboundPlan'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], inboundPlan);
  return inboundPlan;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var inboundPlanvue_type_script_lang_ts_ = (inboundPlanvue_type_script_lang_ts_inboundPlan);
// CONCATENATED MODULE: ./src/components/purchase/inboundPlan.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_inboundPlanvue_type_script_lang_ts_ = (inboundPlanvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/inboundPlan.vue?vue&type=custom&index=0&blockType=i18n
var inboundPlanvue_type_custom_index_0_blockType_i18n = __webpack_require__("32fe");

// CONCATENATED MODULE: ./src/components/purchase/inboundPlan.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_inboundPlanvue_type_script_lang_ts_,
  inboundPlanvue_type_template_id_609388a0_render,
  inboundPlanvue_type_template_id_609388a0_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof inboundPlanvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(inboundPlanvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_inboundPlan = (component.exports);
// EXTERNAL MODULE: ./src/services/location.service.ts
var location_service = __webpack_require__("e73b");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-package-edit.vue?vue&type=script&lang=ts&
























var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');
var userModule = Object(lib["c" /* namespace */])('userModule');

var purchase_package_editvue_type_script_lang_ts_PurchasePackageEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchasePackageEdit, _super);

  function PurchasePackageEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.locationService = new location_service["a" /* LocationService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.order = [];
    _this.orderDetail = [];
    _this.locationList = [];
    _this.locationDict = {};
    _this.save_flag = 0;
    _this.originData = [];
    _this.isShowDetail = false; //是否只是详情展示

    _this.menu_code = '';
    _this.editAble = false;
    _this.currentLi = '';
    _this.detailColumns = [];
    _this.selectedRowKeys = [];
    _this.summaryList = ['package_qty', 'aktu_box_qty'];
    _this.domain = '';
    _this.topDepartmentList = [];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  Object.defineProperty(PurchasePackageEdit.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });

  PurchasePackageEdit.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;
      this.updateOrder(this.info);
    }
  };

  PurchasePackageEdit.prototype.onDataChange = function () {
    if (this.orderDetail.length) {
      var sm = this.orderDetail.find(function (x) {
        return x.id == 'summary';
      });

      if (sm) {
        var ret = common_service["a" /* CommonService */].getSummaryData(this.orderDetail, this.summaryList);

        for (var _i = 0, _a = this.summaryList; _i < _a.length; _i++) {
          var i = _a[_i];
          sm[i] = ret[i];
        }
      }
    }
  };

  PurchasePackageEdit.prototype.updateOrder = function (order) {
    this.originData = order; // this.$nextTick(() => {

    this.order = order[0];
    this.save_flag = 1;
    this.editAble = false;
    this.orderDetail = this.order.package_lines.map(function (x) {
      return x;
    });
    this.selectedRowKeys = []; // })

    this.setFormValues();

    if (this.summaryList != undefined && this.summaryList.length && this.orderDetail.length) {
      var sm = this.orderDetail.find(function (x) {
        return x.id == 'summary';
      });
      var ret = common_service["a" /* CommonService */].getSummaryData(this.orderDetail, this.summaryList);

      if (sm) {
        for (var _i = 0, _a = this.summaryList; _i < _a.length; _i++) {
          var i = _a[_i];
          sm[i] = ret[i];
        }
      } else {
        ret['id'] = 'summary';
        this.orderDetail.push(ret);
        this.$nextTick(function () {
          var querySelector = 'tr[data-row-key="summary"]';
          var tr = document.querySelector(querySelector);
          tr.style.background = '#fdfdfd';
        });
      }
    }
  };

  PurchasePackageEdit.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
    this.getLocationList();
    this.getDepartmentList();
    this.topDepartmentList = this.departmentList.filter(function (x) {
      return x.dept_type == 30;
    });
    this.form = this.$form.createForm(this);
    this.form2 = this.$form.createForm(this);
  };

  PurchasePackageEdit.prototype.mounted = function () {
    var _this = this;

    this.detailColumns = [{
      key: 'default_code',
      title: this.$t('columns.default_code'),
      dataIndex: 'default_code',
      width: 100
    }, {
      key: 'package_qty',
      title: this.$t('columns.package_qty'),
      dataIndex: 'package_qty',
      align: 'right',
      width: 100
    }, {
      key: 'aktu_box_qty',
      title: this.$t('columns.aktu_box_qty'),
      width: 100,
      align: 'right',
      scopedSlots: {
        customRender: 'aktu_box_qty'
      }
    }, {
      key: 'box_qty',
      title: this.$t('columns.box_qty'),
      dataIndex: 'box_qty',
      align: 'right',
      width: 100
    }, {
      key: 'aktu_package_qty',
      title: this.$t('columns.aktu_package_qty'),
      width: 100,
      align: 'right',
      scopedSlots: {
        customRender: 'aktu_package_qty'
      }
    }, {
      key: 'length',
      title: this.$t('columns.length'),
      dataIndex: 'length',
      align: 'right',
      width: 100
    }, {
      key: 'width',
      title: this.$t('columns.width'),
      dataIndex: 'width',
      align: 'right',
      width: 100
    }, {
      key: 'height',
      title: this.$t('columns.height'),
      dataIndex: 'height',
      align: 'right',
      width: 100
    }, {
      key: 'gewicht',
      title: this.$t('columns.gewicht'),
      dataIndex: 'gewicht',
      align: 'right',
      width: 100
    }, {
      key: 'is_fba',
      title: this.$t('columns.is_fba'),
      width: 100,
      align: 'center',
      scopedSlots: {
        customRender: 'is_fba'
      }
    }, {
      key: 'is_change_sku',
      title: this.$t('columns.is_change_sku'),
      width: 100,
      align: 'center',
      scopedSlots: {
        customRender: 'is_change_sku'
      }
    }, {
      key: 'change_no',
      title: this.$t('columns.change_no'),
      dataIndex: 'change_no',
      align: 'left',
      width: 120
    }, {
      key: 'cp_note',
      title: this.$t('columns.cp_note'),
      width: 100,
      scopedSlots: {
        customRender: 'cp_note'
      }
    }, {
      key: 'import_memo',
      title: this.$t('columns.import_memo'),
      width: 100,
      scopedSlots: {
        customRender: 'import_memo'
      }
    }, {
      key: 'ist_box_qty',
      title: this.$t('columns.ist_box_qty'),
      dataIndex: 'ist_box_qty',
      align: 'center',
      width: 100,
      scopedSlots: {
        customRender: 'ist_box_qty'
      }
    }, {
      key: 'location_id',
      title: this.$t('columns.location_id'),
      width: 100,
      scopedSlots: {
        customRender: 'location_id'
      }
    }, {
      key: 'note',
      title: this.$t('columns.note'),
      width: 100,
      scopedSlots: {
        customRender: 'note'
      }
    }, {
      key: 'order2_id',
      title: this.$t('columns.order2_id'),
      dataIndex: 'order2_id',
      width: 100
    }, {
      key: 'out_number',
      title: this.$t('columns.out_number'),
      dataIndex: 'out_number',
      width: 100
    }, {
      key: 'pack_qty',
      title: this.$t('columns.pack_qty'),
      dataIndex: 'pack_qty',
      align: 'right',
      width: 100
    }, {
      key: 'pre_sale',
      title: this.$t('columns.pre_sale'),
      dataIndex: 'pre_sale',
      width: 100
    }, {
      key: 'product_id',
      title: this.$t('columns.product_id'),
      dataIndex: 'product_id',
      width: 100
    }, {
      key: 'dept_id',
      title: this.$t('columns.dept_id'),
      dataIndex: 'dept_id',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getDepartName(value);
        }

        return value;
      }
    }, {
      key: 'state',
      title: this.$t('columns.state'),
      dataIndex: 'state',
      width: 100
    }, {
      key: 'write_product_f4',
      title: this.$t('columns.write_product_f4'),
      width: 100,
      scopedSlots: {
        customRender: 'write_product_f4'
      }
    }, {
      key: 'action',
      title: this.$t('action.action'),
      width: 80,
      fixed: 'right',
      scopedSlots: {
        customRender: 'action'
      }
    }];

    if (this.save_flag == 0) {
      this.editAble = true;
    }

    if (this.info) {
      this.updateOrder(this.info);
    }

    if (!this.menu_code) {
      this.menu_code = common_service["a" /* CommonService */].getMenuCode('replenishment-demand');
    }

    this.domain = window.location.host;
  };

  PurchasePackageEdit.prototype.setFormValues = function () {
    var values = this.form.getFieldsValue();
    var values2 = this.form2.getFieldsValue();

    for (var i in values) {
      values[i] = this.order[i];
    }

    for (var j in values2) {
      values2[j] = this.order[j];
    }

    this.form.setFieldsValue(values);
    this.form2.setFieldsValue(values2); // if (this.order.is_pd) {
    //     let is_pd: any = window.document.getElementById('is_pd')
    //     is_pd.parentNode.className = 'ant-checkbox ant-checkbox-checked'
    // }
  };

  PurchasePackageEdit.prototype.onCheckboxChange = function (id, e) {
    var dm = window.document.getElementById(id);

    if (e.target.checked) {
      dm.parentNode.className = 'ant-checkbox ant-checkbox-checked';
      dm.checked = true;
    } else {
      dm.parentNode.className = 'ant-checkbox';
      dm.checked = false;
    }

    var values = this.form.getFieldsValue();
    values[id] = e.target.checked;
    this.form.setFieldsValue(values);
  };

  PurchasePackageEdit.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchasePackageEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      values['id'] = _this.order.id;
      delete values['pre_status']; // for (let i of this.orderDetail) {
      //     if (
      //         i.aktu_box_qty < 1 ||
      //         i.aktu_package_qty < 1 ||
      //         !i.cp_note ||
      //         !i.import_memo ||
      //         i.location_id < 1 ||
      //         !i.note ||
      //         !i.write_product_f4
      //     ) {
      //         this.$message.error('请先完善明细中的信息,深色背景为必填项')
      //         return
      //     }
      // }

      values['package_lines'] = _this.orderDetail.filter(function (y) {
        return y.id != 'summary';
      }).map(function (x) {
        return {
          aktu_box_qty: x.aktu_box_qty,
          aktu_package_qty: x.aktu_package_qty,
          cp_note: x.cp_note,
          id: x.id,
          import_memo: x.import_memo,
          is_fba: x.is_fba,
          location_id: x.location_id,
          note: x.note,
          is_change_sku: x.is_change_sku ? x.is_change_sku : false,
          write_product_f4: x.write_product_f4
        };
      });

      _this.form2.validateFields().then(function (values2) {
        for (var i in values2) {
          values[i] = values2[i];
        }

        _this.innerAction.setActionAPI('purchase_management/save_package_order', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));

        _this.publicService.modify(new http["RequestParams"](values, {
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.$message.success(msg);
        }, function (err) {
          _this.$message.error(err.message);
        });
      });
    });
  };

  PurchasePackageEdit.prototype.editChange = function () {
    this.editAble = !this.editAble;
    var pageId = 'purchasepackageedit' + this.order.id;
    var item = this.commonPageInfo.find(function (x) {
      return x.index == pageId;
    });

    if (item) {
      if (this.editAble) {
        item.edit = 1;
      } else {
        item.edit = 0;
      }
    }
  };

  PurchasePackageEdit.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePackageEdit.prototype.getVendorName = function (code) {
    var ret = code;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePackageEdit.prototype.onDelete = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_package_order_line', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_id_list: [row.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.orderDetail = _this.orderDetail.filter(function (x) {
        return x.id != row.id;
      });

      _this.onDataChange(); //更新缓存


      var pageId = 'purchasepackageedit' + _this.order.id;

      var item = _this.commonPageInfo.find(function (x) {
        return x.index == pageId;
      });

      if (item) {
        item.info[0].package_lines = _this.orderDetail;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.onChangeGiveDate = function () {
    var _this = this;

    this.$modal.open(change_give_date_form["a" /* default */], {}, {
      title: this.$t('action.change_give_date')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('purchase_management/update_purchase_order_line_give_date', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));

      _this.publicService.modify(new http["RequestParams"]({
        line_id_list: _this.selectedRowKeys,
        change_give_date: data.change_give_date,
        change_give_date_memo: data.change_give_date_memo
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.importInfo = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      values['id'] = _this.order.id;

      _this.$modal.open(upload_excel["a" /* default */], {
        urlPath: '/ship_order/upload_ship_order_items&menu_code=' + common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'),
        uploadParams: values
      }, {
        title: 'Import',
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  PurchasePackageEdit.prototype.onTbRowClick = function (row) {
    this.currentLi = row.id;
  };

  PurchasePackageEdit.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target != undefined && value.target.value != undefined) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }

    if (column == 'aktu_box_qty') {
      this.onDataChange();
    }
  };

  PurchasePackageEdit.prototype.addProduct = function () {
    var _this = this;

    this.$modal.open(add_package_order_product["a" /* default */], {
      package_id: this.order.id,
      departmentList: this.topDepartmentList
    }, {
      title: this.$t('action.add_product'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.refreshLines();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.giveAktuValue = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/button_give_aktu_value', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.orderDetail.filter(function (y) {
        return _this.selectedRowKeys.includes(y.id);
      }).map(function (x) {
        x.aktu_package_qty = x.product_qty;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.writeF4 = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/change_purchase_line_write_product_f4', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.rWarehouse = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/change_product_f4_W_to_R', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.tWarehouse = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/change_product_f4_W_to_T', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.isBoxQty = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/button_is_box_qty', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.orderDetail.filter(function (y) {
        return _this.selectedRowKeys.includes(y.id);
      }).map(function (x) {
        x.ist_box_qty = !x.ist_box_qty;
        var nowDate = new Date();
        var cur_date = nowDate.getFullYear().toString() + (nowDate.getMonth() + 1 < 10 ? '0' + (nowDate.getMonth() + 1) : nowDate.getMonth() + 1).toString() + (nowDate.getDate() < 10 ? '0' + nowDate.getDate() : nowDate.getDate()).toString();

        if (x.ist_box_qty) {
          x.write_product_f4 = cur_date + 'inL(+' + x.box_qty.toString() + ',' + _this.locationDict[parseInt(x.location_id)] + ').sf';
        } else {
          x.write_product_f4 = cur_date + 'inL(+' + x.box_qty.toString() + ',' + '2' + _this.locationDict[parseInt(x.location_id)] + ').sf';
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.changeLocationId = function (name) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/change_purchase_line_location_id', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_ids: this.selectedRowKeys,
      name: name
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.onVerify = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/update_package_order_state', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      package_id_list: [this.order.id],
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.order.state = state;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.onLandIn = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/land_in_warehouse', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"]({
      package_id: this.order.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.inbound = function () {
    var _this = this;

    this.$modal.open(purchase_inboundPlan, {
      name: this.form.getFieldValue('name')
    }, {
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('success');

      _this.refreshLines();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.refreshLines = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/query_package_order_info', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.query(new http["RequestParams"]({
      package_id: this.order.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.orderDetail = data[0].package_lines.map(function (x) {
        return x;
      });

      if (_this.summaryList != undefined && _this.summaryList.length && _this.orderDetail.length) {
        var sm = _this.orderDetail.find(function (x) {
          return x.id == 'summary';
        });

        var ret = common_service["a" /* CommonService */].getSummaryData(_this.orderDetail, _this.summaryList);

        if (sm) {
          for (var _i = 0, _a = _this.summaryList; _i < _a.length; _i++) {
            var i = _a[_i];
            sm[i] = ret[i];
          }
        } else {
          ret['id'] = 'summary';

          _this.orderDetail.push(ret);

          _this.$nextTick(function () {
            var querySelector = 'tr[data-row-key="summary"]';
            var tr = document.querySelector(querySelector);
            tr.style.background = '#fdfdfd';
          });
        }
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageEdit.prototype.getLocationList = function () {
    var _this = this;

    this.locationService.getLocationList(new http["RequestParams"]()).subscribe(function (data) {
      _this.locationList = data;

      for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
        var i = data_1[_i];
        _this.locationDict[i.code] = i.name;
      }
    }, function (err) {
      _this.$message.error('获取库位列表失败');
    });
  };

  PurchasePackageEdit.prototype.getDepartName = function (department) {
    var ret = department;
    var item = this.departmentList.find(function (x) {
      return x.id == department;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "purchasePackageParams", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "commonPageInfo", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "getVendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageEdit.prototype, "getDepartmentList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchasePackageEdit.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('data'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchasePackageEdit.prototype, "onDataChange", null);

  PurchasePackageEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchasePackageEdit);
  return PurchasePackageEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_package_editvue_type_script_lang_ts_ = (purchase_package_editvue_type_script_lang_ts_PurchasePackageEdit);
// CONCATENATED MODULE: ./src/components/purchase/purchase-package-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_package_editvue_type_script_lang_ts_ = (purchase_package_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/purchase-package-edit.vue?vue&type=style&index=0&lang=css&
var purchase_package_editvue_type_style_index_0_lang_css_ = __webpack_require__("6e52");

// EXTERNAL MODULE: ./src/components/purchase/purchase-package-edit.vue?vue&type=custom&index=0&blockType=i18n
var purchase_package_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("6c6f");

// CONCATENATED MODULE: ./src/components/purchase/purchase-package-edit.vue






/* normalize component */

var purchase_package_edit_component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_package_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_package_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_package_editvue_type_custom_index_0_blockType_i18n["default"])(purchase_package_edit_component)

/* harmony default export */ var purchase_package_edit = __webpack_exports__["a"] = (purchase_package_edit_component.exports);

/***/ }),

/***/ "241d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_modify_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0555");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_modify_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_modify_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_modify_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "245d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"user_purchase":"Purchase User","merchandiser":"Merchandiser","vendor_id":"Vendor","submit":"Submit","cancel":"Cancel"},"zh-cn":{"user_purchase":"采购员","merchandiser":"跟单员","vendor_id":"供应商","submit":"提交","cancel":"取消"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "2748":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "28ec":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "29fe":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a59a");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "2b59":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cb4d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "32fe":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_inboundPlan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b606");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_inboundPlan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_inboundPlan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_inboundPlan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "36ec":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/import-purchase-product-plan-memo.vue?vue&type=template&id=92a5db12&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.import_type')}},[_c('p',{staticStyle:{"margin":"0","padding":"0","line-height":"30px"}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(['import_track_memo']),expression:"['import_track_memo']"}]}),_vm._v(" "+_vm._s(_vm.$t('columns.import_track_memo'))+" ")],1),_c('p',{staticStyle:{"margin":"0","padding":"0","line-height":"30px"}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(['import_finish_time']),expression:"['import_finish_time']"}]}),_vm._v(" "+_vm._s(_vm.$t('columns.import_finish_time'))+" ")],1),_c('p',{staticStyle:{"margin":"0","padding":"0","line-height":"30px"}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(['import_finish_qty']),expression:"['import_finish_qty']"}]}),_vm._v(" "+_vm._s(_vm.$t('columns.import_finish_qty'))+" ")],1)])],1),_c('a-col',{staticStyle:{"margin-top":"10px"},attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.import_method'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'import_method',
                            { rules: _vm.rules.required }
                        ]),expression:"[\n                            'import_method',\n                            { rules: rules.required }\n                        ]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please Select"}},[_c('a-select-option',{key:"source_doc",attrs:{"value":"source_doc"}},[_vm._v(_vm._s(_vm.$t('columns.source_doc')))]),_c('a-select-option',{key:"warehouse",attrs:{"value":"warehouse"}},[_vm._v(_vm._s(_vm.$t('columns.warehouse')))])],1)],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('next')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/import-purchase-product-plan-memo.vue?vue&type=template&id=92a5db12&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/import-purchase-product-plan-memo.vue?vue&type=script&lang=ts&





var import_purchase_product_plan_memovue_type_script_lang_ts_ImportPurchaseProductPlanMemo =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ImportPurchaseProductPlanMemo, _super);

  function ImportPurchaseProductPlanMemo() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  ImportPurchaseProductPlanMemo.prototype.submit = function () {
    return true;
  };

  ImportPurchaseProductPlanMemo.prototype.cancel = function () {
    return;
  };

  ImportPurchaseProductPlanMemo.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ImportPurchaseProductPlanMemo.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        for (var i in values) {
          if (!values[i]) {
            delete values[i];
          }
        }

        _this.$modal.open(upload_excel["a" /* default */], {
          urlPath: '/system_api/upload?inner_action=purchase_order_plan/upload_edit_info&menu_code=' + common_service["a" /* CommonService */].getMenuCode('purchase-product-plan'),
          uploadParams: values
        }, {
          title: _this.$t('import'),
          width: '1000px'
        }).subscribe(function (data) {
          _this.$message.success('Import Success');
        }, function (err) {
          _this.$message.error(err.message);
        });

        _this.cancel();
      }
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ImportPurchaseProductPlanMemo.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ImportPurchaseProductPlanMemo.prototype, "cancel", null);

  ImportPurchaseProductPlanMemo = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ImportPurchaseProductPlanMemo);
  return ImportPurchaseProductPlanMemo;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var import_purchase_product_plan_memovue_type_script_lang_ts_ = (import_purchase_product_plan_memovue_type_script_lang_ts_ImportPurchaseProductPlanMemo);
// CONCATENATED MODULE: ./src/components/purchase/import-purchase-product-plan-memo.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_import_purchase_product_plan_memovue_type_script_lang_ts_ = (import_purchase_product_plan_memovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/import-purchase-product-plan-memo.vue?vue&type=custom&index=0&blockType=i18n
var import_purchase_product_plan_memovue_type_custom_index_0_blockType_i18n = __webpack_require__("ab09");

// CONCATENATED MODULE: ./src/components/purchase/import-purchase-product-plan-memo.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_import_purchase_product_plan_memovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof import_purchase_product_plan_memovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(import_purchase_product_plan_memovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var import_purchase_product_plan_memo = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "36ff":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "3b14":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_ship_plan_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("831b");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_ship_plan_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_ship_plan_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "47e3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c328");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "4b6c":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "4bc0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/depo-detail.vue?vue&type=template&id=479fbd41&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-detail"},[_c('a-card',[_c('a-descriptions',{staticClass:"depo_detail",attrs:{"title":"Detail Info","column":2,"size":"small","bordered":""}},[_c('a-descriptions-item',{attrs:{"label":"Name"}},[_vm._v(" "+_vm._s(_vm.data.name)+" ")]),_c('a-descriptions-item',{attrs:{"label":"Invoice No."}},[_vm._v(" "+_vm._s(_vm.data.invoice_no)+" ")]),_c('a-descriptions-item',{attrs:{"label":"Vendor"}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.data.vendor,_vm.vendorList))+" ")]),_c('a-descriptions-item',{attrs:{"label":"Create User"}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.data.create_user,_vm.systemUsers))+" ")]),_c('a-descriptions-item',{attrs:{"label":"Ref No."}},[_vm._v(" "+_vm._s(_vm.data.ref_no)+" ")]),_c('a-descriptions-item',{attrs:{"label":"Create Date"}},[_vm._v(" "+_vm._s(_vm.data.create_date)+" ")]),_c('a-descriptions-item',{attrs:{"label":"Company Name"}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.data.company_name,_vm.companyList))+" ")]),_c('a-descriptions-item',{attrs:{"label":"Shipment Item"}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.data.shipment_item,_vm.shipmentItemList))+" ")]),_c('a-descriptions-item',{attrs:{"label":"Extra File"}},[_vm._v(" "+_vm._s(_vm.data.extra_fee)+" ")]),_c('a-descriptions-item',{attrs:{"label":"From Port"}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.data.from_port,_vm.fromPortList))+" ")]),_c('a-descriptions-item',{attrs:{"label":""}}),_c('a-descriptions-item',{attrs:{"label":"To Port"}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.data.to_port,_vm.toPortList))+" ")])],1),_c('h3',{staticStyle:{"font-weight":"600"}},[_vm._v("Order Lines")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.orderDetail,"pagination":false,"rowKey":"id","columns":_vm.detailColumns,"scroll":{ y: 400 },"bordered":""}})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/depo-detail.vue?vue&type=template&id=479fbd41&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/depo-detail.vue?vue&type=script&lang=ts&








var datasModule = Object(lib["c" /* namespace */])('datasModule');

var depo_detailvue_type_script_lang_ts_DePoDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](DePoDetail, _super);

  function DePoDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = {};
    _this.orderDetail = [];
    _this.detailColumns = [];
    _this.companyList = [];
    _this.fromPortList = [];
    _this.toPortList = [];
    _this.vendorList = [];
    _this.shipmentItemList = [];
    _this.summaryList = ['product_qty', 'product_box', 'weight_netto', 'weight_brutto', 'volume'];
    _this.editable = false;
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  DePoDetail.prototype.onDetailChange = function () {
    if (this.detail.id) {
      this.data = Object.assign({}, this.detail);
      this.orderDetail = this.data.de_po_line || [];
      this.calcSummaryLine();
    }
  };

  DePoDetail.prototype.created = function () {
    this.getSystemuser();
  };

  DePoDetail.prototype.mounted = function () {
    this.data = Object.assign({}, this.detail);
    this.orderDetail = this.data.de_po_line || [];
    this.calcSummaryLine();
    this.detailColumns = [{
      title: 'Product',
      width: 100,
      dataIndex: 'default_code',
      scopedSlots: {
        customRender: 'default_code'
      },
      align: 'left'
    }, {
      title: 'Qty',
      width: 100,
      dataIndex: 'product_qty',
      align: 'right'
    }, {
      title: 'Box',
      width: 100,
      dataIndex: 'product_box',
      align: 'right'
    }, {
      title: 'Category',
      width: 100,
      dataIndex: 'product_cate',
      align: 'left'
    }, {
      title: 'G.W.(KGS)',
      width: 100,
      dataIndex: 'weight_netto',
      align: 'right'
    }, {
      title: 'N.W.(KGS)',
      width: 100,
      dataIndex: 'weight_brutto',
      align: 'right'
    }, {
      title: 'CBM',
      width: 100,
      dataIndex: 'volume',
      align: 'right'
    }, {
      title: 'C/S No.',
      width: 100,
      dataIndex: 'container_no',
      align: 'left'
    }];
    this.companyList = [{
      code: 'woltu',
      name: 'Woltu'
    }, {
      code: 'eugad',
      name: 'Eugad'
    }, {
      code: 'situ',
      name: 'Situ'
    }, {
      code: 'elight',
      name: 'Elight'
    }, {
      code: 'wowo',
      name: 'WoWo'
    }, {
      code: 'meteorsRain',
      name: 'MeteorsRain'
    }, {
      code: 'brichimon',
      name: 'BRICHIMON LIMITED'
    }];
    this.fromPortList = [{
      code: 'QINGDAO',
      name: 'QINGDAO'
    }, {
      code: 'TIANJIN',
      name: 'TIANJIN'
    }, {
      code: 'XIAMEN',
      name: 'XIAMEN'
    }, {
      code: 'FUZHOU',
      name: 'FUZHOU'
    }, {
      code: 'NINGBO',
      name: 'NINGBO'
    }, {
      code: 'YANTIAN',
      name: 'YANTIAN'
    }, {
      code: 'SHANGHAI',
      name: 'SHANGHAI'
    }, {
      code: 'XIAOLAN',
      name: 'XIAOLAN'
    }, {
      code: 'SHENZHEN',
      name: 'SHENZHEN'
    }];
    this.toPortList = [{
      code: 'FELIXSTOWE',
      name: 'FELIXSTOWE'
    }, {
      code: 'ROTTERDAM',
      name: 'ROTTERDAM'
    }, {
      code: 'SOUTHAMPTON',
      name: 'SOUTHAMPTON'
    }, {
      code: 'DUISBURG',
      name: 'DUISBURG'
    }, {
      code: 'NEUSS',
      name: 'NEUSS'
    }];
    this.vendorList = [{
      code: 'wawa',
      name: 'WAWAHOME'
    }, {
      code: 'ye',
      name: 'YEMELEK'
    }, {
      code: 'situ',
      name: 'ST-SITU'
    }, {
      code: 'runheng',
      name: 'RH-RUNHENG'
    }, {
      code: 'andong',
      name: 'AD-ANDONG'
    }, {
      code: 'cheng',
      name: 'OH-ORANGE'
    }, {
      code: 'dy',
      name: 'DY-DEALCRAFTS'
    }, {
      code: 'ice',
      name: 'ICE-ICEBERG'
    }, {
      code: 'kd',
      name: 'KD-KENDA'
    }, {
      code: 'wt',
      name: 'WT-HENAN PROSPER SKINS AND LEATHER'
    }, {
      code: 'yt',
      name: 'YT-YUTONG'
    }, {
      code: 'zl',
      name: 'ZL-JINHUA RUNCHN'
    }, {
      code: 'ykzh',
      name: 'YKZH-YONGKANG ZEHUI'
    }, {
      code: 'anji',
      name: 'BY-BAOYOU'
    }, {
      code: 'wj',
      name: 'WJ-WORKING'
    }];
    this.shipmentItemList = [{
      code: 'FOB',
      name: 'FOB'
    }, {
      code: 'CIF',
      name: 'CIF'
    }];
  };

  DePoDetail.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  DePoDetail.prototype.calcSummaryLine = function () {
    if (this.summaryList != undefined && this.summaryList.length && this.orderDetail.length) {
      var sm = this.orderDetail.find(function (x) {
        return x.id == 'summary';
      });
      var ret = common_service["a" /* CommonService */].getSummaryData(this.orderDetail, this.summaryList);

      if (sm) {
        for (var _i = 0, _a = this.summaryList; _i < _a.length; _i++) {
          var i = _a[_i];
          sm[i] = ret[i];
        }
      } else {
        ret['id'] = 'summary';
        ret['index'] = 'summary';
        this.orderDetail.push(ret);
        this.$nextTick(function () {
          var querySelector = 'tr[data-row-key="summary"]';
          var tr = document.querySelector(querySelector);
          tr.style.background = '#fdfdfd';
        });
      }
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DePoDetail.prototype, "detail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DePoDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], DePoDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], DePoDetail.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('detail'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], DePoDetail.prototype, "onDetailChange", null);

  DePoDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], DePoDetail);
  return DePoDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var depo_detailvue_type_script_lang_ts_ = (depo_detailvue_type_script_lang_ts_DePoDetail);
// CONCATENATED MODULE: ./src/components/purchase/depo-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_depo_detailvue_type_script_lang_ts_ = (depo_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/depo-detail.vue?vue&type=style&index=0&lang=css&
var depo_detailvue_type_style_index_0_lang_css_ = __webpack_require__("6236");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/depo-detail.vue?vue&type=custom&index=0&blockType=i18n
var depo_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("21c6");

// CONCATENATED MODULE: ./src/components/purchase/depo-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_depo_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof depo_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(depo_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var depo_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "4c21":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "57fb4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-finish-item.vue?vue&type=template&id=418b04e6&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('table',{staticClass:"xtb"},[_c('tr',[_c('td',{staticStyle:{"color":"red","width":"15%"}},[_vm._v(" "+_vm._s(_vm.$t('columns.purchase_detail'))+" ")]),_c('td',{staticStyle:{"padding":"0"}},[_c('table',{staticClass:"xtb",staticStyle:{"border":"none"}},[_c('tr',[_c('th',[_vm._v(_vm._s(_vm.$t('columns.name')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.quantity')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.finish_qty')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.finish_yn')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.cn_category')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.color')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.material')))])]),_vm._l((_vm.info),function(x,i){return _c('tr',{key:i},[_c('td',{key:x.req_name},[_vm._v(_vm._s(x.req_name))]),_c('td',{key:x.product_qty},[_vm._v(_vm._s(x.product_qty))]),_c('td',{key:x.finish_yn},[_vm._v(_vm._s(x.finish_yn))]),_c('td',{key:x.z_sub_category},[_vm._v(" "+_vm._s(x.z_sub_category)+" ")]),_c('td',{key:x.product_color},[_vm._v(" "+_vm._s(x.product_color)+" ")]),_c('td',{key:x.pack_material},[_vm._v(" "+_vm._s(x.pack_material)+" ")])])})],2)])]),_c('tr',[_c('td',[_vm._v(_vm._s(_vm.$t('columns.reason')))]),_c('td',{staticClass:"required"},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['reason']),expression:"['reason']"}],ref:"reason",staticStyle:{"width":"100%"},attrs:{"size":"small"},model:{value:(_vm.reason),callback:function ($$v) {_vm.reason=$$v},expression:"reason"}})],1)])]),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-finish-item.vue?vue&type=template&id=418b04e6&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-finish-item.vue?vue&type=script&lang=ts&









var purchase_finish_itemvue_type_script_lang_ts_PurchaseFinishItem =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseFinishItem, _super);

  function PurchaseFinishItem() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.reason = '';
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  PurchaseFinishItem.prototype.submit = function () {
    return true;
  };

  PurchaseFinishItem.prototype.cancel = function () {
    return;
  };

  PurchaseFinishItem.prototype.mounted = function () {
    var _this = this;

    this.$nextTick(function () {
      var reasonInput = _this.$refs.reason;
      reasonInput.focus();
    });
  };

  PurchaseFinishItem.prototype.onSubmit = function () {
    var _this = this;

    if (!this.reason) {
      this.$message.error('原因不能为空!');
      var reasonInput = this.$refs.reason;
      reasonInput.focus();
      return;
    }

    this.innerAction.setActionAPI('purchase_order_plan/finish_purchase_item', common_service["a" /* CommonService */].getMenuCode('purchase-product-plan'));
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.info.map(function (x) {
        return x.id;
      }),
      finishItemMemo: this.reason
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.info(data.message);

      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseFinishItem.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseFinishItem.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseFinishItem.prototype, "info", void 0);

  PurchaseFinishItem = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseFinishItem);
  return PurchaseFinishItem;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_finish_itemvue_type_script_lang_ts_ = (purchase_finish_itemvue_type_script_lang_ts_PurchaseFinishItem);
// CONCATENATED MODULE: ./src/components/purchase/purchase-finish-item.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_finish_itemvue_type_script_lang_ts_ = (purchase_finish_itemvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/purchase-finish-item.vue?vue&type=style&index=0&lang=css&
var purchase_finish_itemvue_type_style_index_0_lang_css_ = __webpack_require__("13cb");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/purchase-finish-item.vue?vue&type=custom&index=0&blockType=i18n
var purchase_finish_itemvue_type_custom_index_0_blockType_i18n = __webpack_require__("c08b");

// CONCATENATED MODULE: ./src/components/purchase/purchase-finish-item.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_finish_itemvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_finish_itemvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_finish_itemvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_finish_item = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "6236":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_depo_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9b16");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_depo_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_depo_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "6666":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"submit":"Submit","cancel":"Cancel","columns":{"warehouse_id":"Warehouse Id","thc_invoice":"Thc Invoice","pick_terminal":"Pick Terminal","ship_line":"Ship Line","predict_eta":"Predict Eta","vessel":"Vessel","predict_eta_memo":"Predict Eta Memo","terminal":"Terminal","company_name":"Company Name","size_type":"Size Type","set_etd_null":"Set Etd Null ","goods_description":"Goods Description","netto_weight":"Netto Weight"}},"zh-cn":{"submit":"提交","cancel":"取消","columns":{"warehouse_id":"仓库","thc_invoice":"Thc Invoice","pick_terminal":"Pick Terminal","ship_line":"Ship Line","predict_eta":"Predict Eta","vessel":"Vessel","predict_eta_memo":"Predict Eta Memo","terminal":"Terminal","company_name":"Company Name","size_type":"Size Type","set_etd_null":"Set Etd Null ","goods_description":"Goods Description","netto_weight":"Netto Weight"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "6781":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/create-ship-plan.vue?vue&type=template&id=394056f9&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save')))]),_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"type":"default","size":"small","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onSplit()}}},[_vm._v(_vm._s(_vm.$t('action.split'))+" ")]),_c('a-button',{staticStyle:{"margin-right":"5px"},attrs:{"disabled":!_vm.selectedRowKeys.length,"size":"small"},on:{"click":function($event){return _vm.onDelete()}}},[_vm._v(" "+_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.orderDetail,"pagination":false,"rowKey":"index","columns":_vm.detailColumns,"rowSelection":{
            selectedRowKeys: _vm.selectedRowKeys,
            onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
        },"customRow":function (record) { return ({
                on: {
                    click: function () {
                        this$1.selectedRowKeys = [record.index]
                        _vm.onTbRowClick(record)
                    }
                }
            }); },"scroll":{ x: 1300, y: 300 },"bordered":""},scopedSlots:_vm._u([{key:"ship_aging",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_aging']),expression:"['ship_aging']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"value":row.ship_aging,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e, row, 'ship_aging'); }}},_vm._l((_vm.$dict.LogisticsProviderAging),function(i){return _c('a-select-option',{key:i.value,attrs:{"value":i.value}},[_vm._v(" "+_vm._s(_vm.$t(i.label))+" ")])}),1):_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(typeof row.ship_aging == 'object' && row.ship_aging.length == 2 ? row.ship_aging[0] : row.ship_aging,'LogisticsProviderAging'))))])]}},{key:"dest_location_id",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dest_location_id']),expression:"['dest_location_id']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"value":row.dest_location_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.handleChange(e, row, 'dest_location_id'); }}},_vm._l((_vm.locationList),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code}},[_vm._v(" "+_vm._s(i.name)+" ")])}),1):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(typeof row.dest_location_id == 'object' && row.dest_location_id.length == 2 ? row.dest_location_id[0] : row.dest_location_id,_vm.locationList)))])]}},{key:"ship_qty",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input-number',{attrs:{"size":"small","value":row.ship_qty,"min":1,"max":row.product_qty - row.shipped_qty},on:{"change":function (e) { return _vm.handleChange(e, row, 'ship_qty'); }}}):_c('span',[_vm._v(_vm._s(row.ship_qty))])]}},{key:"available_ship_qty",fn:function(text, row){return [_vm._v(_vm._s(Math.max(0, row.product_qty - row.shipped_qty)))]}},{key:"ship_date",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-date-picker',{staticClass:"required",attrs:{"size":"small","format":"YYYY-MM-DD","value":row.ship_date},on:{"change":function (e) { return _vm.handleChange(e, row, 'ship_date'); }}}):_c('span',[_vm._v(_vm._s(row.ship_date ? row.ship_date.format('YYYY-MM-DD') : ''))])]}},{key:"date_render",fn:function(text){return [_vm._v(_vm._s(_vm._f("datetolocal")(text)))]}},{key:"amazon_sku",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{attrs:{"size":"small","value":row.amazon_sku},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'amazon_sku'); }}}):_c('span',[_vm._v(_vm._s(row.amazon_sku))])]}},{key:"amazon_asin",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{attrs:{"size":"small","value":row.amazon_asin},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'amazon_asin'); }}}):_c('span',[_vm._v(_vm._s(row.amazon_asin))])]}},{key:"fn_sku",fn:function(text, row){return [(_vm.currentRow == row.index)?_c('a-input',{staticClass:"required",attrs:{"size":"small","value":row.fn_sku},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'fn_sku'); }}}):_c('span',[_vm._v(_vm._s(row.fn_sku))])]}}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/create-ship-plan.vue?vue&type=template&id=394056f9&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/services/location.service.ts
var location_service = __webpack_require__("e73b");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/create-ship-plan.vue?vue&type=script&lang=ts&



















var create_ship_planvue_type_script_lang_ts_CreateShipPlan =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](CreateShipPlan, _super);

  function CreateShipPlan() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.locationService = new location_service["a" /* LocationService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.order = [];
    _this.orderDetail = [];
    _this.save_flag = 0;
    _this.originData = [];
    _this.menu_code = '';
    _this.editAble = false;
    _this.currentRow = '';
    _this.detailColumns = [];
    _this.selectedRowKeys = [];
    _this.locationList = [];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  CreateShipPlan.prototype.submit = function () {
    return true;
  };

  CreateShipPlan.prototype.cancel = function () {
    return;
  };

  CreateShipPlan.prototype.onInfoChange = function () {
    if (this.info) {
      this.updateOrder();
    }
  };

  CreateShipPlan.prototype.created = function () {
    this.getLocationList();
  };

  CreateShipPlan.prototype.mounted = function () {
    this.detailColumns = [{
      key: 'purchase_num',
      title: this.$t('columns.purchase_num'),
      dataIndex: 'purchase_num',
      width: 100
    }, {
      key: 'common_sku',
      title: this.$t('columns.common_sku'),
      dataIndex: 'common_sku',
      align: 'left',
      width: 100
    }, {
      key: 'give_date',
      title: this.$t('columns.give_date'),
      dataIndex: 'give_date',
      width: 100,
      align: 'right',
      scopedSlots: {
        customRender: 'date_render'
      }
    }, {
      key: 'product_qty',
      title: this.$t('columns.product_qty'),
      dataIndex: 'product_qty',
      width: 100,
      align: 'right',
      scopedSlots: {
        customRender: 'product_qty'
      }
    }, {
      key: 'shipped_qty',
      title: this.$t('columns.shipped_qty'),
      dataIndex: 'shipped_qty',
      align: 'right',
      width: 100
    }, {
      key: 'available_ship_qty',
      title: this.$t('columns.available_ship_qty'),
      dataIndex: 'available_ship_qty',
      align: 'right',
      width: 100,
      scopedSlots: {
        customRender: 'available_ship_qty'
      }
    }, {
      key: 'ship_qty',
      title: this.$t('columns.ship_qty'),
      dataIndex: 'ship_qty',
      align: 'right',
      width: 100,
      scopedSlots: {
        customRender: 'ship_qty'
      }
    }, {
      key: 'ship_date',
      title: this.$t('columns.ship_date'),
      dataIndex: 'ship_date',
      align: 'left',
      width: 120,
      scopedSlots: {
        customRender: 'ship_date'
      }
    }, {
      key: 'ship_aging',
      title: this.$t('columns.ship_aging'),
      dataIndex: 'ship_aging',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'ship_aging'
      }
    }, {
      key: 'dest_location_id',
      title: this.$t('columns.dest_location_id'),
      dataIndex: 'dest_location_id',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'dest_location_id'
      }
    }, {
      key: 'amazon_sku',
      title: this.$t('columns.amazon_sku'),
      dataIndex: 'amazon_sku',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'amazon_sku'
      }
    }, {
      key: 'amazon_asin',
      title: this.$t('columns.amazon_asin'),
      dataIndex: 'amazon_asin',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'amazon_asin'
      }
    }, {
      key: 'fn_sku',
      title: this.$t('columns.fn_sku'),
      dataIndex: 'fn_sku',
      align: 'left',
      width: 100,
      scopedSlots: {
        customRender: 'fn_sku'
      }
    }];

    if (this.info) {
      this.updateOrder();
    }
  };

  CreateShipPlan.prototype.updateOrder = function () {
    if (this.info.length) {
      this.orderDetail = JSON.parse(JSON.stringify(this.info.map(function (x) {
        x['ship_date'] = '';
        x['dest_location_id'] = '';
        x['ship_aging'] = '';
        x['save_flag'] = 0;
        x['ship_qty'] = 0;
        return x;
      })));
    }
  };

  CreateShipPlan.prototype.onSplit = function () {
    var _loop_1 = function _loop_1(i) {
      var item = this_1.orderDetail.find(function (x) {
        return x.index == i;
      });

      if (item) {
        var param = Object.assign({}, item);
        param['index'] = uuid_default.a.generate();
        this_1.orderDetail.push(param);
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      _loop_1(i);
    }
  };

  CreateShipPlan.prototype.onSubmit = function () {
    var _this = this;

    var nowDate = new Date().getTime();
    var cur = this.moment(nowDate).format('YYYY-MM-DD');

    for (var _i = 0, _a = this.orderDetail; _i < _a.length; _i++) {
      var i = _a[_i];

      if (!i.ship_aging || !i.dest_location_id || !i.ship_date || !i.fn_sku) {
        this.$message.error('请先完善明细信息，深色背景为必填项');
        return false;
      }
    }

    var params = JSON.parse(JSON.stringify(this.orderDetail));
    this.innerAction.setActionAPI('/shipping_plan/save_shipping_plan', common_service["a" /* CommonService */].getMenuCode('create-shipping-plan'));
    this.publicService.modify(new http["RequestParams"]({
      date_list: params.map(function (x) {
        delete x.index;
        return x;
      }),
      cur_date: cur
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      // let msg: any = this.$t('tips.save_success')
      // this.$message.success(msg)
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  CreateShipPlan.prototype.onDelete = function () {
    var _this = this;

    this.$message.success('操作成功');
    this.orderDetail = this.orderDetail.filter(function (x) {
      return !_this.selectedRowKeys.includes(x.index);
    });
  };

  CreateShipPlan.prototype.onTbRowClick = function (row) {
    this.currentRow = row.index;
  };

  CreateShipPlan.prototype.handleChange = function (e, row, column) {
    row[column] = e;

    if (column == 'product_qty') {
      row.available_ship_qty = e - row.shipped_qty;
    }
  };

  CreateShipPlan.prototype.getLocationList = function () {
    var _this = this;

    this.locationService.getLocationList(new http["RequestParams"]()).subscribe(function (data) {
      _this.locationList = data;
    }, function (err) {
      _this.$message.error('获取库位列表失败');
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], CreateShipPlan.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], CreateShipPlan.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], CreateShipPlan.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], CreateShipPlan.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], CreateShipPlan.prototype, "onInfoChange", null);

  CreateShipPlan = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], CreateShipPlan);
  return CreateShipPlan;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var create_ship_planvue_type_script_lang_ts_ = (create_ship_planvue_type_script_lang_ts_CreateShipPlan);
// CONCATENATED MODULE: ./src/components/purchase/create-ship-plan.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_create_ship_planvue_type_script_lang_ts_ = (create_ship_planvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/create-ship-plan.vue?vue&type=style&index=0&lang=css&
var create_ship_planvue_type_style_index_0_lang_css_ = __webpack_require__("3b14");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/create-ship-plan.vue?vue&type=custom&index=0&blockType=i18n
var create_ship_planvue_type_custom_index_0_blockType_i18n = __webpack_require__("1ef9");

// CONCATENATED MODULE: ./src/components/purchase/create-ship-plan.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_create_ship_planvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof create_ship_planvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(create_ship_planvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var create_ship_plan = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "6c6f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a720");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "6e52":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4b6c");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "6ebc":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"purchase_detail":"Attention Detail","reason":"取消原因","name":"Name","quantity":"Quantity","attention_item":"Attention Item","cn_category":"Cn Category","color":"Color","material":"Material"},"return_reason":"Return Reason","submit":"Submit","cancel":"Cancel"},"zh-cn":{"columns":{"purchase_detail":"关注明细","reason":"取消关注原因","name":"物品","quantity":"数量","attention_item":"关注点","cn_category":"中文子类","color":"颜色","material":"材料"},"return_reason":"返回原因","submit":"提交","cancel":"取消"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "7647":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_give_date_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ec4b");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_give_date_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_give_date_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_give_date_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "76e0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("144a");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7aba":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/change-give-date-form.vue?vue&type=template&id=c6b47ca4&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.change_give_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["change_give_date"]),expression:"[`change_give_date`]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"}})],1)],1),_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.change_give_date_memo'),"required":""}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "change_give_date_memo",
                            { rules: _vm.rules.required }
                        ]),expression:"[\n                            `change_give_date_memo`,\n                            { rules: rules.required }\n                        ]"}],attrs:{"size":"small"}})],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/change-give-date-form.vue?vue&type=template&id=c6b47ca4&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/change-give-date-form.vue?vue&type=script&lang=ts&



var change_give_date_formvue_type_script_lang_ts_ChangeGiveDateForm =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ChangeGiveDateForm, _super);

  function ChangeGiveDateForm() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  ChangeGiveDateForm.prototype.submit = function (value) {
    return value;
  };

  ChangeGiveDateForm.prototype.cancel = function () {
    return;
  };

  ChangeGiveDateForm.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ChangeGiveDateForm.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        _this.submit(values);
      }
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ChangeGiveDateForm.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ChangeGiveDateForm.prototype, "cancel", null);

  ChangeGiveDateForm = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ChangeGiveDateForm);
  return ChangeGiveDateForm;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var change_give_date_formvue_type_script_lang_ts_ = (change_give_date_formvue_type_script_lang_ts_ChangeGiveDateForm);
// CONCATENATED MODULE: ./src/components/purchase/change-give-date-form.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_change_give_date_formvue_type_script_lang_ts_ = (change_give_date_formvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/change-give-date-form.vue?vue&type=custom&index=0&blockType=i18n
var change_give_date_formvue_type_custom_index_0_blockType_i18n = __webpack_require__("7647");

// CONCATENATED MODULE: ./src/components/purchase/change-give-date-form.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_change_give_date_formvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof change_give_date_formvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(change_give_date_formvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var change_give_date_form = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "7f8b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_head_logistics_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b6a0");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_head_logistics_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_head_logistics_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_head_logistics_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "81eb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/modify-package-order.vue?vue&type=template&id=07f4ddcf&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["warehouse_id"]),expression:"[`warehouse_id`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.thc_invoice')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["thc_invoice"]),expression:"[`thc_invoice`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.pick_terminal')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["pick_terminal"]),expression:"[`pick_terminal`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.ship_line')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["ship_line"]),expression:"[`ship_line`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.predict_eta')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["predict_eta"]),expression:"[`predict_eta`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.vessel')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["vessel"]),expression:"[`vessel`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.predict_eta_memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["predict_eta_memo"]),expression:"[`predict_eta_memo`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.terminal')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["terminal"]),expression:"[`terminal`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.company_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['company_name']),expression:"['company_name']"}],style:({
                            width: '100%',
                            'max-width': '240px'
                        }),attrs:{"size":"small","placeholder":"Please Select"}},[_c('a-select-option',{key:"woltu",attrs:{"value":"woltu"}},[_vm._v(" Woltu ")]),_c('a-select-option',{key:"eugad",attrs:{"value":"eugad"}},[_vm._v(" EUGAD ")]),_c('a-select-option',{key:"situ",attrs:{"value":"situ"}},[_vm._v(" Situ ")]),_c('a-select-option',{key:"elight",attrs:{"value":"elight"}},[_vm._v(" Elight ")]),_c('a-select-option',{key:"wowo",attrs:{"value":"wowo"}},[_vm._v(" Wowo ")]),_c('a-select-option',{key:"meteorsrain",attrs:{"value":"meteorsrain"}},[_vm._v(" Meteorsrain ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.size_type')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["size_type"]),expression:"[`size_type`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.set_etd_null')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["set_etd_null"]),expression:"[`set_etd_null`]"}]})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.goods_description')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["goods_description"]),expression:"[`goods_description`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.netto_weight')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["netto_weight"]),expression:"[`netto_weight`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/modify-package-order.vue?vue&type=template&id=07f4ddcf&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/modify-package-order.vue?vue&type=script&lang=ts&








var modify_package_ordervue_type_script_lang_ts_ModifyPackageOrder =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ModifyPackageOrder, _super);

  function ModifyPackageOrder() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  ModifyPackageOrder.prototype.submit = function () {
    return true;
  };

  ModifyPackageOrder.prototype.cancel = function () {
    return;
  };

  ModifyPackageOrder.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ModifyPackageOrder.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        _this.saveInfo(values);
      }
    });
  };

  ModifyPackageOrder.prototype.saveInfo = function (values) {
    var _this = this;

    values['package_id_list'] = this.ids;
    this.innerAction.setActionAPI('purchase_management/modify_change_purchase_info', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
    this.publicService.modify(new http["RequestParams"](values, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ModifyPackageOrder.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ModifyPackageOrder.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ModifyPackageOrder.prototype, "ids", void 0);

  ModifyPackageOrder = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ModifyPackageOrder);
  return ModifyPackageOrder;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var modify_package_ordervue_type_script_lang_ts_ = (modify_package_ordervue_type_script_lang_ts_ModifyPackageOrder);
// CONCATENATED MODULE: ./src/components/purchase/modify-package-order.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_modify_package_ordervue_type_script_lang_ts_ = (modify_package_ordervue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/modify-package-order.vue?vue&type=custom&index=0&blockType=i18n
var modify_package_ordervue_type_custom_index_0_blockType_i18n = __webpack_require__("d66e");

// CONCATENATED MODULE: ./src/components/purchase/modify-package-order.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_modify_package_ordervue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof modify_package_ordervue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(modify_package_ordervue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var modify_package_order = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "831b":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "83b2":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"purchase_detail":"采购量未达到需求量的90%，无法手动完成","reason":"Finish Reason","name":"Name","quantity":"Quantity","finish_qty":"Finish QTY","finish_yn":"Is Finish","cn_category":"Cn Category","color":"Color","material":"Material"},"return_reason":"Return Reason","submit":"Submit","cancel":"Cancel"},"zh-cn":{"columns":{"purchase_detail":"采购量未达到需求量的90%，无法手动完成","reason":"完成原因","name":"物品","quantity":"数量","finish_qty":"发货量","finish_yn":"完成情况","cn_category":"中文子类","color":"颜色","material":"材料"},"return_reason":"返回原因","submit":"提交","cancel":"取消"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "8519":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"submit":"Submit","cancel":"Cancel","columns":{"source_doc1":"Invoice Number","carrier_name":"Carrier Code","bl_code":"BL Code","package_code":"Package Code","bl_xingshi":"BL Model","express_name":"Express Name","shipment_number":"Shipment Number","clearance_data_submit_date":"Clearance Data Submit Date","bl_finish_date":"BL Finish Date","port_start":"Start Port","port_end":"End Port"}},"zh-cn":{"submit":"提交","cancel":"取消","columns":{"source_doc1":"发票号","carrier_name":"船公司简码","bl_code":"提单号","package_code":"集装箱号","bl_xingshi":"BL Model","express_name":"快递公司","shipment_number":"快递单号","clearance_data_submit_date":"清关资料提交时间","bl_finish_date":"电放完成时间","port_start":"始发港","port_end":"到达港"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "9b16":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "9c26":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/make-package-order.vue?vue&type=template&id=acaa9c4e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-card',{staticClass:" order-edit-page"},[_c('a-form',{staticClass:"customForm",attrs:{"form":_vm.form,"labelCol":{ span: 7 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('ship_date'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "ship_date",
                                {
                                    initialValue: _vm.moment(Date.now())
                                },
                                {
                                    rule: _vm.rules.required
                                }
                            ]),expression:"[\n                                `ship_date`,\n                                {\n                                    initialValue: moment(Date.now())\n                                },\n                                {\n                                    rule: rules.required\n                                }\n                            ]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('document_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "doc_date",
                                {
                                    initialValue: _vm.moment(Date.now())
                                }
                            ]),expression:"[\n                                `doc_date`,\n                                {\n                                    initialValue: moment(Date.now())\n                                }\n                            ]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"}})],1)],1)],1),_c('a-row',[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('eta_date'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "land_date",
                                {
                                    initialValue: _vm.moment(Date.now())
                                },
                                {
                                    rule: _vm.rules.required
                                }
                            ]),expression:"[\n                                `land_date`,\n                                {\n                                    initialValue: moment(Date.now())\n                                },\n                                {\n                                    rule: rules.required\n                                }\n                            ]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('receive_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "recv_date",
                                {
                                    initialValue: _vm.moment(Date.now())
                                }
                            ]),expression:"[\n                                `recv_date`,\n                                {\n                                    initialValue: moment(Date.now())\n                                }\n                            ]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"}})],1)],1)],1),_c('a-row',[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('ref_no'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "source_doc1",
                                {
                                    rule: _vm.rules.required
                                }
                            ]),expression:"[\n                                `source_doc1`,\n                                {\n                                    rule: rules.required\n                                }\n                            ]"}],attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('boat_company'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "carrier_name",
                                {
                                    rule: _vm.rules.required
                                }
                            ]),expression:"[\n                                `carrier_name`,\n                                {\n                                    rule: rules.required\n                                }\n                            ]"}],attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1)],1)],1),_c('a-row',[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('company_id'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'company_name',
                                {
                                    rules: _vm.rules.required
                                }
                            ]),expression:"[\n                                'company_name',\n                                {\n                                    rules: rules.required\n                                }\n                            ]"}],attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{key:"woltu",attrs:{"value":"woltu"}},[_vm._v(" Woltu ")]),_c('a-select-option',{key:"eugad",attrs:{"value":"eugad"}},[_vm._v(" EUGAD ")]),_c('a-select-option',{key:"situ",attrs:{"value":"situ"}},[_vm._v(" Situ ")]),_c('a-select-option',{key:"elight",attrs:{"value":"elight"}},[_vm._v(" Elight ")]),_c('a-select-option',{key:"wowo",attrs:{"value":"wowo"}},[_vm._v(" Wowo ")]),_c('a-select-option',{key:"meteorsrain",attrs:{"value":"meteorsrain"}},[_vm._v(" Meteorsrain ")]),_c('a-select-option',{key:"brichimon",attrs:{"value":"brichimon"}},[_vm._v(" BRICHIMON LIMITED ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('bl_mode'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'bl_xingshi',
                                {
                                    rules: _vm.rules.required
                                }
                            ]),expression:"[\n                                'bl_xingshi',\n                                {\n                                    rules: rules.required\n                                }\n                            ]"}],attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{key:"zs",attrs:{"value":"zs"}},[_vm._v(" OBL ")]),_c('a-select-option',{key:"df",attrs:{"value":"df"}},[_vm._v(" TR ")])],1)],1)],1)],1),_c('a-row',[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('ship_company_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_company_id']),expression:"['ship_company_id']"}],style:({
                                width: '100%'
                            }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{key:"tnt",attrs:{"value":"tnt"}},[_vm._v(" TNT ")]),_c('a-select-option',{key:"dhl",attrs:{"value":"dhl"}},[_vm._v(" DHL ")])],1)],1)],1),_c('a-col',{attrs:{"span":12,"required":""}},[_c('a-form-item',{attrs:{"label":_vm.$t('bl_no')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "bl_code",
                                {
                                    rules: _vm.rules.required
                                }
                            ]),expression:"[\n                                `bl_code`,\n                                {\n                                    rules: rules.required\n                                }\n                            ]"}],attrs:{"size":"small","placeholder":_vm.$t('plzInput')}})],1)],1)],1),_c('a-row',[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('shipment_no')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["shipment_no"]),expression:"[`shipment_no`]"}],attrs:{"size":"small","placeholder":_vm.$t('plzInput')}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('port_of_origin'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "port_start",
                                {
                                    rules: _vm.rules.required
                                }
                            ]),expression:"[\n                                `port_start`,\n                                {\n                                    rules: rules.required\n                                }\n                            ]"}],attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1)],1)],1),_c('a-row',[_c('a-col',{staticClass:"height35",attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('batch_create')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                "batch_create",
                                { initialValue: false }
                            ]),expression:"[\n                                `batch_create`,\n                                { initialValue: false }\n                            ]"}],model:{value:(_vm.batchCreate),callback:function ($$v) {_vm.batchCreate=$$v},expression:"batchCreate"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('port_of_arrival'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'port_end',
                                {
                                    rules: _vm.rules.required
                                }
                            ]),expression:"[\n                                'port_end',\n                                {\n                                    rules: rules.required\n                                }\n                            ]"}],attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{key:"Felix",attrs:{"value":"Felix"}},[_vm._v(" Felix ")]),_c('a-select-option',{key:"Rotterdam",attrs:{"value":"Rotterdam"}},[_vm._v(" Rotterdam ")]),_c('a-select-option',{key:"southampton",attrs:{"value":"southampton"}},[_vm._v(" SOUTHAMPTON ")]),_c('a-select-option',{key:"Duisburg",attrs:{"value":"Duisburg"}},[_vm._v(" Duisburg ")]),_c('a-select-option',{key:"Neuss",attrs:{"value":"Neuss"}},[_vm._v(" Neuss ")]),_c('a-select-option',{key:"longBeach",attrs:{"value":"longBeach"}},[_vm._v(" Long Beach ")]),_c('a-select-option',{key:"losAngeles",attrs:{"value":"losAngeles"}},[_vm._v(" Los Angeles ")])],1)],1)],1)],1)],1),_c('p',{staticStyle:{"margin":"3px","color":"red"}},[_vm._v(" 选择批量创建会根据Container Group(1000除外)不同批量创建货柜 ")])],1),_c('a-card',{staticClass:"margin-top"},[_c('p',[_vm._v(" Container Group: "),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['group']),expression:"['group']"}],ref:"group",staticStyle:{"width":"200px"},attrs:{"size":"small","placeholder":_vm.$t('plzInput')},model:{value:(_vm.container_group),callback:function ($$v) {_vm.container_group=$$v},expression:"container_group"}}),_c('a-button',{staticStyle:{"margin-left":"3px"},attrs:{"type":"primary","size":"small"},on:{"click":_vm.getLinesByGroup}},[_vm._v("Search ")])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"id","columns":_vm.detailColumns,"scroll":{ x: 900, y: 300 }},scopedSlots:_vm._u([{key:"product_qty",fn:function(row){return [_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["product_qty"]),expression:"[`product_qty`]"}],style:({
                        width: '100%',
                        background: '#ecc5e9'
                    }),attrs:{"value":row.product_qty,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_qty', e); }}})]}},{key:"is_change_sku",fn:function(row){return [_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["is_change_sku"]),expression:"[`is_change_sku`]"}],attrs:{"checked":row.is_change_sku,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'is_change_sku',
                                e.target.checked
                            ); }}})]}},{key:"package_code",fn:function(row){return [_c('a-input',{style:({
                        width: '100%',
                        background: '#ecc5e9'
                    }),attrs:{"size":"small"},model:{value:(row.package_code),callback:function ($$v) {_vm.$set(row, "package_code", $$v)},expression:"row.package_code"}})]}},{key:"box_qty",fn:function(row){return [_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["box_qty"]),expression:"[`box_qty`]"}],style:({
                        width: '100%'
                    }),attrs:{"value":row.box_qty,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'box_qty', e); }}})]}},{key:"container_group",fn:function(row){return [_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["container_group"]),expression:"[`container_group`]"}],style:({
                        width: '100%'
                    }),attrs:{"value":row.container_group,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'container_group', e); }}})]}},{key:"action",fn:function(row){return [_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDel(row)}}},[_c('a',{staticClass:"btnDel"},[_c('a-icon',{attrs:{"type":"delete"}})],1)])]}}])})],1),_c('div',{staticClass:"flex-row justify-content-end",staticStyle:{"margin-top":"20px"}},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit'))+" ")])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/make-package-order.vue?vue&type=template&id=acaa9c4e&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/make-package-order.vue?vue&type=script&lang=ts&















var make_package_ordervue_type_script_lang_ts_MakePackageOrder =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](MakePackageOrder, _super);

  function MakePackageOrder() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.operateCnt = 0;
    _this.giveDate = null;
    _this.batchCreate = false;
    _this.detailColumns = [];
    _this.currentLi = '';
    _this.moment = moment_default.a;
    _this.selectedRowKeys = [];
    _this.container_group = '';
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  MakePackageOrder.prototype.submit = function () {
    return true;
  };

  MakePackageOrder.prototype.cancel = function () {
    return;
  };

  MakePackageOrder.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  MakePackageOrder.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.data);
  };

  MakePackageOrder.prototype.mounted = function () {
    this.detailColumns = [{
      key: 'prod_name',
      title: this.$t('columns.prod_name'),
      dataIndex: 'prod_name',
      width: 150
    }, {
      key: 'out_number',
      title: this.$t('columns.out_number'),
      dataIndex: 'out_number',
      width: 100
    }, {
      key: 'product_qty',
      title: this.$t('columns.product_qty'),
      width: 90,
      scopedSlots: {
        customRender: 'product_qty'
      }
    }, {
      key: 'package_code',
      title: this.$t('columns.package_code'),
      width: 80,
      scopedSlots: {
        customRender: 'package_code'
      }
    }, {
      key: 'name',
      title: this.$t('columns.name'),
      dataIndex: 'order2_name',
      width: 85
    }, {
      key: 'box_qty',
      title: this.$t('columns.box_qty'),
      width: 70,
      scopedSlots: {
        customRender: 'box_qty'
      }
    }, {
      key: 'note',
      title: this.$t('columns.note'),
      dataIndex: 'note',
      width: 90
    }, {
      key: 'is_change_sku',
      title: this.$t('columns.is_change_sku'),
      width: 70,
      scopedSlots: {
        customRender: 'is_change_sku'
      }
    }, {
      key: 'package_qty',
      title: this.$t('columns.package_qty'),
      width: 90,
      dataIndex: 'package_qty',
      scopedSlots: {
        customRender: 'package_qty'
      }
    }, {
      key: 'container_group',
      title: this.$t('columns.container_group'),
      width: 70,
      scopedSlots: {
        customRender: 'container_group'
      }
    }, {
      key: 'warehouse_id',
      title: this.$t('columns.warehouse_id'),
      dataIndex: 'warehouse_id',
      width: 80
    }, {
      key: 'action',
      title: this.$t('columns.action'),
      width: 40,
      scopedSlots: {
        customRender: 'action'
      }
    }];

    if (this.lines) {
      this.data = this.lines.map(function (x) {
        x['is_change_sku'] = false;
        return x;
      });
      this.setFormValues();
    }
  };

  MakePackageOrder.prototype.onLinesChange = function () {
    if (this.lines) {
      this.data = this.lines.map(function (x) {
        x['is_change_sku'] = false;
        return x;
      });
      this.setFormValues();
    }
  };

  MakePackageOrder.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target != undefined && value.target.value != undefined) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }

    if (column == 'package_code') {
      this.data.filter(function (x) {
        return x.container_group == row.container_group;
      }).map(function (y) {
        y.package_code = value.target.value;
      });
    }
  };

  MakePackageOrder.prototype.onDel = function (row) {
    if (this.currentRow == row.id) {
      this.currentRow = -1;
    }

    this.data = this.data.filter(function (x) {
      return x.id != row.id;
    });
  };

  MakePackageOrder.prototype.onSubmit = function () {
    //save
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        if (!_this.data.length) {
          _this.$message.error('至少添加一条明细信息');

          return false;
        }

        for (var i in _this.data) {
          if (!_this.data[i].product_qty) {
            _this.$message.error('请输入product_qty');

            return;
          }

          if (!_this.data[i].package_code) {
            _this.$message.error('请先完善明细中的信息,深色背景为必填项');

            _this.currentLi = _this.data[i].id;
            return false;
          }
        }

        values['package_lines'] = _this.data.map(function (x) {
          return {
            order2_id: x.order2_id,
            product_id: x.product_id,
            warehouse_id: x.warehouse_id,
            id: x.id,
            container_group: x.container_group,
            package_code: x.package_code,
            product_qty: x.product_qty,
            package_qty: x.package_qty,
            box_qty: x.box_qty,
            is_change_sku: x.is_change_sku ? true : false
          };
        });
        values.ship_date = moment_default()(values.ship_date).format('YYYY-MM-DD').toString();
        values.doc_date = moment_default()(values.doc_date).format('YYYY-MM-DD').toString();
        values.land_date = moment_default()(values.land_date).format('YYYY-MM-DD').toString();
        values.recv_date = moment_default()(values.recv_date).format('YYYY-MM-DD').toString();

        _this.innerAction.setActionAPI('purchase_management/create_package_order', common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'));

        _this.publicService.modify(new http["RequestParams"](values, {
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.submit();
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  MakePackageOrder.prototype.onTbRowClick = function (row) {
    this.currentLi = row.id;
  };

  MakePackageOrder.prototype.getLinesByGroup = function () {
    var _this = this;

    if (!this.container_group) {
      this.$message.error('Please input Container Group');
      var group = this.$refs.group;
      group.focus();
    }

    this.innerAction.setActionAPI('ship_order/query_ship_order_items', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      order_ids: this.ids,
      container_group: this.container_group
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], MakePackageOrder.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], MakePackageOrder.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], MakePackageOrder.prototype, "lines", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], MakePackageOrder.prototype, "ids", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('lines'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], MakePackageOrder.prototype, "onLinesChange", null);

  MakePackageOrder = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], MakePackageOrder);
  return MakePackageOrder;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var make_package_ordervue_type_script_lang_ts_ = (make_package_ordervue_type_script_lang_ts_MakePackageOrder);
// CONCATENATED MODULE: ./src/components/purchase/make-package-order.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_make_package_ordervue_type_script_lang_ts_ = (make_package_ordervue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/make-package-order.vue?vue&type=style&index=0&lang=less&
var make_package_ordervue_type_style_index_0_lang_less_ = __webpack_require__("fed53");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/make-package-order.vue?vue&type=custom&index=0&blockType=i18n
var make_package_ordervue_type_custom_index_0_blockType_i18n = __webpack_require__("c8fc");

// CONCATENATED MODULE: ./src/components/purchase/make-package-order.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_make_package_ordervue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof make_package_ordervue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(make_package_ordervue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var make_package_order = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "a56a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_finish_qty_vendor_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("e500");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_finish_qty_vendor_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_finish_qty_vendor_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_finish_qty_vendor_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "a59a":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"amount_total":"amount_total","approve_memo":"approve_memo","approved_user":"approved_user","change_give_date":"change_give_date","change_give_date_memo":"change_give_date_memo","end_order_number":"end_order_number","give_date":"give_date","make_user":"make_user","merchandiser":"merchandiser","name":"name","order_company_id":"order_company_id","order_date":"order_date","percent":"percent","user_purchase":"user_purchase","vendor_id":"vendor_id","alerts":"alerts","buyer_change_give_date":"buyer_change_give_date","buyer_change_give_date_memo":"buyer_change_give_date_memo","date_expected":"date_expected","default_code":"default_code","description_purchase":"description_purchase","id":"id","ist_box_qty":"ist_box_qty","note":"note","price_subtotal":"price_subtotal","product_basic_size":"product_basic_size","product_color":"product_color","product_id":"product_id","product_manual_code":"product_manual_code","product_manual_url":"product_manual_url","product_manual_version":"product_manual_version","product_package_size":"product_package_size","product_purchase_currency":"product_purchase_currency","product_purchase_price":"product_purchase_price","product_qty":"product_qty","product_specification_url":"product_specification_url","product_specification_version":"product_specification_version","product_sub_cate":"product_sub_cate","product_uom":"product_uom","product_ve":"product_ve","product_weight":"product_weight","product_weight1":"product_weight1","req_id":"req_id","state":"state","user_require":"user_require","warehouse_id":"Warehouse","specification_code":"Specification Code","manual_code":"Manual Code"},"action":{"order_detail":"Order Detail","other_form":"Other Form","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","today":"Today","yestoday":"Yestoday","3day":"3 Day","send_email":"Send Email","refund":"Refund Supplement Wizard","modify_cp":"Modify CP","other_info":"Other Info","save":"Save","sync_product_info":"Synchronize Product","change_give_date":"Change Give Date","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse","verify_mome":"Memo"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"amount_total":"amount_total","approve_memo":"审批意见","approved_user":"审批人","change_give_date":"变更交期","change_give_date_memo":"变更交期说明","end_order_number":"单据编号","give_date":"合同交期","make_user":"制单员","merchandiser":"跟单员","name":"需求编号","order_company_id":"公司","order_date":"订单日期","percent":"percent","source_doc1":"实际采购合同号","user_purchase":"采购员","vendor_id":"供应商","alerts":"alerts","buyer_change_give_date":"采购变更交期","buyer_change_give_date_memo":"采购变更交期备注","date_expected":"期望入库","default_code":"货号","description_purchase":"采购描述","id":"id","ist_box_qty":"是否箱数","note":"备注","price_subtotal":"价格汇总","product_basic_size":"产品基础尺寸","product_color":"产品颜色","product_id":"产品","product_manual_code":"说明书编号","product_manual_url":"说明书url","product_manual_version":"说明书版本号","product_package_size":"包裹尺寸","product_purchase_currency":"币种","product_purchase_price":"采购价","product_qty":"产品数量","product_specification_url":"工艺单地址","product_specification_version":"工艺单版本号","product_sub_cate":"产品子分类","product_uom":"产品计量单位","product_ve":"装箱率","product_weight":"净重","product_weight1":"毛重","req_id":"需求ID","state":"状态","user_require":"需求人","warehouse_id":"仓库","specification_code":"工艺单编号","manual_code":"说明书编号"},"action":{"order_detail":"订单明细","other_form":"其它信息","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","today":"前一天","yestoday":"前两天","3day":"前三天","send_email":"发送邮件","refund":"退款管理","modify_cp":"修改CP","other_info":"其它信息","save":"保存","sync_product_info":"同步产品信息","change_give_date":"修改采购交期","verify":"审核","reset":"重置","confirm":"确认","refuse":"确认拒绝","verify_mome":"备注"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a720":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"aktu_box_qty":"Aktu Box Qty","aktu_package_qty":"Aktu Package Qty","box_qty":"Box Qty","cp_note":"Cp Note","default_code":"Default Code","gewicht":"Gewicht","height":"Height","import_memo":"Import Memo","is_fba":"Is Fba","ist_box_qty":"Ist Box Qty","length":"Length","location_id":"Location","note":"Note","order2_id":"Order2 ID","out_number":"Out Number","pack_qty":"Pack Qty","package_qty":"Package Qty","pre_sale":"Pre Sale","product_id":"Product ID","product_qty":"Product Qty","state":"State","width":"Width","dept_id":"Department","write_product_f4":"Write Product F4","is_change_sku":"Is SKU Changed","change_no":"Change No."},"action":{"order_detail":"Order Detail","other_form":"Other Form","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","today":"Today","yestoday":"Yestoday","3day":"3 Day","send_email":"Send Email","refund":"Refund Supplement Wizard","modify_cp":"Modify CP","other_info":"Other Info","save":"Save","sync_product_info":"Synchronize Product","change_give_date":"Change Give Date","import":"Import","add_product":"新增产品","write_f4":"Write F4","aktu_value":"Aktu Value","r_warehouse":"R Warehouse","t_warehouse":"T Warehouse","is_box_qty":"Is Box Qty","confirm":"Confirm","reset":"Reset","ship":"Ship","set_to_ship":"Set To Ship","land":"Land","approved":"Approved","process_clearance":"Process Clearance","waiting_arrange_in":"Waiting Arrange In","waiting_in":"Waiting In","verify":"Verify","land_in":"Land In","set_to_draft":"To Draft","inbound":"Inbound Plan(no items)"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","none":"None","requirement_lines":"Requirement Lines","logistic_info":"Logistic Info","name":"Name","ship_date":"Ship Date","de_po":"De Po","land_date":"ETA","company_name":"Company Name","etd_date":"ETD","make_user":"Make User","af_date":"Af Date","approved_user":"Approved User","yd_state":"Yd State","doc_date":"Document Date","yd_merge_time":"Yd Merge Time","recv_date":"Recv Date","yd_memo":"Yd Memo","done_date":"Done Date","source_doc1":"Source Doc1","expect_eta":"Expect Eta","carrier_name":"Carrier Name","expect_etd":"Expect Etd","bl_code":"Bl No.","predict_eta":"Predict Eta","package_code":"Package Code","predict_eta_memo":"Predict Eta Memo","bl_xingshi":"Bl Mode","change_etd_memo":"Change Etd Memo","express_name":"Express Name","pre_status":"Pre Sale Symbol","shipment_number":"Shipment Number","warehouse_id":"Warehouse Id","clearance_data_submit_date":"Clearance Data Submit Date","real_date":"IN WH Date","bl_finish_date":"Bl Finish Date","is_pd":"Is Pd","port_start":"Port Start","ist_aushilfe":"Ist Aushilfe","port_end":"Port End","aushilfe_note":"Aushilfe Note","note_text":"Note Text","display_stock_in":"Display Stock In","ist_number_qty":"Ist Number Qty","ship_line":"Ship Line","seal_num":"Seal No.","thc_invoice":"Thc Invoice","size_type":"Size Type","vessel":"Vessel","netto_weight":"Netto Weight","terminal":"Terminal","goods_description":"Goods Description","trans_model":"Trans Model","empty_depot":"Empty Depot","pick_terminal":"Pick Up Time Terminal","pick_reference":"Pick Reference","demurrage_time":"Demurrage Time"},"zh-cn":{"desc":"这是订单页面1","columns":{"aktu_box_qty":"Aktu 箱数","aktu_package_qty":"Aktu 数量","box_qty":"箱数","cp_note":"Cp Note","default_code":"货号","gewicht":"毛重","height":"高","import_memo":"Import Memo","is_fba":"Fba产品","ist_box_qty":"是否箱数","length":"长","location_id":"库位","note":"Note","order2_id":"Order2 ID","out_number":"Out Number","pack_qty":"Pack Qty","package_qty":"Package Qty","pre_sale":"预售","product_id":"产品 ID","product_qty":"产品数量","state":"状态","width":"宽","dept_id":"部门","write_product_f4":"写入产品F4","is_change_sku":"是否变更SKU","change_no":"变更单号"},"action":{"order_detail":"订单明细","other_form":"其它信息","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","today":"前一天","yestoday":"前两天","3day":"前三天","send_email":"发送邮件","refund":"退款管理","modify_cp":"修改CP","other_info":"其它信息","save":"保存","sync_product_info":"同步产品信息","change_give_date":"修改采购交期","import":"导入","add_product":"添加货柜明细","write_f4":"Write F4","aktu_value":"Aktu Value","r_warehouse":"R Warehouse","t_warehouse":"T Warehouse","is_box_qty":"Is Box Qty","confirm":"确认","verify":"审核","reset":"重置","ship":"Ship","set_to_ship":"Set To Ship","land":"Land","approved":"Approved","process_clearance":"Process Clearance","waiting_arrange_in":"Waiting Arrange In","waiting_in":"Waiting In","land_in":"Land In","set_to_draft":"设为草稿","inbound":"Inbound Plan(no items)"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","none":"无","requirement_lines":"Requirement Lines","logistic_info":"Logistic Info","name":"货柜号","ship_date":"发船日期","de_po":"De Po","land_date":"ETA","company_name":"公司名称","etd_date":"ETD","make_user":"创建人","af_date":"预售结束时间","approved_user":"审批人","yd_state":"Yd State","doc_date":"单据日期","yd_merge_time":"Yd Merge Time","recv_date":"接收日期","yd_memo":"Yd Memo","done_date":"完成日期","source_doc1":"发票号","expect_eta":"期望ETA","carrier_name":"船公司简码","expect_etd":"期望ETD","bl_code":"提单号","predict_eta":"变更ETA","package_code":"集装箱号","predict_eta_memo":"变更ETA原因","bl_xingshi":"Bl Mode","change_etd_memo":"变更ETD备注","express_name":"快递公司","pre_status":"预售标志","shipment_number":"快递单号","warehouse_id":"仓库","clearance_data_submit_date":"清关资料提交时间","real_date":"入库时间","bl_finish_date":"电放完成时间","is_pd":"是否盘点","port_start":"始发港","ist_aushilfe":"Ist Aushilfe","port_end":"到达港","aushilfe_note":"Aushilfe Note","note_text":"备注","display_stock_in":"库存","ist_number_qty":"Ist Number Qty","ship_line":"航线","seal_num":"封条号/货柜号","thc_invoice":"THC发票","size_type":"Size Type","vessel":"船名","netto_weight":"净重","terminal":"终点站","goods_description":"Goods Description","trans_model":"Trans Model","empty_depot":"Empty Depot","pick_terminal":"终点站开放时间","pick_reference":"Pick Reference","demurrage_time":"Demurrage Time"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a954":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f14d");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "aa60":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/logistics-providers-edit.vue?vue&type=template&id=a21480b0&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('div',{staticStyle:{"padding":"0 20px 10px 0","min-height":"40px","display":"inline-block"}},[(_vm.order.id)?_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.editChange}},[(!_vm.editAble)?_c('span',[_vm._v(_vm._s(_vm.$t('action.edit')))]):_c('span',[_vm._v(_vm._s(_vm.$t('action.discard')))])]):_vm._e(),(_vm.editAble || !_vm.order.id)?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]):_vm._e(),_c('div',{staticStyle:{"position":"absolute","top":"10px","right":"10px"}},[_c('div',{staticClass:"progress-bar"},_vm._l((_vm.$dict.LogisticsProviderState),function(item){return _c('li',{key:item.value,class:{ active: _vm.order.state == item.value },staticStyle:{"font-size":"12px"},attrs:{"value":item.value}},[_c('span',[_vm._v(_vm._s(_vm.$t(item.label)))])])}),0)])],1),_c('section',{staticClass:"component edit-customer"},[_c('a-form',{attrs:{"form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-card',{staticClass:"margin-top order-edit-page"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.name'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'name',
                                        { rules: _vm.rules.required }
                                    ]),expression:"[\n                                        'name',\n                                        { rules: rules.required }\n                                    ]"}],attrs:{"size":"small","placeholder":_vm.$t('plzInput'),"disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['code']),expression:"['code']"}],attrs:{"size":"small","placeholder":_vm.$t('plzInput'),"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.contact_person'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'contact_person',
                                        { rules: _vm.rules.required }
                                    ]),expression:"[\n                                        'contact_person',\n                                        { rules: rules.required }\n                                    ]"}],attrs:{"placeholder":_vm.$t('plzInput'),"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.contact_tel'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'contact_tel',
                                        { rules: _vm.rules.required }
                                    ]),expression:"[\n                                        'contact_tel',\n                                        { rules: rules.required }\n                                    ]"}],attrs:{"placeholder":_vm.$t('plzInput'),"size":"small","maxLength":11,"disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.currency_id'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'currency_id',
                                        { rules: _vm.rules.required }
                                    ]),expression:"[\n                                        'currency_id',\n                                        { rules: rules.required }\n                                    ]"}],style:({
                                        width: '200px'
                                    }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption,"placeholder":_vm.$t('plzSelect'),"disabled":!_vm.editAble}},_vm._l((_vm.currencyList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.memo')}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["memo"]),expression:"[`memo`]"}],attrs:{"placeholder":_vm.$t('plzInput'),"size":"small","disabled":!_vm.editAble}})],1)],1)],1)],1),_c('div',{staticClass:"margin-top"},[_c('AddLogisticsProviderDetail',{attrs:{"info":_vm.orderDetail,"id":_vm.order.logistics_providers_id
                                ? _vm.order.logistics_providers_id
                                : 0,"state":_vm.order.id ? 1 : 0,"editAble":_vm.editAble,"systemUsers":_vm.systemUsers,"countryList":_vm.countryList,"currencyList":_vm.currencyList},on:{"change":function($event){return _vm.onDetailListChange($event)}}})],1)],1)],1)])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/logistics-providers-edit.vue?vue&type=template&id=a21480b0&scoped=true&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/components/purchase/add-logistics-provider-detail.vue + 4 modules
var add_logistics_provider_detail = __webpack_require__("42f5");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/services/currency.service.ts
var currency_service = __webpack_require__("6a96");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/logistics-providers-edit.vue?vue&type=script&lang=ts&


















var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');
var userModule = Object(lib["c" /* namespace */])('userModule');

var logistics_providers_editvue_type_script_lang_ts_LogisticsProvidersEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](LogisticsProvidersEdit, _super);

  function LogisticsProvidersEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.currencyService = new currency_service["a" /* CurrencyService */]();
    _this.currencyList = []; // 表格数据源

    _this.order = {
      id: 0,
      state: 'draft'
    };
    _this.orderDetail = [];
    _this.save_flag = 0;
    _this.originData = [];
    _this.isShowDetail = false; //是否只是详情展示

    _this.menu_code = '';
    _this.editAble = false;
    _this.defaultMakeUser = '';
    _this.subDepartList = [];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  Object.defineProperty(LogisticsProvidersEdit.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });

  LogisticsProvidersEdit.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;

      if (this.info) {
        this.updateOrder(this.info);
      }
    }
  };

  LogisticsProvidersEdit.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.save_flag = 1;
      _this.editAble = false;

      if (_this.order.channel_list != undefined && _this.order.channel_list.length) {
        _this.orderDetail = _this.order.channel_list.map(function (x) {
          return x;
        });
      } // this.order.is_together_purchase = true
      // this.order.together_require_name = 'Hs00er-2,BF0029'
      // this.order.sale_range_from = '2020-12'


      _this.form.setFieldsValue(_this.order);
    });
  };

  LogisticsProvidersEdit.prototype.created = function () {
    this.getcurrency();
    this.getcountry();
    this.getSystemuser();
    this.form = this.$form.createForm(this);
    this.getSubDepartmentList();
  };

  LogisticsProvidersEdit.prototype.mounted = function () {
    if (this.save_flag == 0) {
      this.editAble = true;
      this.defaultMakeUser = this.id;
    }

    if (this.info.length) {
      this.updateOrder(this.info);
      this.defaultMakeUser = this.info[0].user_id;
    }

    if (!this.menu_code) {
      this.menu_code = common_service["a" /* CommonService */].getMenuCode('logistics-providers-detail');
    }
  };

  LogisticsProvidersEdit.prototype.getcurrency = function () {
    var _this = this;

    this.currencyService.getCurrency(new http["RequestParams"]({})).subscribe(function (data) {
      _this.currencyList = data;
    }, function (err) {});
  };

  LogisticsProvidersEdit.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  LogisticsProvidersEdit.prototype.onDetailListChange = function (data) {
    this.orderDetail = data; //更新缓存

    var pageId = 'replenishmentedit' + this.order.id;
    var item = this.commonPageInfo.find(function (x) {
      return x.index == pageId;
    });

    if (item) {
      item.info[0].channel_list = this.orderDetail;
    }
  };

  LogisticsProvidersEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      values['save_flag'] = _this.save_flag;

      if (_this.save_flag) {
        values['id'] = _this.order.logistics_providers_id;
      }

      var details = _this.orderDetail.filter(function (x) {
        return x.id != 'summary';
      });

      if (!details.length) {
        _this.$message.error('明细列表不能为空');

        return false;
      }

      for (var _i = 0, details_1 = details; _i < details_1.length; _i++) {
        var i = details_1[_i];

        if (!i.prescription || !i.dest_country_id || !i.dest_country_id || !i.shipping_channel || !i.payment_method) {
          _this.$message.error('请先完善明细信息，深色背景为必填项');

          return false;
        }
      }

      var channel_list = JSON.parse(JSON.stringify(details));

      for (var i_1 in channel_list) {
        delete channel_list[i_1].index;
      }

      values['channel_list'] = channel_list; //TODO

      values['delete_channel_list'] = [];

      _this.innerAction.setActionAPI('/logistics_providers/modify_record', _this.menu_code);

      _this.publicService.modify(new http["RequestParams"](values, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        var msg = _this.$t('tips.save_success');

        _this.$message.success(msg);

        if (_this.save_flag === 0) {
          _this.save_flag = 1;
        }

        _this.order.logistics_providers_id = data.id;
        _this.order.code = data.code;
        _this.editAble = false;

        _this.orderDetail.map(function (x) {
          x['save_flag'] = 1;
        });

        _this.onRefreshData(_this.order.id);

        var values = _this.form.getFieldsValue();

        values['code'] = data.code;

        _this.form.setFieldsValue(values);
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  LogisticsProvidersEdit.prototype.editChange = function () {
    this.editAble = !this.editAble;
    var pageId = 'replenishmentedit' + this.order.id;
    var item = this.commonPageInfo.find(function (x) {
      return x.index == pageId;
    });

    if (item) {
      if (this.editAble) {
        item.edit = 1;
      } else {
        item.edit = 0;
      }
    }
  };

  LogisticsProvidersEdit.prototype.onGiveDateChange = function (e) {
    for (var i in this.orderDetail) {
      this.orderDetail[i].sales_change_give_date = e.format('YYYY-MM-DD');
    }
  };

  LogisticsProvidersEdit.prototype.onGiveDateMemoChange = function (e) {
    for (var i in this.orderDetail) {
      this.orderDetail[i].sales_change_give_date_memo = e.target.value;
    }
  };

  LogisticsProvidersEdit.prototype.onRefreshData = function (id) {
    var _this = this;

    this.innerAction.setActionAPI('/logistics_providers/query_detail', common_service["a" /* CommonService */].getMenuCode('logistics-providers-detail'));
    this.publicService.query(new http["RequestParams"]({
      logistics_providers_id: this.order.logistics_providers_id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.orderDetail = data.map(function (x) {
        return x;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  LogisticsProvidersEdit.prototype.getSubDepartmentList = function () {
    // this.subDepartList = this.departmentList.filter(x => x.dept_type == 100)
    //TODO
    this.subDepartList = this.departmentList;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "getcountry", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "replenishEditParams", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "commonPageInfo", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "getDepartmentList", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersEdit.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], LogisticsProvidersEdit.prototype, "onInfoChange", null);

  LogisticsProvidersEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddLogisticsProviderDetail: add_logistics_provider_detail["a" /* default */]
    }
  })], LogisticsProvidersEdit);
  return LogisticsProvidersEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var logistics_providers_editvue_type_script_lang_ts_ = (logistics_providers_editvue_type_script_lang_ts_LogisticsProvidersEdit);
// CONCATENATED MODULE: ./src/components/purchase/logistics-providers-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_logistics_providers_editvue_type_script_lang_ts_ = (logistics_providers_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/logistics-providers-edit.vue?vue&type=style&index=0&id=a21480b0&scoped=true&lang=css&
var logistics_providers_editvue_type_style_index_0_id_a21480b0_scoped_true_lang_css_ = __webpack_require__("2076");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/logistics-providers-edit.vue?vue&type=custom&index=0&blockType=i18n
var logistics_providers_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("47e3");

// CONCATENATED MODULE: ./src/components/purchase/logistics-providers-edit.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_logistics_providers_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  "a21480b0",
  null
  
)

/* custom blocks */

if (typeof logistics_providers_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(logistics_providers_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var logistics_providers_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "ab09":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_import_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("decd");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_import_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_import_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_import_purchase_product_plan_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ac1c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/edit-finish-qty-vendor.vue?vue&type=template&id=2290a57c&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"id","customRow":function (rowKey) { return ({
                    on: {
                        // 单击每行
                        click: function () {
                            _vm.currentRow = rowKey.id
                        }
                    }
                }); },"bordered":""}},[_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('columns.default_code'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.default_code))])]}}])}),_c('a-table-column',{key:"real_pre_purchase_order",attrs:{"title":_vm.$t('columns.real_pre_purchase_order'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.real_pre_purchase_order))])]}}])}),_c('a-table-column',{key:"order_id",attrs:{"title":_vm.$t('columns.order_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.order_id))])]}}])}),_c('a-table-column',{key:"product_qty",attrs:{"title":_vm.$t('columns.product_qty'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.product_qty))])]}}])}),_c('a-table-column',{key:"finish_yn",attrs:{"title":_vm.$t('columns.finish_yn'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'finish_yn',
                            {
                                initialValue: row.finish_yn,
                                valuePropName: 'checked'
                            }
                        ]),expression:"[\n                            'finish_yn',\n                            {\n                                initialValue: row.finish_yn,\n                                valuePropName: 'checked'\n                            }\n                        ]"}],attrs:{"disabled":true}})]}}])}),_c('a-table-column',{key:"finish_qty",attrs:{"title":_vm.$t('columns.finish_qty'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.finish_qty))])]}}])}),_c('a-table-column',{key:"new_finish_qty",attrs:{"title":_vm.$t('columns.new_finish_qty'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['new_finish_qty']),expression:"['new_finish_qty']"}],style:({ width: '100%', background: '#ecc5e9' }),attrs:{"decimalSeparator":",","value":row.new_finish_qty,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'new_finish_qty', e); }}})]}}])}),_c('a-table-column',{key:"vendor_id",attrs:{"title":_vm.$t('columns.vendor_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id']),expression:"['vendor_id']"}],style:({ width: '100%' }),attrs:{"showSearch":"","placeholder":"Please select","size":"small","value":row.vendor_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"filterOption":_vm.filterSelectOption},on:{"change":function (e) { return _vm.onRowChange(row, 'vendor_id', e); }}},_vm._l((_vm.vendorList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)]}}])})],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/edit-finish-qty-vendor.vue?vue&type=template&id=2290a57c&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/edit-finish-qty-vendor.vue?vue&type=script&lang=ts&









var edit_finish_qty_vendorvue_type_script_lang_ts_EditFinishQtyVendor =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](EditFinishQtyVendor, _super);

  function EditFinishQtyVendor() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.vendorList = [];
    _this.editable = true;
    return _this;
  }

  EditFinishQtyVendor.prototype.getVendorList = function () {
    var _this = this;

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('/vendor/get_vendor_list', common_service["a" /* CommonService */].getMenuCode('vendor-product-manage'));
    this.publicService.query(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      _this.vendorList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  EditFinishQtyVendor.prototype.created = function () {
    this.getVendorList();

    if (this.data) {
      for (var i in this.data) {
        this.data[i]['new_finish_qty'] = this.data[i].finish_qty;
      }
    }
  };

  EditFinishQtyVendor.prototype.mounted = function () {
    if (this.data) {
      for (var i in this.data) {
        this.data[i]['new_finish_qty'] = this.data[i].finish_qty;
      }
    }
  };

  EditFinishQtyVendor.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target && value.target.value) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }
  };

  EditFinishQtyVendor.prototype.onSubmit = function () {
    var _this = this;

    var new_data = [];

    for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
      var i = _a[_i];
      new_data.push({
        id: i.id,
        finish_qty: i.finish_qty,
        new_finish_qty: i.new_finish_qty,
        vendor_id: i.vendor_id,
        default_code: i.default_code
      });
    }

    var inneraction = new inner_action_service["a" /* InnerActionService */]();
    inneraction.setActionAPI('purchase_order_plan/confirm_change_finish_pty', common_service["a" /* CommonService */].getMenuCode('purchase-product-plan'));
    this.publicService.modify(new http["RequestParams"]({
      req_lines: new_data
    }, {
      loading: this.loadingService,
      innerAction: inneraction
    })).subscribe(function (data) {
      return true;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  EditFinishQtyVendor.prototype.cancel = function () {
    return;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], EditFinishQtyVendor.prototype, "data", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditFinishQtyVendor.prototype, "onSubmit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditFinishQtyVendor.prototype, "cancel", null);

  EditFinishQtyVendor = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], EditFinishQtyVendor);
  return EditFinishQtyVendor;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var edit_finish_qty_vendorvue_type_script_lang_ts_ = (edit_finish_qty_vendorvue_type_script_lang_ts_EditFinishQtyVendor);
// CONCATENATED MODULE: ./src/components/purchase/edit-finish-qty-vendor.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_edit_finish_qty_vendorvue_type_script_lang_ts_ = (edit_finish_qty_vendorvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/edit-finish-qty-vendor.vue?vue&type=custom&index=0&blockType=i18n
var edit_finish_qty_vendorvue_type_custom_index_0_blockType_i18n = __webpack_require__("a56a");

// CONCATENATED MODULE: ./src/components/purchase/edit-finish-qty-vendor.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_edit_finish_qty_vendorvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof edit_finish_qty_vendorvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(edit_finish_qty_vendorvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var edit_finish_qty_vendor = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "ada2c":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "ada3":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"instock":"Inventory Info","base":"Product Info","shipment":"Shipment Info","record":"In and Out Record","log":"Operate Log","depart":"Product Status","action":{"create":"Create","batch-create":"EXCEL Import","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Discard"}},"zh-cn":{"instock":"库存信息","base":"产品详情","shipment":"物流信息","record":"出入库记录","log":"日志","depart":"产品状态","action":{"create":"新建","batch-create":"EXCEL导入","edit":"编辑","delete":"删除","ok":"确定","cancel":"丢弃"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "b068":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cancel_attention_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("6ebc");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cancel_attention_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cancel_attention_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cancel_attention_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b4f6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_provider_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2748");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_provider_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_provider_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "b606":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"whs_id":"Warehouse","plan_date":"Planned Time","plzSelectWhs":"Please Select Warehouse","plzSelectDate":"Please Select Date","submit":"Submit","cancel":"Cancel"},"zh-cn":{"whs_id":"仓库","plan_date":"计划时间","plzSelectWhs":"请选择仓库","plzSelectDate":"请选择日期","submit":"提交","cancel":"取消"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "b6a0":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"submit":"Submit","cancel":"Cancel","columns":{"freight_forwarder_ship_owner":"freight_forwarder/ship_owner","shipping_company":"shipping_company","shipping_channel":"shipping_channel","historical_inquiry":"historical_inquiry","actual_quotation":"actual_quotation","shipping_amount":"shipping_amount","tax_amount":"tax_amount","insurance_amount":"insurance_amount","start_place":"start_place","destination_port":"destination_port","etd_estimated_domestic":"etd_estimated_domestic","actual_domestic":"actual_domestic","eta_estimated_arrival":"eta_estimated_arrival","actual_arrival":"actual_arrival","estimated_delivery":"estimated_delivery","shipment_number":"shipment_number","courier_company":"courier_company","customs_clearance_fee":"customs_clearance_fee","boat_company_code":"boat_company_code","package_number":"package_number","container_number":"container_number","invoice_number":"invoice_number","lading_number":"lading_number"}},"zh-cn":{"submit":"提交","cancel":"取消","columns":{"freight_forwarder_ship_owner":"货代/船东","shipping_company":"发货公司","shipping_channel":"发货渠道","historical_inquiry":"历史询价（单价）","actual_quotation":"实际报价（单价)","shipping_amount":"发货总金额","tax_amount":"税金","insurance_amount":"保险金额","start_place":"出发地点","destination_port":"目的港","etd_estimated_domestic":"ETD预计国内出发时间","actual_domestic":"国内实际出发时间","eta_estimated_arrival":"ETA预计到港时间","actual_arrival":"国外实际到港时间","estimated_delivery":"预计派送时间","shipment_number":"物流单号","courier_company":"快递公司","customs_clearance_fee":"清关尾程费用","boat_company_code":"船公司简码","package_number":"货柜号","container_number":"集装箱号","invoice_number":"发票号","lading_number":"提单号"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "bd4a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-feedback.vue?vue&type=template&id=24707a27&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.purchase_feedback'),"required":""}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                    "purchase_feedback",
                    { rules: _vm.rules.required }
                ]),expression:"[\n                    `purchase_feedback`,\n                    { rules: rules.required }\n                ]"}],attrs:{"size":"small"}})],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-feedback.vue?vue&type=template&id=24707a27&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-feedback.vue?vue&type=script&lang=ts&



var purchase_feedbackvue_type_script_lang_ts_PurchaseFeedback =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseFeedback, _super);

  function PurchaseFeedback() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  PurchaseFeedback.prototype.submit = function (value) {
    return value.purchase_feedback;
  };

  PurchaseFeedback.prototype.cancel = function () {
    return;
  };

  PurchaseFeedback.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  PurchaseFeedback.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        _this.submit(values);
      }
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseFeedback.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseFeedback.prototype, "cancel", null);

  PurchaseFeedback = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseFeedback);
  return PurchaseFeedback;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_feedbackvue_type_script_lang_ts_ = (purchase_feedbackvue_type_script_lang_ts_PurchaseFeedback);
// CONCATENATED MODULE: ./src/components/purchase/purchase-feedback.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_feedbackvue_type_script_lang_ts_ = (purchase_feedbackvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/purchase-feedback.vue?vue&type=custom&index=0&blockType=i18n
var purchase_feedbackvue_type_custom_index_0_blockType_i18n = __webpack_require__("d66f");

// CONCATENATED MODULE: ./src/components/purchase/purchase-feedback.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_feedbackvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_feedbackvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_feedbackvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_feedback = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "c08b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_finish_item_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("83b2");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_finish_item_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_finish_item_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_finish_item_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "c2f5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-contract-edit.vue?vue&type=template&id=6c05c788&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[(_vm.order.id)?_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[(_vm.order.state == 'draft')?_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.editChange}},[(!_vm.editAble)?_c('span',[_vm._v(_vm._s(_vm.$t('action.edit')))]):_c('span',[_vm._v(_vm._s(_vm.$t('action.discard')))])]):_vm._e(),(_vm.editAble)?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]):_vm._e(),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"default","size":"small","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.onBatchDelete}},[_c('span',[_vm._v(_vm._s(_vm.$t('action.delete')))])]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"default","size":"small"},on:{"click":_vm.onSyncProduct}},[_c('span',[_vm._v(_vm._s(_vm.$t('action.sync_product_info')))])]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"default","size":"small","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.onChangeGiveDate}},[_c('span',[_vm._v(_vm._s(_vm.$t('action.change_give_date')))])]),(_vm.order.state == 'confirm')?_c('a-button',{staticStyle:{"margin-left":"5px"},on:{"click":function($event){return _vm.verifyWithMemo('approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(_vm.order.state == 'refuse')?_c('a-button',{staticStyle:{"margin-left":"5px"},on:{"click":function($event){return _vm.onVerify('draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(_vm.order.state == 'draft')?_c('a-button',{staticStyle:{"margin-left":"5px"},on:{"click":function($event){return _vm.onVerify('confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(_vm.order.state == 'confirm')?_c('a-button',{staticStyle:{"margin-left":"5px"},on:{"click":function($event){return _vm.verifyWithMemo('refuse')}}},[_vm._v(" "+_vm._s(_vm.$t('action.refuse'))+" ")]):_vm._e(),_c('div',{staticStyle:{"position":"absolute","top":"10px","right":"10px"}},[_c('div',{staticClass:"progress-bar"},_vm._l((_vm.$dict.PurchaseContractState),function(item){return _c('li',{key:item.value,class:{ active: _vm.order.state == item.value },staticStyle:{"font-size":"12px"},attrs:{"value":item.value}},[_c('span',[_vm._v(_vm._s(_vm.$t(item.label)))])])}),0)])],1):_vm._e(),_c('section',{staticClass:"component edit-customer"},[_c('a-form',{attrs:{"form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-card',{staticClass:"margin-top order-edit-page"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.name')}},[_c('label',[_vm._v(_vm._s(_vm.order.name))])])],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.source_doc1'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                    "source_doc1",
                                    {
                                        rules: _vm.rules.required
                                    }
                                ]),expression:"[\n                                    `source_doc1`,\n                                    {\n                                        rules: rules.required\n                                    }\n                                ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.vendor_id'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                    "vendor_id",
                                    {
                                        rules: _vm.rules.required
                                    }
                                ]),expression:"[\n                                    `vendor_id`,\n                                    {\n                                        rules: rules.required\n                                    }\n                                ]"}],staticStyle:{"width":"300px"},attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption,"disabled":!_vm.editAble},model:{value:(_vm.order.vendor_id),callback:function ($$v) {_vm.$set(_vm.order, "vendor_id", $$v)},expression:"order.vendor_id"}},_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.order_date'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["order_date"]),expression:"[`order_date`]"}],staticStyle:{"width":"200px"},attrs:{"disabled":!_vm.editAble,"format":"YYYY-MM-DD","size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.order_company_id'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                    "order_company_id",
                                    {
                                        rules: _vm.rules.required
                                    }
                                ]),expression:"[\n                                    `order_company_id`,\n                                    {\n                                        rules: rules.required\n                                    }\n                                ]"}],staticStyle:{"width":"300px"},attrs:{"show-search":"","size":"small","disabled":!_vm.editAble},model:{value:(_vm.order.order_company_id),callback:function ($$v) {_vm.$set(_vm.order, "order_company_id", $$v)},expression:"order.order_company_id"}},[_c('a-select-option',{key:"woltu",attrs:{"value":"woltu"}},[_vm._v(" Woltu ")]),_c('a-select-option',{key:"eugad",attrs:{"value":"eugad"}},[_vm._v(" EUGAD ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.give_date'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                    "give_date",
                                    {
                                        rules: _vm.rules.required
                                    }
                                ]),expression:"[\n                                    `give_date`,\n                                    {\n                                        rules: rules.required\n                                    }\n                                ]"}],staticStyle:{"width":"200px"},attrs:{"disabled":!_vm.editAble,"format":"YYYY-MM-DD","size":"small"},on:{"change":function (e) { return _vm.onFormChange(e, 'give_date'); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.make_user')}},[_c('label',[_vm._v(_vm._s(_vm._f("dict2")(_vm.order.make_user,_vm.systemUsers)))])])],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.change_give_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["change_give_date"]),expression:"[`change_give_date`]"}],staticStyle:{"width":"200px"},attrs:{"disabled":!_vm.editAble,"format":"YYYY-MM-DD","size":"small"},on:{"change":function (e) { return _vm.onFormChange(e, 'change_give_date'); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.merchandiser')}},[_c('label',[_vm._v(_vm._s(_vm._f("dict2")(_vm.order.merchandiser,_vm.systemUsers)))])])],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.change_give_date_memo')}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["change_give_date_memo"]),expression:"[`change_give_date_memo`]"}],attrs:{"disabled":!_vm.editAble,"rows":"1","size":"small"},on:{"change":function (e) { return _vm.onFormChange(
                                            e,
                                            'change_give_date_memo'
                                        ); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.user_purchase')}},[_c('label',[_vm._v(_vm._s(_vm._f("dict2")(_vm.order.user_purchase,_vm.systemUsers)))])])],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.approved_user')}},[_c('label',[_vm._v(_vm._s(_vm._f("dict2")(_vm.order.approved_user,_vm.systemUsers)))])])],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.approve_memo')}},[_c('p',[_vm._v(_vm._s(_vm.order.approve_memo))])])],1)],1)],1),_c('a-card',{staticClass:"margin-top"},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.orderDetail,"pagination":false,"rowKey":"id","columns":_vm.detailColumns,"rowSelection":{
                        selectedRowKeys: _vm.selectedRowKeys,
                        onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                    },"customRow":function (record) { return ({
                            on: {
                                click: function () {
                                    this$1.selectedRowKeys = [record.id]
                                    //onRowClick(record)
                                }
                            }
                        }); },"scroll":{ x: 2000, y: 600 },"bordered":""},scopedSlots:_vm._u([{key:"ist_box_qty",fn:function(text, row){return [(row.id != 'summary')?_c('a-checkbox',{attrs:{"checked":row.ist_box_qty,"disabled":""}}):_vm._e()]}},{key:"product_purchase_price",fn:function(text){return [_vm._v(" "+_vm._s(text ? text.toFixed(2) : '')+" ")]}},{key:"manual_code",fn:function(text, row){return [(row.product_manual_url)?_c('a',{attrs:{"href":row.product_manual_url,"target":"_blank"}},[_vm._v(_vm._s(row.product_manual_code))]):_c('span')]}},{key:"specification_code",fn:function(text, row){return [(row.product_specification_url)?_c('a',{attrs:{"href":row.product_specification_url,"target":"_blank"}},[_vm._v(_vm._s(row.specification_code))]):_c('span')]}},{key:"action",fn:function(row){return [_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[(row.id != 'summary')?_c('a',{staticClass:"btnDel"},[_vm._v(_vm._s(_vm.$t('action.delete')))]):_vm._e()])]}}])})],1)],1)],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-contract-edit.vue?vue&type=template&id=6c05c788&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/purchase/change-give-date-form.vue + 4 modules
var change_give_date_form = __webpack_require__("7aba");

// EXTERNAL MODULE: ./src/components/cs_email_return/chat-modify-memo.vue + 4 modules
var chat_modify_memo = __webpack_require__("439a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-contract-edit.vue?vue&type=script&lang=ts&



















var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');
var userModule = Object(lib["c" /* namespace */])('userModule');

var purchase_contract_editvue_type_script_lang_ts_PurchaseContractEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseContractEdit, _super);

  function PurchaseContractEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.order = [];
    _this.orderDetail = [];
    _this.save_flag = 0;
    _this.originData = [];
    _this.isShowDetail = false; //是否只是详情展示

    _this.menu_code = '';
    _this.editAble = false;
    _this.detailColumns = [];
    _this.selectedRowKeys = [];
    _this.currencyList = [];
    _this.summaryList = ['product_qty', 'price_subtotal'];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  PurchaseContractEdit.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;
      this.updateOrder(this.info);
    }
  };

  PurchaseContractEdit.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.save_flag = 1;
      _this.editAble = false;

      if (_this.order.order_line.length) {
        _this.orderDetail = _this.order.order_line.map(function (x) {
          return x;
        });
      } else {
        _this.orderDetail = [];
      }

      if (_this.summaryList != undefined && _this.summaryList.length && _this.orderDetail.length) {
        var sm = _this.orderDetail.find(function (x) {
          return x.id == 'summary';
        });

        var ret = common_service["a" /* CommonService */].getSummaryData(_this.orderDetail, _this.summaryList); // ret['product_purchase_price'] = this.orderDetail.reduce(
        //     (total, x) => {
        //         return total + x.product_qty * x.product_purchase_price
        //     },
        //     0
        // )

        if (sm) {
          for (var _i = 0, _a = _this.summaryList; _i < _a.length; _i++) {
            var i = _a[_i];
            sm[i] = ret[i];
          }
        } else {
          ret['id'] = 'summary';
          ret['index'] = 'summary';

          _this.orderDetail.push(ret);

          _this.$nextTick(function () {
            var querySelector = 'tr[data-row-key="summary"]';
            var tr = document.querySelector(querySelector);
            tr.style.background = '#fdfdfd';
            var checkboxItem = tr.querySelector('.ant-table-selection-column .ant-checkbox-inner');
            checkboxItem.style.display = 'none';
            var span = document.createElement('span');
            span.innerText = '汇总';
            tr.querySelector('td').appendChild(span);
          });
        }
      }

      _this.form.setFieldsValue(_this.order);

      _this.selectedRowKeys = [];
    });
  };

  PurchaseContractEdit.prototype.created = function () {
    this.getcurrency();
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
    this.form = this.$form.createForm(this);
  };

  PurchaseContractEdit.prototype.mounted = function () {
    var _this = this;

    if (this.save_flag == 0) {
      this.editAble = true;
    }

    if (this.info) {
      this.updateOrder(this.info);
    }

    if (!this.menu_code) {
      this.menu_code = common_service["a" /* CommonService */].getMenuCode('replenishment-demand');
    }

    this.detailColumns = [{
      key: 'default_code',
      title: this.$t('columns.default_code'),
      dataIndex: 'default_code',
      width: 100
    }, {
      key: 'product_manual_version',
      title: this.$t('columns.product_manual_version'),
      dataIndex: 'product_manual_version',
      width: 100
    }, {
      key: 'product_manual_code',
      title: this.$t('columns.manual_code'),
      dataIndex: 'product_manual_code',
      width: 100,
      scopedSlots: {
        customRender: 'manual_code'
      }
    }, {
      key: 'specification_version',
      title: this.$t('columns.product_specification_version'),
      dataIndex: 'specification_version',
      width: 100
    }, {
      key: 'product_specification_code',
      title: this.$t('columns.specification_code'),
      dataIndex: 'product_specification_code',
      width: 100,
      scopedSlots: {
        customRender: 'specification_code'
      }
    }, {
      key: 'product_qty',
      title: this.$t('columns.product_qty'),
      dataIndex: 'product_qty',
      align: 'right',
      width: 100
    }, {
      key: 'product_purchase_price',
      title: this.$t('columns.product_purchase_price'),
      dataIndex: 'product_purchase_price',
      align: 'right',
      width: 100,
      scopedSlots: {
        customRender: 'product_purchase_price'
      }
    }, {
      key: 'product_purchase_currency',
      title: this.$t('columns.product_purchase_currency'),
      dataIndex: 'product_purchase_currency',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getCurrencyName(value);
        }

        return value;
      }
    }, {
      key: 'buyer_change_give_date',
      title: this.$t('columns.buyer_change_give_date'),
      dataIndex: 'buyer_change_give_date',
      width: 100
    }, {
      key: 'buyer_change_give_date_memo',
      title: this.$t('columns.buyer_change_give_date_memo'),
      dataIndex: 'buyer_change_give_date_memo',
      width: 100
    }, {
      key: 'date_expected',
      title: this.$t('columns.date_expected'),
      dataIndex: 'date_expected',
      width: 100
    }, {
      key: 'description_purchase',
      title: this.$t('columns.description_purchase'),
      dataIndex: 'description_purchase',
      ellipsis: true,
      width: 100
    }, {
      key: 'give_date',
      title: this.$t('columns.give_date'),
      dataIndex: 'give_date',
      width: 100
    }, {
      key: 'ist_box_qty',
      title: this.$t('columns.ist_box_qty'),
      dataIndex: 'ist_box_qty',
      width: 100,
      align: 'center',
      scopedSlots: {
        customRender: 'ist_box_qty'
      }
    }, {
      key: 'warehouse_id',
      title: this.$t('columns.warehouse_id'),
      dataIndex: 'warehouse_id',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getWarehouseName(value);
        }

        return value;
      }
    }, {
      key: 'note',
      title: this.$t('columns.note'),
      dataIndex: 'note',
      width: 100
    }, {
      key: 'price_subtotal',
      title: this.$t('columns.price_subtotal'),
      dataIndex: 'price_subtotal',
      align: 'right',
      width: 100
    }, {
      key: 'product_basic_size',
      title: this.$t('columns.product_basic_size'),
      dataIndex: 'product_basic_size',
      width: 100
    }, {
      key: 'product_color',
      title: this.$t('columns.product_color'),
      dataIndex: 'product_color',
      width: 100
    }, {
      key: 'product_package_size',
      title: this.$t('columns.product_package_size'),
      dataIndex: 'product_package_size',
      width: 100
    }, {
      key: 'product_sub_cate',
      title: this.$t('columns.product_sub_cate'),
      dataIndex: 'product_sub_cate',
      width: 100
    }, {
      key: 'product_uom',
      title: this.$t('columns.product_uom'),
      dataIndex: 'product_uom',
      width: 100
    }, {
      key: 'product_ve',
      title: this.$t('columns.product_ve'),
      dataIndex: 'product_ve',
      width: 100
    }, {
      key: 'product_weight',
      title: this.$t('columns.product_weight'),
      dataIndex: 'product_weight',
      align: 'right',
      width: 100
    }, {
      key: 'product_weight1',
      title: this.$t('columns.product_weight1'),
      dataIndex: 'product_weight1',
      align: 'right',
      width: 100
    }, {
      key: 'state',
      title: this.$t('columns.state'),
      dataIndex: 'state',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.$t(_this.$dict.ReplenishmentState.find(function (x) {
            return x.value == value;
          }).label);
        }

        return value;
      }
    }, {
      key: 'user_purchase',
      title: this.$t('columns.user_purchase'),
      dataIndex: 'user_purchase',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getUserName(value);
        }

        return value;
      }
    }, {
      key: 'merchandiser',
      title: this.$t('columns.merchandiser'),
      dataIndex: 'merchandiser',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getUserName(value);
        }

        return value;
      }
    }, {
      key: 'user_require',
      title: this.$t('columns.user_require'),
      dataIndex: 'user_require',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getUserName(value);
        }

        return value;
      }
    }, {
      key: 'vendor_id',
      title: this.$t('columns.vendor_id'),
      dataIndex: 'vendor_id',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getVendorName(value);
        }

        return value;
      }
    }, {
      key: 'action',
      title: this.$t('action.action'),
      width: 80,
      fixed: 'right',
      scopedSlots: {
        customRender: 'action'
      }
    }];
  };

  PurchaseContractEdit.prototype.getcurrency = function () {
    var _this = this;

    this.innerAction.setActionAPI('/vendor/get_currency_list', common_service["a" /* CommonService */].getMenuCode('vendor-product-manage'));
    this.publicService.query(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.currencyList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractEdit.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseContractEdit.prototype.updateDetailInfo = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/query_purchase_order_info', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));
    this.publicService.query(new http["RequestParams"]({
      order_id: this.info[0].id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.orderDetail = data[0].order_line;
    });
  };

  PurchaseContractEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      values['id'] = _this.order.id;
      values['save_flag'] = 1;

      _this.innerAction.setActionAPI('purchase_management/save_purchase_order_info', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));

      if (values.give_date && Object(esm_typeof["a" /* default */])(values.give_date) == 'object') {
        values.give_date = values.give_date.format('YYYY-MM-DD').toString();
      }

      if (values.change_give_date && Object(esm_typeof["a" /* default */])(values.change_give_date) == 'object') {
        values.change_give_date = values.change_give_date.format('YYYY-MM-DD').toString();
      }

      if (values.order_date && Object(esm_typeof["a" /* default */])(values.order_date) == 'object') {
        values.order_date = values.order_date.format('YYYY-MM-DD').toString();
      }

      var order_lines = [];

      if (_this.orderDetail) {
        order_lines = _this.orderDetail.map(function (x) {
          return {
            id: parseInt(x.id),
            order_date: values.order_date,
            give_date: values.give_date,
            buyer_change_give_date: values.change_give_date,
            buyer_change_give_date_memo: values.change_give_date_memo
          };
        });
      }

      values['order_lines'] = order_lines;

      _this.publicService.modify(new http["RequestParams"](values, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        var msg = _this.$t('tips.save_success');

        _this.$message.success(msg);
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  PurchaseContractEdit.prototype.editChange = function () {
    var pageId = 'purchasecontractedit' + this.order.id;
    var item = this.commonPageInfo.find(function (x) {
      return x.index == pageId;
    });

    if (item) {
      if (this.editAble) {
        item.edit = 1;
      } else {
        item.edit = 0;
      }
    }

    this.editAble = !this.editAble;
  };

  PurchaseContractEdit.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseContractEdit.prototype.getVendorName = function (code) {
    var ret = code;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseContractEdit.prototype.getCurrencyName = function (code) {
    var ret = code;
    var item = this.currencyList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseContractEdit.prototype.getWarehouseName = function (code) {
    var ret = code;
    var item = this.$dict.WarehouseId.find(function (x) {
      return x.value == code;
    });

    if (item) {
      ret = this.$t(item.label);
    }

    return ret;
  };

  PurchaseContractEdit.prototype.onDelete = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_purchase_order_line', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_id_list: [row.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.orderDetail = _this.orderDetail.filter(function (x) {
        return x.id != row.id;
      }); //更新缓存

      var pageId = 'purchasecontractedit' + _this.order.id;

      var item = _this.commonPageInfo.find(function (x) {
        return x.index == pageId;
      });

      if (item) {
        item.info[0].order_line = _this.orderDetail;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractEdit.prototype.onBatchDelete = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_purchase_order_line', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));
    this.publicService.modify(new http["RequestParams"]({
      line_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractEdit.prototype.onSyncProduct = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/sync_purchase_order_product_info', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));
    this.publicService.modify(new http["RequestParams"]({
      order_id_list: [this.order.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.updateDetailInfo();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractEdit.prototype.onChangeGiveDate = function () {
    var _this = this;

    this.$modal.open(change_give_date_form["a" /* default */], {}, {
      title: this.$t('action.change_give_date')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('purchase_management/update_purchase_order_line_give_date', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));

      _this.publicService.modify(new http["RequestParams"]({
        line_id_list: _this.selectedRowKeys,
        change_give_date: data.change_give_date,
        change_give_date_memo: data.change_give_date_memo
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractEdit.prototype.onVerify = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/update_purchase_order_state', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));
    this.publicService.modify(new http["RequestParams"]({
      order_id_list: [this.order.id],
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.order.state = state;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractEdit.prototype.verifyWithMemo = function (state) {
    var _this = this;

    this.$modal.open(chat_modify_memo["a" /* default */], {}, {
      title: this.$t('action.verify_mome')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('purchase_management/update_purchase_order_state', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));

      _this.publicService.modify(new http["RequestParams"]({
        order_id_list: [_this.order.id],
        state: state,
        approve_memo: data
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');

        _this.order.state = state;
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractEdit.prototype.onFormChange = function (e, field) {
    var value = '';
    var key = '';

    if (field == 'give_date') {
      key = 'give_date';
      value = e.format('YYYY-MM-DD').toString();
    } else if (field == 'change_give_date') {
      key = 'buyer_change_give_date';
      value = e.format('YYYY-MM-DD').toString();
    } else if (field == 'change_give_date_memo') {
      key = 'buyer_change_give_date_memo';
      value = e.target.value;
    }

    this.orderDetail.map(function (x) {
      x[key] = value;
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "purchaseContractParams", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "commonPageInfo", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "getVendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractEdit.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseContractEdit.prototype, "onInfoChange", null);

  PurchaseContractEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseContractEdit);
  return PurchaseContractEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_contract_editvue_type_script_lang_ts_ = (purchase_contract_editvue_type_script_lang_ts_PurchaseContractEdit);
// CONCATENATED MODULE: ./src/components/purchase/purchase-contract-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_contract_editvue_type_script_lang_ts_ = (purchase_contract_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/purchase-contract-edit.vue?vue&type=style&index=0&lang=css&
var purchase_contract_editvue_type_style_index_0_lang_css_ = __webpack_require__("d3de");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/purchase-contract-edit.vue?vue&type=custom&index=0&blockType=i18n
var purchase_contract_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("29fe");

// CONCATENATED MODULE: ./src/components/purchase/purchase-contract-edit.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_contract_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_contract_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_contract_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_contract_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "c328":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"name":"Name","code":"Code","contact_person":"Contact Person","contact_tel":"Contact Tel","memo":"Memo","currency_id":"Currency"},"action":{"order_detail":"Order Detail","other_form":"Other Form","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","today":"Today","yestoday":"Yestoday","3day":"3 Day","send_email":"Send Email","refund":"Refund Supplement Wizard","modify_cp":"Modify CP","other_info":"Other Info","save":"Save","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","plzInput":"Please Input","plzSelect":"Please Select"},"zh-cn":{"desc":"这是订单页面1","columns":{"name":"物流商名称","code":"物流商编码","contact_person":"联系人","contact_tel":"联系电话","memo":"备注","currency_id":"币种"},"action":{"order_detail":"订单明细","other_form":"其它信息","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","today":"前一天","yestoday":"前两天","3day":"前三天","send_email":"发送邮件","refund":"退款管理","modify_cp":"修改CP","other_info":"其它信息","save":"保存","verify":"审核","reset":"重置","confirm":"确认","refuse":"确认拒绝"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","plzInput":"请输入","plzSelect":"请选择"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "c58d":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "c8fc":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_make_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1f6d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_make_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_make_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_make_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "cab8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_return_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("28ec");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_return_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_return_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "cb4d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"actual_give_date":"Actual Give Date","actual_give_date_memo":"Actual Give Date Memo","box_qty":"Box Qty","container_group":"Container Group","currency_unit":"Currency Unit","default_code":"Default Code","gewicht":"Gewicht","height":"Height","id":"Id","is_fba":"Is Fba","length":"Length","name":"Name","note":"Note","out_number":"Out Number","pack_qty":"Pack Qty","price_subtotal":"Price Subtotal","price_unit":"Price Unit","prod_name":"Prod Name","product_cate":"Product Cate","product_qty":"Product Qty","product_volume":"Product Volume(m³)","product_weight":"Product Weight","state":"State","user_purchase":"User Purchase","warehouse_id":"warehouse_id","width":"Width","source_doc":"Source Doc","give_date":"Give Date","vendor_id":"vendor","order_date":"Order Date","make_user":"Make User","approved_user":"Approved User","is_change_sku":"Is Change SKU","change_no":"Change No."},"action":{"order_detail":"Order Detail","other_form":"Other Form","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","today":"Today","yestoday":"Yestoday","3day":"3 Day","send_email":"Send Email","refund":"Refund Supplement Wizard","modify_cp":"Modify CP","other_info":"Other Info","save":"Save","sync_product_info":"Synchronize Product","change_give_date":"Change Give Date","import":"Import","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse","verify_mome":"Memo"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"actual_give_date":"实际交期","actual_give_date_memo":"实际交期说明","box_qty":"箱数","container_group":"Container Group","currency_unit":"币种","default_code":"货号","gewicht":"毛重","height":"高","id":"Id","is_fba":"是否Fba","length":"长","name":"Name","note":"Note","out_number":"Out Number","pack_qty":"Pack Qty","price_subtotal":"Price Subtotal","price_unit":"Price Unit","prod_name":"产品名称","product_cate":"产品分类","product_qty":"产品数量","product_volume":"产品体积(m³)","product_weight":"产品宽度","state":"状态","user_purchase":"采购员","warehouse_id":"仓库","width":"宽","source_doc":"实际发货合同号","give_date":"合同交期","vendor_id":"供应商","order_date":"订单日期","make_user":"制单员","approved_user":"审核人","is_change_sku":"是否变更SKU","change_no":"变更单号"},"action":{"order_detail":"订单明细","other_form":"其它信息","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","today":"前一天","yestoday":"前两天","3day":"前三天","send_email":"发送邮件","refund":"退款管理","modify_cp":"修改CP","other_info":"其它信息","save":"保存","sync_product_info":"同步产品信息","change_give_date":"修改采购交期","import":"导入","verify":"审核","reset":"重置","confirm":"确认","refuse":"确认拒绝","verify_mome":"备注"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "cd0a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_provider_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0909");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_provider_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_provider_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_provider_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "cda4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-ship-order-edit.vue?vue&type=template&id=7fd908e4&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[(_vm.order.id && _vm.order.state == 'draft')?_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.editChange}},[(!_vm.editAble)?_c('span',[_vm._v(_vm._s(_vm.$t('action.edit')))]):_c('span',[_vm._v(_vm._s(_vm.$t('action.discard')))])]):_vm._e(),(_vm.editAble)?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save')))]):_vm._e(),(_vm.order.id && _vm.order.state == 'confirm')?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(_vm.order.id && _vm.order.state == 'confirm')?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(_vm.order.id && _vm.order.state == 'draft')?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),_c('div',{staticStyle:{"position":"absolute","top":"10px","right":"10px"}},[_c('div',{staticClass:"progress-bar"},_vm._l((_vm.$dict.PurchaseShipOrderState),function(item){return _c('li',{key:item.value,class:{ active: _vm.order.state == item.value },staticStyle:{"font-size":"12px"},attrs:{"value":item.value}},[_c('span',[_vm._v(_vm._s(_vm.$t(item.label)))])])}),0)])],1),_c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-card',{staticClass:"margin-top order-edit-page"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.save_flag),expression:"save_flag"}],attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["name"]),expression:"[`name`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.source_doc'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "source_doc",
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `source_doc`,\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.vendor_id'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "vendor_id",
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `vendor_id`,\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"300px"},attrs:{"show-search":"","size":"small","filterOption":_vm.filterSelectOption,"disabled":!_vm.editAble}},_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.give_date'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "give_date",
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `give_date`,\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"200px"},attrs:{"disabled":!_vm.editAble,"format":"YYYY-MM-DD","size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.order_date'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "order_date",
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `order_date`,\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"200px"},attrs:{"disabled":!_vm.editAble,"format":"YYYY-MM-DD","size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.actual_give_date_memo')}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["actual_give_date_memo"]),expression:"[`actual_give_date_memo`]"}],attrs:{"disabled":!_vm.editAble,"rows":"1","size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.make_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["make_user"]),expression:"[`make_user`]"}],staticStyle:{"width":"300px"},attrs:{"size":"small","disabled":""}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.save_flag),expression:"save_flag"}],attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.approved_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["approved_user"]),expression:"[`approved_user`]"}],staticStyle:{"width":"300px"},attrs:{"size":"small","disabled":""}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1)],1)],1)],1),_c('a-card',{staticClass:"margin-top"},[(this.order.state == 'draft')?_c('div',{staticStyle:{"margin":"10px"}},[_c('a-button',{on:{"click":_vm.importInfo}},[_vm._v(" "+_vm._s(_vm.$t('action.import'))+" ")])],1):_vm._e(),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.orderDetail,"pagination":false,"rowKey":"id","columns":_vm.detailColumns,"rowSelection":{
                        selectedRowKeys: _vm.selectedRowKeys,
                        onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                    },"customRow":function (record) { return ({
                            on: {
                                click: function () {
                                    this$1.selectedRowKeys = [record.id]
                                    //onRowClick(record)
                                }
                            }
                        }); },"scroll":{ x: 3000, y: 600 },"bordered":""},scopedSlots:_vm._u([{key:"product_volume",fn:function(text, row){return [(row.id != 'summary')?_c('span',[_vm._v(_vm._s(text / 1000000))]):_c('span',[_vm._v(_vm._s(text))])]}},{key:"check_render",fn:function(text){return [_c('a-checkbox',{attrs:{"disabled":"","checked":text}})]}},{key:"action",fn:function(row){return [_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[(row.id != 'summary')?_c('a',{staticClass:"btnDel"},[_vm._v(_vm._s(_vm.$t('action.delete')))]):_vm._e()])]}}])})],1)],1)])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-ship-order-edit.vue?vue&type=template&id=7fd908e4&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/purchase/change-give-date-form.vue + 4 modules
var change_give_date_form = __webpack_require__("7aba");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// EXTERNAL MODULE: ./src/components/cs_email_return/chat-modify-memo.vue + 4 modules
var chat_modify_memo = __webpack_require__("439a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-ship-order-edit.vue?vue&type=script&lang=ts&



















var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');
var userModule = Object(lib["c" /* namespace */])('userModule');

var purchase_ship_order_editvue_type_script_lang_ts_PurchaseShipOrderEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseShipOrderEdit, _super);

  function PurchaseShipOrderEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.order = {};
    _this.orderDetail = [];
    _this.save_flag = 0;
    _this.originData = [];
    _this.isShowDetail = false; //是否只是详情展示

    _this.menu_code = '';
    _this.editAble = false;
    _this.detailColumns = [];
    _this.selectedRowKeys = [];
    _this.summaryList = ['box_qty', 'pack_qty', 'product_qty', 'product_volume'];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  PurchaseShipOrderEdit.prototype.onShipContractParamsChange = function () {
    if (this.info) {
      this.editAble = false;
      this.updateOrder(this.info);
    }
  };

  PurchaseShipOrderEdit.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.save_flag = 1;
      _this.editAble = false;
      _this.orderDetail = _this.order.order_lines.map(function (x) {
        return x;
      });

      if (_this.summaryList != undefined && _this.summaryList.length && _this.orderDetail.length) {
        var sm = _this.orderDetail.find(function (x) {
          return x.id == 'summary';
        });

        var ret = common_service["a" /* CommonService */].getSummaryData(_this.orderDetail, _this.summaryList);

        if (sm) {
          for (var _i = 0, _a = _this.summaryList; _i < _a.length; _i++) {
            var i = _a[_i];
            sm[i] = ret[i];
          }
        } else {
          ret['id'] = 'summary';
          ret['index'] = 'summary';

          if (ret.product_volume) {
            ret.product_volume = _this.originData[0].product_volume;
          }

          _this.orderDetail.push(ret);

          _this.$nextTick(function () {
            var querySelector = 'tr[data-row-key="summary"]';
            var tr = document.querySelector(querySelector);
            tr.style.background = '#fdfdfd';
          });
        }
      }

      _this.selectedRowKeys = [];
    });
  };

  PurchaseShipOrderEdit.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
    this.form = this.$form.createForm(this);
  };

  PurchaseShipOrderEdit.prototype.mounted = function () {
    var _this = this;

    if (this.save_flag == 0) {
      this.editAble = true;
    }

    this.order.state = 'draft';

    if (this.info.length) {
      this.form.setFieldsValue(this.info[0]);
      this.updateOrder(this.info);
    }

    if (!this.menu_code) {
      this.menu_code = common_service["a" /* CommonService */].getMenuCode('replenishment-demand');
    }

    this.detailColumns = [{
      key: 'default_code',
      title: this.$t('columns.default_code'),
      dataIndex: 'default_code',
      width: 100
    }, {
      key: 'warehouse_id',
      title: this.$t('columns.warehouse_id'),
      dataIndex: 'warehouse_id',
      width: 100
    }, {
      key: 'box_qty',
      title: this.$t('columns.box_qty'),
      dataIndex: 'box_qty',
      align: 'right',
      width: 100
    }, {
      key: 'container_group',
      title: this.$t('columns.container_group'),
      dataIndex: 'container_group',
      width: 100
    }, {
      key: 'pack_qty',
      title: this.$t('columns.pack_qty'),
      dataIndex: 'pack_qty',
      align: 'right',
      width: 100
    }, {
      key: 'price_subtotal',
      title: this.$t('columns.price_subtotal'),
      dataIndex: 'price_subtotal',
      align: 'right',
      width: 100
    }, {
      key: 'price_unit',
      title: this.$t('columns.price_unit'),
      dataIndex: 'price_unit',
      align: 'center',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return row.id && row.id != 'summary' ? 'Units' : '';
        }

        return row.id && row.id != 'summary' ? 'Units' : '';
      }
    }, {
      key: 'prod_name',
      title: this.$t('columns.prod_name'),
      dataIndex: 'prod_name',
      width: 200
    }, {
      key: 'z_category',
      title: this.$t('columns.product_cate'),
      dataIndex: 'z_category',
      width: 100
    }, {
      key: 'product_qty',
      title: this.$t('columns.product_qty'),
      dataIndex: 'product_qty',
      align: 'right',
      width: 100
    }, {
      key: 'product_volume',
      title: this.$t('columns.product_volume'),
      dataIndex: 'product_volume',
      align: 'right',
      width: 100,
      scopedSlots: {
        customRender: 'product_volume'
      }
    }, {
      key: 'product_weight',
      title: this.$t('columns.product_weight'),
      dataIndex: 'product_weight',
      align: 'right',
      width: 100
    }, {
      key: 'state',
      title: this.$t('columns.state'),
      dataIndex: 'state',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          var item = _this.$dict.ReplenishmentState.find(function (x) {
            return x.value == value;
          });

          return item ? _this.$t(item.label) : value;
        }

        return value;
      }
    }, {
      key: 'actual_give_date',
      title: this.$t('columns.actual_give_date'),
      dataIndex: 'actual_give_date',
      width: 100
    }, {
      key: 'actual_give_date_memo',
      title: this.$t('columns.actual_give_date_memo'),
      dataIndex: 'actual_give_date_memo',
      width: 100
    }, {
      key: 'user_purchase',
      title: this.$t('columns.user_purchase'),
      dataIndex: 'user_purchase',
      width: 100,
      customRender: function customRender(value, row, index) {
        if (value) {
          return _this.getUserName(value);
        }

        return value;
      }
    }, {
      key: 'width',
      title: this.$t('columns.width'),
      dataIndex: 'width',
      align: 'right',
      width: 100
    }, {
      key: 'currency_unit',
      title: this.$t('columns.currency_unit'),
      dataIndex: 'currency_unit',
      width: 100
    }, {
      key: 'gewicht',
      title: this.$t('columns.gewicht'),
      dataIndex: 'gewicht',
      align: 'right',
      width: 100
    }, {
      key: 'height',
      title: this.$t('columns.height'),
      dataIndex: 'height',
      align: 'right',
      width: 100
    }, {
      key: 'is_fba',
      title: this.$t('columns.is_fba'),
      dataIndex: 'is_fba',
      width: 100
    }, {
      key: 'length',
      title: this.$t('columns.length'),
      dataIndex: 'length',
      align: 'right',
      width: 100
    }, {
      key: 'name',
      title: this.$t('columns.name'),
      dataIndex: 'name',
      width: 100
    }, {
      key: 'note',
      title: this.$t('columns.note'),
      dataIndex: 'note',
      width: 100
    }, {
      key: 'out_number',
      title: this.$t('columns.out_number'),
      dataIndex: 'out_number',
      align: 'right',
      width: 100
    }, {
      key: 'is_change_sku',
      title: this.$t('columns.is_change_sku'),
      dataIndex: 'is_change_sku',
      align: 'center',
      width: 80,
      scopedSlots: {
        customRender: 'check_render'
      }
    }, {
      key: 'change_no',
      title: this.$t('columns.change_no'),
      dataIndex: 'change_no',
      align: 'left',
      width: 120
    }, {
      key: 'action',
      title: this.$t('action.action'),
      width: 80,
      fixed: 'right',
      scopedSlots: {
        customRender: 'action'
      }
    }];
  };

  PurchaseShipOrderEdit.prototype.setFormValues = function () {
    var vl = this.form.getFieldsValue();
    vl.give_date = '2020-01-01';
    this.form.setFieldsValue(this.order);
  };

  PurchaseShipOrderEdit.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseShipOrderEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        if (_this.save_flag) {
          values['id'] = _this.order.id;
          values['save_flag'] = 1;
        } else {
          values['id'] = 0;
          values['save_flag'] = 0;
        }

        if (values.give_date) {
          values.give_date = moment_default()(values.give_date).format('YYYY-MM-DD');
        }

        if (values.order_date) {
          values.order_date = moment_default()(values.order_date).format('YYYY-MM-DD');
        }

        _this.innerAction.setActionAPI('ship_order/save_ship_order', common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'));

        _this.publicService.modify(new http["RequestParams"](values, {
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.order['id'] = data.message.order_id;
          _this.save_flag = 1;
          _this.order['name'] = data.message.order_name;

          _this.setFormValues();

          var msg = _this.$t('tips.save_success');

          _this.$message.success(msg);
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseShipOrderEdit.prototype.editChange = function () {
    this.editAble = !this.editAble;
    var pageId = 'purchaseshiporderedit' + this.order.id;
    var item = this.commonPageInfo.find(function (x) {
      return x.index == pageId;
    });

    if (item) {
      if (this.editAble) {
        item.edit = 1;
      } else {
        item.edit = 0;
      }
    }
  };

  PurchaseShipOrderEdit.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseShipOrderEdit.prototype.getVendorName = function (code) {
    var ret = code;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseShipOrderEdit.prototype.onDelete = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('ship_order/delete_ship_order_items', common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'));
    this.publicService.modify(new http["RequestParams"]({
      ids: [row.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.orderDetail = _this.orderDetail.filter(function (x) {
        return x.id != row.id;
      }); //更新缓存

      var pageId = 'purchaseshiporderedit' + _this.order.id;

      var item = _this.commonPageInfo.find(function (x) {
        return x.index == pageId;
      });

      if (item) {
        item.info[0].order_lines = _this.orderDetail;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrderEdit.prototype.onChangeGiveDate = function () {
    var _this = this;

    this.$modal.open(change_give_date_form["a" /* default */], {}, {
      title: this.$t('action.change_give_date')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('purchase_management/update_purchase_order_line_give_date', common_service["a" /* CommonService */].getMenuCode('purchase-contract-manage'));

      _this.publicService.modify(new http["RequestParams"]({
        line_id_list: _this.selectedRowKeys,
        change_give_date: data.change_give_date,
        change_give_date_memo: data.change_give_date_memo
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrderEdit.prototype.importInfo = function () {
    var _this = this;

    if (!this.order.id) {
      this.$message.success('Please save first then upload product information.');
      return;
    }

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['id'] = _this.order.id;
        var param = {};

        for (var i in values) {
          if (values[i]) {
            if (values[i]._isAMomentObject) {
              values[i] = values[i].format('YYYY-MM-DD');
            }

            param[i] = values[i];
          }
        }

        param['save_flag'] = _this.save_flag;

        _this.$modal.open(upload_excel["a" /* default */], {
          urlPath: '/system_api/upload?inner_action=ship_order/upload_ship_order_items&menu_code=' + common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'),
          uploadParams: {
            ship_order: JSON.stringify(param)
          },
          attachmentUrlPath: '/system/download_import_template?type=ShipOrderImport'
        }, {
          title: 'Import',
          width: '1000px'
        }).subscribe(function (data) {
          _this.$message.success('操作成功');

          if (data.message.create_msg) {
            _this.$message.warning(data.message.create_msg);
          }

          _this.refreshLline();
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseShipOrderEdit.prototype.onVerify = function (state) {
    var _this = this;

    if (state == 'confirm' && this.order.state == 'draft') {
      if (this.orderDetail.length < 1) {
        this.$message.error('明细行不能为空');
        return;
      }
    }

    this.innerAction.setActionAPI('ship_order/change_ship_order_state', common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'));
    this.publicService.modify(new http["RequestParams"]({
      order_ids: [this.order.id],
      old_state: this.order.state,
      new_state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.order.state = state;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrderEdit.prototype.verifyWithMemo = function (state) {
    var _this = this;

    this.$modal.open(chat_modify_memo["a" /* default */], {}, {
      title: this.$t('action.verify_mome')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('ship_order/change_ship_order_state', common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'));

      _this.publicService.modify(new http["RequestParams"]({
        order_ids: [_this.order.id],
        old_state: _this.order.state,
        new_state: state,
        approve_memo: data
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');

        _this.order.state = state;
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrderEdit.prototype.refreshLline = function () {
    var _this = this;

    this.innerAction.setActionAPI('ship_order/query_one_ship_orders', common_service["a" /* CommonService */].getMenuCode('purchase-ship-order'));
    this.publicService.query(new http["RequestParams"]({
      order_id: this.order.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      if (data[0].order_lines.length) {
        for (var i in data[0].order_lines) {
          _this.orderDetail.push(data[0].order_lines[i]);
        }
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "shipContractParams", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "commonPageInfo", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "getVendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrderEdit.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseShipOrderEdit.prototype, "onShipContractParamsChange", null);

  PurchaseShipOrderEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseShipOrderEdit);
  return PurchaseShipOrderEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_ship_order_editvue_type_script_lang_ts_ = (purchase_ship_order_editvue_type_script_lang_ts_PurchaseShipOrderEdit);
// CONCATENATED MODULE: ./src/components/purchase/purchase-ship-order-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_ship_order_editvue_type_script_lang_ts_ = (purchase_ship_order_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/purchase-ship-order-edit.vue?vue&type=style&index=0&lang=css&
var purchase_ship_order_editvue_type_style_index_0_lang_css_ = __webpack_require__("a954");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/purchase-ship-order-edit.vue?vue&type=custom&index=0&blockType=i18n
var purchase_ship_order_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("2b59");

// CONCATENATED MODULE: ./src/components/purchase/purchase-ship-order-edit.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_ship_order_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_ship_order_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_ship_order_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_ship_order_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "d3de":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4c21");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "d66e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("6666");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_modify_package_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "d66f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d696");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_feedback_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "d696":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"submit":"Submit","cancel":"Cancel","columns":{"purchase_feedback":"FeedBack"}},"zh-cn":{"submit":"提交","cancel":"取消","columns":{"purchase_feedback":"反馈"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "decd":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"import_type":"Import Type","import_method":"Import Method","none":"None","source_doc":"Import According To Source Doc","warehouse":"Import According To Warehouse","import_track_memo":"Import Track Memo","import_finish_time":"Import Finish Time","import_finish_qty":"Import Finish Qty"},"next":"Next Step","cancel":"Cancel","import":"Import"},"zh-cn":{"columns":{"import_type":"导入类型","import_method":"导入方式","none":"无","source_doc":"根据合同号导入","warehouse":"根据仓库导入","import_track_memo":"跟踪备注","import_finish_time":"工厂完成时间","import_finish_qty":"工厂完成备注"},"next":"下一步","cancel":"取消","import":"导入"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "e500":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"default_code":"SKU","real_pre_purchase_order":"Real Pre Purchase Order","order_id":"Make Requirement Order","product_qty":"Product Qty","finish_yn":"Is Finish","finish_qty":"Finish Qty","new_finish_qty":"New Finish Qty","vendor_id":"Vendor"},"action":{"edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","save":"Save","return":"Return","active":"Active","inactive":"Inactive","submit":"Submit"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"default_code":"货号","real_pre_purchase_order":"合同号","order_id":"订单号","product_qty":"数量","finish_yn":"跟踪完成","finish_qty":"原发货数量","new_finish_qty":"先发货数量","vendor_id":"供应商"},"action":{"edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","save":"保存","return":"返回","active":"还原","inactive":"归档","submit":"提交"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "e7bd":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("245d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_change_purchase_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ec4b":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"submit":"Submit","cancel":"Cancel","columns":{"change_give_date":"Change Give Date","change_give_date_memo":"Change Give Date Memo"}},"zh-cn":{"submit":"提交","cancel":"取消","columns":{"change_give_date":"修改交期","change_give_date_memo":"修改交期说明"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "f14d":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "f5d9":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"purchase_num":"purchase_num","common_sku":"common_sku","give_date":"give_date","shipped_qty":"shipped_qty","ship_qty":"ship_qty","product_qty":"product_qty","available_ship_qty":"available_ship_qty","ship_date":"ship_date","ship_aging":"ship_aging","dest_location_id":"dest_location_id","amazon_sku":"amazon_sku","amazon_asin":"amazon_asin","fn_sku":"fn_sku"},"action":{"split":"Split","edit":"Edit","delete":"Delete","ok":"Yes","more":"More","save":"Save","confirm":"Confirm","cancel":"Cancel"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"purchase_num":"采购订单编号","common_sku":"通用SKU","give_date":"订单交期","shipped_qty":"已发货数量","ship_qty":"本次发货数量","product_qty":"数量","available_ship_qty":"可发货数量","ship_date":"发货日期","ship_aging":"发货时效","dest_location_id":"目的地","amazon_sku":"Amazon SKU","amazon_asin":"ASIN","fn_sku":"FN SKU"},"action":{"split":"拆分","edit":"编辑","delete":"删除","ok":"确定","more":"更多操作","save":"保存","cancel":"取消"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "fb21":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/modify-package-logistic.vue?vue&type=template&id=52fb078a&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.source_doc1')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["source_doc1"]),expression:"[`source_doc1`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.carrier_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["carrier_name"]),expression:"[`carrier_name`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.bl_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["bl_code"]),expression:"[`bl_code`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.package_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["package_code"]),expression:"[`package_code`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.clearance_data_submit_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["clearance_data_submit_date"]),expression:"[`clearance_data_submit_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.bl_finish_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["bl_finish_date"]),expression:"[`bl_finish_date`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small","format":"YYYY-MM-DD"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.shipment_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["shipment_number"]),expression:"[`shipment_number`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.port_start')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["port_start"]),expression:"[`port_start`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.port_end')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["port_end"]),expression:"[`port_end`]"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.bl_xingshi')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['bl_xingshi']),expression:"['bl_xingshi']"}],style:({
                            width: '100%',
                            'max-width': '240px'
                        }),attrs:{"size":"small","placeholder":"Please Select"}},[_c('a-select-option',{key:"zs",attrs:{"value":"zs"}},[_vm._v(" ZS ")]),_c('a-select-option',{key:"df",attrs:{"value":"df"}},[_vm._v(" DF ")])],1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.express_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['express_name']),expression:"['express_name']"}],style:({
                            width: '100%',
                            'max-width': '240px'
                        }),attrs:{"size":"small","placeholder":"Please Select"}},[_c('a-select-option',{key:"tnt",attrs:{"value":"tnt"}},[_vm._v(" TNT ")]),_c('a-select-option',{key:"dhl",attrs:{"value":"dhl"}},[_vm._v(" DHL ")])],1)],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/modify-package-logistic.vue?vue&type=template&id=52fb078a&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/modify-package-logistic.vue?vue&type=script&lang=ts&








var modify_package_logisticvue_type_script_lang_ts_ModifyPackageLogistic =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ModifyPackageLogistic, _super);

  function ModifyPackageLogistic() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  ModifyPackageLogistic.prototype.submit = function () {
    return true;
  };

  ModifyPackageLogistic.prototype.cancel = function () {
    return;
  };

  ModifyPackageLogistic.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ModifyPackageLogistic.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        _this.saveInfo(values);
      }
    });
  };

  ModifyPackageLogistic.prototype.saveInfo = function (values) {
    var _this = this;

    var flag = true;

    for (var item in values) {
      if (values[item]) {
        flag = false;
      } else {
        delete values[item];
      }
    }

    if (flag) {
      this.$message.error('至少输入一项');
    } else {
      values['pack_id_list'] = this.ids;
      this.innerAction.setActionAPI('purchase_management/update_package_logistics', common_service["a" /* CommonService */].getMenuCode('purchase-package-manage'));
      this.publicService.modify(new http["RequestParams"](values, {
        loading: this.loadingService,
        innerAction: this.innerAction
      })).subscribe(function (data) {
        _this.submit();
      }, function (err) {
        _this.$message.error(err.message);
      });
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ModifyPackageLogistic.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ModifyPackageLogistic.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ModifyPackageLogistic.prototype, "ids", void 0);

  ModifyPackageLogistic = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ModifyPackageLogistic);
  return ModifyPackageLogistic;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var modify_package_logisticvue_type_script_lang_ts_ = (modify_package_logisticvue_type_script_lang_ts_ModifyPackageLogistic);
// CONCATENATED MODULE: ./src/components/purchase/modify-package-logistic.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_modify_package_logisticvue_type_script_lang_ts_ = (modify_package_logisticvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/modify-package-logistic.vue?vue&type=custom&index=0&blockType=i18n
var modify_package_logisticvue_type_custom_index_0_blockType_i18n = __webpack_require__("0ff6");

// CONCATENATED MODULE: ./src/components/purchase/modify-package-logistic.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_modify_package_logisticvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof modify_package_logisticvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(modify_package_logisticvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var modify_package_logistic = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "fc12":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-cancel-attention.vue?vue&type=template&id=304baaec&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('table',{staticClass:"xtb"},[_c('tr',[_c('td',[_vm._v(_vm._s(_vm.$t('columns.purchase_detail')))]),_c('td',{staticStyle:{"padding":"0"}},[_c('table',{staticClass:"xtb",staticStyle:{"border":"none"}},[_c('tr',[_c('th',[_vm._v(_vm._s(_vm.$t('columns.name')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.attention_item')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.quantity')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.cn_category')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.color')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.material')))])]),_vm._l((_vm.info),function(x,i){return _c('tr',{key:i},[_c('td',{key:x.req_name},[_vm._v(_vm._s(x.req_name))]),_c('td',{key:x.attention_item},[_vm._v(" "+_vm._s(x.attention_item)+" ")]),_c('td',{key:x.product_qty},[_vm._v(_vm._s(x.product_qty))]),_c('td',{key:x.z_sub_category},[_vm._v(" "+_vm._s(x.z_sub_category)+" ")]),_c('td',{key:x.product_color},[_vm._v(" "+_vm._s(x.product_color)+" ")]),_c('td',{key:x.pack_material},[_vm._v(" "+_vm._s(x.pack_material)+" ")])])})],2)])]),_c('tr',[_c('td',[_vm._v(_vm._s(_vm.$t('columns.reason')))]),_c('td',{staticClass:"required"},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['reason']),expression:"['reason']"}],ref:"reason",staticStyle:{"width":"100%"},attrs:{"size":"small"},model:{value:(_vm.reason),callback:function ($$v) {_vm.reason=$$v},expression:"reason"}})],1)])]),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-cancel-attention.vue?vue&type=template&id=304baaec&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-cancel-attention.vue?vue&type=script&lang=ts&









var purchase_cancel_attentionvue_type_script_lang_ts_PurchaseCancelAttention =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseCancelAttention, _super);

  function PurchaseCancelAttention() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.reason = '';
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  PurchaseCancelAttention.prototype.submit = function () {
    return true;
  };

  PurchaseCancelAttention.prototype.cancel = function () {
    return;
  };

  PurchaseCancelAttention.prototype.mounted = function () {
    var _this = this;

    this.$nextTick(function () {
      var reasonInput = _this.$refs.reason;
      reasonInput.focus();
    });
  };

  PurchaseCancelAttention.prototype.onSubmit = function () {
    var _this = this;

    if (!this.reason) {
      this.$message.error('原因不能为空!');
      var reasonInput = this.$refs.reason;
      reasonInput.focus();
      return;
    }

    this.innerAction.setActionAPI('purchase_order_plan/change_exists_attention', common_service["a" /* CommonService */].getMenuCode('purchase-product-plan'));
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.info.map(function (x) {
        return x.id;
      }),
      cancelAttentionMemo: this.reason
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseCancelAttention.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseCancelAttention.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseCancelAttention.prototype, "info", void 0);

  PurchaseCancelAttention = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseCancelAttention);
  return PurchaseCancelAttention;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_cancel_attentionvue_type_script_lang_ts_ = (purchase_cancel_attentionvue_type_script_lang_ts_PurchaseCancelAttention);
// CONCATENATED MODULE: ./src/components/purchase/purchase-cancel-attention.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_cancel_attentionvue_type_script_lang_ts_ = (purchase_cancel_attentionvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/purchase-cancel-attention.vue?vue&type=style&index=0&lang=css&
var purchase_cancel_attentionvue_type_style_index_0_lang_css_ = __webpack_require__("1474");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/purchase-cancel-attention.vue?vue&type=custom&index=0&blockType=i18n
var purchase_cancel_attentionvue_type_custom_index_0_blockType_i18n = __webpack_require__("b068");

// CONCATENATED MODULE: ./src/components/purchase/purchase-cancel-attention.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_cancel_attentionvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_cancel_attentionvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_cancel_attentionvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_cancel_attention = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "fe3b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-return.vue?vue&type=template&id=6cf2f2e0&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('table',{staticClass:"xtb"},[_c('tr',[_c('td',[_vm._v(_vm._s(_vm.$t('columns.purchase_detail')))]),_c('td',{staticStyle:{"padding":"0"}},[_c('table',{staticClass:"xtb",staticStyle:{"border":"none"}},[_c('tr',[_c('th',[_vm._v(_vm._s(_vm.$t('columns.name')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.quantity')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.cn_category')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.color')))]),_c('th',[_vm._v(_vm._s(_vm.$t('columns.material')))])]),_vm._l((_vm.info),function(x,i){return _c('tr',{key:i},[_c('td',{key:x.default_code},[_vm._v(_vm._s(x.default_code))]),_c('td',{key:x.product_qty},[_vm._v(_vm._s(x.product_qty))]),_c('td',{key:x.z_sub_category},[_vm._v(" "+_vm._s(x.z_sub_category)+" ")]),_c('td',{key:x.product_color},[_vm._v(" "+_vm._s(x.product_color)+" ")]),_c('td',{key:x.pack_material},[_vm._v(" "+_vm._s(x.pack_material)+" ")])])})],2)])]),_c('tr',[_c('td',[_vm._v(_vm._s(_vm.$t('columns.reason')))]),_c('td',{staticClass:"required"},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['reason']),expression:"['reason']"}],ref:"reason",staticStyle:{"width":"100%"},attrs:{"size":"small"},model:{value:(_vm.reason),callback:function ($$v) {_vm.reason=$$v},expression:"reason"}})],1)])]),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('submit')))])],1)])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/purchase-return.vue?vue&type=template&id=6cf2f2e0&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/purchase-return.vue?vue&type=script&lang=ts&









var purchase_returnvue_type_script_lang_ts_PurchaseReturn =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseReturn, _super);

  function PurchaseReturn() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.reason = '';
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  PurchaseReturn.prototype.submit = function () {
    return true;
  };

  PurchaseReturn.prototype.cancel = function () {
    return;
  };

  PurchaseReturn.prototype.mounted = function () {
    var _this = this;

    this.$nextTick(function () {
      var reasonInput = _this.$refs.reason;
      reasonInput.focus();
    });
  };

  PurchaseReturn.prototype.onSubmit = function () {
    var _this = this;

    if (!this.reason) {
      this.$message.error('原因不能为空!');
      var reasonInput = this.$refs.reason;
      reasonInput.focus();
      return;
    }

    this.innerAction.setActionAPI('purchase_requirement/refuse_make_purchase_order', common_service["a" /* CommonService */].getMenuCode('purchase-pre-make-order'));
    this.publicService.modify(new http["RequestParams"]({
      refuse_lines: this.info.map(function (x) {
        return x.id;
      }),
      refuse_memo: this.reason
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseReturn.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseReturn.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseReturn.prototype, "info", void 0);

  PurchaseReturn = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseReturn);
  return PurchaseReturn;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_returnvue_type_script_lang_ts_ = (purchase_returnvue_type_script_lang_ts_PurchaseReturn);
// CONCATENATED MODULE: ./src/components/purchase/purchase-return.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_returnvue_type_script_lang_ts_ = (purchase_returnvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/purchase-return.vue?vue&type=style&index=0&lang=css&
var purchase_returnvue_type_style_index_0_lang_css_ = __webpack_require__("cab8");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/purchase-return.vue?vue&type=custom&index=0&blockType=i18n
var purchase_returnvue_type_custom_index_0_blockType_i18n = __webpack_require__("76e0");

// CONCATENATED MODULE: ./src/components/purchase/purchase-return.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_returnvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_returnvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_returnvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_return = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "fed53":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_11_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_11_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_11_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_11_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_make_package_order_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ada2c");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_11_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_11_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_11_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_11_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_make_package_order_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_11_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_11_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_11_oneOf_1_2_node_modules_less_loader_dist_cjs_js_ref_11_oneOf_1_3_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_make_package_order_vue_vue_type_style_index_0_lang_less___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ })

}]);