(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~4ebb1a2a"],{

/***/ "00a1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EmailService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("7d9b");




/**
 * 邮件API服务
 */

var EmailService =
/** @class */
function () {
  function EmailService() {}
  /**
   * 邮件客户列表
   * @param requestParams
   */


  EmailService.prototype.getEmailUserList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 当前客户邮件往来记录
   * @param requestParams
   */


  EmailService.prototype.getCurrentUserMessage = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 发送邮件
   * @param requestParams
   */


  EmailService.prototype.actionSendEmail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 设置已回复
   * @param requestParams
   */


  EmailService.prototype.actionSetReply = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取模板接口
   * @param requestParams
   */


  EmailService.prototype.getTemplates = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取模板接口
   * @param requestParams
   */


  EmailService.prototype.saveTemplate = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 关注模板接口
   * @param requestParams
   */


  EmailService.prototype.starTemplate = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 关注模板接口
   * @param requestParams
   */


  EmailService.prototype.deleteTemplate = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改memo接口
   * @param requestParams
   */


  EmailService.prototype.actionWriteMemo = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 创建批注接口
   * @param requestParams
   */


  EmailService.prototype.actionCreateAnnotation = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取邮件原文接口
   * @param requestParams
   */


  EmailService.prototype.getOriginMessage = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 撤销未实际发送的信息
   * @param requestParams
   */


  EmailService.prototype.revertMessage = function (requestParams) {
    return requestParams.request();
  };
  /**
   *
   * @param requestParams
   */


  EmailService.prototype.queryPickingList = function (requestParams) {
    return requestParams.request();
  };
  /**
   *
   * @param requestParams
   */


  EmailService.prototype.modifyMemo = function (requestParams) {
    return requestParams.request();
  };
  /**
   *
   * @param requestParams
   */


  EmailService.prototype.queryNoNeedReply = function (requestParams) {
    return requestParams.request();
  };
  /**
   *
   * @param requestParams
   */


  EmailService.prototype.setNoNeedReplyDone = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].get_userlist
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], EmailService.prototype, "getEmailUserList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].get_currentUserMessage
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], EmailService.prototype, "getCurrentUserMessage", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].action_send_email
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], EmailService.prototype, "actionSendEmail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].action_set_reply
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], EmailService.prototype, "actionSetReply", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].get_templates
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], EmailService.prototype, "getTemplates", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].saveTemplate
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], EmailService.prototype, "saveTemplate", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].starTemplate
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], EmailService.prototype, "starTemplate", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].deleteTemplate
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], EmailService.prototype, "deleteTemplate", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].action_write_memo
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], EmailService.prototype, "actionWriteMemo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].action_create_annotation
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], EmailService.prototype, "actionCreateAnnotation", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].get_origin_message
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], EmailService.prototype, "getOriginMessage", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].revert_message
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], EmailService.prototype, "revertMessage", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].queryPickingList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], EmailService.prototype, "queryPickingList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].modifyMemo
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_2 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _2 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_3 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _3 : Object)], EmailService.prototype, "modifyMemo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].queryNoNeedReply
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_4 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _4 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_5 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _5 : Object)], EmailService.prototype, "queryNoNeedReply", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_cs_email_controller__WEBPACK_IMPORTED_MODULE_3__[/* EmailController */ "a"].setNoNeedReplyDone
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_6 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _6 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_7 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _7 : Object)], EmailService.prototype, "setNoNeedReplyDone", null);

  return EmailService;
}();



/***/ }),

/***/ "0d91":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PurchaseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("f384");




/**
 * 订单API服务
 */

var PurchaseService =
/** @class */
function () {
  function PurchaseService() {}
  /**
   * 生成采购预算数据
   * @param requestParams
   */


  PurchaseService.prototype.save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询船运费接口
   * @param requestParams
   */


  PurchaseService.prototype.query_all_boat_shipping_fee = function (requestParams) {
    return requestParams.request();
  };
  /**
   * save船运费接口
   * @param requestParams
   */


  PurchaseService.prototype.save_boat_shipping_fee = function (requestParams) {
    return requestParams.request();
  };
  /**
   * delete船运费接口
   * @param requestParams
   */


  PurchaseService.prototype.delete_boat_shipping_fee = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询船费预警接口
   * @param requestParams
   */


  PurchaseService.prototype.query_all_boat_shipping_fee_monitor = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询采购金额用接口
   * @param requestParams
   */


  PurchaseService.prototype.query_all_purchase_price_report = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询采购交期用接口
   * @param requestParams
   */


  PurchaseService.prototype.query_all_purchase_give_date_report = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询采购降本费用接口
   * @param requestParams
   */


  PurchaseService.prototype.query_all_purchase_reduce_costs_report = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询SKU库存
   * @param requestParams
   */


  PurchaseService.prototype.query_all_purchase_prod_qty_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询采购产品质量合格率
   * @param requestParams
   */


  PurchaseService.prototype.query_all_quality_pass_ratio_report = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PurchaseService.prototype, "save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].query_all_boat_shipping_fee
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], PurchaseService.prototype, "query_all_boat_shipping_fee", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].save_boat_shipping_fee
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], PurchaseService.prototype, "save_boat_shipping_fee", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].delete_boat_shipping_fee
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], PurchaseService.prototype, "delete_boat_shipping_fee", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].query_all_boat_shipping_fee_monitor
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], PurchaseService.prototype, "query_all_boat_shipping_fee_monitor", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].query_all_purchase_price_report
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], PurchaseService.prototype, "query_all_purchase_price_report", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].query_all_purchase_give_date_report
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], PurchaseService.prototype, "query_all_purchase_give_date_report", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].query_all_purchase_reduce_costs_report
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], PurchaseService.prototype, "query_all_purchase_reduce_costs_report", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].query_all_purchase_prod_qty_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], PurchaseService.prototype, "query_all_purchase_prod_qty_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchase_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseController */ "a"].query_all_quality_pass_ratio_report
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], PurchaseService.prototype, "query_all_quality_pass_ratio_report", null);

  return PurchaseService;
}();



/***/ }),

/***/ "1af5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ShipmentService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_shipment_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("96bb");




/**
 * 产品API服务
 */

var ShipmentService =
/** @class */
function () {
  function ShipmentService() {}
  /**
   * 物流类型查询
   * @param requestParams
   */


  ShipmentService.prototype.queryAllShipType = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 物流类型保存
   * @param requestParams
   */


  ShipmentService.prototype.saveShipType = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取发送RT邮件数据
   * @param requestParams
   */


  ShipmentService.prototype.getSendData = function (requestParams) {
    return requestParams.request();
  };
  /**
   * done_picking_get_shipping_label
   * @param requestParams
   */


  ShipmentService.prototype.donePickingGetLabel = function (requestParams) {
    return requestParams.request();
  };
  /**
   * done_picking_get_shipping_label
   * @param requestParams
   */


  ShipmentService.prototype.deleteShipmentOrder = function (requestParams) {
    return requestParams.request();
  };
  /**
   * done_picking_get_shipping_label
   * @param requestParams
   */


  ShipmentService.prototype.getShipmentList = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_shipment_controller__WEBPACK_IMPORTED_MODULE_3__[/* ShipmentController */ "a"].query_all_ship_type
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], ShipmentService.prototype, "queryAllShipType", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_shipment_controller__WEBPACK_IMPORTED_MODULE_3__[/* ShipmentController */ "a"].save_ship_type
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], ShipmentService.prototype, "saveShipType", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_shipment_controller__WEBPACK_IMPORTED_MODULE_3__[/* ShipmentController */ "a"].getSendData
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], ShipmentService.prototype, "getSendData", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_shipment_controller__WEBPACK_IMPORTED_MODULE_3__[/* ShipmentController */ "a"].done_picking_get_shipping_label
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], ShipmentService.prototype, "donePickingGetLabel", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_shipment_controller__WEBPACK_IMPORTED_MODULE_3__[/* ShipmentController */ "a"].delete_shipment_order
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], ShipmentService.prototype, "deleteShipmentOrder", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_shipment_controller__WEBPACK_IMPORTED_MODULE_3__[/* ShipmentController */ "a"].query_all_shipment
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], ShipmentService.prototype, "getShipmentList", null);

  return ShipmentService;
}();



/***/ }),

/***/ "1c60":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AliexpressService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("ddb4");




/**
 * 订单API服务
 */

var AliexpressService =
/** @class */
function () {
  function AliexpressService() {}
  /**
   * 导入订单
   * @param requestParams
   */


  AliexpressService.prototype.importOrders = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 结单
   * @param requestParams
   */


  AliexpressService.prototype.fulfilOrders = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 库存管理接口
   * @param requestParams
   */


  AliexpressService.prototype.query_all = function (requestParams) {
    return requestParams.request();
  };
  /**
   * listing_save
   * @param requestParams
   */


  AliexpressService.prototype.listing_save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 库存管理merge user
   * @param requestParams
   */


  AliexpressService.prototype.mergeUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 库存管理merge auto
   * @param requestParams
   */


  AliexpressService.prototype.mergeAuto = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 库存管理cancelAuto
   * @param requestParams
   */


  AliexpressService.prototype.cancelAuto = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__[/* AliexpressController */ "a"].importOrders
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], AliexpressService.prototype, "importOrders", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__[/* AliexpressController */ "a"].fulfilOrders
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], AliexpressService.prototype, "fulfilOrders", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__[/* AliexpressController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], AliexpressService.prototype, "query_all", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__[/* AliexpressController */ "a"].listing_save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], AliexpressService.prototype, "listing_save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__[/* AliexpressController */ "a"].mergeUser
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], AliexpressService.prototype, "mergeUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__[/* AliexpressController */ "a"].mergeAuto
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], AliexpressService.prototype, "mergeAuto", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_aliexpress_controller__WEBPACK_IMPORTED_MODULE_3__[/* AliexpressController */ "a"].cancelAuto
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], AliexpressService.prototype, "cancelAuto", null);

  return AliexpressService;
}();



/***/ }),

/***/ "1d1e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ProductService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("e5fb");




/**
 * 订单API服务
 */

var ProductService =
/** @class */
function () {
  function ProductService() {}
  /**
   * 查询关联sku
   * @param requestParams
   */


  ProductService.prototype.queryProductPack = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询sku
   * @param requestParams
   */


  ProductService.prototype.queryProducForStockMove = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询sku new
   * @param requestParams
   */


  ProductService.prototype.queryAsyncProductInfo = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询通用货号
   * @param requestParams
   */


  ProductService.prototype.query_all_common_sku = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询基础货号
   * @param requestParams
   */


  ProductService.prototype.query_all_basic_sku = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询组合货号
   * @param requestParams
   */


  ProductService.prototype.query_all_bp_pack = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品详情
   * @param requestParams
   */


  ProductService.prototype.query_product_basic_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品extra info
   * @param requestParams
   */


  ProductService.prototype.query_product_extra_value = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品物流信息
   * @param requestParams
   */


  ProductService.prototype.query_de_best_logistic_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品物流信息
   * @param requestParams
   */


  ProductService.prototype.query_uk_best_logistic_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品库存信息
   * @param requestParams
   */


  ProductService.prototype.query_product_stock_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品库存信息
   * @param requestParams
   */


  ProductService.prototype.query_location_stock_detail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品库存信息
   * @param requestParams
   */


  ProductService.prototype.query_factory_product_detail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品库存信息
   * @param requestParams
   */


  ProductService.prototype.query_shipping_product_detail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品库存信息
   * @param requestParams
   */


  ProductService.prototype.query_amazon_listing_detail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存产品基础信息
   * @param requestParams
   */


  ProductService.prototype.save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存产品额外信息
   * @param requestParams
   */


  ProductService.prototype.save_product_extra_value = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除产品额外信息
   * @param requestParams
   */


  ProductService.prototype.delete_extra_value = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 商品出入库记录
   * @param requestParams
   */


  ProductService.prototype.query_product_stock_operation = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有货号
   * @param requestParams
   */


  ProductService.prototype.query_all_type_sku = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询日志
   * @param requestParams
   */


  ProductService.prototype.query_product_log = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询说明书版本
   * @param requestParams
   */


  ProductService.prototype.query_manual_version = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询说明书
   * @param requestParams
   */


  ProductService.prototype.query_all_product_manual = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询配件/B品
   * @param requestParams
   */


  ProductService.prototype.query_all_basic_product_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   *产品常用查询
   * @param requestParams
   */


  ProductService.prototype.query_all_product_template = function (requestParams) {
    return requestParams.request();
  };
  /**
   *工艺单查询
   * @param requestParams
   */


  ProductService.prototype.query_all_product_specification = function (requestParams) {
    return requestParams.request();
  };
  /**
   *工艺单版本查询
   * @param requestParams
   */


  ProductService.prototype.query_specification_version = function (requestParams) {
    return requestParams.request();
  };
  /**
   *编辑说明书
   * @param requestParams
   */


  ProductService.prototype.save_prod_manual_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   *编辑工艺单
   * @param requestParams
   */


  ProductService.prototype.save_prod_specification_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   *删除说明书
   * @param requestParams
   */


  ProductService.prototype.delete_prod_manual_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   *删除说明书
   * @param requestParams
   */


  ProductService.prototype.reset_prod_manual_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   *删除工艺单
   * @param requestParams
   */


  ProductService.prototype.delete_prod_specification_info = function (requestParams) {
    return requestParams.request();
  };
  /**
   *根据条件查询产品出入库记录
   * @param requestParams
   */


  ProductService.prototype.query_all_product_in_out_warehouse = function (requestParams) {
    return requestParams.request();
  };
  /**
   *标记归档
   * @param requestParams
   */


  ProductService.prototype.mergeInactive = function (requestParams) {
    return requestParams.request();
  };
  /**
   *还原归档
   * @param requestParams
   */


  ProductService.prototype.mergeActive = function (requestParams) {
    return requestParams.request();
  };
  /**
   *同步通用货号信息
   * @param requestParams
   */


  ProductService.prototype.synCommonSkuInfo = function (requestParams) {
    return requestParams.request();
  };
  /**
   *同步通用货号额外属性
   * @param requestParams
   */


  ProductService.prototype.synCommonSkuExtraAttributes = function (requestParams) {
    return requestParams.request();
  };
  /**
   *同步组合产品分类数据
   * @param requestParams
   */


  ProductService.prototype.updatePackProductCategory = function (requestParams) {
    return requestParams.request();
  };
  /**
   *同步组合产品分类数据
   * @param requestParams
   */


  ProductService.prototype.queryProductHistoryStock = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询中文子类
   * @param requestParams
   */


  ProductService.prototype.query_all_sub_category_attributes = function (requestParams) {
    return requestParams.request();
  };
  /**
   *保存中文子类属性列表
   * @param requestParams
   */


  ProductService.prototype.save_sub_category_attributes = function (requestParams) {
    return requestParams.request();
  };
  /**
   *query_all_cs_tmp_product_part
   * @param requestParams
   */


  ProductService.prototype.query_all_cs_tmp_product_part = function (requestParams) {
    return requestParams.request();
  };
  /**
   *save_cs_tmp_product_part
   * @param requestParams
   */


  ProductService.prototype.save_cs_tmp_product_part = function (requestParams) {
    return requestParams.request();
  };
  /**
   *save_cs_tmp_product_part
   * @param requestParams
   */


  ProductService.prototype.query_all_for_stock_pack_operation = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_product_pack_by_sku
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], ProductService.prototype, "queryProductPack", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_for_stock_move
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], ProductService.prototype, "queryProducForStockMove", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_async_product_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], ProductService.prototype, "queryAsyncProductInfo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_common_sku
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], ProductService.prototype, "query_all_common_sku", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_basic_sku
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], ProductService.prototype, "query_all_basic_sku", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_bp_pack
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], ProductService.prototype, "query_all_bp_pack", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_product_basic_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], ProductService.prototype, "query_product_basic_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_product_extra_value
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], ProductService.prototype, "query_product_extra_value", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_de_best_logistic_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], ProductService.prototype, "query_de_best_logistic_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_uk_best_logistic_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], ProductService.prototype, "query_uk_best_logistic_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_product_stock_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], ProductService.prototype, "query_product_stock_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_location_stock_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], ProductService.prototype, "query_location_stock_detail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_factory_product_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], ProductService.prototype, "query_factory_product_detail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_shipping_product_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_2 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _2 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_3 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _3 : Object)], ProductService.prototype, "query_shipping_product_detail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_amazon_listing_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_4 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _4 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_5 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _5 : Object)], ProductService.prototype, "query_amazon_listing_detail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_6 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _6 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_7 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _7 : Object)], ProductService.prototype, "save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].save_product_extra_value
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_8 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _8 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_9 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _9 : Object)], ProductService.prototype, "save_product_extra_value", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].delete_extra_value
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_10 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _10 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_11 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _11 : Object)], ProductService.prototype, "delete_extra_value", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_product_stock_operation
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_12 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _12 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_13 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _13 : Object)], ProductService.prototype, "query_product_stock_operation", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_type_sku
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_14 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _14 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_15 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _15 : Object)], ProductService.prototype, "query_all_type_sku", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_product_log
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_16 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _16 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_17 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _17 : Object)], ProductService.prototype, "query_product_log", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_manual_version
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_18 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _18 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_19 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _19 : Object)], ProductService.prototype, "query_manual_version", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_product_manual
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_20 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _20 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_21 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _21 : Object)], ProductService.prototype, "query_all_product_manual", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_basic_product_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_22 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _22 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_23 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _23 : Object)], ProductService.prototype, "query_all_basic_product_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_product_template
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_24 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _24 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_25 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _25 : Object)], ProductService.prototype, "query_all_product_template", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_product_specification
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_26 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _26 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_27 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _27 : Object)], ProductService.prototype, "query_all_product_specification", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_specification_version
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_28 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _28 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_29 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _29 : Object)], ProductService.prototype, "query_specification_version", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].save_prod_manual_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_30 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _30 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_31 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _31 : Object)], ProductService.prototype, "save_prod_manual_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].save_prod_specification_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_32 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _32 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_33 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _33 : Object)], ProductService.prototype, "save_prod_specification_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].delete_prod_manual_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_34 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _34 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_35 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _35 : Object)], ProductService.prototype, "delete_prod_manual_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].reset_prod_manual_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_36 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _36 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_37 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _37 : Object)], ProductService.prototype, "reset_prod_manual_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].delete_prod_specification_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_38 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _38 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_39 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _39 : Object)], ProductService.prototype, "delete_prod_specification_info", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_product_in_out_warehouse
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_40 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _40 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_41 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _41 : Object)], ProductService.prototype, "query_all_product_in_out_warehouse", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].merge_inactive
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_42 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _42 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_43 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _43 : Object)], ProductService.prototype, "mergeInactive", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].merge_active
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_44 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _44 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_45 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _45 : Object)], ProductService.prototype, "mergeActive", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].synCommonSkuInfo
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_46 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _46 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_47 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _47 : Object)], ProductService.prototype, "synCommonSkuInfo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].synCommonSkuExtraAttributes
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_48 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _48 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_49 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _49 : Object)], ProductService.prototype, "synCommonSkuExtraAttributes", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].updatePackProductCategory
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_50 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _50 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_51 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _51 : Object)], ProductService.prototype, "updatePackProductCategory", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].queryProductHistoryStock
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_52 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _52 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_53 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _53 : Object)], ProductService.prototype, "queryProductHistoryStock", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_sub_category_attributes
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_54 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _54 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_55 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _55 : Object)], ProductService.prototype, "query_all_sub_category_attributes", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].save_sub_category_attributes
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_56 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _56 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_57 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _57 : Object)], ProductService.prototype, "save_sub_category_attributes", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_cs_tmp_product_part
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_58 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _58 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_59 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _59 : Object)], ProductService.prototype, "query_all_cs_tmp_product_part", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].save_cs_tmp_product_part
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_60 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _60 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_61 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _61 : Object)], ProductService.prototype, "save_cs_tmp_product_part", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_controller__WEBPACK_IMPORTED_MODULE_3__[/* ProductController */ "a"].query_all_for_stock_pack_operation
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_62 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _62 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_63 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _63 : Object)], ProductService.prototype, "query_all_for_stock_pack_operation", null);

  return ProductService;
}();



/***/ }),

/***/ "1db3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PresaleManageService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_presale_manage_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("f6a8");




/**
 * 订单API服务
 */

var PresaleManageService =
/** @class */
function () {
  function PresaleManageService() {}
  /**
   * 保存编辑
   * @param requestParams
   */


  PresaleManageService.prototype.save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 生成释放报告
   * @param requestParams
   */


  PresaleManageService.prototype.release = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 生成释放报告
   * @param requestParams
   */


  PresaleManageService.prototype.getInfo = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取货柜及产品信息
   * @param requestParams
   */


  PresaleManageService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_manage_controller__WEBPACK_IMPORTED_MODULE_3__[/* PresaleManageController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PresaleManageService.prototype, "save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_manage_controller__WEBPACK_IMPORTED_MODULE_3__[/* PresaleManageController */ "a"].release
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], PresaleManageService.prototype, "release", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_manage_controller__WEBPACK_IMPORTED_MODULE_3__[/* PresaleManageController */ "a"].getInfo
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], PresaleManageService.prototype, "getInfo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_manage_controller__WEBPACK_IMPORTED_MODULE_3__[/* PresaleManageController */ "a"].queryAll
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], PresaleManageService.prototype, "queryAll", null);

  return PresaleManageService;
}();



/***/ }),

/***/ "2138":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_user_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("6db2");




/**
 * 仓库API服务
 */

var UserService =
/** @class */
function () {
  function UserService() {}
  /**
   * 可用销售代表查询
   * @param requestParams
   */


  UserService.prototype.all = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 可用销售代表查询
   * @param requestParams
   */


  UserService.prototype.querySalesUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 可用销售代表查询
   * @param requestParams
   */


  UserService.prototype.customerServiceUser = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_user_controller__WEBPACK_IMPORTED_MODULE_3__[/* UserController */ "a"].all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], UserService.prototype, "all", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_user_controller__WEBPACK_IMPORTED_MODULE_3__[/* UserController */ "a"].availableSales
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], UserService.prototype, "querySalesUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_user_controller__WEBPACK_IMPORTED_MODULE_3__[/* UserController */ "a"].customerServiceUser
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], UserService.prototype, "customerServiceUser", null);

  return UserService;
}();



/***/ }),

/***/ "2219":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GeneralService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a9bc");




/**
 * 订单API服务
 */

var GeneralService =
/** @class */
function () {
  function GeneralService() {}
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralService.prototype.queryResendMemo = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 语言列表 id->code
   * @param requestParams
   */


  GeneralService.prototype.queryLangList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询表对应的所有列
   * @param requestParams
   */


  GeneralService.prototype.query_table_schema = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询表对应的所有模板
   * @param requestParams
   */


  GeneralService.prototype.query_table_schema_export_template = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 导出模板对应的列
   * @param requestParams
   */


  GeneralService.prototype.query_table_schema_export_template_column = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存导出模板
   * @param requestParams
   */


  GeneralService.prototype.save_table_schema_export_template = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除导出模板
   * @param requestParams
   */


  GeneralService.prototype.delete_table_schema_export_template = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralController */ "a"].query_picking_need_resend
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], GeneralService.prototype, "queryResendMemo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralController */ "a"].queryLangList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], GeneralService.prototype, "queryLangList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralController */ "a"].query_table_schema
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], GeneralService.prototype, "query_table_schema", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralController */ "a"].query_table_schema_export_template
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], GeneralService.prototype, "query_table_schema_export_template", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralController */ "a"].query_table_schema_export_template_column
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], GeneralService.prototype, "query_table_schema_export_template_column", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralController */ "a"].save_table_schema_export_template
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], GeneralService.prototype, "save_table_schema_export_template", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralController */ "a"].delete_table_schema_export_template
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], GeneralService.prototype, "delete_table_schema_export_template", null);

  return GeneralService;
}();



/***/ }),

/***/ "2c1a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PartnerService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_partner_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("8e10e");




/**
 * 订单API服务
 */

var PartnerService =
/** @class */
function () {
  function PartnerService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  PartnerService.prototype.queryCustomerContact = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_partner_controller__WEBPACK_IMPORTED_MODULE_3__[/* PartnerController */ "a"].query_customer_contact
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PartnerService.prototype, "queryCustomerContact", null);

  return PartnerService;
}();



/***/ }),

/***/ "2ce3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SystemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("061c");




/**
 * 权限服务
 */

var SystemService =
/** @class */
function () {
  function SystemService() {}
  /**
   * 查询所有系统用户
   * @param requestParams
   */


  SystemService.prototype.queryAllUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存系统用户
   * @param requestParams
   */


  SystemService.prototype.saveUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 禁用系统用户
   * @param requestParams
   */


  SystemService.prototype.stopUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改密码
   * @param requestParams
   */


  SystemService.prototype.changeUserPassword = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有系统角色
   * @param requestParams
   */


  SystemService.prototype.queryAllRoles = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有系统角色
   * @param requestParams
   */


  SystemService.prototype.saveRole = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除系统角色
   * @param requestParams
   */


  SystemService.prototype.deleteRole = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有子系统
   * @param requestParams
   */


  SystemService.prototype.queryAllSubSystem = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存子系统
   * @param requestParams
   */


  SystemService.prototype.saveSubSystem = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除子系统
   * @param requestParams
   */


  SystemService.prototype.deleteSubSystem = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有模块
   * @param requestParams
   */


  SystemService.prototype.queryAllSystemModule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存模块
   * @param requestParams
   */


  SystemService.prototype.saveModule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除模块
   * @param requestParams
   */


  SystemService.prototype.deleteModule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有子模块
   * @param requestParams
   */


  SystemService.prototype.queryAllSubSystemModule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存子模块
   * @param requestParams
   */


  SystemService.prototype.saveSubModule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除子模块
   * @param requestParams
   */


  SystemService.prototype.deleteSubModule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 给角色添加用户
   * @param requestParams
   */


  SystemService.prototype.addRoleUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询角色对应的用户
   * @param requestParams
   */


  SystemService.prototype.queryRoleUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除系统角色对应的用户
   * @param requestParams
   */


  SystemService.prototype.deleteRoleUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询角色可以添加的用户
   * @param requestParams
   */


  SystemService.prototype.queryRoleNeedAddUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询角色已添加的菜单
   * @param requestParams
   */


  SystemService.prototype.queryMenuByRole = function (requestParams) {
    return requestParams.request();
  };
  /**
   *删除角色中的菜单接口
   * @param requestParams
   */


  SystemService.prototype.deleteRoleMenuRel = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询角色可添加的菜单接口
   * @param requestParams
   */


  SystemService.prototype.queryRoleNeedAddMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *角色添加菜单接口
   * @param requestParams
   */


  SystemService.prototype.addRoleMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询菜单接口
   * @param requestParams
   */


  SystemService.prototype.queryAllMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *保存菜单接口
   * @param requestParams
   */


  SystemService.prototype.saveSystemMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *删除菜单接口
   * @param requestParams
   */


  SystemService.prototype.deleteSystemMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *添加用户菜单
   * @param requestParams
   */


  SystemService.prototype.addUserMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *删除用户菜单
   * @param requestParams
   */


  SystemService.prototype.deleteUserMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *根据用户查询菜单
   * @param requestParams
   */


  SystemService.prototype.queryMenuByUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   *根据角色用户查询菜单
   * @param requestParams
   */


  SystemService.prototype.queryMenuByRoleUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   *保存子用户菜单
   * @param requestParams
   */


  SystemService.prototype.addSubAccountMenu = function (requestParams) {
    return requestParams.request();
  };
  /**
   *根据客户ID查询公告
   * @param requestParams
   */


  SystemService.prototype.queryAllUserNotice = function (requestParams) {
    return requestParams.request();
  };
  /**
   *保存公告
   * @param requestParams
   */


  SystemService.prototype.saveNotice = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询单个公告
   * @param requestParams
   */


  SystemService.prototype.queryOneNotice = function (requestParams) {
    return requestParams.request();
  };
  /**
   *废除公告
   * @param requestParams
   */


  SystemService.prototype.discardNotice = function (requestParams) {
    return requestParams.request();
  };
  /**
   *审核公告
   * @param requestParams
   */


  SystemService.prototype.approveNotice = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询某菜单的所有查询条件
   * @param requestParams
   */


  SystemService.prototype.querySearchConditionByMenuCode = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询某菜单的固定查询条件
   * @param requestParams
   */


  SystemService.prototype.queryFixedSearchConditionByMenuCode = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询某菜单的所有查询条件
   * @param requestParams
   */


  SystemService.prototype.batchCreateSearchCondition = function (requestParams) {
    return requestParams.request();
  };
  /**
   *单删查询条件
   * @param requestParams
   */


  SystemService.prototype.DeleteOneSearchCondition = function (requestParams) {
    return requestParams.request();
  };
  /**
   *创建单个查询条件
   * @param requestParams
   */


  SystemService.prototype.CreateSearchCondition = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询某菜单的所有查询条件
   * @param requestParams
   */


  SystemService.prototype.queryUserSearchCondition = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改登录者密码
   * @param requestParams
   */


  SystemService.prototype.changeOwnPassword = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询汇率
   * @param requestParams
   */


  SystemService.prototype.queryCurrencyChange = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 接口列表管理
   * @param requestParams
   */


  SystemService.prototype.query_all_system_api = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存接口列表
   * @param requestParams
   */


  SystemService.prototype.save_system_api = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改接口列表激活状态
   * @param requestParams
   */


  SystemService.prototype.active_system_api = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询行数据访问规则
   * @param requestParams
   */


  SystemService.prototype.query_all_data_access_rule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存行数据访问规则
   * @param requestParams
   */


  SystemService.prototype.save_data_access_rule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改行数据访问规则状态
   * @param requestParams
   */


  SystemService.prototype.active_data_access_rule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询站点数据访问规则
   * @param requestParams
   */


  SystemService.prototype.query_all_host_data_access_rule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存站点数据访问规则
   * @param requestParams
   */


  SystemService.prototype.save_host_data_access_rule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改站点数据访问规则状态
   * @param requestParams
   */


  SystemService.prototype.active_host_data_access_rule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 更新角色菜单数据访问规则接口
   * @param requestParams
   */


  SystemService.prototype.update_role_menu_access_rule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 更新用户菜单数据访问规则接口
   * @param requestParams
   */


  SystemService.prototype.update_user_menu_access_rule = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75, _76, _77, _78, _79, _80, _81, _82, _83, _84, _85, _86, _87;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], SystemService.prototype, "queryAllUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], SystemService.prototype, "saveUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].stop_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], SystemService.prototype, "stopUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].change_user_password
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], SystemService.prototype, "changeUserPassword", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_system_role
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], SystemService.prototype, "queryAllRoles", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_system_role
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], SystemService.prototype, "saveRole", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_system_role
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], SystemService.prototype, "deleteRole", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_sub_system
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], SystemService.prototype, "queryAllSubSystem", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_sub_system
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], SystemService.prototype, "saveSubSystem", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_sub_system
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], SystemService.prototype, "deleteSubSystem", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_system_model
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], SystemService.prototype, "queryAllSystemModule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_system_model
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], SystemService.prototype, "saveModule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_system_model
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], SystemService.prototype, "deleteModule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_system_sub_model
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_2 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _2 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_3 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _3 : Object)], SystemService.prototype, "queryAllSubSystemModule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_system_sub_model
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_4 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _4 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_5 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _5 : Object)], SystemService.prototype, "saveSubModule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_system_sub_model
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_6 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _6 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_7 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _7 : Object)], SystemService.prototype, "deleteSubModule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].create_role_user_rel
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_8 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _8 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_9 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _9 : Object)], SystemService.prototype, "addRoleUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_user_by_role_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_10 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _10 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_11 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _11 : Object)], SystemService.prototype, "queryRoleUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_role_user_rel
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_12 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _12 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_13 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _13 : Object)], SystemService.prototype, "deleteRoleUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_role_need_add_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_14 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _14 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_15 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _15 : Object)], SystemService.prototype, "queryRoleNeedAddUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_menu_by_role_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_16 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _16 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_17 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _17 : Object)], SystemService.prototype, "queryMenuByRole", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_role_menu_rel
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_18 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _18 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_19 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _19 : Object)], SystemService.prototype, "deleteRoleMenuRel", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_role_need_add_menu
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_20 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _20 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_21 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _21 : Object)], SystemService.prototype, "queryRoleNeedAddMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].create_role_menu_rel
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_22 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _22 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_23 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _23 : Object)], SystemService.prototype, "addRoleMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_system_menu
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_24 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _24 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_25 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _25 : Object)], SystemService.prototype, "queryAllMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_system_menu
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_26 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _26 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_27 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _27 : Object)], SystemService.prototype, "saveSystemMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_system_menu
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_28 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _28 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_29 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _29 : Object)], SystemService.prototype, "deleteSystemMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].add_user_menu
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_30 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _30 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_31 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _31 : Object)], SystemService.prototype, "addUserMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_user_menu
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_32 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _32 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_33 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _33 : Object)], SystemService.prototype, "deleteUserMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_menu_by_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_34 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _34 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_35 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _35 : Object)], SystemService.prototype, "queryMenuByUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_menu_by_role_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_36 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _36 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_37 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _37 : Object)], SystemService.prototype, "queryMenuByRoleUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].add_sub_account_menu
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_38 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _38 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_39 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _39 : Object)], SystemService.prototype, "addSubAccountMenu", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_user_notice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_40 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _40 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_41 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _41 : Object)], SystemService.prototype, "queryAllUserNotice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_notice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_42 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _42 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_43 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _43 : Object)], SystemService.prototype, "saveNotice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_one_notice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_44 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _44 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_45 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _45 : Object)], SystemService.prototype, "queryOneNotice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].discard_notice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_46 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _46 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_47 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _47 : Object)], SystemService.prototype, "discardNotice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].approve_notice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_48 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _48 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_49 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _49 : Object)], SystemService.prototype, "approveNotice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_search_condition_by_menu_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_50 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _50 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_51 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _51 : Object)], SystemService.prototype, "querySearchConditionByMenuCode", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_fixed_search_condition_by_menu_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_52 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _52 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_53 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _53 : Object)], SystemService.prototype, "queryFixedSearchConditionByMenuCode", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].batch_create_search_condition
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_54 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _54 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_55 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _55 : Object)], SystemService.prototype, "batchCreateSearchCondition", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].delete_one_search_condition
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_56 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _56 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_57 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _57 : Object)], SystemService.prototype, "DeleteOneSearchCondition", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].create_search_condition
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_58 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _58 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_59 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _59 : Object)], SystemService.prototype, "CreateSearchCondition", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_user_search_condition
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_60 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _60 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_61 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _61 : Object)], SystemService.prototype, "queryUserSearchCondition", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].change_own_password
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_62 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _62 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_63 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _63 : Object)], SystemService.prototype, "changeOwnPassword", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].queryCurrencyChange
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_64 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _64 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_65 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _65 : Object)], SystemService.prototype, "queryCurrencyChange", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_system_api
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_66 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _66 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_67 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _67 : Object)], SystemService.prototype, "query_all_system_api", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_system_api
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_68 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _68 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_69 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _69 : Object)], SystemService.prototype, "save_system_api", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].active_system_api
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_70 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _70 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_71 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _71 : Object)], SystemService.prototype, "active_system_api", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_data_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_72 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _72 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_73 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _73 : Object)], SystemService.prototype, "query_all_data_access_rule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_data_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_74 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _74 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_75 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _75 : Object)], SystemService.prototype, "save_data_access_rule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].active_data_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_76 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _76 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_77 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _77 : Object)], SystemService.prototype, "active_data_access_rule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].query_all_host_data_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_78 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _78 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_79 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _79 : Object)], SystemService.prototype, "query_all_host_data_access_rule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].save_host_data_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_80 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _80 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_81 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _81 : Object)], SystemService.prototype, "save_host_data_access_rule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].active_host_data_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_82 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _82 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_83 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _83 : Object)], SystemService.prototype, "active_host_data_access_rule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].update_role_menu_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_84 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _84 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_85 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _85 : Object)], SystemService.prototype, "update_role_menu_access_rule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_system_controller__WEBPACK_IMPORTED_MODULE_3__[/* SystemController */ "a"].update_user_menu_access_rule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_86 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _86 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_87 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _87 : Object)], SystemService.prototype, "update_user_menu_access_rule", null);

  return SystemService;
}();



/***/ }),

/***/ "3723":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TaxesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_taxes_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("f243");




/**
 * 订单API服务
 */

var TaxesService =
/** @class */
function () {
  function TaxesService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  TaxesService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_taxes_controller__WEBPACK_IMPORTED_MODULE_3__[/* TaxesController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], TaxesService.prototype, "queryAll", null);

  return TaxesService;
}();



/***/ }),

/***/ "431d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FiscalPositionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_fiscal_position_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("d33f");




/**
 * 订单API服务
 */

var FiscalPositionService =
/** @class */
function () {
  function FiscalPositionService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  FiscalPositionService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_fiscal_position_controller__WEBPACK_IMPORTED_MODULE_3__[/* FiscalPositionController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], FiscalPositionService.prototype, "queryAll", null);

  return FiscalPositionService;
}();



/***/ }),

/***/ "5083":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GeneralCodeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_general_code_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("f913");




/**
 * 订单API服务
 */

var GeneralCodeService =
/** @class */
function () {
  function GeneralCodeService() {}
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.queryShipType = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.queryMvShipType = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralCodeController */ "a"].queryShipType
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], GeneralCodeService.prototype, "queryShipType", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_general_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GeneralCodeController */ "a"].queryMvShipType
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], GeneralCodeService.prototype, "queryMvShipType", null);

  return GeneralCodeService;
}();



/***/ }),

/***/ "57db":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GeneralCodeService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("4904");




/**
 * 订单API服务
 */

var GeneralCodeService =
/** @class */
function () {
  function GeneralCodeService() {}
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.queryAllCodeList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.querySelectCode = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.createProductGenerateCode = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.createMixProductGenerateCode = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.queryCategoryList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.queryColorList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据组类别查询generalcode
   * @param requestParams
   */


  GeneralCodeService.prototype.deleteCode = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GenerateCodeController */ "a"].query_all_code_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], GeneralCodeService.prototype, "queryAllCodeList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GenerateCodeController */ "a"].query_select_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], GeneralCodeService.prototype, "querySelectCode", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GenerateCodeController */ "a"].create_product_generate_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], GeneralCodeService.prototype, "createProductGenerateCode", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GenerateCodeController */ "a"].create_mix_product_generate_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], GeneralCodeService.prototype, "createMixProductGenerateCode", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GenerateCodeController */ "a"].query_category_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], GeneralCodeService.prototype, "queryCategoryList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GenerateCodeController */ "a"].query_color_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], GeneralCodeService.prototype, "queryColorList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_generate_code_controller__WEBPACK_IMPORTED_MODULE_3__[/* GenerateCodeController */ "a"].delete_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], GeneralCodeService.prototype, "deleteCode", null);

  return GeneralCodeService;
}();



/***/ }),

/***/ "5c97":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SellerInstanceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("5c4b");




/**
 * 产品API服务
 */

var SellerInstanceService =
/** @class */
function () {
  function SellerInstanceService() {}
  /**
   * 产品查询
   * @param requestParams
   */


  SellerInstanceService.prototype.getInstanceList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 产品查询
   * @param requestParams
   */


  SellerInstanceService.prototype.getSellerList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 产品保存
   * @param requestParams
   */


  SellerInstanceService.prototype.seller_save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 产品保存
   * @param requestParams
   */


  SellerInstanceService.prototype.instance_save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.seller_delete = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.instance_delete = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.responsible_users_query = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.seller_query_one = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.seller_query_for_selection = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.query_user_login = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.get_instance_list_for_view = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.query_seller_name = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.change_seller_status = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除保存
   * @param requestParams
   */


  SellerInstanceService.prototype.change_instance_status = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取店铺下拉列表
   * @param requestParams
   */


  SellerInstanceService.prototype.queryOdooSellerList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取店铺实例下拉列表
   * @param requestParams
   */


  SellerInstanceService.prototype.queryOdooSellerInstanceList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取实例下拉列表
   * @param requestParams
   */


  SellerInstanceService.prototype.queryInstanceList = function (requestParams) {
    return requestParams.request();
  };
  /**
   *
   * @param requestParams
   */


  SellerInstanceService.prototype.querySellerName = function (requestParams) {
    return requestParams.request();
  };
  /**
   *
   * @param requestParams
   */


  SellerInstanceService.prototype.saveSellerApi = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 根据店铺id获取实例下拉列表
   * @param requestParams
   */


  SellerInstanceService.prototype.queryInstanceBySellerCode = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].instance_query
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], SellerInstanceService.prototype, "getInstanceList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].seller_query
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], SellerInstanceService.prototype, "getSellerList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].seller_save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], SellerInstanceService.prototype, "seller_save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].instance_save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], SellerInstanceService.prototype, "instance_save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].seller_delete
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], SellerInstanceService.prototype, "seller_delete", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].instance_delete
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], SellerInstanceService.prototype, "instance_delete", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].responsible_users_query
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], SellerInstanceService.prototype, "responsible_users_query", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].seller_query_one
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], SellerInstanceService.prototype, "seller_query_one", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].seller_query_for_selection
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], SellerInstanceService.prototype, "seller_query_for_selection", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].query_user_login
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], SellerInstanceService.prototype, "query_user_login", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].get_instance_list_for_view
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], SellerInstanceService.prototype, "get_instance_list_for_view", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].query_seller_name
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], SellerInstanceService.prototype, "query_seller_name", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].change_seller_status
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], SellerInstanceService.prototype, "change_seller_status", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].change_instance_status
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_2 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _2 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_3 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _3 : Object)], SellerInstanceService.prototype, "change_instance_status", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].query_odoo_seller_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_4 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _4 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_5 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _5 : Object)], SellerInstanceService.prototype, "queryOdooSellerList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].query_odoo_seller_instance_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_6 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _6 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_7 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _7 : Object)], SellerInstanceService.prototype, "queryOdooSellerInstanceList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].query_instance_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_8 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _8 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_9 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _9 : Object)], SellerInstanceService.prototype, "queryInstanceList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].query_seller_name
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_10 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _10 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_11 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _11 : Object)], SellerInstanceService.prototype, "querySellerName", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].save_seller_api
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_12 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _12 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_13 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _13 : Object)], SellerInstanceService.prototype, "saveSellerApi", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_seller_instance_controller__WEBPACK_IMPORTED_MODULE_3__[/* SellerInstanceController */ "a"].query_instance_by_seller_code
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_14 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _14 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_15 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _15 : Object)], SellerInstanceService.prototype, "queryInstanceBySellerCode", null);

  return SellerInstanceService;
}();



/***/ }),

/***/ "5d7f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WorkweekService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_workweek_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("d72e");




/**
 * 订单API服务
 */

var WorkweekService =
/** @class */
function () {
  function WorkweekService() {}
  /**
   * 查询列表/id
   * @param requestParams
   */


  WorkweekService.prototype.query_all = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 创建周报
   * @param requestParams
   */


  WorkweekService.prototype.save_week = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询周报详情
   * @param requestParams
   */


  WorkweekService.prototype.query_week_detail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * create_message
   * @param requestParams
   */


  WorkweekService.prototype.create_message = function (requestParams) {
    return requestParams.request();
  };
  /**
   * delete_message
   * @param requestParams
   */


  WorkweekService.prototype.delete_message = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_workweek_controller__WEBPACK_IMPORTED_MODULE_3__[/* WorkweekController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], WorkweekService.prototype, "query_all", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_workweek_controller__WEBPACK_IMPORTED_MODULE_3__[/* WorkweekController */ "a"].save_week
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], WorkweekService.prototype, "save_week", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_workweek_controller__WEBPACK_IMPORTED_MODULE_3__[/* WorkweekController */ "a"].query_week_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], WorkweekService.prototype, "query_week_detail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_workweek_controller__WEBPACK_IMPORTED_MODULE_3__[/* WorkweekController */ "a"].create_message
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], WorkweekService.prototype, "create_message", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_workweek_controller__WEBPACK_IMPORTED_MODULE_3__[/* WorkweekController */ "a"].delete_message
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], WorkweekService.prototype, "delete_message", null);

  return WorkweekService;
}();



/***/ }),

/***/ "5f86":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HelpdeskService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("e7a3");




/**
 * 订单API服务
 */

var HelpdeskService =
/** @class */
function () {
  function HelpdeskService() {}
  /**
   * @param requestParams
   */


  HelpdeskService.prototype.queryAllTicket = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有Invoice Query All
   * @param requestParams
   */


  HelpdeskService.prototype.queryTicket = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询账单明细
   * @param requestParams
   */


  HelpdeskService.prototype.queryHelpdeskTicketBody = function (requestParams) {
    return requestParams.request();
  };
  /**
   *确认拣货单取消
   * @param requestParams
   */


  HelpdeskService.prototype.setPickingCancelledConfirm = function (requestParams) {
    return requestParams.request();
  };
  /**
   *分配用户
   * @param requestParams
   */


  HelpdeskService.prototype.assignTicketUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   *取消分配用户
   * @param requestParams
   */


  HelpdeskService.prototype.cancelTicketUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查看邮件回复情况
   * @param requestParams
   */


  HelpdeskService.prototype.queryTicketReplyContent = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查看邮件回复日志
   * @param requestParams
   */


  HelpdeskService.prototype.query_ticket_changed_log = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查看所有邮件分组
   * @param requestParams
   */


  HelpdeskService.prototype.query_all_email_group = function (requestParams) {
    return requestParams.request();
  };
  /**
   *保存邮件分组
   * @param requestParams
   */


  HelpdeskService.prototype.save_email_group = function (requestParams) {
    return requestParams.request();
  };
  /**
   *停用邮件分组
   * @param requestParams
   */


  HelpdeskService.prototype.cancel_email_group_status = function (requestParams) {
    return requestParams.request();
  };
  /**
   *启用邮件分组
   * @param requestParams
   */


  HelpdeskService.prototype.active_email_group_status = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询客服分配比例
   * @param requestParams
   */


  HelpdeskService.prototype.query_user_allot_ratio = function (requestParams) {
    return requestParams.request();
  };
  /**
   *保存客服分配比例
   * @param requestParams
   */


  HelpdeskService.prototype.save_user_allot_ratio = function (requestParams) {
    return requestParams.request();
  };
  /**
   *启用客服分配比例
   * @param requestParams
   */


  HelpdeskService.prototype.active_user_allot_ratio = function (requestParams) {
    return requestParams.request();
  };
  /**
   *停用客服分配比例
   * @param requestParams
   */


  HelpdeskService.prototype.cancel_user_allot_ratio = function (requestParams) {
    return requestParams.request();
  };
  /**
   *查询所有客服分配记录
   * @param requestParams
   */


  HelpdeskService.prototype.query_all_allot_user = function (requestParams) {
    return requestParams.request();
  };
  /**
   *批量修改客服
   * @param requestParams
   */


  HelpdeskService.prototype.change_allot_user = function (requestParams) {
    return requestParams.request();
  };
  /**
   *自动分配用户
   * @param requestParams
   */


  HelpdeskService.prototype.auto_allot_email = function (requestParams) {
    return requestParams.request();
  };
  /**
   *获取自动回复设置列表
   * @param requestParams
   */


  HelpdeskService.prototype.query_all_send_email_time = function (requestParams) {
    return requestParams.request();
  };
  /**
   *设置自动回复
   * @param requestParams
   */


  HelpdeskService.prototype.set_up_send_mail_time = function (requestParams) {
    return requestParams.request();
  };
  /**
   *获取自动回复设置列表
   * @param requestParams
   */


  HelpdeskService.prototype.query_send_customer_email_time = function (requestParams) {
    return requestParams.request();
  };
  /**
   *设置自动回复
   * @param requestParams
   */


  HelpdeskService.prototype.set_up_send_mail_time_customer = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_all_ticket
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], HelpdeskService.prototype, "queryAllTicket", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_ticket
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], HelpdeskService.prototype, "queryTicket", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_helpdesk_ticket_body
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], HelpdeskService.prototype, "queryHelpdeskTicketBody", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].set_picking_cancelled_confirm
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], HelpdeskService.prototype, "setPickingCancelledConfirm", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].assign_ticket_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], HelpdeskService.prototype, "assignTicketUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].cancel_ticket_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], HelpdeskService.prototype, "cancelTicketUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_ticket_reply_content
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], HelpdeskService.prototype, "queryTicketReplyContent", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_ticket_changed_log
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], HelpdeskService.prototype, "query_ticket_changed_log", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_all_email_group
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], HelpdeskService.prototype, "query_all_email_group", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].save_email_group
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], HelpdeskService.prototype, "save_email_group", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].cancel_email_group_status
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], HelpdeskService.prototype, "cancel_email_group_status", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].active_email_group_status
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], HelpdeskService.prototype, "active_email_group_status", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_user_allot_ratio
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], HelpdeskService.prototype, "query_user_allot_ratio", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].save_user_allot_ratio
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_2 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _2 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_3 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _3 : Object)], HelpdeskService.prototype, "save_user_allot_ratio", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].active_user_allot_ratio
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_4 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _4 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_5 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _5 : Object)], HelpdeskService.prototype, "active_user_allot_ratio", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].cancel_user_allot_ratio
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_6 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _6 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_7 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _7 : Object)], HelpdeskService.prototype, "cancel_user_allot_ratio", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_all_allot_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_8 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _8 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_9 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _9 : Object)], HelpdeskService.prototype, "query_all_allot_user", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].change_allot_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_10 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _10 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_11 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _11 : Object)], HelpdeskService.prototype, "change_allot_user", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].auto_allot_email
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_12 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _12 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_13 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _13 : Object)], HelpdeskService.prototype, "auto_allot_email", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_all_send_email_time
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_14 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _14 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_15 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _15 : Object)], HelpdeskService.prototype, "query_all_send_email_time", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].set_up_send_mail_time
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_16 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _16 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_17 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _17 : Object)], HelpdeskService.prototype, "set_up_send_mail_time", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].query_send_customer_email_time
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_18 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _18 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_19 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _19 : Object)], HelpdeskService.prototype, "query_send_customer_email_time", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_helpdesk_controller__WEBPACK_IMPORTED_MODULE_3__[/* HelpdeskController */ "a"].set_up_send_mail_time_customer
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_20 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _20 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_21 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _21 : Object)], HelpdeskService.prototype, "set_up_send_mail_time_customer", null);

  return HelpdeskService;
}();



/***/ }),

/***/ "6a1c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomProblemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("b20c");




/**
 * 客户API服务
 */

var CustomProblemService =
/** @class */
function () {
  function CustomProblemService() {}
  /**
   * CP查询
   * @param requestParams
   */


  CustomProblemService.prototype.query = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 产品下拉列表
   * @param requestParams
   */


  CustomProblemService.prototype.queryProductDropList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 产品下拉列表
   * @param requestParams
   */


  CustomProblemService.prototype.queryTemplateProductDropList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 客服创建CP
   * @param requestParams
   */


  CustomProblemService.prototype.csSave = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 仓库创建CP
   * @param requestParams
   */


  CustomProblemService.prototype.rtSave = function (requestParams) {
    return requestParams.request();
  };
  /**
   * CP reason 下拉列表集合
   * @param requestParams
   */


  CustomProblemService.prototype.queryCpReasonEnum = function (requestParams) {
    return requestParams.request();
  };
  /**
   * query_by_order_list
   * @param requestParams
   */


  CustomProblemService.prototype.queryByOrderList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * query_by_order_list
   * @param requestParams
   */


  CustomProblemService.prototype.getInitalCP = function (requestParams) {
    return requestParams.request();
  };
  /**
   * batchInReturnWH
   * @param requestParams
   */


  CustomProblemService.prototype.batchInReturnWH = function (requestParams) {
    return requestParams.request();
  };
  /**
   * delete CP
   * @param requestParams
   */


  CustomProblemService.prototype.deleteCP = function (requestParams) {
    return requestParams.request();
  };
  /**
   * create_cp_pic CP
   * @param requestParams
   */


  CustomProblemService.prototype.createCpPic = function (requestParams) {
    return requestParams.request();
  };
  /**
   * query_all_pic
   * @param requestParams
   */


  CustomProblemService.prototype.queryAllPic = function (requestParams) {
    return requestParams.request();
  };
  /**
   * query_all_pic
   * @param requestParams
   */


  CustomProblemService.prototype.queryCustomerProblemProduct = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].query
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], CustomProblemService.prototype, "query", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].query_product_drop_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], CustomProblemService.prototype, "queryProductDropList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].query_template_product_drop_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], CustomProblemService.prototype, "queryTemplateProductDropList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].save_custom_problem_by_cs
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], CustomProblemService.prototype, "csSave", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].save_custom_problem_by_rt
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], CustomProblemService.prototype, "rtSave", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].query_cp_reason_enum
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], CustomProblemService.prototype, "queryCpReasonEnum", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].query_by_order_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], CustomProblemService.prototype, "queryByOrderList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].get_inital_cp
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], CustomProblemService.prototype, "getInitalCP", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].batch_in_return_wh
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], CustomProblemService.prototype, "batchInReturnWH", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].delete_cp
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], CustomProblemService.prototype, "deleteCP", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].create_cp_pic
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], CustomProblemService.prototype, "createCpPic", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].query_all_pic
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], CustomProblemService.prototype, "queryAllPic", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_custom_problem_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomProblemController */ "a"].query_customer_problem_product
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], CustomProblemService.prototype, "queryCustomerProblemProduct", null);

  return CustomProblemService;
}();



/***/ }),

/***/ "6a96":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CurrencyService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_currency_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("7a0b");




/**
 * 币种API服务
 */

var CurrencyService =
/** @class */
function () {
  function CurrencyService() {}
  /**
   * 获取支持币种
   * @param requestParams
   */


  CurrencyService.prototype.getCurrency = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_currency_controller__WEBPACK_IMPORTED_MODULE_3__[/* CurrencyController */ "a"].getCurrency
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], CurrencyService.prototype, "getCurrency", null);

  return CurrencyService;
}();



/***/ }),

/***/ "74b3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SkuSaleService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_skusale_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("24b7");




/**
 * 订单API服务
 */

var SkuSaleService =
/** @class */
function () {
  function SkuSaleService() {}
  /**
   * 查询所有sku销售数据
   * @param requestParams
   */


  SkuSaleService.prototype.query_sum_all = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询具体sku销售数据
   * @param requestParams
   */


  SkuSaleService.prototype.query_by_time = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_skusale_controller__WEBPACK_IMPORTED_MODULE_3__[/* SkuSaleController */ "a"].query_sum_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], SkuSaleService.prototype, "query_sum_all", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_skusale_controller__WEBPACK_IMPORTED_MODULE_3__[/* SkuSaleController */ "a"].query_by_time
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], SkuSaleService.prototype, "query_by_time", null);

  return SkuSaleService;
}();



/***/ }),

/***/ "7a22":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PublicService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_public_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("d04f");




/**
 * 订单API服务
 */

var PublicService =
/** @class */
function () {
  function PublicService() {}
  /**
   * 数据分页查询
   * @param requestParams
   */


  PublicService.prototype.queryPagination = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 数据查询
   * @param requestParams
   */


  PublicService.prototype.query = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 数据更新
   * @param requestParams
   */


  PublicService.prototype.modify = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 倒出数据分页查询
   * @param requestParams
   */


  PublicService.prototype.queryExportPagination = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_public_controller__WEBPACK_IMPORTED_MODULE_3__[/* PublicController */ "a"].queryPagination
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PublicService.prototype, "queryPagination", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_public_controller__WEBPACK_IMPORTED_MODULE_3__[/* PublicController */ "a"].query,
    force: true
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], PublicService.prototype, "query", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_public_controller__WEBPACK_IMPORTED_MODULE_3__[/* PublicController */ "a"].modify
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], PublicService.prototype, "modify", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_public_controller__WEBPACK_IMPORTED_MODULE_3__[/* PublicController */ "a"].queryExportPagination
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], PublicService.prototype, "queryExportPagination", null);

  return PublicService;
}();



/***/ }),

/***/ "828f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WareHouseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_warehouse_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("8494");




/**
 * 仓库API服务
 */

var WareHouseService =
/** @class */
function () {
  function WareHouseService() {}
  /**
   * 可用仓库查询
   * @param requestParams
   */


  WareHouseService.prototype.getAvailable = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_warehouse_controller__WEBPACK_IMPORTED_MODULE_3__[/* WareHouseController */ "a"].available
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], WareHouseService.prototype, "getAvailable", null);

  return WareHouseService;
}();



/***/ }),

/***/ "82e7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AccountService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("7aea");




/**
 * 订单API服务
 */

var AccountService =
/** @class */
function () {
  function AccountService() {}
  /**
   * 创建Invoice
   * @param requestParams
   */


  AccountService.prototype.createInvoice = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有Invoice Query All
   * @param requestParams
   */


  AccountService.prototype.getInvoiceList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询账单明细
   * @param requestParams
   */


  AccountService.prototype.getInvoiceDetail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 编辑时查详情
   * @param requestParams
   */


  AccountService.prototype.queryInvoiceDetailForEdit = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存发票信息
   * @param requestParams
   */


  AccountService.prototype.saveAccountInvoice = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除发票信息
   * @param requestParams
   */


  AccountService.prototype.deleteAccountInvoice = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除发票信息
   * @param requestParams
   */


  AccountService.prototype.modifyInvoiceAddress = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改发票状态
   * @param requestParams
   */


  AccountService.prototype.changeInvoiceState = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 标识账单已退款
   * @param requestParams
   */


  AccountService.prototype.updateRefundTime = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].createInvoice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], AccountService.prototype, "createInvoice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].getInvoiceList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], AccountService.prototype, "getInvoiceList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].getInvoiceDetail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], AccountService.prototype, "getInvoiceDetail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].query_invoice_detail_for_edit
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], AccountService.prototype, "queryInvoiceDetailForEdit", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].save_account_invoice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], AccountService.prototype, "saveAccountInvoice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].delete_account_invoice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], AccountService.prototype, "deleteAccountInvoice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].modify_invoice_address
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], AccountService.prototype, "modifyInvoiceAddress", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].change_invoice_state
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], AccountService.prototype, "changeInvoiceState", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_account_controller__WEBPACK_IMPORTED_MODULE_3__[/* AccountController */ "a"].update_refund_time
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], AccountService.prototype, "updateRefundTime", null);

  return AccountService;
}();



/***/ }),

/***/ "8931":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PricelistService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_pricelist_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("32c0");




/**
 * 订单API服务
 */

var PricelistService =
/** @class */
function () {
  function PricelistService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  PricelistService.prototype.getList = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_pricelist_controller__WEBPACK_IMPORTED_MODULE_3__[/* PricelistController */ "a"].getList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PricelistService.prototype, "getList", null);

  return PricelistService;
}();



/***/ }),

/***/ "8934":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OperateLogService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_operatelog_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("d32f");




/**
 * 操作日子
 */

var OperateLogService =
/** @class */
function () {
  function OperateLogService() {}
  /**
   * 查询批次库存操作日志
   * @param requestParams
   */


  OperateLogService.prototype.viewUserOperateChangedLog = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_operatelog_controller__WEBPACK_IMPORTED_MODULE_3__[/* OperateLogController */ "a"].view_user_operate_changed_log
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], OperateLogService.prototype, "viewUserOperateChangedLog", null);

  return OperateLogService;
}();



/***/ }),

/***/ "8ba7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AmazonListingStockService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_amazon_listing_stock_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("3755");




/**
 * 订单API服务
 */

var AmazonListingStockService =
/** @class */
function () {
  function AmazonListingStockService() {}
  /**
   * Merge user
   * @param requestParams
   */


  AmazonListingStockService.prototype.mergeUser = function (requestParams) {
    return requestParams.request();
  };
  /**
   * Merge auto
   * @param requestParams
   */


  AmazonListingStockService.prototype.mergeAuto = function (requestParams) {
    return requestParams.request();
  };
  /**
   * Cancel auto
   * @param requestParams
   */


  AmazonListingStockService.prototype.cancelAuto = function (requestParams) {
    return requestParams.request();
  };
  /**
   * save
   * @param requestParams
   */


  AmazonListingStockService.prototype.save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * Query All Listing
   * @param requestParams
   */


  AmazonListingStockService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * Query All Listing
   * @param requestParams
   */


  AmazonListingStockService.prototype.querySingleListing = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_amazon_listing_stock_controller__WEBPACK_IMPORTED_MODULE_3__[/* AmazonListingStockController */ "a"].mergeUser
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], AmazonListingStockService.prototype, "mergeUser", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_amazon_listing_stock_controller__WEBPACK_IMPORTED_MODULE_3__[/* AmazonListingStockController */ "a"].mergeAuto
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], AmazonListingStockService.prototype, "mergeAuto", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_amazon_listing_stock_controller__WEBPACK_IMPORTED_MODULE_3__[/* AmazonListingStockController */ "a"].cancelAuto
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], AmazonListingStockService.prototype, "cancelAuto", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_amazon_listing_stock_controller__WEBPACK_IMPORTED_MODULE_3__[/* AmazonListingStockController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], AmazonListingStockService.prototype, "save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_amazon_listing_stock_controller__WEBPACK_IMPORTED_MODULE_3__[/* AmazonListingStockController */ "a"].queryAll
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], AmazonListingStockService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_amazon_listing_stock_controller__WEBPACK_IMPORTED_MODULE_3__[/* AmazonListingStockController */ "a"].querySingleListing
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], AmazonListingStockService.prototype, "querySingleListing", null);

  return AmazonListingStockService;
}();



/***/ }),

/***/ "8cd0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PurchaseCalService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_purchasecal_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("fd36");




/**
 * 订单API服务
 */

var PurchaseCalService =
/** @class */
function () {
  function PurchaseCalService() {}
  /**
   * 查询所有产品采购预算数据
   * @param requestParams
   */


  PurchaseCalService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询单个产品采购预算详情数据
   * @param requestParams
   */


  PurchaseCalService.prototype.queryDetail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询单个产品历史销售数据
   * @param requestParams
   */


  PurchaseCalService.prototype.salesHistory = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询单个产品采购预算日志
   * @param requestParams
   */


  PurchaseCalService.prototype.getLogs = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchasecal_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseCalController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PurchaseCalService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchasecal_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseCalController */ "a"].query_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], PurchaseCalService.prototype, "queryDetail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchasecal_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseCalController */ "a"].sales_history
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], PurchaseCalService.prototype, "salesHistory", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_purchasecal_controller__WEBPACK_IMPORTED_MODULE_3__[/* PurchaseCalController */ "a"].query_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], PurchaseCalService.prototype, "getLogs", null);

  return PurchaseCalService;
}();



/***/ }),

/***/ "914f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("4940");




/**
 * 订单API服务
 */

var ReportService =
/** @class */
function () {
  function ReportService() {}
  /**
   * 查询订单日期下拉
   * @param requestParams
   */


  ReportService.prototype.query_order_date_list = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询国家下拉
   * @param requestParams
   */


  ReportService.prototype.query_country_list = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取分类列表
   * @param requestParams
   */


  ReportService.prototype.query_category_list = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取子类列表
   * @param requestParams
   */


  ReportService.prototype.query_sub_category_list = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取分类子类字典
   * @param requestParams
   */


  ReportService.prototype.query_category_dict = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取品类毛利数据
   * @param requestParams
   */


  ReportService.prototype.query_category_profit_data = function (requestParams) {
    return requestParams.request();
  };
  /**
   * SKU毛利数据
   * @param requestParams
   */


  ReportService.prototype.query_sku_profit_data = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询所有毛利数据
   * @param requestParams
   */


  ReportService.prototype.query_all_profit_data = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_order_date_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], ReportService.prototype, "query_order_date_list", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_country_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], ReportService.prototype, "query_country_list", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_category_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], ReportService.prototype, "query_category_list", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_sub_category_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], ReportService.prototype, "query_sub_category_list", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_category_dict
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], ReportService.prototype, "query_category_dict", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_category_profit_data
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], ReportService.prototype, "query_category_profit_data", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_sku_profit_data
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], ReportService.prototype, "query_sku_profit_data", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_report_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReportController */ "a"].query_all_profit_data
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], ReportService.prototype, "query_all_profit_data", null);

  return ReportService;
}();



/***/ }),

/***/ "9cea":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaleTrendService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_saletrend_controll__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("1369");




/**
 * 订单API服务
 */

var SaleTrendService =
/** @class */
function () {
  function SaleTrendService() {}
  /**
   * 查询所有产品销售趋势数据
   * @param requestParams
   */


  SaleTrendService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存产品销售趋势数据
   * @param requestParams
   */


  SaleTrendService.prototype.save = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_saletrend_controll__WEBPACK_IMPORTED_MODULE_3__[/* SaleTrendController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], SaleTrendService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_saletrend_controll__WEBPACK_IMPORTED_MODULE_3__[/* SaleTrendController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], SaleTrendService.prototype, "save", null);

  return SaleTrendService;
}();



/***/ }),

/***/ "9d74":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InventoryService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_inventory_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("af1d");




/**
 * 库存API服务
 */

var InventoryService =
/** @class */
function () {
  function InventoryService() {}
  /**
   * 查询商品库存
   * @param requestParams
   */


  InventoryService.prototype.getInventory = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_inventory_controller__WEBPACK_IMPORTED_MODULE_3__[/* InventoryController */ "a"].inventory
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], InventoryService.prototype, "getInventory", null);

  return InventoryService;
}();



/***/ }),

/***/ "a0d3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WmsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_wms_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("6762");




/**
 * 仓库API服务
 */

var WmsService =
/** @class */
function () {
  function WmsService() {}
  /**
   * 可用仓库查询
   * @param requestParams
   */


  WmsService.prototype.login = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_wms_controller__WEBPACK_IMPORTED_MODULE_3__[/* WmsController */ "a"].login
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], WmsService.prototype, "login", null);

  return WmsService;
}();



/***/ }),

/***/ "a54a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CompanyService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_company_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("9977");




/**
 * 订单API服务
 */

var CompanyService =
/** @class */
function () {
  function CompanyService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  CompanyService.prototype.getList = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_company_controller__WEBPACK_IMPORTED_MODULE_3__[/* CompanyController */ "a"].query_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], CompanyService.prototype, "getList", null);

  return CompanyService;
}();



/***/ }),

/***/ "ab38":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return VendorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_vendor_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("2f4c");




/**
 * 仓库API服务
 */

var VendorService =
/** @class */
function () {
  function VendorService() {}
  /**
   * 可用销售代表查询
   * @param requestParams
   */


  VendorService.prototype.get_vendor_ref_list = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存供应商
   * @param requestParams
   */


  VendorService.prototype.save_vendor = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_vendor_controller__WEBPACK_IMPORTED_MODULE_3__[/* VendorController */ "a"].get_vendor_ref_list
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], VendorService.prototype, "get_vendor_ref_list", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_vendor_controller__WEBPACK_IMPORTED_MODULE_3__[/* VendorController */ "a"].save_vendor
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], VendorService.prototype, "save_vendor", null);

  return VendorService;
}();



/***/ }),

/***/ "b27d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ProductPurchaseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_product_purchase_control__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("e5f6");




/**
 * 采购排单API服务
 */

var ProductPurchaseService =
/** @class */
function () {
  function ProductPurchaseService() {}
  /**
   * 所有排单计划查询
   * @param requestParams
   */


  ProductPurchaseService.prototype.query_all_requirement_schedule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 确认排单计划
   * @param requestParams
   */


  ProductPurchaseService.prototype.confirm_requirement_schedule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 取消排单计划
   * @param requestParams
   */


  ProductPurchaseService.prototype.cancel_requirement_schedule = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改排单计划数量
   * @param requestParams
   */


  ProductPurchaseService.prototype.change_requirement_schedule_qty = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 计算环比
   * @param requestParams
   */


  ProductPurchaseService.prototype.calculate_category_increase_ratio = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询货柜
   * @param requestParams
   */


  ProductPurchaseService.prototype.queryRequirementPackage = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_purchase_control__WEBPACK_IMPORTED_MODULE_3__[/* ProductPurchaseController */ "a"].query_all_requirement_schedule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], ProductPurchaseService.prototype, "query_all_requirement_schedule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_purchase_control__WEBPACK_IMPORTED_MODULE_3__[/* ProductPurchaseController */ "a"].confirm_requirement_schedule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], ProductPurchaseService.prototype, "confirm_requirement_schedule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_purchase_control__WEBPACK_IMPORTED_MODULE_3__[/* ProductPurchaseController */ "a"].cancel_requirement_schedule
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], ProductPurchaseService.prototype, "cancel_requirement_schedule", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_purchase_control__WEBPACK_IMPORTED_MODULE_3__[/* ProductPurchaseController */ "a"].change_requirement_schedule_qty
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], ProductPurchaseService.prototype, "change_requirement_schedule_qty", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_purchase_control__WEBPACK_IMPORTED_MODULE_3__[/* ProductPurchaseController */ "a"].calculate_category_increase_ratio
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], ProductPurchaseService.prototype, "calculate_category_increase_ratio", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_product_purchase_control__WEBPACK_IMPORTED_MODULE_3__[/* ProductPurchaseController */ "a"].queryRequirementPackage
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], ProductPurchaseService.prototype, "queryRequirementPackage", null);

  return ProductPurchaseService;
}();



/***/ }),

/***/ "bcc9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DeliveryMethodService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_delivery_method_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("5ded");




/**
 * 订单API服务
 */

var DeliveryMethodService =
/** @class */
function () {
  function DeliveryMethodService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  DeliveryMethodService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_delivery_method_controller__WEBPACK_IMPORTED_MODULE_3__[/* DeliveryMethodController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], DeliveryMethodService.prototype, "queryAll", null);

  return DeliveryMethodService;
}();



/***/ }),

/***/ "cf45":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TicketService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_ticket_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("9780");




/**
 * 仓库API服务
 */

var TicketService =
/** @class */
function () {
  function TicketService() {}
  /**
   * 查询系统所有收件箱
   * @param requestParams
   */


  TicketService.prototype.query_fetch_email_server = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_ticket_controller__WEBPACK_IMPORTED_MODULE_3__[/* TicketController */ "a"].query_fetch_email_server
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], TicketService.prototype, "query_fetch_email_server", null);

  return TicketService;
}();



/***/ }),

/***/ "d48f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OrderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("c5db");




/**
 * 订单API服务
 */

var OrderService =
/** @class */
function () {
  function OrderService() {}
  /**
   * 查询订单列表
   * @param requestParams
   */


  OrderService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询订单详情
   * @param requestParams
   */


  OrderService.prototype.getDetail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询订单拣货列表
   * @param requestParams
   */


  OrderService.prototype.getPickList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询订单拣货列表
   * @param requestParams
   */


  OrderService.prototype.getInvoiceList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询客户问题列表
   * @param requestParams
   */


  OrderService.prototype.getCustomerList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取日志
   * @param requestParams
   */


  OrderService.prototype.getLogList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存订单
   * @param requestParams
   */


  OrderService.prototype.save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 订单生成账单
   * @param requestParams
   */


  OrderService.prototype.createAccountInvoice = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 取消订单
   * @param requestParams
   */


  OrderService.prototype.cancelOrder = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 取消状态订单变成草稿状态
   * @param requestParams
   */


  OrderService.prototype.setAsDraft = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 订单生成RT面单
   * @param requestParams
   */


  OrderService.prototype.return = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 标识ebay订单已付款
   * @param requestParams
   */


  OrderService.prototype.markEbayOrderAsPaid = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 订单部分退款/全额退款
   * @param requestParams
   */


  OrderService.prototype.refund = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 订单补发
   * @param requestParams
   */


  OrderService.prototype.deliverMore = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取订单AMA/Ebay DZ数据接口
   * @param requestParams
   */


  OrderService.prototype.queryAmaEbayDz = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 订单生成picking
   * @param requestParams
   */


  OrderService.prototype.confirm = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 订单自动生成picking
   * @param requestParams
   */


  OrderService.prototype.autoConfirm = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 订单自动生成picking
   * @param requestParams
   */


  OrderService.prototype.queryOrderInfo = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 变为草稿状态
   * @param requestParams
   */


  OrderService.prototype.setToDraft = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].getOrderList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], OrderService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].getOrderDetail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], OrderService.prototype, "getDetail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].getPickList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], OrderService.prototype, "getPickList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].getInvoiceList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], OrderService.prototype, "getInvoiceList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].getCustomerList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], OrderService.prototype, "getCustomerList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].getLogList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], OrderService.prototype, "getLogList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], OrderService.prototype, "save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].createAccountInvoice
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], OrderService.prototype, "createAccountInvoice", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].cancelOrder
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], OrderService.prototype, "cancelOrder", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].setAsDraft
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], OrderService.prototype, "setAsDraft", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].return
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], OrderService.prototype, "return", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].markEbayOrderAsPaid
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], OrderService.prototype, "markEbayOrderAsPaid", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].refund
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], OrderService.prototype, "refund", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].deliverMore
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_2 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _2 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_3 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _3 : Object)], OrderService.prototype, "deliverMore", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].queryAmaEbayDz
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_4 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _4 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_5 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _5 : Object)], OrderService.prototype, "queryAmaEbayDz", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].confirm
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_6 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _6 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_7 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _7 : Object)], OrderService.prototype, "confirm", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].autoConfirm
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_8 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _8 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_9 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _9 : Object)], OrderService.prototype, "autoConfirm", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].query_order_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_10 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _10 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_11 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _11 : Object)], OrderService.prototype, "queryOrderInfo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_order_controller__WEBPACK_IMPORTED_MODULE_3__[/* OrderController */ "a"].set_to_draft
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_12 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _12 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_13 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _13 : Object)], OrderService.prototype, "setToDraft", null);

  return OrderService;
}();



/***/ }),

/***/ "d4a0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PreSaleService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("8f4a");




/**
 * 订单API服务
 */

var PreSaleService =
/** @class */
function () {
  function PreSaleService() {}
  /**
   * 查询所有产品销售趋势数据
   * @param requestParams
   */


  PreSaleService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 编辑产品销售趋势数据
   * @param requestParams
   */


  PreSaleService.prototype.re_calculate_purchase_predict = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存产品销售趋势数据
   * @param requestParams
   */


  PreSaleService.prototype.save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 产看产品前几周销售数据
   * @param requestParams
   */


  PreSaleService.prototype.query_sku_week_sales = function (requestParams) {
    return requestParams.request();
  };
  /**
   * active_purchase_predict
   * @param requestParams
   */


  PreSaleService.prototype.active_purchase_predict = function (requestParams) {
    return requestParams.request();
  };
  /**
   * confirm_purchase_predict
   * @param requestParams
   */


  PreSaleService.prototype.confirm_purchase_predict = function (requestParams) {
    return requestParams.request();
  };
  /**
   * approve_purchase_predict
   * @param requestParams
   */


  PreSaleService.prototype.approve_purchase_predict = function (requestParams) {
    return requestParams.request();
  };
  /**
   * renew_purchase_predict
   * @param requestParams
   */


  PreSaleService.prototype.renew_purchase_predict = function (requestParams) {
    return requestParams.request();
  };
  /**
   * return_purchase_predict
   * @param requestParams
   */


  PreSaleService.prototype.return_purchase_predict = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PreSaleService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].re_calculate_purchase_predict
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], PreSaleService.prototype, "re_calculate_purchase_predict", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], PreSaleService.prototype, "save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].query_sku_week_sales
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], PreSaleService.prototype, "query_sku_week_sales", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].active_purchase_predict
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], PreSaleService.prototype, "active_purchase_predict", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].confirm_purchase_predict
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], PreSaleService.prototype, "confirm_purchase_predict", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].approve_purchase_predict
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], PreSaleService.prototype, "approve_purchase_predict", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].renew_purchase_predict
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], PreSaleService.prototype, "renew_purchase_predict", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* PreSaleController */ "a"].return_purchase_predict
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], PreSaleService.prototype, "return_purchase_predict", null);

  return PreSaleService;
}();



/***/ }),

/***/ "d66c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CrmteamService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_crmteam_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("c232");




/**
 * 订单API服务
 */

var CrmteamService =
/** @class */
function () {
  function CrmteamService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  CrmteamService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_crmteam_controller__WEBPACK_IMPORTED_MODULE_3__[/* CrmteamController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], CrmteamService.prototype, "queryAll", null);

  return CrmteamService;
}();



/***/ }),

/***/ "d68d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LogoutService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_logout_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("65c5");




/**
 * 系统用户服务
 */

var LogoutService =
/** @class */
function () {
  function LogoutService() {}
  /**
   * 可用销售代表查询
   * @param requestParams
   */


  LogoutService.prototype.logout = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_logout_controller__WEBPACK_IMPORTED_MODULE_3__[/* LogoutController */ "a"].logout
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], LogoutService.prototype, "logout", null);

  return LogoutService;
}();



/***/ }),

/***/ "db1a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PickingService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("8096");




/**
 * 产品API服务
 */

var PickingService =
/** @class */
function () {
  function PickingService() {}
  /**
   * 发货列表查询
   * @param requestParams
   */


  PickingService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 发货详情查询
   * @param requestParams
   */


  PickingService.prototype.queryDetail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 多个发货详情查询
   * @param requestParams
   */


  PickingService.prototype.queryDetailList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * stock_operation 查询
   * @param requestParams
   */


  PickingService.prototype.queryStockOperation = function (requestParams) {
    return requestParams.request();
  };
  /**
   * stock_move 查询
   * @param requestParams
   */


  PickingService.prototype.queryStockMove = function (requestParams) {
    return requestParams.request();
  };
  /**
   * stock_move 查询(回程单)
   * @param requestParams
   */


  PickingService.prototype.queryStockMoveForReturn = function (requestParams) {
    return requestParams.request();
  };
  /**
   * resend product
   * @param requestParams
   */


  PickingService.prototype.queryStockMoveForResend = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 物流信息查询
   * @param requestParams
   */


  PickingService.prototype.queryShipment = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 退款信息查询
   * @param requestParams
   */


  PickingService.prototype.queryReturnInfo = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 发货地址校验查询
   * @param requestParams
   */


  PickingService.prototype.queryValidateShipment = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 提交地址修改并返回校验
   * @param requestParams
   */


  PickingService.prototype.validateAddress = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 取消stock_picking
   * @param requestParams
   */


  PickingService.prototype.cancelPicking = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 批量保存stock_picking地址
   * @param requestParams
   */


  PickingService.prototype.saveAddress = function (requestParams) {
    return requestParams.request();
  };
  /**
   * Picking设置为草稿
   * @param requestParams
   */


  PickingService.prototype.setAsDraft = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 设置picking为presale
   * @param requestParams
   */


  PickingService.prototype.setPresale = function (requestParams) {
    return requestParams.request();
  };
  /**
   * Picking设置为取消presale
   * @param requestParams
   */


  PickingService.prototype.cancelPresale = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 设置picking为卖超
   * @param requestParams
   */


  PickingService.prototype.markSoldOut = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 设置picking不是卖超
   * @param requestParams
   */


  PickingService.prototype.cancelSoldOut = function (requestParams) {
    return requestParams.request();
  };
  /**
   * Check shipments
   * @param requestParams
   */


  PickingService.prototype.checkShipments = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 设置取消shipments
   * @param requestParams
   */


  PickingService.prototype.cancelCheckShipments = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 标记service process
   * @param requestParams
   */


  PickingService.prototype.serviceProcess = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 标记return process
   * @param requestParams
   */


  PickingService.prototype.returnProcess = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 标记customer_service_stop_plz
   * @param requestParams
   */


  PickingService.prototype.customer_service_stop_plz = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 标记return process
   * @param requestParams
   */


  PickingService.prototype.cancel_stock_picking_for_order_refund = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存picking
   * @param requestParams
   */


  PickingService.prototype.save = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存picking operations
   * @param requestParams
   */


  PickingService.prototype.saveOperations = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存picking Move
   * @param requestParams
   */


  PickingService.prototype.saveMove = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存customer problem
   * @param requestParams
   */


  PickingService.prototype.saveCustomerProblem = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存picking shipments
   * @param requestParams
   */


  PickingService.prototype.saveShipmentInfo = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 预留
   * @param requestParams
   */


  PickingService.prototype.reserve = function (requestParams) {
    return requestParams.request();
  };
  /**
   * create_shipments_lines
   * @param requestParams
   */


  PickingService.prototype.createShipmentsLines = function (requestParams) {
    return requestParams.request();
  };
  /**
  /**
  * 保存ReturnShipment
  * @param requestParams
  */


  PickingService.prototype.returnShipment = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 发送邮件cancel_picking_and_send_email
   * @param requestParams
   */


  PickingService.prototype.SendEmail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取picking日志
   * @param requestParams
   */


  PickingService.prototype.queryPickingLog = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除物流面单
   * @param requestParams
   */


  PickingService.prototype.deleteDhlShiDpment = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 确认产品零部件
   * @param requestParams
   */


  PickingService.prototype.confirmProductParts = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询产品零部件query_product_part
   * @param requestParams
   */


  PickingService.prototype.query_product_part = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 假单号
   * @param requestParams
   */


  PickingService.prototype.fake_shipments = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 上传单号
   * @param requestParams
   */


  PickingService.prototype.upload_shipment = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 上传假单号
   * @param requestParams
   */


  PickingService.prototype.upload_fake_shipment = function (requestParams) {
    return requestParams.request();
  };
  /**
   * assign_to_user
   * @param requestParams
   */


  PickingService.prototype.assign_to_user = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 创建运单 不同类型同个接口
   * @param requestParams
   */


  PickingService.prototype.create_shipment_lines_by_ship_type = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 创建运单 不同类型同个接口
   * @param requestParams
   */


  PickingService.prototype.create_dhl_dpd_gift = function (requestParams) {
    return requestParams.request();
  };
  /**
   * force_available
   * @param requestParams
   */


  PickingService.prototype.force_available = function (requestParams) {
    return requestParams.request();
  };
  /**
   * force_pass_validate_shipping_address
   * @param requestParams
   */


  PickingService.prototype.forceVerifyAddress = function (requestParams) {
    return requestParams.request();
  };
  /**
   * save_customer_problem_by_order_id
   * @param requestParams
   */


  PickingService.prototype.saveCustomerProblemByOrderId = function (requestParams) {
    return requestParams.request();
  };
  /**
   * delete_cancel_picking
   * @param requestParams
   */


  PickingService.prototype.deleteCancelPicking = function (requestParams) {
    return requestParams.request();
  };
  /**
   * query_stock_move_base_product
   * @param requestParams
   */


  PickingService.prototype.query_stock_move_base_product = function (requestParams) {
    return requestParams.request();
  };
  /**
   * create_product_tmpl_part_sku
   * @param requestParams
   */


  PickingService.prototype.create_product_tmpl_part_sku = function (requestParams) {
    return requestParams.request();
  };
  /**
   * create_product_tmpl_part_sku
   * @param requestParams
   */


  PickingService.prototype.query_all_picking_resend_detail = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2, _3, _4, _5, _6, _7, _8, _9, _10, _11, _12, _13, _14, _15, _16, _17, _18, _19, _20, _21, _22, _23, _24, _25, _26, _27, _28, _29, _30, _31, _32, _33, _34, _35, _36, _37, _38, _39, _40, _41, _42, _43, _44, _45, _46, _47, _48, _49, _50, _51, _52, _53, _54, _55, _56, _57, _58, _59, _60, _61, _62, _63, _64, _65, _66, _67, _68, _69, _70, _71, _72, _73, _74, _75;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], PickingService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_one_picking
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], PickingService.prototype, "queryDetail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_more_picking
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], PickingService.prototype, "queryDetailList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_stock_operation
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], PickingService.prototype, "queryStockOperation", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_stock_move
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], PickingService.prototype, "queryStockMove", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_stock_move_for_return
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], PickingService.prototype, "queryStockMoveForReturn", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_stock_move_for_resend
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], PickingService.prototype, "queryStockMoveForResend", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_shipments
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], PickingService.prototype, "queryShipment", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_customer_problem_return_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], PickingService.prototype, "queryReturnInfo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_picking_for_validate_shipment
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], PickingService.prototype, "queryValidateShipment", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].validate_picking_shipping_address
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_w = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _w : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_x = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _x : Object)], PickingService.prototype, "validateAddress", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].cancel_stock_picking
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_y = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _y : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_z = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _z : Object)], PickingService.prototype, "cancelPicking", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].save_picking_address
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_0 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _0 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_1 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _1 : Object)], PickingService.prototype, "saveAddress", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].setAsDraft
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_2 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _2 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_3 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _3 : Object)], PickingService.prototype, "setAsDraft", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].setPresale
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_4 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _4 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_5 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _5 : Object)], PickingService.prototype, "setPresale", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].cancelPresale
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_6 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _6 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_7 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _7 : Object)], PickingService.prototype, "cancelPresale", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].markSoldOut
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_8 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _8 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_9 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _9 : Object)], PickingService.prototype, "markSoldOut", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].cancelSoldOut
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_10 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _10 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_11 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _11 : Object)], PickingService.prototype, "cancelSoldOut", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].checkShipments
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_12 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _12 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_13 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _13 : Object)], PickingService.prototype, "checkShipments", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].cancelCheckShipments
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_14 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _14 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_15 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _15 : Object)], PickingService.prototype, "cancelCheckShipments", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].serviceProcess
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_16 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _16 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_17 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _17 : Object)], PickingService.prototype, "serviceProcess", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].returnProcess
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_18 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _18 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_19 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _19 : Object)], PickingService.prototype, "returnProcess", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].customer_service_stop_plz
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_20 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _20 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_21 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _21 : Object)], PickingService.prototype, "customer_service_stop_plz", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].cancel_stock_picking_for_order_refund
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_22 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _22 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_23 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _23 : Object)], PickingService.prototype, "cancel_stock_picking_for_order_refund", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_24 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _24 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_25 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _25 : Object)], PickingService.prototype, "save", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].save_stock_pack_operation
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_26 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _26 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_27 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _27 : Object)], PickingService.prototype, "saveOperations", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].save_stock_move
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_28 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _28 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_29 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _29 : Object)], PickingService.prototype, "saveMove", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].save_customer_problem
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_30 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _30 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_31 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _31 : Object)], PickingService.prototype, "saveCustomerProblem", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].save_shipment_info
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_32 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _32 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_33 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _33 : Object)], PickingService.prototype, "saveShipmentInfo", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].reserve
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_34 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _34 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_35 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _35 : Object)], PickingService.prototype, "reserve", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].create_shipments_lines
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_36 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _36 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_37 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _37 : Object)], PickingService.prototype, "createShipmentsLines", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].ReturnShipment
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_38 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _38 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_39 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _39 : Object)], PickingService.prototype, "returnShipment", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].cancel_picking_and_send_email
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_40 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _40 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_41 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _41 : Object)], PickingService.prototype, "SendEmail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_picking_log
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_42 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _42 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_43 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _43 : Object)], PickingService.prototype, "queryPickingLog", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].delete_dhl_shipment
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_44 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _44 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_45 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _45 : Object)], PickingService.prototype, "deleteDhlShiDpment", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].confirm_product_parts
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_46 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _46 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_47 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _47 : Object)], PickingService.prototype, "confirmProductParts", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_product_part
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_48 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _48 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_49 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _49 : Object)], PickingService.prototype, "query_product_part", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].fake_shipments
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_50 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _50 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_51 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _51 : Object)], PickingService.prototype, "fake_shipments", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].upload_shipment
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_52 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _52 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_53 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _53 : Object)], PickingService.prototype, "upload_shipment", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].upload_fake_shipment
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_54 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _54 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_55 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _55 : Object)], PickingService.prototype, "upload_fake_shipment", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].assign_to_user
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_56 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _56 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_57 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _57 : Object)], PickingService.prototype, "assign_to_user", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].create_shipment_lines_by_ship_type
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_58 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _58 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_59 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _59 : Object)], PickingService.prototype, "create_shipment_lines_by_ship_type", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].create_dhl_dpd_gift
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_60 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _60 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_61 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _61 : Object)], PickingService.prototype, "create_dhl_dpd_gift", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].force_available
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_62 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _62 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_63 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _63 : Object)], PickingService.prototype, "force_available", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].force_pass_validate_shipping_address
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_64 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _64 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_65 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _65 : Object)], PickingService.prototype, "forceVerifyAddress", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].save_customer_problem_by_order_id
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_66 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _66 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_67 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _67 : Object)], PickingService.prototype, "saveCustomerProblemByOrderId", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].delete_cancel_picking
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_68 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _68 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_69 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _69 : Object)], PickingService.prototype, "deleteCancelPicking", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_stock_move_base_product
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_70 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _70 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_71 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _71 : Object)], PickingService.prototype, "query_stock_move_base_product", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].create_product_tmpl_part_sku
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_72 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _72 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_73 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _73 : Object)], PickingService.prototype, "create_product_tmpl_part_sku", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_picking_controller__WEBPACK_IMPORTED_MODULE_3__[/* PickingController */ "a"].query_all_picking_resend_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_74 = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _74 : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_75 = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _75 : Object)], PickingService.prototype, "query_all_picking_resend_detail", null);

  return PickingService;
}();



/***/ }),

/***/ "e342":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MailService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("a8d3");




/**
 * 邮件API服务
 */

var MailService =
/** @class */
function () {
  function MailService() {}
  /**
   * 发送邮件
   * @param requestParams
   */


  MailService.prototype.createEmail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询邮件模板列表
   * @param requestParams
   */


  MailService.prototype.queryEmailTemplate = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询邮件模板内容
   * @param requestParams
   */


  MailService.prototype.renderEmailTemplate = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询邮件所有违禁词
   * @param requestParams
   */


  MailService.prototype.queryAllIllegalWords = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 批量删除违禁词
   * @param requestParams
   */


  MailService.prototype.batchDeleteIllegalWords = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存违禁词
   * @param requestParams
   */


  MailService.prototype.saveIllegalWords = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询ticket seller name
   * @param requestParams
   */


  MailService.prototype.queryTicketSellerName = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询ticket site id
   * @param requestParams
   */


  MailService.prototype.querySiteId = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询ticket类型
   * @param requestParams
   */


  MailService.prototype.query_ticket_type = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].create_email
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], MailService.prototype, "createEmail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].query_email_template
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], MailService.prototype, "queryEmailTemplate", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].render_email_template
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], MailService.prototype, "renderEmailTemplate", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].query_all_illegal_words
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], MailService.prototype, "queryAllIllegalWords", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].batch_delete_illegal_words
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], MailService.prototype, "batchDeleteIllegalWords", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].save_illegal_words
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], MailService.prototype, "saveIllegalWords", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].query_ticket_seller_name
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], MailService.prototype, "queryTicketSellerName", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].query_ticket_site_id_by_ticket_seller_name
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], MailService.prototype, "querySiteId", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_mail_controller__WEBPACK_IMPORTED_MODULE_3__[/* MailController */ "a"].query_ticket_type
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], MailService.prototype, "query_ticket_type", null);

  return MailService;
}();



/***/ }),

/***/ "e73b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LocationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_location_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("1ba9");




/**
 * 订单API服务
 */

var LocationService =
/** @class */
function () {
  function LocationService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  LocationService.prototype.getLocationList = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_location_controller__WEBPACK_IMPORTED_MODULE_3__[/* LocationController */ "a"].query_stock_location
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], LocationService.prototype, "getLocationList", null);

  return LocationService;
}();



/***/ }),

/***/ "eae2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReleasePreSaleService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_release_presale_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("de55");




/**
 * 订单API服务
 */

var ReleasePreSaleService =
/** @class */
function () {
  function ReleasePreSaleService() {}
  /**
   * 获取所有预售订单
   * @param requestParams
   */


  ReleasePreSaleService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询具体产品
   * @param requestParams
   */


  ReleasePreSaleService.prototype.queryProduct = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 取消
   * @param requestParams
   */


  ReleasePreSaleService.prototype.cancel = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 完成
   * @param requestParams
   */


  ReleasePreSaleService.prototype.done = function (requestParams) {
    return requestParams.request();
  };
  /**
   * query one
   * @param requestParams
   */


  ReleasePreSaleService.prototype.query_one = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_release_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReleasePreSaleController */ "a"].queryAll
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], ReleasePreSaleService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_release_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReleasePreSaleController */ "a"].queryProduct
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], ReleasePreSaleService.prototype, "queryProduct", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_release_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReleasePreSaleController */ "a"].cancel
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], ReleasePreSaleService.prototype, "cancel", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_release_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReleasePreSaleController */ "a"].done
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], ReleasePreSaleService.prototype, "done", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_release_presale_controller__WEBPACK_IMPORTED_MODULE_3__[/* ReleasePreSaleController */ "a"].query_one
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], ReleasePreSaleService.prototype, "query_one", null);

  return ReleasePreSaleService;
}();



/***/ }),

/***/ "ef0a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CaseService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("5fa3");




/**
 * 日程管理服务
 */

var CaseService =
/** @class */
function () {
  function CaseService() {}
  /**
   * 获取所有日程
   * @param requestParams
   */


  CaseService.prototype.queryAll = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 获取所有日程
   * @param requestParams
   */


  CaseService.prototype.queryAllCalendar = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存日程
   * @param requestParams
   */


  CaseService.prototype.saveCase = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询日程详情
   * @param requestParams
   */


  CaseService.prototype.queryCaseDetail = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 创建消息
   * @param requestParams
   */


  CaseService.prototype.createMessage = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除消息
   * @param requestParams
   */


  CaseService.prototype.deleteMessage = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 状态字典
   * @param requestParams
   */


  CaseService.prototype.queryCaseType = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 删除case
   * @param requestParams
   */


  CaseService.prototype.deleteCase = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 修改状态
   * @param requestParams
   */


  CaseService.prototype.changeCaseState = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 返回可选择的父日程列表
   * @param requestParams
   */


  CaseService.prototype.getParentCase = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].query_all
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], CaseService.prototype, "queryAll", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].query_all_calendar
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], CaseService.prototype, "queryAllCalendar", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].save_case
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], CaseService.prototype, "saveCase", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].query_case_detail
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_g = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _g : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_h = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _h : Object)], CaseService.prototype, "queryCaseDetail", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].create_message
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_j = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _j : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_k = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _k : Object)], CaseService.prototype, "createMessage", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].delete_message
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_l = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _l : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_m = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _m : Object)], CaseService.prototype, "deleteMessage", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].query_case_type
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_o = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _o : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_p = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _p : Object)], CaseService.prototype, "queryCaseType", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].delete_case
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_q = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _q : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_r = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _r : Object)], CaseService.prototype, "deleteCase", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].change_case_state
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_s = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _s : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_t = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _t : Object)], CaseService.prototype, "changeCaseState", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_case_controller__WEBPACK_IMPORTED_MODULE_3__[/* CaseController */ "a"].get_parent_case_ids
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_u = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _u : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_v = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _v : Object)], CaseService.prototype, "getParentCase", null);

  return CaseService;
}();



/***/ }),

/***/ "f4f1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CountryService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_country_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("640c");




/**
 * 订单API服务
 */

var CountryService =
/** @class */
function () {
  function CountryService() {}
  /**
   * 查询国家列表/id
   * @param requestParams
   */


  CountryService.prototype.getList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 查询国家列表/code
   * @param requestParams
   */


  CountryService.prototype.getListCode = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_country_controller__WEBPACK_IMPORTED_MODULE_3__[/* CountryController */ "a"].getList
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], CountryService.prototype, "getList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_country_controller__WEBPACK_IMPORTED_MODULE_3__[/* CountryController */ "a"].getListByISOCode2
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], CountryService.prototype, "getListCode", null);

  return CountryService;
}();



/***/ }),

/***/ "f966":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9ab4");
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("c4d0");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("e9b9");
/* harmony import */ var _config_services_customer_controller__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("8c20");




/**
 * 客户API服务
 */

var CustomerService =
/** @class */
function () {
  function CustomerService() {}
  /**
   * 客户查询
   * @param requestParams
   */


  CustomerService.prototype.getCustomerList = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 批量分配仓库
   * @param requestParams
   */


  CustomerService.prototype.batchSetStorage = function (requestParams) {
    return requestParams.request();
  };
  /**
   * 保存客户
   * @param requestParams
   */


  CustomerService.prototype.save = function (requestParams) {
    return requestParams.request();
  };

  var _a, _b, _c, _d, _e, _f;

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_customer_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomerController */ "a"].query
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_a = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _a : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_b = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _b : Object)], CustomerService.prototype, "getCustomerList", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_customer_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomerController */ "a"].batchSetWms
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_c = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _c : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_d = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _d : Object)], CustomerService.prototype, "batchSetStorage", null);

  tslib__WEBPACK_IMPORTED_MODULE_0__[/* __decorate */ "c"]([Object(_core_http__WEBPACK_IMPORTED_MODULE_1__["Request"])({
    server: _config_services_customer_controller__WEBPACK_IMPORTED_MODULE_3__[/* CustomerController */ "a"].save
  }), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:type", Function), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:paramtypes", [typeof (_e = typeof _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"] !== "undefined" && _core_http__WEBPACK_IMPORTED_MODULE_1__["RequestParams"]) === "function" ? _e : Object]), tslib__WEBPACK_IMPORTED_MODULE_0__[/* __metadata */ "f"]("design:returntype", typeof (_f = typeof rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"] !== "undefined" && rxjs__WEBPACK_IMPORTED_MODULE_2__[/* Observable */ "a"]) === "function" ? _f : Object)], CustomerService.prototype, "save", null);

  return CustomerService;
}();



/***/ })

}]);