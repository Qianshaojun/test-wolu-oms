(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~2d0332cf"],{

/***/ "056e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-sale-state-change-report.vue?vue&type=template&id=92f8e76e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.sku')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'sku_type',
                        { initialValue: 'default_code' }
                    ]),expression:"[\n                        'sku_type',\n                        { initialValue: 'default_code' }\n                    ]"}],style:({ width: '120px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"default_code"}},[_vm._v(" "+_vm._s(_vm.$t('forms.base_sku'))+" ")]),_c('a-select-option',{attrs:{"value":"common_sku"}},[_vm._v(" "+_vm._s(_vm.$t('forms.common_sku'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sku']),expression:"['sku']"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_operator',
                        { initialValue: 20 }
                    ]),expression:"[\n                        'fuzzy_search_operator',\n                        { initialValue: 20 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category', { initialValue: '' }]),expression:"['z_category', { initialValue: '' }]"}],style:({ width: '90px' }),attrs:{"showSearch":"","placeholder":_vm.$t('columns.z_category'),"filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate,attrs:{"title":cate}},[_vm._v(" "+_vm._s(cate)+" ")])})],2),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category', { initialValue: '' }]),expression:"['z_sub_category', { initialValue: '' }]"}],style:({ width: '180px' }),attrs:{"showSearch":"","placeholder":_vm.$t('columns.z_sub_category'),"filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate,attrs:{"title":cate}},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.month')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'month',
                        { initialValue: [_vm.currentMonth] }
                    ]),expression:"[\n                        'month',\n                        { initialValue: [currentMonth] }\n                    ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""}},_vm._l((_vm.monthData),function(month){return _c('a-select-option',{key:month.value},[_vm._v(" "+_vm._s(month.value)+" ")])}),1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse', { initialValue: '' }]),expression:"['warehouse', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{key:"DE",attrs:{"value":"DE"}},[_vm._v("DE")]),_c('a-radio-button',{key:"UK",attrs:{"value":"UK"}},[_vm._v("UK")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.operator')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator']),expression:"['operator']"}],staticStyle:{"width":"200px"},attrs:{"size":"small","placeholder":"模糊查询"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.leader')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['leader']),expression:"['leader']"}],staticStyle:{"width":"200px"},attrs:{"size":"small","placeholder":"模糊查询"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.origin_prod_status')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'product_origin_state',
                        { initialValue: '' }
                    ]),expression:"[\n                        'product_origin_state',\n                        { initialValue: '' }\n                    ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.final_result')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['final_result', { initialValue: '' }]),expression:"['final_result', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2)],1)]},proxy:true},{key:"collapse",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.prod_status_is_change')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'prod_status_is_change',
                        { initialValue: 0 }
                    ]),expression:"[\n                        'prod_status_is_change',\n                        { initialValue: 0 }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":-1}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":0}},[_vm._v(_vm._s(_vm.$t('forms.prod_status_change'))+" ")]),_c('a-radio-button',{attrs:{"value":1}},[_vm._v(_vm._s(_vm.$t('forms.prod_status_not_change'))+" ")])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.exportReport()}}},[_vm._v(" "+_vm._s(_vm.$t('action.export_report'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"state_range",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'SaleState')))+" ")])}},{key:"approve_state",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.approve_state,'UnsalableApproveState')))+" ")]}}],null,false,1571867366)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"state_range",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'SaleState')))+" ")])}},{key:"approve_state",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.approve_state,'UnsalableApproveState')))+" ")]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/product-sale-state-change-report.vue?vue&type=template&id=92f8e76e&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-sale-state-change-report.vue?vue&type=script&lang=ts&



























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_sale_state_change_reportvue_type_script_lang_ts_ProductSaleStateChangeReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductSaleStateChangeReport, _super);

  function ProductSaleStateChangeReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.queryConsition = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.menu_code = '';
    _this.editRow = {
      id: null
    };
    _this.queryUrl = '/report/query_product_unsalable_approved_report';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.yearPickShow = false;
    _this.moment = moment_default.a;
    _this.topDepartmentList = [];
    _this.currentMonth = '';
    _this.monthData = [];
    _this.needSaveNotes = [];
    return _this;
  }

  ProductSaleStateChangeReport.prototype.handleOpenChange = function (status) {
    this.yearPickShow = status;
  }; // 得到年份选择器的值


  ProductSaleStateChangeReport.prototype.handlePanelChange = function (value) {
    var values = this.dataForm.getValues();
    values['years'] = value.format('YYYY');
    this.dataForm.setValues(values);
    this.yearPickShow = false;
  };

  Object.defineProperty(ProductSaleStateChangeReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ProductSaleStateChangeReport.prototype.created = function () {
    var _this = this;

    this.getSystemuser();
    this.getVendorList();
    this.getDepartmentList();
    this.generateMonth();
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
    this.topDepartmentList = this.departmentList.filter(function (x) {
      return x.dept_type == 30;
    });
  };

  ProductSaleStateChangeReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
    this.menu_code = common_service["a" /* CommonService */].getMenuCode();
  };

  ProductSaleStateChangeReport.prototype.onRowClick = function (row) {
    this.editRow = {
      id: row
    };
  };

  ProductSaleStateChangeReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };

  ProductSaleStateChangeReport.prototype.generateMonth = function () {
    var cur_year = new Date().getFullYear();
    var last_year = cur_year - 1;
    var cur_month = new Date().getMonth();

    if (cur_month < 10) {
      this.currentMonth = cur_year + '-' + '0' + cur_month.toString();
    } else {
      this.currentMonth = cur_year + '-' + cur_month.toString();
    }

    var month_list = ['12', '11', '10', '09', '08', '07', '06', '05', '04', '03', '02', '01'];

    for (var _i = 0, month_list_1 = month_list; _i < month_list_1.length; _i++) {
      var i = month_list_1[_i];
      this.monthData.push({
        code: cur_year.toString() + '-' + i,
        value: cur_year.toString() + '-' + i
      });
    }

    for (var _a = 0, month_list_2 = month_list; _a < month_list_2.length; _a++) {
      var i = month_list_2[_a];
      this.monthData.push({
        code: last_year.toString() + '-' + i,
        value: last_year.toString() + '-' + i
      });
    }
  };

  ProductSaleStateChangeReport.prototype.exportReport = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var sku_type = values['sku_type'];
      values[sku_type] = values['sku'];
      delete values['sku_type'];
      delete values['sku'];
      var fuzzy_search_operator = values['fuzzy_search_operator'];
      var operator = 'like';

      if (fuzzy_search_operator == 20) {
        operator = '=';
      }

      delete values['fuzzy_search_operator'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: operator,
        common_sku: operator,
        z_category: 'like',
        z_sub_category: 'like',
        operator: 'like',
        leader: 'like',
        month: 'in',
        final_result: 'in'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      _this.queryConsition = nowConditions;
      var query_condition = encodeURI(JSON.stringify(params.query_condition));
      window.open(app_config["a" /* default */].server + '/product/export_product_sale_state_change_report?query_condition=' + query_condition);
    });
  };
  /**
   * 获取订单数据
   */


  ProductSaleStateChangeReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var sku_type = values['sku_type'];
      values[sku_type] = values['sku'];
      delete values['sku_type'];
      delete values['sku'];
      var fuzzy_search_operator = values['fuzzy_search_operator'];
      var operator = 'like';

      if (fuzzy_search_operator == 20) {
        operator = '=';
      }

      delete values['fuzzy_search_operator'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: operator,
        common_sku: operator,
        z_category: 'like',
        z_sub_category: 'like',
        operator: 'like',
        leader: 'like',
        month: 'in',
        final_result: 'in'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      for (var _b = 0, nowConditions_1 = nowConditions; _b < nowConditions_1.length; _b++) {
        var i = nowConditions_1[_b];

        if (i.query_name == 'unsalable_judgment') {
          i.operate = i.value == 'null' ? 'null' : i.value == 'not_null' ? 'not null' : '=';

          if (i.operate != '=') {
            i.value = '';
          }
        }
      }

      _this.queryConsition = nowConditions;

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ProductSaleStateChangeReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  ProductSaleStateChangeReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductSaleStateChangeReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ProductSaleStateChangeReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  ProductSaleStateChangeReport.prototype.handleChange = function (e, row, column) {
    row[column] = e;
    var item = this.needSaveNotes.find(function (x) {
      return x.id == row.id;
    });

    if (item) {
      item[column] = e;
    } else {
      var param = {
        id: row.id
      };
      param[column] = e;
      this.needSaveNotes.push(param);
    }
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductSaleStateChangeReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductSaleStateChangeReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductSaleStateChangeReport.prototype, "page_flag", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductSaleStateChangeReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductSaleStateChangeReport.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductSaleStateChangeReport.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductSaleStateChangeReport.prototype, "getVendorList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductSaleStateChangeReport.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductSaleStateChangeReport.prototype, "getDepartmentList", void 0);

  ProductSaleStateChangeReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-sale-state-change-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ProductSaleStateChangeReport);
  return ProductSaleStateChangeReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_sale_state_change_reportvue_type_script_lang_ts_ = (product_sale_state_change_reportvue_type_script_lang_ts_ProductSaleStateChangeReport);
// CONCATENATED MODULE: ./src/pages/reports/product-sale-state-change-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_product_sale_state_change_reportvue_type_script_lang_ts_ = (product_sale_state_change_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/product-sale-state-change-report.vue?vue&type=custom&index=0&blockType=i18n
var product_sale_state_change_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("16bb");

// CONCATENATED MODULE: ./src/pages/reports/product-sale-state-change-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_product_sale_state_change_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_sale_state_change_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_sale_state_change_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_sale_state_change_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "1192":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a4f4");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "16bb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_state_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5ec3");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_state_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_state_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_sale_state_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1f74":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("45be");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "3554":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7aa2");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "387a6":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "45be":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"shop_type":"platform","cn_sub_category":"cn sub category","order_date":"Order Date","bp_sale_num":"Sale Number","country":"Country","customer":"Customer","normal_product_price":"Normal Product Price","per_product_price":"Per Product Price","price_subtotal":"Price Subtotal","product_price_percent":"Product Price Percent","product_price_total":"Product Price Total","profit":"Profit","profit_percent":"Profit Percent","refund":"Refund","refund_percent":"Refund Percent","per_shipment_fee":"Per Shipment Fee","normal_shipment_fee":"Normal Shipment Fee","shipment_fee":"Shipment Fee","shipment_fee_percent":"Shipment Fee Percent","sku":"Sku"},"export_excel_detail":"Export Excel Sku","export_excel_cate":"Export Excel Category","abnormal_price":"Abnormal Price","abnormal_shipping":"Abnormal Shipping"},"zh-cn":{"columns":{"shop_type":"平台","cn_sub_category":"中文子类","order_date":"订单日期","bp_sale_num":"销量","country":"国家","customer":"订单类型","normal_product_price":"产品最低价","per_product_price":"产品销售单价","price_subtotal":"总销售额","product_price_percent":"成本占比","product_price_total":"成本总额","profit":"毛利","profit_percent":"毛利率","refund":"退款","refund_percent":"退款占比","per_shipment_fee":"实际运费","normal_shipment_fee":"理论运费","shipment_fee":"运费","shipment_fee_percent":"运费占比","sku":"Sku"},"export_excel_detail":"导出sku明细","export_excel_cate":"导出品类明细","abnormal_price":"价格异常","abnormal_shipping":"运费异常"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "4992":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "4aab":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_user_purchase_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("818a");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_user_purchase_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_user_purchase_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_user_purchase_vendor_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "4bb3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/purchase-order-daily-report.vue?vue&type=template&id=60fddb05&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.year')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['years']),expression:"['years']"}],attrs:{"mode":"year","format":"YYYY","open":_vm.yearPickShow},on:{"panelChange":_vm.handlePanelChange,"openChange":_vm.handleOpenChange}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.month')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['months']),expression:"['months']"}],style:({ width: '200px' }),attrs:{"min":1,"max":12,"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.week')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['week']),expression:"['week']"}],style:({ width: '200px' }),attrs:{"min":1,"max":53,"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 'default_code' }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 'default_code' }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"order_name"}},[_vm._v(" "+_vm._s(_vm.$t('columns.order_id'))+" ")]),_c('a-select-option',{attrs:{"value":"real_pre_purchase_order"}},[_vm._v(" "+_vm._s(_vm.$t('columns.contact_no'))+" ")]),_c('a-select-option',{attrs:{"value":"default_code"}},[_vm._v(" "+_vm._s(_vm.$t('columns.default_code'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '145px', 'margin-left': '5px' }),attrs:{"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_operator',
                        { initialValue: 'like' }
                    ]),expression:"[\n                        'fuzzy_search_operator',\n                        { initialValue: 'like' }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"like"}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":"="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")]),_c('a-select-option',{attrs:{"value":"in_or="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_list'))+" ")])],1)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}],null,false,1435417471)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/purchase-order-daily-report.vue?vue&type=template&id=60fddb05&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/purchase-order-daily-report.vue?vue&type=script&lang=ts&




















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_order_daily_reportvue_type_script_lang_ts_PurchaseOrderDailyReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseOrderDailyReport, _super);

  function PurchaseOrderDailyReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.queryUrl = 'report_management/query_all_make_order_daily_info';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.yearPickShow = false;
    return _this;
  }

  PurchaseOrderDailyReport.prototype.handleOpenChange = function (status) {
    this.yearPickShow = status;
  }; // 得到年份选择器的值


  PurchaseOrderDailyReport.prototype.handlePanelChange = function (value) {
    var values = this.dataForm.getValues();
    values['years'] = value.format('YYYY');
    this.dataForm.setValues(values);
    this.yearPickShow = false;
  };

  Object.defineProperty(PurchaseOrderDailyReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchaseOrderDailyReport.prototype.created = function () {
    this.getSystemuser();
    this.getVendorList();
  };

  PurchaseOrderDailyReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  PurchaseOrderDailyReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  PurchaseOrderDailyReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var operator = values['fuzzy_search_operator'];
      var search_field_name = values['fuzzy_search_code'];
      values[search_field_name] = values['fuzzy_search_value'];
      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      delete values['fuzzy_search_operator'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: operator,
        real_pre_purchase_order: operator,
        order_name: operator
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseOrderDailyReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseOrderDailyReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  PurchaseOrderDailyReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseOrderDailyReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseOrderDailyReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseOrderDailyReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseOrderDailyReport.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseOrderDailyReport.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseOrderDailyReport.prototype, "getVendorList", void 0);

  PurchaseOrderDailyReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-order-daily-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], PurchaseOrderDailyReport);
  return PurchaseOrderDailyReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_order_daily_reportvue_type_script_lang_ts_ = (purchase_order_daily_reportvue_type_script_lang_ts_PurchaseOrderDailyReport);
// CONCATENATED MODULE: ./src/pages/reports/purchase-order-daily-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_purchase_order_daily_reportvue_type_script_lang_ts_ = (purchase_order_daily_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/purchase-order-daily-report.vue?vue&type=custom&index=0&blockType=i18n
var purchase_order_daily_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("5e3e");

// CONCATENATED MODULE: ./src/pages/reports/purchase-order-daily-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_purchase_order_daily_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_order_daily_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_order_daily_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_order_daily_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "5521":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"no":"no","desc":"this is a Order Page1"},"zh-cn":{"no":"无","desc":"这是订单页面1"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "5771":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("eaf1");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "5e3e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a190");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_order_daily_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "5e90":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profit_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("387a6");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profit_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_profit_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "5ec3":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","apply_discount":"Apply For Discount","save":"Save","approve":"Approve","null":"Null","importUnsaleable":"Import","directApprove":"Directly Approve","confirm_cancel":"Are you sure aprrove?","export_report":"Export Report"},"columns":{"cn_sub_category":"CN Category","z_category":"Category","z_sub_category":"Sub Category","warehouse_id":"Warehouse","year":"Year","month":"Month","week":"Week","order_id":"Order No.","contact_no":"Contact No.","default_code":"Default Code","operator":"Operator","is_need_manual_intervetion":"Need Manual Intervetion","origin_prod_status":"Product Origin State","final_result":"Product Changed State","approve_state":"Approve State","unsalable_judgment":"Unsalable Judgment","leader":"Leader","prod_status_is_change":"Origin Data Compare State"},"rules":{"date_range_error":"start date can\u0027t later start date"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search","sku":"SKU","common_sku":"Common SKU","base_sku":"Base SKU","yes":"Yes","no":"No","prod_status_change":"Status Changed","prod_status_not_change":"Status Not Changed"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确认","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","apply_discount":"折扣申请","save":"保存","approve":"审批","null":"无","importUnsaleable":"导入","directApprove":"一键审批","confirm_cancel":"确认审批吗?","export_report":"下载当前变更报表"},"columns":{"cn_sub_category":"中文分类","z_category":"二级分类","z_sub_category":"三级分类","warehouse_id":"仓库","year":"年度","month":"月度","week":"周次","order_id":"订单号","contact_no":"合同号","default_code":"货号","operator":"运营","is_need_manual_intervetion":"是否需要人工干预","origin_prod_status":"产品原状态","final_result":"产品变更后状态","approve_state":"审批状态","unsalable_judgment":"该月滞销判断(运营)","leader":"运营主管","prod_status_is_change":"原数据对比状态"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询","sku":"货号","common_sku":"通用货号","base_sku":"基础货号","yes":"是","no":"否","prod_status_change":"状态变更数据","prod_status_not_change":"状态未变更数据"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "707c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/purchase-price-change-report.vue?vue&type=template&id=34ddaa20&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 10 }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 10 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('columns.package_name'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('columns.ship_name'))+" ")]),_c('a-select-option',{attrs:{"value":30}},[_vm._v(" "+_vm._s(_vm.$t('columns.real_pre_purchase_order'))+" ")]),_c('a-select-option',{attrs:{"value":40}},[_vm._v(" "+_vm._s(_vm.$t('columns.sku'))+" ")]),_c('a-select-option',{attrs:{"value":50}},[_vm._v(" "+_vm._s(_vm.$t('columns.common_sku'))+" ")]),_c('a-select-option',{attrs:{"value":60}},[_vm._v(" "+_vm._s(_vm.$t('columns.purchase_name'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.create_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['create_date']),expression:"['create_date']"}],attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.exception_status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['exception_status', { initialValue: '' }]),expression:"['exception_status', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PurchasePriceChangeReportStatus),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label)))])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onMarkHandled(20)}}},[_vm._v(" "+_vm._s(_vm.$t('action.mark_handled'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onMarkHandled(30)}}},[_vm._v(" "+_vm._s(_vm.$t('action.mark_changed_price'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onMarkHandled(40)}}},[_vm._v(" "+_vm._s(_vm.$t('action.mark_no_handled'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"state_render",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PurchasePriceChangeReportStatus')))+" ")]}}],null,false,4056509140)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"state_render",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PurchasePriceChangeReportStatus')))+" ")]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/purchase-price-change-report.vue?vue&type=template&id=34ddaa20&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/purchase-price-change-report.vue?vue&type=script&lang=ts&





















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_price_change_reportvue_type_script_lang_ts_ProductVendorReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductVendorReport, _super);

  function ProductVendorReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.publicService = new public_service["a" /* PublicService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.queryUrl = '/report/query_purchase_price_change';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  Object.defineProperty(ProductVendorReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ProductVendorReport.prototype.created = function () {
    this.getSystemuser();
  };

  ProductVendorReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  ProductVendorReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  ProductVendorReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var fuzzy_search_value = values['fuzzy_search_value'];

      if (fuzzy_search_value) {
        var fuzzy_search_code = values['fuzzy_search_code'];
        var search_field_name = 'package_name';

        switch (fuzzy_search_code) {
          case 10:
            search_field_name = 'package_name';
            break;

          case 20:
            search_field_name = 'ship_name';
            break;

          case 30:
            search_field_name = 'real_pre_purchase_order';
            break;

          case 40:
            search_field_name = 'sku';
            break;

          case 50:
            search_field_name = 'common_sku';
            break;

          case 60:
            search_field_name = 'purchase_name';
            break;

          default:
            search_field_name = 'package_name';
        }

        values[search_field_name] = fuzzy_search_value;
      }

      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        package_name: '=',
        ship_name: '=',
        real_pre_purchase_order: '=',
        sku: '=',
        common_sku: '=',
        purchase_name: '='
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.data = data.map(function (x) {
            x.index = uuid_default.a.generate();
            return x;
          });
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ProductVendorReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductVendorReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ProductVendorReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  ProductVendorReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  ProductVendorReport.prototype.onMarkHandled = function (type) {
    var _this = this;

    if (!this.selectedRowKeys.length) {
      this.$message.error('请先选择要标记的列');
      return;
    }

    this.innerAction.setActionAPI('report_management/update_purchase_price_change_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      exception_status: type,
      line_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('Succeess');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductVendorReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductVendorReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductVendorReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductVendorReport.prototype, "getSystemuser", void 0);

  ProductVendorReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-price-change-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ProductVendorReport);
  return ProductVendorReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_price_change_reportvue_type_script_lang_ts_ = (purchase_price_change_reportvue_type_script_lang_ts_ProductVendorReport);
// CONCATENATED MODULE: ./src/pages/reports/purchase-price-change-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_purchase_price_change_reportvue_type_script_lang_ts_ = (purchase_price_change_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/purchase-price-change-report.vue?vue&type=custom&index=0&blockType=i18n
var purchase_price_change_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("c78f");

// CONCATENATED MODULE: ./src/pages/reports/purchase-price-change-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_purchase_price_change_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_price_change_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_price_change_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_price_change_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "78f8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-user-purchase-vendor-report.vue?vue&type=template&id=e1c84e28&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":1,"labelCol":{ span: 3 },"wrapperCol":{ span: 20, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.user_purchase')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_purchase', { initialValue: '' }]),expression:"['user_purchase', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(cate){return _c('a-select-option',{key:cate.code},[_vm._v(" "+_vm._s(cate.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.merchandiser')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['merchandiser', { initialValue: '' }]),expression:"['merchandiser', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(cate){return _c('a-select-option',{key:cate.code},[_vm._v(" "+_vm._s(cate.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 'default_code' }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 'default_code' }\n                    ]"}],style:({ width: '150px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"default_code"}},[_vm._v(" "+_vm._s(_vm.$t('columns.default_code'))+" ")]),_c('a-select-option',{attrs:{"value":"common_sku"}},[_vm._v(" "+_vm._s(_vm.$t('columns.common_sku'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_operator',
                        { initialValue: 'like' }
                    ]),expression:"[\n                        'fuzzy_search_operator',\n                        { initialValue: 'like' }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"like"}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":"="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")]),_c('a-select-option',{attrs:{"value":"in_or="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_list'))+" ")])],1)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}],null,false,1435417471)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/product-user-purchase-vendor-report.vue?vue&type=template&id=e1c84e28&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-user-purchase-vendor-report.vue?vue&type=script&lang=ts&




















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_user_purchase_vendor_reportvue_type_script_lang_ts_ProductUserPurchaseVendorReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductUserPurchaseVendorReport, _super);

  function ProductUserPurchaseVendorReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.queryUrl = 'report_management/query_all_product_vendor_purchase_info';
    return _this;
  }

  Object.defineProperty(ProductUserPurchaseVendorReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ProductUserPurchaseVendorReport.prototype.created = function () {
    this.getSystemuser();
    this.getVendorList();
  };

  ProductUserPurchaseVendorReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  ProductUserPurchaseVendorReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  ProductUserPurchaseVendorReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var operator = values['fuzzy_search_operator'];
      var search_field_name = values['fuzzy_search_code'];
      values[search_field_name] = values['fuzzy_search_value'];
      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      delete values['fuzzy_search_operator'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: operator,
        common_sku: operator
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ProductUserPurchaseVendorReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductUserPurchaseVendorReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ProductUserPurchaseVendorReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductUserPurchaseVendorReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductUserPurchaseVendorReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUserPurchaseVendorReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUserPurchaseVendorReport.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUserPurchaseVendorReport.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUserPurchaseVendorReport.prototype, "getVendorList", void 0);

  ProductUserPurchaseVendorReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-user-purchase-vendor-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ProductUserPurchaseVendorReport);
  return ProductUserPurchaseVendorReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_user_purchase_vendor_reportvue_type_script_lang_ts_ = (product_user_purchase_vendor_reportvue_type_script_lang_ts_ProductUserPurchaseVendorReport);
// CONCATENATED MODULE: ./src/pages/reports/product-user-purchase-vendor-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_product_user_purchase_vendor_reportvue_type_script_lang_ts_ = (product_user_purchase_vendor_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/product-user-purchase-vendor-report.vue?vue&type=custom&index=0&blockType=i18n
var product_user_purchase_vendor_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("4aab");

// CONCATENATED MODULE: ./src/pages/reports/product-user-purchase-vendor-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_product_user_purchase_vendor_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_user_purchase_vendor_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_user_purchase_vendor_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_user_purchase_vendor_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "7aa2":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"no":"no","desc":"this is a Order Page1"},"zh-cn":{"no":"无","desc":"这是订单页面1"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "7e9a4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/profit-detail.vue?vue&type=template&id=427d0257&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer"},[_c('data-form',{ref:"dataForm",attrs:{"column":1},on:{"submit":_vm.getCategoryProfit},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.shop_type')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['shop_type', { initialValue: '' }]),expression:"['shop_type', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.shopType),function(item){return _c('a-radio-button',{key:item,attrs:{"value":item}},[_vm._v(_vm._s(item)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.country')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['country']),expression:"['country']"}],staticStyle:{"width":"28%"},attrs:{"mode":"multiple","size":"small","placeholder":_vm.$t('plzSelect')}},_vm._l((_vm.countryList),function(country){return _c('a-select-option',{key:country,attrs:{"value":country}},[_vm._v(" "+_vm._s(country)+" ")])}),1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_date')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_date']),expression:"['order_date']"}],staticStyle:{"width":"28%"},attrs:{"mode":"multiple","size":"small","placeholder":_vm.$t('plzSelect')}},_vm._l((_vm.order_date_list),function(order_date){return _c('a-select-option',{key:order_date,attrs:{"value":order_date}},[_vm._v(" "+_vm._s(order_date)+" ")])}),1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_category']),expression:"['cn_category']"}],staticStyle:{"width":"120px"},attrs:{"size":"small","placeholder":"category","allowClear":""},on:{"change":_vm.handleFatherCateChange}},_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1),_c('a-select',{staticStyle:{"width":"40%","margin-left":"25px"},attrs:{"mode":"multiple","placeholder":"sub category","size":"small"},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('span',{staticStyle:{"margin-left":"50px","color":"black"}},[_vm._v(_vm._s(_vm.$t('abnormal_price')))]),_c('a-switch',{on:{"change":_vm.priceOnChange},model:{value:(_vm.price_switch),callback:function ($$v) {_vm.price_switch=$$v},expression:"price_switch"}}),_c('span',{staticStyle:{"margin-left":"50px"}},[_vm._v(_vm._s(_vm.$t('abnormal_shipping')))]),_c('a-switch',{on:{"change":_vm.feeOnChange},model:{value:(_vm.fee_switch),callback:function ($$v) {_vm.fee_switch=$$v},expression:"fee_switch"}}),_c('JsonExcel',{staticClass:"export-excel-wrapper",attrs:{"data":_vm.dataDetail,"fields":_vm.json_fields_sku,"name":"sku毛利导出明细.xls"}},[_c('a-button',{attrs:{"type":"primary","disabled":!_vm.dataDetail.length}},[_vm._v(_vm._s(_vm.$t('export_excel_detail'))+" ")])],1),_c('JsonExcel',{staticClass:"export-excel-wrapper",attrs:{"data":_vm.selectedRows,"fields":_vm.json_fields_cate,"name":"品类毛利导出明细.xls"}},[_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRows.length}},[_vm._v(_vm._s(_vm.$t('export_excel_cate'))+" ")])],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"id","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, select_rows) {
                    _vm.selectedRows = select_rows
                    _vm.selectedRowKeys = keys
                }
            },"scroll":{ y: 160 }},on:{"on-page-change":_vm.getCategoryProfit,"onClick":function (record) {
                    this$1.selectCategory(record)
                }}},[_c('a-table-column',{key:"cn_sub_category",attrs:{"title":_vm.$t('columns.cn_sub_category'),"data-index":"cn_sub_category","align":"left"}}),_c('a-table-column',{key:"bp_sale_num",attrs:{"title":_vm.$t('columns.bp_sale_num'),"data-index":"bp_sale_num","align":"right","sorter":function (a, b) {
                        return a.bp_sale_num - b.bp_sale_num
                    }},scopedSlots:_vm._u([{key:"default",fn:function(bp_sale_num){return [_vm._v(_vm._s(_vm._f("datatofixed")(bp_sale_num,2))+" ")]}}])}),_c('a-table-column',{key:"price_subtotal",attrs:{"title":_vm.$t('columns.price_subtotal'),"data-index":"price_subtotal","align":"right","sorter":function (a, b) {
                        return a.price_subtotal - b.price_subtotal
                    }},scopedSlots:_vm._u([{key:"default",fn:function(price_subtotal){return [_vm._v(_vm._s(_vm._f("datatofixed")(price_subtotal,2))+" ")]}}])}),_c('a-table-column',{key:"product_price_total",attrs:{"title":_vm.$t('columns.product_price_total'),"data-index":"product_price_total","align":"right","sorter":function (a, b) {
                        return a.product_price_total - b.product_price_total
                    }},scopedSlots:_vm._u([{key:"default",fn:function(product_price_total){return [_vm._v(_vm._s(_vm._f("datatofixed")(product_price_total,2))+" ")]}}])}),_c('a-table-column',{key:"product_price_percent",attrs:{"title":_vm.$t('columns.product_price_percent'),"data-index":"product_price_percent","align":"right","sorter":function (a, b) {
                        return (
                            a.product_price_percent -
                            b.product_price_percent
                        )
                    }},scopedSlots:_vm._u([{key:"default",fn:function(product_price_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(product_price_percent))+" ")]}}])}),_c('a-table-column',{key:"profit",attrs:{"title":_vm.$t('columns.profit'),"data-index":"profit","align":"right","sorter":function (a, b) {
                        return a.profit - b.profit
                    }},scopedSlots:_vm._u([{key:"default",fn:function(profit){return [_vm._v(_vm._s(_vm._f("datatofixed")(profit,2))+" ")]}}])}),_c('a-table-column',{key:"profit_percent",attrs:{"title":_vm.$t('columns.profit_percent'),"data-index":"profit_percent","align":"right","sorter":function (a, b) {
                        return a.profit_percent - b.profit_percent
                    }},scopedSlots:_vm._u([{key:"default",fn:function(profit_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(profit_percent))+" ")]}}])}),_c('a-table-column',{key:"refund",attrs:{"title":_vm.$t('columns.refund'),"data-index":"refund","align":"right","sorter":function (a, b) {
                        return a.refund - b.refund
                    }},scopedSlots:_vm._u([{key:"default",fn:function(refund){return [_vm._v(_vm._s(_vm._f("datatofixed")(refund,2))+" ")]}}])}),_c('a-table-column',{key:"refund_percent",attrs:{"title":_vm.$t('columns.refund_percent'),"data-index":"refund_percent","align":"right","sorter":function (a, b) {
                        return a.refund_percent - b.refund_percent
                    }},scopedSlots:_vm._u([{key:"default",fn:function(refund_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(refund_percent))+" ")]}}])}),_c('a-table-column',{key:"shipment_fee",attrs:{"title":_vm.$t('columns.shipment_fee'),"data-index":"shipment_fee","align":"right","sorter":function (a, b) {
                        return a.shipment_fee - b.shipment_fee
                    }},scopedSlots:_vm._u([{key:"default",fn:function(shipment_fee){return [_vm._v(_vm._s(_vm._f("datatofixed")(shipment_fee,2))+" ")]}}])}),_c('a-table-column',{key:"shipment_fee_percent",attrs:{"title":_vm.$t('columns.shipment_fee_percent'),"data-index":"shipment_fee_percent","align":"right","sorter":function (a, b) {
                        return (
                            a.shipment_fee_percent - b.shipment_fee_percent
                        )
                    }},scopedSlots:_vm._u([{key:"default",fn:function(shipment_fee_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(shipment_fee_percent))+" ")]}}])})],1)],1),_c('a-card',{staticClass:"margin-y"},[[_c('section',{staticClass:"component customer-detail"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"data":_vm.dataDetail,"rowKey":"id","stripe":true,"scroll":{ y: 500 }},on:{"on-page-change":_vm.getDetailData}},[_c('a-table-column',{key:"sku",attrs:{"title":_vm.$t('columns.sku'),"data-index":"sku","align":"left"}}),_c('a-table-column',{key:"cn_sub_category",attrs:{"title":_vm.$t('columns.cn_sub_category'),"data-index":"cn_sub_category","align":"left"}}),_c('a-table-column',{key:"bp_sale_num",attrs:{"title":_vm.$t('columns.bp_sale_num'),"data-index":"bp_sale_num","align":"right","sorter":function (a, b) {
                                return a.bp_sale_num - b.bp_sale_num
                            }},scopedSlots:_vm._u([{key:"default",fn:function(bp_sale_num){return [_vm._v(_vm._s(_vm._f("datatofixed")(bp_sale_num,2))+" ")]}}])}),_c('a-table-column',{key:"price_subtotal",attrs:{"title":_vm.$t('columns.price_subtotal'),"data-index":"price_subtotal","align":"right","sorter":function (a, b) {
                                return a.price_subtotal - b.price_subtotal
                            }},scopedSlots:_vm._u([{key:"default",fn:function(price_subtotal){return [_vm._v(_vm._s(_vm._f("datatofixed")(price_subtotal,2))+" ")]}}])}),_c('a-table-column',{key:"product_price_total",attrs:{"title":_vm.$t('columns.product_price_total'),"data-index":"product_price_total","align":"right","sorter":function (a, b) {
                                return (
                                    a.product_price_total -
                                    b.product_price_total
                                )
                            }},scopedSlots:_vm._u([{key:"default",fn:function(product_price_total){return [_vm._v(_vm._s(_vm._f("datatofixed")(product_price_total,2))+" ")]}}])}),_c('a-table-column',{key:"product_price_percent",attrs:{"title":_vm.$t('columns.product_price_percent'),"data-index":"product_price_percent","align":"right","sorter":function (a, b) {
                                return (
                                    a.product_price_percent -
                                    b.product_price_percent
                                )
                            }},scopedSlots:_vm._u([{key:"default",fn:function(product_price_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(product_price_percent))+" ")]}}])}),_c('a-table-column',{key:"profit",attrs:{"title":_vm.$t('columns.profit'),"data-index":"profit","align":"right","sorter":function (a, b) {
                                return a.profit - b.profit
                            }},scopedSlots:_vm._u([{key:"default",fn:function(profit){return [_vm._v(_vm._s(_vm._f("datatofixed")(profit,2))+" ")]}}])}),_c('a-table-column',{key:"profit_percent",attrs:{"title":_vm.$t('columns.profit_percent'),"data-index":"profit_percent","align":"right","sorter":function (a, b) {
                                return a.profit_percent - b.profit_percent
                            }},scopedSlots:_vm._u([{key:"default",fn:function(profit_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(profit_percent))+" ")]}}])}),_c('a-table-column',{key:"refund",attrs:{"title":_vm.$t('columns.refund'),"data-index":"refund","align":"right","sorter":function (a, b) {
                                return a.refund - b.refund
                            }},scopedSlots:_vm._u([{key:"default",fn:function(refund){return [_vm._v(_vm._s(_vm._f("datatofixed")(refund,2))+" ")]}}])}),_c('a-table-column',{key:"refund_percent",attrs:{"title":_vm.$t('columns.refund_percent'),"data-index":"refund_percent","align":"right","sorter":function (a, b) {
                                return a.refund_percent - b.refund_percent
                            }},scopedSlots:_vm._u([{key:"default",fn:function(refund_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(refund_percent))+" ")]}}])}),_c('a-table-column',{key:"normal_product_price",attrs:{"title":_vm.$t('columns.normal_product_price'),"data-index":"normal_product_price","align":"right","sorter":function (a, b) {
                                return (
                                    a.normal_product_price -
                                    b.normal_product_price
                                )
                            }},scopedSlots:_vm._u([{key:"default",fn:function(normal_product_price, row){return [_c('span',{style:(row.normal_product_price >
                                    row.per_product_price
                                        ? 'color: red'
                                        : '')},[_vm._v(_vm._s(_vm._f("datatofixed")(normal_product_price,2)))])]}}])}),_c('a-table-column',{key:"per_product_price",attrs:{"title":_vm.$t('columns.per_product_price'),"data-index":"per_product_price","align":"right","sorter":function (a, b) {
                                return (
                                    a.per_product_price -
                                    b.per_product_price
                                )
                            }},scopedSlots:_vm._u([{key:"default",fn:function(normal_product_price, row){return [_c('span',{style:(row.normal_product_price >
                                    row.per_product_price
                                        ? 'color: red'
                                        : '')},[_vm._v(_vm._s(_vm._f("datatofixed")(normal_product_price,2)))])]}}])}),_c('a-table-column',{key:"normal_shipment_fee",attrs:{"title":_vm.$t('columns.normal_shipment_fee'),"data-index":"normal_shipment_fee","align":"right","sorter":function (a, b) {
                                return (
                                    a.normal_shipment_fee -
                                    b.normal_shipment_fee
                                )
                            }},scopedSlots:_vm._u([{key:"default",fn:function(normal_shipment_fee, row){return [_c('span',{style:(row.normal_shipment_fee <
                                    row.per_shipment_fee
                                        ? 'color: orange'
                                        : '')},[_vm._v(_vm._s(_vm._f("datatofixed")(normal_shipment_fee,2)))])]}}])}),_c('a-table-column',{key:"per_shipment_fee",attrs:{"title":_vm.$t('columns.per_shipment_fee'),"data-index":"per_shipment_fee","align":"right","sorter":function (a, b) {
                                return (
                                    a.per_shipment_fee - b.per_shipment_fee
                                )
                            }},scopedSlots:_vm._u([{key:"default",fn:function(per_shipment_fee, row){return [_c('span',{style:(row.normal_shipment_fee <
                                    row.per_shipment_fee
                                        ? 'color: orange'
                                        : '')},[_vm._v(_vm._s(_vm._f("datatofixed")(per_shipment_fee,2)))])]}}])}),_c('a-table-column',{key:"shipment_fee",attrs:{"title":_vm.$t('columns.shipment_fee'),"data-index":"shipment_fee","align":"right","sorter":function (a, b) {
                                return a.shipment_fee - b.shipment_fee
                            }},scopedSlots:_vm._u([{key:"default",fn:function(shipment_fee){return [_vm._v(_vm._s(_vm._f("datatofixed")(shipment_fee,2))+" ")]}}])}),_c('a-table-column',{key:"shipment_fee_percent",attrs:{"title":_vm.$t('columns.shipment_fee_percent'),"data-index":"shipment_fee_percent","align":"right","sorter":function (a, b) {
                                return (
                                    a.shipment_fee_percent -
                                    b.shipment_fee_percent
                                )
                            }},scopedSlots:_vm._u([{key:"default",fn:function(shipment_fee_percent){return [_vm._v(_vm._s(_vm._f("toPercent")(shipment_fee_percent))+" ")]}}])})],1)],1)]],2)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/profit-detail.vue?vue&type=template&id=427d0257&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.js
var es_set = __webpack_require__("6062");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__("3ca3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__("ddb0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.to-fixed.js
var es_number_to_fixed = __webpack_require__("b680");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.from.js
var es_array_from = __webpack_require__("a630");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/vue-json-excel/JsonExcel.vue + 4 modules
var JsonExcel = __webpack_require__("1bdd");

// EXTERNAL MODULE: ./src/shared/filters/datatofixed.filter.ts
var datatofixed_filter = __webpack_require__("6b48");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/profit-detail.vue?vue&type=script&lang=ts&





















var profit_detailvue_type_script_lang_ts_ProfitDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProfitDetail, _super);

  function ProfitDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */](); // private pageService_detail = new PageService()

    _this.reportService = new report_service["a" /* ReportService */]();
    _this.shopType = ['B2C', 'Amazon', 'Ebay', 'Wish', 'Cdiscount', 'Aliexpress'];
    _this.rules = {
      required: [{
        required: true
      }]
    };
    _this.price_switch = false;
    _this.fee_switch = false;
    _this.selectedRowKeys = [];
    _this.selectedRows = [];
    _this.cn_sub_category_list = [];
    _this.selectedList = [];
    _this.countryList = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedSet = new Set();
    _this.data = [];
    _this.dataDetail = [];
    _this.init_dataDetail = [];
    _this.json_fields_sku = {
      Sku: 'sku',
      中文子类: 'cn_sub_category',
      销量: {
        field: 'bp_sale_num',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      总销售额: {
        field: 'price_subtotal',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      成本总额: {
        field: 'product_price_total',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      成本占比: {
        field: 'product_price_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      },
      毛利: {
        field: 'profit',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      毛利率: {
        field: 'profit_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      },
      退款: {
        field: 'refund',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      退款占比: {
        field: 'refund_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      },
      产品最低价: {
        field: 'normal_product_price',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      产品销售单价: {
        field: 'per_product_price',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      理论运费: {
        field: 'normal_shipment_fee',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      实际运费: {
        field: 'per_shipment_fee',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      运费: {
        field: 'shipment_fee',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      运费占比: {
        field: 'shipment_fee_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      }
    };
    _this.json_fields_cate = {
      中文子类: 'cn_sub_category',
      销量: {
        field: 'bp_sale_num',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      总销售额: {
        field: 'price_subtotal',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      成本总额: {
        field: 'product_price_total',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      成本占比: {
        field: 'product_price_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      },
      毛利: {
        field: 'profit',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      毛利率: {
        field: 'profit_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      },
      退款: {
        field: 'refund',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      退款占比: {
        field: 'refund_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      },
      运费: {
        field: 'shipment_fee',
        callback: function callback(value) {
          return Object(datatofixed_filter["a" /* default */])(value, 2);
        }
      },
      运费占比: {
        field: 'shipment_fee_percent',
        callback: function callback(value) {
          return _this.toPecent(value);
        }
      }
    };
    _this.order_date_list = [];
    return _this;
  }

  ProfitDetail.prototype.priceOnChange = function (value) {
    this.price_switch = value;
  };

  ProfitDetail.prototype.feeOnChange = function (value) {
    this.fee_switch = value;
  };

  ProfitDetail.prototype.swichData = function () {
    var tempdata = [];

    if (this.price_switch && !this.fee_switch) {
      tempdata = this.init_dataDetail.filter(function (x) {
        return x.per_product_price < x.normal_product_price;
      });
    } else if (this.fee_switch && !this.price_switch) {
      tempdata = this.init_dataDetail.filter(function (x) {
        return x.per_shipment_fee > x.normal_shipment_fee;
      });
    } else if (this.fee_switch && this.price_switch) {
      tempdata = this.init_dataDetail.filter(function (x) {
        return x.per_shipment_fee > x.normal_shipment_fee || x.per_product_price < x.normal_product_price;
      });
    } else {
      tempdata = this.init_dataDetail;
    }

    this.dataDetail = tempdata;
  };

  ProfitDetail.prototype.onPriceSwitchChange = function () {
    this.swichData();
  };

  ProfitDetail.prototype.onFeeSwitchChange = function () {
    this.swichData();
  };

  ProfitDetail.prototype.toPecent = function (value) {
    if (value && typeof value == 'number') {
      return (value * 100).toFixed(1) + '%';
    }

    return value;
  };

  ProfitDetail.prototype.created = function () {
    this.getCn_cate();
    this.getOrderDateList();
    this.getCountryList();
  };

  ProfitDetail.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  ProfitDetail.prototype.getDetailData = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      // if (!values['shop_type'] || values['shop_type'].length == 0) {
      //     this.$message.error('请选择平台')
      //     return false
      // }
      if (values['order_date'] && values['order_date'].length == 0) {
        delete values['order_date'];
      }

      if (values['cn_category'] && values['cn_category'].length == 0) {
        delete values['cn_category'];
      }

      if (values['country'] && values['country'].length == 0) {
        delete values['country'];
      }

      var cn_sub_category_list = Array.from(_this.selectedSet);

      if (cn_sub_category_list.length > 0) {
        values['cn_sub_category'] = cn_sub_category_list;
      } else if (cn_sub_category_list.length === 0 && _this.selectedList.length > 0) {
        values['cn_sub_category'] = _this.selectedList;
      } else {
        _this.$message.warn('请检查查询条件');

        return false;
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        shop_type: 'like',
        cn_sub_category: 'in',
        order_date: 'in',
        country: 'in'
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];
        nowConditions.push(item);
      }

      params.query_condition = nowConditions;

      _this.reportService.query_sku_profit_data(new http["RequestParams"](params, {
        loading: _this.loadingService
      })).subscribe(function (data) {
        for (var i = 0; i < data.length; i++) {
          data[i].id = i;
        }

        _this.init_dataDetail = data;

        _this.swichData();
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {
      _this.$message.error('请检查查询条件');
    });
  };

  ProfitDetail.prototype.onChangeSelectedSet = function () {
    if (this.selectedSet.size > 0) {
      this.getDetailData();
    }
  };

  ProfitDetail.prototype.onChangeSelectedRowKeys = function () {
    var tempSet = new Set();

    var _loop_1 = function _loop_1(i) {
      var row = this_1.data.find(function (x) {
        return x.id == i;
      });

      if (row) {
        tempSet.add(row.cn_sub_category);
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      _loop_1(i);
    }

    if (!this.eqSet(tempSet, this.selectedSet)) {
      this.selectedSet = tempSet;
    }
  };

  ProfitDetail.prototype.eqSet = function (as, bs) {
    if (as.size !== bs.size) {
      return false;
    }

    for (var _i = 0, as_1 = as; _i < as_1.length; _i++) {
      var i = as_1[_i];

      if (!bs.has(i)) {
        return false;
      }
    }

    return true;
  };

  ProfitDetail.prototype.getCountryList = function () {
    var _this = this;

    this.reportService.query_country_list(new http["RequestParams"]()).subscribe(function (data) {
      _this.countryList = data;
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProfitDetail.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProfitDetail.prototype.getOrderDateList = function () {
    var _this = this;

    this.reportService.query_order_date_list(new http["RequestParams"]()).subscribe(function (data) {
      _this.order_date_list = data;
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProfitDetail.prototype.selectCategory = function (record) {
    var set = new Set(this.selectedRowKeys);

    if (set.has(record)) {
      set.delete(record);
    } else {
      set.add(record);
    }

    this.selectedRowKeys = Array.from(set);
    this.selectedRows = [];

    var _loop_2 = function _loop_2(i) {
      this_2.selectedRows.push(this_2.data.find(function (x) {
        return x.id == i;
      }));
    };

    var this_2 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      _loop_2(i);
    }
  };

  ProfitDetail.prototype.getCategoryProfit = function (sorter) {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      // if (!values['shop_type'] || values['shop_type'].length == 0) {
      //     this.$message.error('请选择平台')
      //     return false
      // }
      if (values['order_date'] && values['order_date'].length == 0) {
        delete values['order_date'];
      }

      if (values['country'] && values['country'].length == 0) {
        delete values['country'];
      }

      if (_this.selectedList.length > 0) {
        values['cn_sub_category'] = _this.selectedList;
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        shop_type: 'like',
        cn_sub_category: 'in',
        order_date: 'in',
        country: 'in'
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];
        nowConditions.push(item);
      }

      _this.reportService.query_category_profit_data(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        for (var i = 0; i < data.length; i++) {
          data[i].id = i;
        }

        _this.data = data;
        _this.selectedRowKeys = [];
        _this.init_dataDetail = [];
        _this.dataDetail = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {
      _this.$message.error('请检查查询条件');
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProfitDetail.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProfitDetail.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('price_switch'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProfitDetail.prototype, "onPriceSwitchChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('fee_switch'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProfitDetail.prototype, "onFeeSwitchChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('selectedSet'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProfitDetail.prototype, "onChangeSelectedSet", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('selectedRowKeys'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProfitDetail.prototype, "onChangeSelectedRowKeys", null);

  ProfitDetail = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'profit-detail'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      JsonExcel: JsonExcel["a" /* default */]
    },
    filters: {
      toPercent: function toPercent(value) {
        if (value && typeof value == 'number') {
          return (value * 100).toFixed(1) + '%';
        }

        return value;
      }
    }
  })], ProfitDetail);
  return ProfitDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var profit_detailvue_type_script_lang_ts_ = (profit_detailvue_type_script_lang_ts_ProfitDetail);
// CONCATENATED MODULE: ./src/pages/reports/profit-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_profit_detailvue_type_script_lang_ts_ = (profit_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/reports/profit-detail.vue?vue&type=style&index=0&lang=css&
var profit_detailvue_type_style_index_0_lang_css_ = __webpack_require__("5e90");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/profit-detail.vue?vue&type=custom&index=0&blockType=i18n
var profit_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("1f74");

// CONCATENATED MODULE: ./src/pages/reports/profit-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_profit_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof profit_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(profit_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var profit_detail = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "818a":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return"},"columns":{"z_sub_category":"Sub Category","vendor_id":"Vendor","default_code":"Default Code","common_sku":"Common SKU","user_purchase":"User Purchase","merchandiser":"Merchandiser"},"rules":{"date_range_error":"start date can\u0027t later start date"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货"},"columns":{"z_sub_category":"中文子类","vendor_id":"供应商","default_code":"基础货号","common_sku":"通用货号","user_purchase":"采购员","merchandiser":"跟单员"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "81fb":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return"},"columns":{"z_sub_category":"Sub Category","vendor_id":"Vendor","user_purchase":"User Purchase","user_require":"User Require","default_code":"SKU","req_name":"Req Name"},"rules":{"date_range_error":"start date can\u0027t later start date"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","require_log":"Requirement Log","ship_log":"Shipement Log"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货"},"columns":{"z_sub_category":"中文子类","vendor_id":"供应商","user_purchase":"采购人","user_require":"需求人","default_code":"SKU","req_name":"需求编号"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","require_log":"补货需求日志","ship_log":"发货日志"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a190":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return"},"columns":{"z_sub_category":"Sub Category","vendor_id":"Vendor","year":"Year","month":"Month","week":"Week","order_id":"Order No.","contact_no":"Contact No.","default_code":"Default Code"},"rules":{"date_range_error":"start date can\u0027t later start date"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货"},"columns":{"z_sub_category":"中文子类","vendor_id":"供应商","year":"年度","month":"月度","week":"周次","order_id":"订单号","contact_no":"合同号","default_code":"货号"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a4f4":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return"},"columns":{"z_sub_category":"Sub Category","vendor_id":"Vendor"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货"},"columns":{"z_sub_category":"中文子类","vendor_id":"供应商"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a702":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_requirement_history_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("81fb");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_requirement_history_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_requirement_history_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_requirement_history_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b3ca":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-unsalable-report-leader.vue?vue&type=template&id=4c22cdbe&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('ProductUnsalableReportContent',{attrs:{"page_flag":_vm.page_flag}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/product-unsalable-report-leader.vue?vue&type=template&id=4c22cdbe&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/components/product/product-unsalable-report-content.vue + 4 modules
var product_unsalable_report_content = __webpack_require__("0092");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-unsalable-report-leader.vue?vue&type=script&lang=ts&






var product_unsalable_report_leadervue_type_script_lang_ts_ProductUnsalableReportLeader =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductUnsalableReportLeader, _super);

  function ProductUnsalableReportLeader() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // 表格数据源


    _this.page_flag = 'leader';
    return _this;
  }

  ProductUnsalableReportLeader.prototype.created = function () {};

  ProductUnsalableReportLeader.prototype.mounted = function () {
    this.page_flag = 'leader';
  };

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], ProductUnsalableReportLeader.prototype, "pageContainer", void 0);

  ProductUnsalableReportLeader = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-unsalable-report-leader'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductUnsalableReportContent: product_unsalable_report_content["a" /* default */]
    }
  })], ProductUnsalableReportLeader);
  return ProductUnsalableReportLeader;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_unsalable_report_leadervue_type_script_lang_ts_ = (product_unsalable_report_leadervue_type_script_lang_ts_ProductUnsalableReportLeader);
// CONCATENATED MODULE: ./src/pages/reports/product-unsalable-report-leader.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_product_unsalable_report_leadervue_type_script_lang_ts_ = (product_unsalable_report_leadervue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/reports/product-unsalable-report-leader.vue?vue&type=style&index=0&lang=css&
var product_unsalable_report_leadervue_type_style_index_0_lang_css_ = __webpack_require__("ed05");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/product-unsalable-report-leader.vue?vue&type=custom&index=0&blockType=i18n
var product_unsalable_report_leadervue_type_custom_index_0_blockType_i18n = __webpack_require__("d415");

// CONCATENATED MODULE: ./src/pages/reports/product-unsalable-report-leader.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_product_unsalable_report_leadervue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_unsalable_report_leadervue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_unsalable_report_leadervue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_unsalable_report_leader = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "b88b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/purchase-requirement-history-report.vue?vue&type=template&id=3c9dff38&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":1,"labelCol":{ span: 3 },"wrapperCol":{ span: 20, offset: 0 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.user_purchase')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_purchase', { initialValue: '' }]),expression:"['user_purchase', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(cate){return _c('a-select-option',{key:cate.code},[_vm._v(" "+_vm._s(cate.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.user_require')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_require', { initialValue: '' }]),expression:"['user_require', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(cate){return _c('a-select-option',{key:cate.code},[_vm._v(" "+_vm._s(cate.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 'default_code' }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 'default_code' }\n                    ]"}],style:({ width: '200px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"default_code"}},[_vm._v(" "+_vm._s(_vm.$t('columns.default_code'))+" ")]),_c('a-select-option',{attrs:{"value":"req_name"}},[_vm._v(" "+_vm._s(_vm.$t('columns.req_name'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', 'margin-left': '5px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_operator',
                        { initialValue: 'like' }
                    ]),expression:"[\n                        'fuzzy_search_operator',\n                        { initialValue: 'like' }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"like"}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":"="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")]),_c('a-select-option',{attrs:{"value":"in_or="}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_list'))+" ")])],1)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onTrClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"date_approve",fn:function(text, row){return [_c('span',{attrs:{"id":'id' + row.id}},[_vm._v(_vm._s(text ? text : '')+" "+_vm._s(_vm.calcStyle(row)))])]}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}],null,false,169704729)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":2000,"scrollY":400},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"date_approve",fn:function(text, row){return [_c('span',{attrs:{"id":'id' + row.id}},[_vm._v(_vm._s(text ? text : '')+" "+_vm._s(_vm.calcStyle(row)))])]}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}])})],1),(_vm.selectedRowKeys[0])?_c('a-card',[_c('a-tabs',{attrs:{"defaultActiveKey":"require_log"},on:{"change":function (e) { return _vm.onPanelChange(e); }}},[_c('a-tab-pane',{key:"require_log",attrs:{"tab":_vm.$t('require_log')}},[_c('LogView',{attrs:{"object_name":_vm.object_name,"record_code":_vm.record_code,"is_special_table":true}})],1),_c('a-tab-pane',{key:"ship_log",attrs:{"tab":_vm.$t('ship_log')}},[_c('LogView',{attrs:{"object_name":_vm.object_name,"record_code":_vm.record_code,"is_special_table":true}})],1)],1)],1):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/purchase-requirement-history-report.vue?vue&type=template&id=3c9dff38&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/purchase-requirement-history-report.vue?vue&type=script&lang=ts&























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_requirement_history_reportvue_type_script_lang_ts_PurchaseRequirementHistoryReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseRequirementHistoryReport, _super);

  function PurchaseRequirementHistoryReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.queryUrl = 'report_management/query_all_product_purchase_histry';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.record_code = '';
    _this.object_name = 'req_line';
    _this.currentRow = '';
    _this.currentLogType = 'require_log';
    return _this;
  }

  Object.defineProperty(PurchaseRequirementHistoryReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchaseRequirementHistoryReport.prototype.created = function () {
    this.getSystemuser();
    this.getVendorFullNameList();
  };

  PurchaseRequirementHistoryReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  PurchaseRequirementHistoryReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  PurchaseRequirementHistoryReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var operator = values['fuzzy_search_operator'];
      var search_field_name = values['fuzzy_search_code'];
      values[search_field_name] = values['fuzzy_search_value'];
      delete values['fuzzy_search_value'];
      delete values['fuzzy_search_code'];
      delete values['fuzzy_search_operator'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: operator,
        req_name: operator
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseRequirementHistoryReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseRequirementHistoryReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  PurchaseRequirementHistoryReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  PurchaseRequirementHistoryReport.prototype.calcStyle = function (row) {
    this.$nextTick(function () {
      if (row.date_approve) {
        var no_order_7day = row.no_order_7day;
        var no_order_3day = row.no_order_3day;
        var sp = document.getElementById('id' + row.id);
        var tr = sp.parentNode.parentNode;

        if (no_order_7day) {
          tr.style.color = 'red';
        } else if (no_order_3day) {
          tr.style.color = '#f90';
        }
      }
    });
  };

  PurchaseRequirementHistoryReport.prototype.onTrClick = function (record) {
    this.currentRow = this.data.find(function (x) {
      return x.id === record;
    });

    if (this.currentLogType == 'require_log') {
      this.record_code = this.currentRow.req_line_id;
    } else {
      this.record_code = this.currentRow.order2_line_id;
    }
  };

  PurchaseRequirementHistoryReport.prototype.onPanelChange = function (key) {
    if (key == 'require_log') {
      this.record_code = this.currentRow.req_line_id;
    } else {
      this.record_code = this.currentRow.order2_line_id;
    }
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseRequirementHistoryReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseRequirementHistoryReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseRequirementHistoryReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseRequirementHistoryReport.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseRequirementHistoryReport.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseRequirementHistoryReport.prototype, "getVendorFullNameList", void 0);

  PurchaseRequirementHistoryReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-requirement-history-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      LogView: log_view["a" /* default */]
    }
  })], PurchaseRequirementHistoryReport);
  return PurchaseRequirementHistoryReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_requirement_history_reportvue_type_script_lang_ts_ = (purchase_requirement_history_reportvue_type_script_lang_ts_PurchaseRequirementHistoryReport);
// CONCATENATED MODULE: ./src/pages/reports/purchase-requirement-history-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_purchase_requirement_history_reportvue_type_script_lang_ts_ = (purchase_requirement_history_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/purchase-requirement-history-report.vue?vue&type=custom&index=0&blockType=i18n
var purchase_requirement_history_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("a702");

// CONCATENATED MODULE: ./src/pages/reports/purchase-requirement-history-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_purchase_requirement_history_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_requirement_history_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_requirement_history_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_requirement_history_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "c78f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_price_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d4d5");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_price_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_price_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_price_change_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "c8c8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-unsalable-report.vue?vue&type=template&id=25390cb4&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('ProductUnsalableReportContent',{attrs:{"page_flag":_vm.page_flag}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/product-unsalable-report.vue?vue&type=template&id=25390cb4&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/components/product/product-unsalable-report-content.vue + 4 modules
var product_unsalable_report_content = __webpack_require__("0092");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-unsalable-report.vue?vue&type=script&lang=ts&






var product_unsalable_reportvue_type_script_lang_ts_ProductUnsalableReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductUnsalableReport, _super);

  function ProductUnsalableReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // 表格数据源


    _this.page_flag = '';
    return _this;
  }

  ProductUnsalableReport.prototype.created = function () {};

  ProductUnsalableReport.prototype.mounted = function () {
    this.page_flag = '';
  };

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], ProductUnsalableReport.prototype, "pageContainer", void 0);

  ProductUnsalableReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-unsalable-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductUnsalableReportContent: product_unsalable_report_content["a" /* default */]
    }
  })], ProductUnsalableReport);
  return ProductUnsalableReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_unsalable_reportvue_type_script_lang_ts_ = (product_unsalable_reportvue_type_script_lang_ts_ProductUnsalableReport);
// CONCATENATED MODULE: ./src/pages/reports/product-unsalable-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_product_unsalable_reportvue_type_script_lang_ts_ = (product_unsalable_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/reports/product-unsalable-report.vue?vue&type=style&index=0&lang=css&
var product_unsalable_reportvue_type_style_index_0_lang_css_ = __webpack_require__("5771");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/product-unsalable-report.vue?vue&type=custom&index=0&blockType=i18n
var product_unsalable_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("3554");

// CONCATENATED MODULE: ./src/pages/reports/product-unsalable-report.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_product_unsalable_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_unsalable_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_unsalable_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_unsalable_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "d415":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_leader_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5521");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_leader_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_leader_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_leader_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "d4d5":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","mark_handled":"Mark to Handled","mark_no_handled":"Mark to No Handled","mark_pre_handled":"Mark to Pre Handled","mark_changed_price":"Mark Changed Price"},"columns":{"package_name":"Package Name","ship_name":"Ship Name","real_pre_purchase_order":"real_pre_purchase_order","sku":"Sku","common_sku":"Common Sku","purchase_name":"Purchase Name","create_date":"Package Create Date","exception_status":"Exception Status"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search"}},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","mark_handled":"标记已处理","mark_no_handled":"标记已忽略","mark_pre_handled":"标记未处理","mark_changed_price":"标记已调价"},"columns":{"package_name":"货柜号","ship_name":"发货合同号","real_pre_purchase_order":"外箱合同号","sku":"Sku","common_sku":"通用Sku","purchase_name":"采购合同号","create_date":"货柜创建时间","exception_status":"处理状态"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "eaf1":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "ed05":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_leader_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4992");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_leader_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_leader_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "f86f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-vendor-report.vue?vue&type=template&id=631db138&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category', { initialValue: '' }]),expression:"['z_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category', { initialValue: '' }]),expression:"['z_sub_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}],null,false,1435417471)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/reports/product-vendor-report.vue?vue&type=template&id=631db138&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/reports/product-vendor-report.vue?vue&type=script&lang=ts&




















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_vendor_reportvue_type_script_lang_ts_ProductVendorReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductVendorReport, _super);

  function ProductVendorReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.queryUrl = 'report_management/query_all_product_vendor_report';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  Object.defineProperty(ProductVendorReport.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ProductVendorReport.prototype.created = function () {
    var _this = this;

    this.getSystemuser();
    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProductVendorReport.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  ProductVendorReport.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  ProductVendorReport.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (_this.selectedList.length > 0) {
        values['z_sub_category'] = _this.selectedList;
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: 'in_or_=',
        z_sub_category: 'in'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ProductVendorReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductVendorReport.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ProductVendorReport.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  ProductVendorReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductVendorReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductVendorReport.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductVendorReport.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductVendorReport.prototype, "getSystemuser", void 0);

  ProductVendorReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'product-vendor-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ProductVendorReport);
  return ProductVendorReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_vendor_reportvue_type_script_lang_ts_ = (product_vendor_reportvue_type_script_lang_ts_ProductVendorReport);
// CONCATENATED MODULE: ./src/pages/reports/product-vendor-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var reports_product_vendor_reportvue_type_script_lang_ts_ = (product_vendor_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/reports/product-vendor-report.vue?vue&type=custom&index=0&blockType=i18n
var product_vendor_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("1192");

// CONCATENATED MODULE: ./src/pages/reports/product-vendor-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  reports_product_vendor_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_vendor_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_vendor_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_vendor_report = __webpack_exports__["default"] = (component.exports);

/***/ })

}]);