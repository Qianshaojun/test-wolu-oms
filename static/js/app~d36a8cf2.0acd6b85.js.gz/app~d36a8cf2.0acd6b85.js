(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~d36a8cf2"],{

/***/ "2bb8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./src/core/application_store.ts
var application_store = __webpack_require__("d19e");

// CONCATENATED MODULE: ./src/bootstrap/directives/auth.ts







/* harmony default export */ var auth = (function (store) {
  /**
   * v-Auth 按钮权限控制
   */
  return {
    bind: function bind(el, binding) {// let spanNode = document.createElement('span')
      // setButtonName(el, binding, store, spanNode)
    },
    inserted: function inserted(el, binding) {
      // 获取绑定的权限值
      var authCode = binding.value;

      if (!authCode) {
        return;
      }

      var permissions = [];
      var menuObj = store.state.buttonAuthInfo.find(function (v) {
        return v.menu_code === store.state.menuCode;
      });

      if (menuObj && menuObj.exists_authority) {
        permissions = menuObj.button_list.map(function (v) {
          return v.button_name;
        });
      }

      var hasPermission = checkAuthority(authCode, permissions);

      if (!hasPermission) {
        if (el.parentNode) {
          el.parentNode.removeChild(el);
        }
      }
    },
    componentUpdated: function componentUpdated(el, binding) {// let spanNode = document.createElement('span')
      // setButtonName(el, binding, store, spanNode)
    }
  };
}); //校验按钮权限

var checkAuthority = function checkAuthority(permissionCode, permissions) {
  var hasPermission = true;

  if (permissionCode) {
    //区分指令绑定的是单个或多个权限
    if (permissionCode instanceof Array && permissionCode.length > 0) {
      hasPermission = permissions.some(function (it) {
        return permissionCode.includes(it);
      });
    } else {
      hasPermission = permissions.some(function (item) {
        return item === permissionCode;
      });
    }
  }

  return hasPermission;
}; //设置按钮名称


var auth_setButtonName = function setButtonName(el, binding, store, node) {
  var local = application_store["a" /* ApplicationStore */].getStore().state.locale; //获取当前语言

  var menuObj = store.state.buttonAuthInfo.find(function (v) {
    return v.menu_code === store.state.menuCode;
  });
  var hasSetAuthButtonInfo = {};

  if (menuObj) {
    if (menuObj.exists_authority) {
      hasSetAuthButtonInfo = menuObj.button_list.find(function (v) {
        return v.button_name === binding.value;
      });
    }

    if (el && hasSetAuthButtonInfo && JSON.stringify(hasSetAuthButtonInfo) != '{}') {
      var buttonName = "" + (local === 'zh-cn' ? hasSetAuthButtonInfo.button_name_cn : hasSetAuthButtonInfo.button_name_en);
      node.innerText = buttonName;

      if (el.children.length) {
        el.replaceChild(node, el.children[0]);
      }
    }
  }
};
// CONCATENATED MODULE: ./src/bootstrap/directives/focus.ts
/* harmony default export */ var directives_focus = (function (store) {
  /**
   * v-focus input自动焦点
   */
  return function (el, binding, vnode) {
    var able = binding.value;

    if (able) {
      el.focus();
    } else {
      return;
    }
  };
});
// CONCATENATED MODULE: ./src/bootstrap/directives/index.ts


/* harmony default export */ var directives = __webpack_exports__["a"] = (function (store) {
  return {
    /**
     * 资源认证
     */
    auth: auth(store),
    focus: directives_focus(store)
  };
});

/***/ }),

/***/ "8f32":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, "b", function() { return /* reexport */ launch_launch; });
__webpack_require__.d(__webpack_exports__, "a", function() { return /* binding */ boots_boot; });

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/store/index.ts + 9 modules
var src_store = __webpack_require__("0613");

// EXTERNAL MODULE: ./src/bootstrap/services/token.service.ts
var token_service = __webpack_require__("be38");

// EXTERNAL MODULE: ./node_modules/ant-design-vue/es/message/index.js
var message = __webpack_require__("f64c");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// CONCATENATED MODULE: ./src/bootstrap/boots/http.boot.ts







 // import { TokenService } from '~/extension/services/token.service'



/* harmony default export */ var http_boot = (function () {
  // 配置服务端信息
  http["RequestService"].setConfig({
    server: app_config["a" /* default */].server,
    timeout: app_config["a" /* default */].timeout
  }); // 添加状态拦截器

  http["RequestService"].interceptors.status.use(function (respone) {
    var result = respone.data.result;
    return result.code === 0;
  }); // 添加成功拦截器

  http["RequestService"].interceptors.success.use(function (respone) {
    var result = respone.data.result;

    if (result.length !== undefined) {
      return result.results;
    } else {
      return result;
    }
  }); // 添加失败拦截器

  http["RequestService"].interceptors.error.use(function (respone) {
    loading_service["a" /* LoadingService */].clearTimer();

    if (Object(esm_typeof["a" /* default */])(respone.data.result.message) === 'object') {
      var msg = JSON.stringify(respone.data.result.message).replace('{', '').replace('}', '');
      respone.data.result.message = msg;
    } // if (respone.data.result.message == 'Odoo Session Expired') {
    //     setTimeout(function() {
    //         router.push({ name: 'login' })
    //     }, 1000)
    // }


    return respone.data.result;
  }); // 网络异常处理

  http["RequestService"].requestCatchHandle = function (respone) {
    loading_service["a" /* LoadingService */].clearTimer();
    var defaultError = 'Connect Server Failed, Please try again!';
    var messages = {
      400: '请求参数错误',
      405: '请求服务方法错误',
      500: '服务器内部错误',
      403: '没有权限，请重新登陆'
    };

    if (respone) {
      var errMsg = (respone.data || {}).message;

      if (respone.status === 403) {
        setTimeout(function () {
          src_store["a" /* default */].dispatch('clearUserLoginData').catch();
        }, 2000);
      }

      if (respone.data && respone.data.error && respone.data.error.message === 'Odoo Session Expired') {
        message["a" /* default */].error('登录Session过期，请重新登录'); // setTimeout(function() {
        //     router.push({ name: 'login' })
        // }, 1000)
      } else {
        message["a" /* default */].error(errMsg || messages[respone.status] || defaultError);
      }
    } else {// message.error(defaultError)
      // setTimeout(function() {
      //     router.push({ name: 'login' })
      // }, 1000)
    }
  }; // 安装全局服务扩展


  http["RequestService"].installExtendService(new token_service["a" /* TokenService */]());
});
// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__("99af");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./src/core/application_router.ts
var application_router = __webpack_require__("f303");

// EXTERNAL MODULE: ./node_modules/mobile-detect/mobile-detect.js
var mobile_detect = __webpack_require__("c6c6");
var mobile_detect_default = /*#__PURE__*/__webpack_require__.n(mobile_detect);

// CONCATENATED MODULE: ./src/bootstrap/boots/guard.boot.ts






 // 认证白名单

var authWhiteList = ['login', 'login-mobile']; // 认证状态检测

var authCheck = function authCheck(store, toname) {
  var menuArr = [];

  if (store.state.userModule.menus) {
    var menus = store.state.userModule.menus.map(function (item) {
      var menu = [];

      if (item.children && item.children.length) {
        menu = item.children.map(function (x) {
          var smenu = [];

          if (x.children && x.children.length) {
            smenu = x.children.map(function (y) {
              return y.name;
            });
          }

          smenu.push(x.name);
          return smenu;
        });
      }

      menu.push(item.name);
      var menuTemp = [];

      for (var _i = 0, menu_1 = menu; _i < menu_1.length; _i++) {
        var i = menu_1[_i];

        if (typeof i == 'string') {
          menuTemp.push(i);
        } else {
          for (var _a = 0, i_1 = i; _a < i_1.length; _a++) {
            var k = i_1[_a];
            menuTemp.push(k);
          }
        }
      }

      return menuTemp;
    });
    menuArr = [].concat.apply([], menus);
  } // menuArr.push('user-order')
  // menuArr.push('picking-detail')
  // menuArr.push('product-detail')
  // menuArr.push('presale-detail')
  // menuArr.push('vendor-detail-multi')
  // // menuArr.push('purchase-contract-edit')
  // // menuArr.push('purchase-package-edit')
  // menuArr.push('common-page')
  // menuArr.push('swap-page')
  // menuArr.push('list-page')
  // menuArr.push('sent-email-detail')
  // menuArr.push('depo-detail')


  var detailRouteName = ['user-order', 'picking-detail', 'product-detail', 'presale-detail', 'vendor-detail-multi', 'common-page', 'swap-page', 'list-page', 'sent-email-detail', 'depo-detail'];
  menuArr.push.apply(menuArr, detailRouteName);
  return !!store.state.userModule.username && (toname === 'workspace' || menuArr.includes(toname));
};
/**
 * 安装认证守卫
 */


function installAuthGuard() {
  application_router["a" /* ApplicationRouter */].registerGuard(function (_a, _b) {
    var store = _a.store,
        router = _a.router;
    var to = _b.to,
        from = _b.from,
        next = _b.next; // 认证白名单

    if (authWhiteList.includes(to.name)) {
      return true;
    } // 认证检测


    if (!authCheck(store, to.name)) {
      var detect = new mobile_detect_default.a(navigator.userAgent);
      var isMobile = !!detect.mobile();
      return {
        name: isMobile ? 'login-mobile' : 'login'
      };
    }
  });
}

/* harmony default export */ var guard_boot = (function () {
  // 安装认证守卫
  installAuthGuard();
});
// EXTERNAL MODULE: ./node_modules/mockjs/dist/mock.js
var mock = __webpack_require__("96eb");
var mock_default = /*#__PURE__*/__webpack_require__.n(mock);

// CONCATENATED MODULE: ./src/bootstrap/boots/mock.boot.ts

/* harmony default export */ var mock_boot = (function () {
  mock_default.a.setup({
    timeout: '200-600'
  }); // Object.values(mockServices).forEach(item => {
  //     const services = item['services']
  //     if (services) {
  //         services.forEach(service => {
  //             service()
  //         })
  //     }
  // })
});
// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// CONCATENATED MODULE: ./src/bootstrap/boots/launch.ts
var _this = undefined;


var launch_launch = function launch(_a) {
  var store = _a.store,
      router = _a.router;
  return tslib_es6["b" /* __awaiter */](_this, void 0, void 0, function () {
    return tslib_es6["e" /* __generator */](this, function (_b) {
      return [2
      /*return*/
      ];
    });
  });
};
// CONCATENATED MODULE: ./src/bootstrap/boots/index.ts





var boots_boot = function boot() {
  // 初始化网络配置
  http_boot(); // 初始化守卫

  guard_boot(); // 初始化Mock服务

  if (app_config["a" /* default */].mock) {
    mock_boot();
  }
};

/***/ }),

/***/ "ada2d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _shared_filters__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a4f9");

/* harmony default export */ __webpack_exports__["a"] = (function (_a) {
  var store = _a.store;
  return _shared_filters__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"];
});

/***/ }),

/***/ "f62f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return registerComponent; });
/* harmony import */ var _shared_components_page_container_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4d09");
/* harmony import */ var _shared_components_data_form_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("f878");
/* harmony import */ var _shared_components_data_table_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("8975");
/* harmony import */ var _shared_components_svg_icon_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("e007");
/* harmony import */ var _shared_components_label_container_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__("629f");
/* harmony import */ var _shared_components_label_item_vue__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__("7760");






/**
 * 注册全局自定义组件
 */

var registerComponent = function registerComponent(Vue) {
  Vue.component('page-container', _shared_components_page_container_vue__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"]);
  Vue.component('data-form', _shared_components_data_form_vue__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"]);
  Vue.component('data-table', _shared_components_data_table_vue__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"]);
  Vue.component('svg-icon', _shared_components_svg_icon_vue__WEBPACK_IMPORTED_MODULE_3__[/* default */ "a"]);
  Vue.component('label-container', _shared_components_label_container_vue__WEBPACK_IMPORTED_MODULE_4__[/* default */ "a"]);
  Vue.component('label-item', _shared_components_label_item_vue__WEBPACK_IMPORTED_MODULE_5__[/* default */ "a"]);
};

/***/ })

}]);