(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~272e8d2c"],{

/***/ "0390":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("fd34");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "0e94":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2e18");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1fd0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenish_split_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b20b");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenish_split_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenish_split_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "278b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenish_split_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3d43");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenish_split_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenish_split_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenish_split_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "2e18":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"company_id":"Company","date_approve":"Approve Date","date_expected":"Expected Date","date_req":"Req Date","id":"Id","merchandiser":"Merchandiser","name":"Name","real_state":"Real State","req_type":"Req Type","state":"State","user_approve":"Approve User","user_id":"Created User","user_purchase":"Purchase User","warehouse":"Warehouse","change_date":"Change Date","change_date_memo":"Change Date Memo","product_qty":"Product Qty","make_user":"Make User","dept_id":"Department","together_require_name":"together_require_name","is_together_purchase":"is_together_purchase","plan_sale_month":"plan_sale_month"},"action":{"order_detail":"Order Detail","other_form":"Other Form","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","today":"Today","yestoday":"Yestoday","3day":"3 Day","send_email":"Send Email","refund":"Refund Supplement Wizard","modify_cp":"Modify CP","other_info":"Other Info","save":"Save","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"company_id":"公司","date_approve":"审批日期","date_expected":"期望入库","date_req":"需求日期","id":"Id","merchandiser":"跟单员","name":"需求编号","real_state":"Real State","req_type":"补货类型","state":"状态","user_approve":"审批人","user_id":"创建人","user_purchase":"采购员","warehouse":"仓库","change_date":"变更交期","change_date_memo":"变更交期备注","product_qty":"产品数量","make_user":"需求人","dept_id":"部门","together_require_name":"主部门补货需求编号","is_together_purchase":"合并补货","plan_sale_month":"预计销售月份"},"action":{"order_detail":"订单明细","other_form":"其它信息","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消需求","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","today":"前一天","yestoday":"前两天","3day":"前三天","send_email":"发送邮件","refund":"退款管理","modify_cp":"修改CP","other_info":"其它信息","save":"保存","verify":"审核","reset":"设置为草稿","confirm":"提交需求","refuse":"确认拒绝"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "3d43":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"reference":"Reference","state":"state","user_purchase":"Purchase user","user_id":"Requirement User","purchase_date":"Purchase Date","origin_line_id":"Origin Requirement Line ID","requirement_line_id":"Requirement Line ID","product":"Product","product_id":"Product","finish_qty":"Finish Qty","is_finish":"Is Finish","quantity":"Quantity","warehouse_id":"Warehouse","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Cancel"}},"zh-cn":{"reference":"需求编号","state":"状态","user_purchase":"采购员","user_id":"需求人","purchase_date":"采购日期","origin_line_id":"原需求列ID","requirement_line_id":"需求列ID","product":"产品","product_id":"产品","finish_qty":"已发货数量","is_finish":"已完成发货","quantity":"数量","warehouse_id":"仓库","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"取消"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "5c69":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/replenish-split.vue?vue&type=template&id=307b4095&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-card',{staticClass:"margin-top order-edit-page"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":4}},[_c('h3',[_vm._v(_vm._s(_vm.$t('reference'))+" :")])]),_c('a-col',{attrs:{"span":8}},[_vm._v(" "+_vm._s(_vm.info.name)+" ")]),_c('a-col',{attrs:{"span":4}},[_c('h3',[_vm._v(_vm._s(_vm.$t('user_purchase'))+" :")])]),_c('a-col',{attrs:{"span":8}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.info.user_purchase,_vm.systemUsers))+" ")])],1),_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":4}},[_c('h3',[_vm._v(_vm._s(_vm.$t('user_id'))+":")])]),_c('a-col',{attrs:{"span":8}},[_vm._v(" "+_vm._s(_vm._f("dict2")(_vm.info.user_id,_vm.systemUsers))+" ")]),_c('a-col',{attrs:{"span":4}},[_c('h3',[_vm._v(_vm._s(_vm.$t('state'))+":")])]),_c('a-col',{attrs:{"span":8}},[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(_vm.info.state,'ReplenishmentState')))+" ")])],1),_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":4}},[_c('h3',[_vm._v(_vm._s(_vm.$t('purchase_date'))+":")])]),_c('a-col',{attrs:{"span":8}},[_vm._v(" "+_vm._s(_vm.info.date_req.toString().substr(0, 10))+" ")])],1)],1),_c('div',{staticStyle:{"padding":"20px 20px 0 20px"}},[_c('a-button',{attrs:{"type":"primary","size":"small"},on:{"click":_vm.addBtn}},[_c('a-icon',{attrs:{"type":"plus"}}),_vm._v(_vm._s(_vm.$t('actions.add')))],1)],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.req_line,"pagination":false,"rowKey":"index","customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"bordered":""}},[_c('a-table-column',{key:"id",attrs:{"title":_vm.$t('requirement_line_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.id))])]}}])}),_c('a-table-column',{key:"origin_line_id",attrs:{"title":_vm.$t('origin_line_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable && !row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['origin_line_id']),expression:"['origin_line_id']"}],style:({ width: '100%', background: '#ecc5e9' }),attrs:{"value":row.origin_line_id,"size":"small","min":0},on:{"change":function (e) { return _vm.onRowChange(row, 'origin_line_id', e); }}}):_c('span',[_vm._v(_vm._s(row.origin_line_id))])]}}])}),_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('product_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable && !row.id)?_c('a-auto-complete',{staticStyle:{"width":"100%"},attrs:{"dataSource":_vm.skuSource,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"defaultValue":row.default_code,"size":"small","placeholder":"input for search"},on:{"search":_vm.onSkuSearch,"change":function (e) { return _vm.onRowChange(row, 'default_code', e); }}},[_c('template',{slot:"dataSource"},[_vm._l((_vm.skuSource),function(opt){return _c('a-select-option',{key:opt,attrs:{"value":opt,"title":opt}},[_vm._v(" "+_vm._s(opt)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(row)}}},[_vm._v(" Search More ")])])],2)],2):_c('span',[_vm._v(_vm._s(row.default_code))])]}}])}),_c('a-table-column',{key:"product_qty",attrs:{"title":_vm.$t('quantity'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable && !row.id)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_qty']),expression:"['product_qty']"}],style:({ width: '100%', background: '#ecc5e9' }),attrs:{"decimalSeparator":",","value":row.product_qty,"min":0,"size":"small","align":"right"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_qty', e); }}}):_c('span',[_vm._v(_vm._s(row.product_qty))])]}}])}),_c('a-table-column',{key:"warehouse_id",attrs:{"title":_vm.$t('warehouse_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id']),expression:"['warehouse_id']"}],style:({ width: '100%' }),attrs:{"value":row.warehouse_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '120px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'warehouse_id', e); }}},_vm._l((_vm.$dict.WarehouseId),function(i){return _c('a-select-option',{key:i.value,attrs:{"value":i.value,"title":_vm.$t(i.label)}},[_vm._v(" "+_vm._s(_vm.$t(i.label))+" ")])}),1)]}}])}),_c('a-table-column',{key:"finish_qty",attrs:{"title":_vm.$t('finish_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.finish_qty))])]}}])}),_c('a-table-column',{key:"finish_yn",attrs:{"title":_vm.$t('is_finish'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_c('a-checkbox',{attrs:{"disabled":"","checked":row.finish_yn}})],1)]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(!row.id)?_c('a',{on:{"click":function($event){return _vm.onDel(row)}}},[_vm._v(" "+_vm._s(_vm.$t('actions.delete'))+" ")]):_vm._e(),(!row.id)?_c('a',{on:{"click":function (e) { return _vm.cancelBtn(e); }}},[_vm._v(" "+_vm._s(_vm.$t('actions.cancel'))+" ")]):_vm._e()]}}])})],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/replenish-split.vue?vue&type=template&id=307b4095&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/replenish-split.vue?vue&type=script&lang=ts&



















var replenish_splitvue_type_script_lang_ts_ReplenishSplit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ReplenishSplit, _super);

  function ReplenishSplit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.req_line = [];
    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.operateCnt = 0;
    _this.moment = moment_default.a;
    return _this;
  }

  ReplenishSplit.prototype.submit = function () {
    return true;
  };

  ReplenishSplit.prototype.cancel = function () {
    return;
  };

  ReplenishSplit.prototype.mounted = function () {
    if (this.info && this.info.req_line) {
      this.req_line = this.info.req_line.map(function (x) {
        if (!x.index) {
          x['index'] = uuid_default.a.generate();
          x['origin_line_id'] = 0;
        }

        return x;
      });
    }
  };

  ReplenishSplit.prototype.onInfoChange = function () {
    if (this.info && this.info.req_line) {
      this.req_line = this.info.req_line.map(function (x) {
        if (!x.index) {
          x['index'] = uuid_default.a.generate();
          x['origin_line_id'] = 0;
        }

        return x;
      });
    }
  };

  ReplenishSplit.prototype.addBtn = function () {
    var index = uuid_default.a.generate();
    this.req_line.push({
      index: index,
      id: 0,
      origin_line_id: 0,
      default_code: '',
      finish_qty: 0,
      finish_yn: false,
      product_qty: 0,
      warehouse_id: 'de'
    });
    this.currentRow = index;
  };

  ReplenishSplit.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      row[column] = value.target.value;
    } else {
      row[column] = value;
    }

    if (column === 'default_code') {
      var productItem = this.skuQueryResult.find(function (x) {
        return x.default_code == value;
      });

      if (productItem) {
        row.default_code = productItem.default_code;
        row.product_id = productItem.product_id;
      }
    }
  };

  ReplenishSplit.prototype.cancelBtn = function (e) {
    e.stopPropagation();
    this.currentRow = -1;
  };

  ReplenishSplit.prototype.onDel = function (row) {
    this.currentRow = -1;
    var item = this.req_line.find(function (x) {
      return x.index === row.index;
    });
    item['save_flag'] = 2;
    this.req_line = this.req_line.filter(function (x) {
      return !x.save_flag || x.save_flag < 2;
    });
  };

  ReplenishSplit.prototype.onSkuSearch = function (key) {
    var _this = this;

    var params = common_service["a" /* CommonService */].createQueryCondition({
      default_code: key
    }, tslib_es6["a" /* __assign */]({
      default_code: 'like'
    }, form_config["a" /* formConfig */].condition));
    params['page_index'] = 1;
    params['page_size'] = 10;
    this.productService.queryAsyncProductInfo(new http["RequestParams"](params, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.skuSource = data.map(function (x) {
        return x.default_code;
      });
      _this.skuQueryResult = data;
    });
  };

  ReplenishSplit.prototype.searchMore = function (row) {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {}, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      var item = _this.req_line.find(function (x) {
        return x.index === row.index;
      });

      item['product_id'] = data.product_id;
      item['default_code'] = data.default_code;
      _this.currentRow = -1;
      setTimeout(function () {
        _that.currentRow = row.index;
      }, 100);
    });
  };

  ReplenishSplit.prototype.onSubmit = function () {
    var _this = this;

    var lines = [];

    if (this.req_line.length == 0) {
      this.$message.error('至少添加一条明细信息');
      return false;
    }

    var _loop_1 = function _loop_1(i) {
      if (this_1.req_line[i].id == 0) {
        if (!this_1.req_line[i].default_code || !this_1.req_line[i].product_qty || !this_1.req_line[i].origin_line_id) {
          this_1.$message.error('请先完善明细中的信息,深色背景为必填项');
          this_1.currentRow = this_1.data[i].id;
          return {
            value: false
          };
        }

        var findItem = this_1.req_line.find(function (x) {
          return x.id == _this.req_line[i].origin_line_id;
        });

        if (!findItem) {
          this_1.$message.error('原需求列ID不在所选的范围');
          return {
            value: false
          };
        }
      }

      lines[i] = Object.assign({}, this_1.req_line[i]);

      if (lines[i].index) {
        delete lines[i].index;
        delete lines[i].alerts;
      }
    };

    var this_1 = this;

    for (var i in this.req_line) {
      var state_1 = _loop_1(i);

      if (Object(esm_typeof["a" /* default */])(state_1) === "object") return state_1.value;
    } //save


    this.innerAction.setActionAPI('purchase_management/split_purchase_prod_quantity_warehouse', common_service["a" /* CommonService */].getMenuCode('replenishment-demand'));
    this.publicService.modify(new http["RequestParams"]({
      req_id: this.info.id,
      req_lines: lines
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ReplenishSplit.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ReplenishSplit.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishSplit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishSplit.prototype, "taxesList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishSplit.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ReplenishSplit.prototype, "onInfoChange", null);

  ReplenishSplit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ReplenishSplit);
  return ReplenishSplit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var replenish_splitvue_type_script_lang_ts_ = (replenish_splitvue_type_script_lang_ts_ReplenishSplit);
// CONCATENATED MODULE: ./src/components/purchase/replenish-split.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_replenish_splitvue_type_script_lang_ts_ = (replenish_splitvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/replenish-split.vue?vue&type=style&index=0&lang=css&
var replenish_splitvue_type_style_index_0_lang_css_ = __webpack_require__("1fd0");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/replenish-split.vue?vue&type=custom&index=0&blockType=i18n
var replenish_splitvue_type_custom_index_0_blockType_i18n = __webpack_require__("278b");

// CONCATENATED MODULE: ./src/components/purchase/replenish-split.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_replenish_splitvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof replenish_splitvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(replenish_splitvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var replenish_split = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "b1fb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/replenishment-edit.vue?vue&type=template&id=ec773248&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('div',{staticStyle:{"padding":"0 20px 10px 0px","min-height":"40px","display":"inline-block"}},[(_vm.order.id)?_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.editChange}},[(!_vm.editAble)?_c('span',[_vm._v(_vm._s(_vm.$t('action.edit')))]):_c('span',[_vm._v(_vm._s(_vm.$t('action.discard')))])]):_vm._e(),(_vm.editAble || !_vm.order.id)?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]):_vm._e(),(_vm.order.state == 'to approve')?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(_vm.order.state == 'cancel')?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(_vm.order.id && _vm.order.state == 'draft')?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('to approve')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(
                    _vm.order.id &&
                        (_vm.order.state == 'to approve' ||
                            _vm.order.state == 'draft')
                )?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('cancel')}}},[_vm._v(" "+_vm._s(_vm.$t('action.cancel'))+" ")]):_vm._e(),(_vm.order.state == 'refuse')?_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onVerify('refuse')}}},[_vm._v(" "+_vm._s(_vm.$t('action.refuse'))+" ")]):_vm._e(),_c('div',{staticStyle:{"position":"absolute","top":"10px","right":"10px"}},[_c('div',{staticClass:"progress-bar"},_vm._l((_vm.$dict.ReplenishmentState),function(item){return _c('li',{key:item.value,class:{ active: _vm.order.state == item.value },staticStyle:{"font-size":"12px"},attrs:{"value":item.value}},[_c('span',[_vm._v(_vm._s(_vm.$t(item.label)))])])}),0)])],1),_c('section',{staticClass:"component edit-customer"},[_c('a-form',{attrs:{"form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-card',{staticClass:"margin-top order-edit-page"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.make_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'user_id',
                                        { initialValue: _vm.defaultMakeUser }
                                    ]),expression:"[\n                                        'user_id',\n                                        { initialValue: defaultMakeUser }\n                                    ]"}],style:({
                                        width: '100%',
                                        'max-width': '300px'
                                    }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption,"disabled":!_vm.editAble ||
                                            !(
                                                (_vm.order.state != undefined &&
                                                    _vm.order.state ==
                                                        'draft') ||
                                                (_vm.order.state ==
                                                    'to approve' &&
                                                    _vm.order.req_type ==
                                                        'abnormal_purchase')
                                            )}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.user_approve')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_approve']),expression:"['user_approve']"}],style:({
                                        width: '100%',
                                        'max-width': '300px'
                                    }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption,"disabled":""}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.date_req'),"required":""}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "date_req",
                                        {
                                            initialValue: _vm.moment(Date.now())
                                        },
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `date_req`,\n                                        {\n                                            initialValue: moment(Date.now())\n                                        },\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.date_approve')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["date_approve"]),expression:"[`date_approve`]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD HH:mm:ss","size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.warehouse'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        "warehouse_id",
                                        {
                                            initialValue:
                                                _vm.$dict.WarehouseId[0].value
                                        },
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        `warehouse_id`,\n                                        {\n                                            initialValue:\n                                                $dict.WarehouseId[0].value\n                                        },\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],staticStyle:{"width":"300px"},attrs:{"show-search":"","size":"small","disabled":!_vm.editAble ||
                                            (_vm.order.state != undefined &&
                                                _vm.order.state != 'draft')}},_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.company_id'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'company_id',
                                        {
                                            initialValue:
                                                _vm.companyList[0].code
                                        },
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        'company_id',\n                                        {\n                                            initialValue:\n                                                companyList[0].code\n                                        },\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],style:({
                                        width: '100%',
                                        'max-width': '300px'
                                    }),attrs:{"showSearch":"","size":"small","filterOption":_vm.filterSelectOption,"placeholder":"Please Select","disabled":!_vm.editAble ||
                                            (_vm.order.state != undefined &&
                                                _vm.order.state != 'draft')}},_vm._l((_vm.companyList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.change_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(["change_give_date"]),expression:"[`change_give_date`]"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small","disabled":!_vm.editAble},on:{"change":function (e) { return _vm.onGiveDateChange(e); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.req_type'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                        'req_type',
                                        {
                                            initialValue:
                                                _vm.$dict.ReplenishmentType[0]
                                                    .value
                                        },
                                        {
                                            rules: _vm.rules.required
                                        }
                                    ]),expression:"[\n                                        'req_type',\n                                        {\n                                            initialValue:\n                                                $dict.ReplenishmentType[0]\n                                                    .value\n                                        },\n                                        {\n                                            rules: rules.required\n                                        }\n                                    ]"}],attrs:{"showSearch":"","size":"small","placeholder":"Please Select","checked":_vm.order.req_type,"v-model":_vm.order.req_type,"disabled":!_vm.editAble ||
                                            (_vm.order.state != undefined &&
                                                _vm.order.state != 'draft')},on:{"change":function (e) { return _vm.onReqypeChange(e); }}},_vm._l((_vm.$dict.ReplenishmentType),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.change_date_memo')}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["change_give_date_memo"]),expression:"[`change_give_date_memo`]"}],attrs:{"size":"small","disabled":!_vm.editAble},on:{"change":function (e) { return _vm.onGiveDateMemoChange(e); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.dept_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dept_id']),expression:"['dept_id']"}],attrs:{"showSearch":"","size":"small","placeholder":"Please Select","disabled":""}},_vm._l((_vm.subDepartList),function(item){return _c('a-select-option',{key:item.id,attrs:{"value":item.id}},[_vm._v(" "+_vm._s(item.dept_name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.is_together_purchase')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(['is_together_purchase']),expression:"['is_together_purchase']"}],attrs:{"size":"small","checked":_vm.order.is_together_purchase,"v-model":_vm.order.is_together_purchase,"disabled":!_vm.editAble ||
                                            (_vm.order.state != undefined &&
                                                _vm.order.state != 'draft')},on:{"change":function (e) { return _vm.onTogetherPurchaseChange(
                                                e.target.checked
                                            ); }}})],1)],1),_c('a-col',{attrs:{"span":12}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.together_require_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['together_require_name']),expression:"['together_require_name']"}],attrs:{"size":"small","disabled":!_vm.editAble ||
                                            !_vm.order.is_together_purchase ||
                                            (_vm.order.state != undefined &&
                                                _vm.order.state != 'draft')}})],1)],1),_c('a-col',{attrs:{"span":7}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.plan_sale_month'),"labelCol":{ span: 12 },"wrapperCol":{ span: 10, offset: 2 }}},[_c('a-month-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_range_from']),expression:"['sale_range_from']"}],attrs:{"size":"small","disabled":!_vm.editAble ||
                                            (_vm.order.state != undefined &&
                                                _vm.order.state != 'draft')},on:{"change":function (e) { return _vm.onSaleMonthFromChange(e); }}})],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"--","labelCol":{ span: 2 },"wrapperCol":{ span: 20, offset: 1 }}},[_c('a-month-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_range_to']),expression:"['sale_range_to']"}],attrs:{"size":"small","disabled":!_vm.editAble ||
                                            (_vm.order.state != undefined &&
                                                _vm.order.state != 'draft')},on:{"change":function (e) { return _vm.onSaleMonthToChange(e); }}})],1)],1)],1)],1),_c('div',{staticClass:"margin-top"},[_c('AddReplenishDetail',{attrs:{"info":_vm.orderDetail,"state":(_vm.order.state && _vm.order.state == 'draft') ||
                            !_vm.order.id
                                ? 1
                                : 0,"editAble":_vm.editAble && _vm.order.state == 'draft',"systemUsers":_vm.systemUsers},on:{"change":function($event){return _vm.onDetailListChange($event)}}})],1)],1)],1)])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/purchase/replenishment-edit.vue?vue&type=template&id=ec773248&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-detail.vue + 4 modules
var add_replenish_detail = __webpack_require__("f5bb");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/purchase/replenishment-edit.vue?vue&type=script&lang=ts&

















var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');
var userModule = Object(lib["c" /* namespace */])('userModule');

var replenishment_editvue_type_script_lang_ts_ReplenishmentEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ReplenishmentEdit, _super);

  function ReplenishmentEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.order = {
      id: 0,
      state: 'draft'
    };
    _this.orderDetail = [];
    _this.save_flag = 0;
    _this.originData = [];
    _this.isShowDetail = false; //是否只是详情展示

    _this.menu_code = '';
    _this.editAble = false;
    _this.defaultMakeUser = '';
    _this.subDepartList = [];
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  Object.defineProperty(ReplenishmentEdit.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });

  ReplenishmentEdit.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;

      if (this.info) {
        this.updateOrder(this.info);
      }
    }
  };

  ReplenishmentEdit.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.save_flag = 1;
      _this.editAble = false;

      if (_this.order.req_line != undefined && _this.order.req_line.length) {
        _this.orderDetail = _this.order.req_line.map(function (x) {
          return x;
        });
      }

      _this.order.dept_id = _this.orderDetail[0].dept_id;
      _this.order.is_together_purchase = _this.order.is_together_purchase ? true : false; // this.order.together_require_name = 'Hs00er-2,BF0029'

      _this.form.setFieldsValue(_this.order);
    });
  };

  ReplenishmentEdit.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.form = this.$form.createForm(this);
    this.getDepartmentList();
    this.getSubDepartmentList();
  };

  ReplenishmentEdit.prototype.mounted = function () {
    if (this.save_flag == 0) {
      this.editAble = true;
      this.defaultMakeUser = this.id;
    }

    if (this.info.length) {
      this.updateOrder(this.info);
      this.defaultMakeUser = this.info[0].user_id;
    }

    if (!this.menu_code) {
      this.menu_code = common_service["a" /* CommonService */].getMenuCode('replenishment-demand');
    }
  };

  ReplenishmentEdit.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ReplenishmentEdit.prototype.onDetailListChange = function (data) {
    this.orderDetail = data; //更新缓存

    var pageId = 'replenishmentedit' + this.order.id;
    var item = this.commonPageInfo.find(function (x) {
      return x.index == pageId;
    });

    if (item) {
      item.info[0].req_line = this.orderDetail;
    }
  };

  ReplenishmentEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      values['save_flag'] = _this.save_flag;

      if (_this.save_flag) {
        values['id'] = _this.order.id;
      }

      if (values['is_together_purchase'] && !values['together_require_name']) {
        _this.$message.error('together_require_name(主部门补货需求编号) is required');

        return;
      }

      var details = _this.orderDetail.filter(function (x) {
        return x.id != 'summary';
      });

      if (!details.length) {
        _this.$message.error('明细列表不能为空');

        return false;
      }

      for (var _i = 0, details_1 = details; _i < details_1.length; _i++) {
        var i = details_1[_i];

        if (!i.default_code || !i.product_qty || !i.sales_expected_give_date || !i.date_expected || !i.warehouse_id || !i.sale_range_from || !i.sale_range_to) {
          _this.$message.error('请先完善明细信息，深色背景为必填项');

          return false;
        }
      }

      values['sale_range_from'] = values['sale_range_from'] ? values['sale_range_from'].format('YYYY-MM') : '';
      values['sale_range_to'] = values['sale_range_to'] ? values['sale_range_to'].format('YYYY-MM') : '';
      var req_lines = JSON.parse(JSON.stringify(details));

      for (var i_1 in req_lines) {
        delete req_lines[i_1].index;

        if (req_lines[i_1].date_expected) {
          req_lines[i_1].date_expected = req_lines[i_1].date_expected.substring(0, 10);
        }

        if (req_lines[i_1].buyer_change_give_date) {
          req_lines[i_1].buyer_change_give_date = req_lines[i_1].buyer_change_give_date.substring(0, 10);
        }

        if (req_lines[i_1].give_date) {
          req_lines[i_1].give_date = req_lines[i_1].give_date.substring(0, 10);
        }

        if (req_lines[i_1].sales_expected_give_date) {
          req_lines[i_1].sales_expected_give_date = req_lines[i_1].sales_expected_give_date.substring(0, 10);
        }

        if (!req_lines[i_1].sale_range_from) {
          _this.$message.info('请输入销售起始日期!');

          return;
        }

        if (!req_lines[i_1].sale_range_to) {
          _this.$message.info('请输入销售结束日期!');

          return;
        } // req_lines[i].sale_range_from = values['sale_range_from']
        // req_lines[i].sale_range_to = values['sale_range_to']

      }

      values['req_lines'] = req_lines;

      _this.innerAction.setActionAPI('purchase_management/save_purchase_requirement', _this.menu_code);

      _this.publicService.modify(new http["RequestParams"](values, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        var msg = _this.$t('tips.save_success');

        if (data.message.special_check) {
          msg += ': ' + data.message.special_check;
        }

        _this.$message.success(msg);

        if (_this.save_flag === 0) {
          _this.save_flag = 1;
        }

        _this.order.id = data.message.id;
        _this.editAble = false;

        _this.orderDetail.map(function (x) {
          x['save_flag'] = 1;
        });

        _this.onRefreshData(_this.order.id); // this.form.resetFields()

      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ReplenishmentEdit.prototype.editChange = function () {
    this.editAble = !this.editAble;
    var pageId = 'replenishmentedit' + this.order.id;
    var item = this.commonPageInfo.find(function (x) {
      return x.index == pageId;
    });

    if (item) {
      if (this.editAble) {
        item.edit = 1;
      } else {
        item.edit = 0;
      }
    }
  };

  ReplenishmentEdit.prototype.onChangeGiveDate = function () {
    var _this = this;

    var values = this.form.getFieldsValue();

    if (!values['change_give_date']) {
      this.$message.error('请输入变更交期');
      return;
    }

    if (!values['change_give_date_memo']) {
      this.$message.error('请输入变更交期备注');
      return;
    }

    this.innerAction.setActionAPI('purchase_management/update_requirement_change_give_date', this.menu_code);
    this.publicService.modify(new http["RequestParams"]({
      req_id_list: [this.order.id],
      change_give_date: values.change_give_date,
      change_give_date_memo: values.change_give_date_memo
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      if (_this.save_flag === 0) {
        _this.save_flag = 1;
      }

      _this.order.id = data.message.id; // this.form.resetFields()
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentEdit.prototype.onGiveDateChange = function (e) {
    for (var i in this.orderDetail) {
      this.orderDetail[i].sales_change_give_date = e.format('YYYY-MM-DD');
    }
  };

  ReplenishmentEdit.prototype.onGiveDateMemoChange = function (e) {
    for (var i in this.orderDetail) {
      this.orderDetail[i].sales_change_give_date_memo = e.target.value;
    }
  };

  ReplenishmentEdit.prototype.onVerify = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/update_purchase_requirement_state', common_service["a" /* CommonService */].getMenuCode('replenishment-demand'));
    this.publicService.modify(new http["RequestParams"]({
      req_id_list: [this.order.id],
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.order.state = state;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentEdit.prototype.onRefreshData = function (id) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/query_purchase_requirement_info', common_service["a" /* CommonService */].getMenuCode('replenishment-demand'));
    this.publicService.query(new http["RequestParams"]({
      req_id: id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      if (data[0].req_line != undefined && data[0].req_line.length) {
        _this.orderDetail = data[0].req_line.map(function (x) {
          return x;
        });
      }
    }, function (err) {// this.$message.error(err.message)
    });
  };

  ReplenishmentEdit.prototype.getSubDepartmentList = function () {
    // this.subDepartList = this.departmentList.filter(x => x.dept_type == 100)
    //TODO
    this.subDepartList = this.departmentList;
  };

  ReplenishmentEdit.prototype.onTogetherPurchaseChange = function (e) {
    this.order.is_together_purchase = e;

    if (e === false) {
      var values = this.form.getFieldsValue();
      values['together_require_name'] = '';
      this.form.setFieldsValue(values);
    }
  };

  ReplenishmentEdit.prototype.onSaleMonthFromChange = function (e) {
    for (var _i = 0, _a = this.orderDetail; _i < _a.length; _i++) {
      var i = _a[_i];
      i['sale_range_from'] = e.format('YYYY-MM');
    }
  };

  ReplenishmentEdit.prototype.onReqypeChange = function (e) {
    this.order.req_type = e;
  };

  ReplenishmentEdit.prototype.onSaleMonthToChange = function (e) {
    for (var _i = 0, _a = this.orderDetail; _i < _a.length; _i++) {
      var i = _a[_i];
      i['sale_range_to'] = e.format('YYYY-MM');
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "replenishEditParams", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "commonPageInfo", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "getDepartmentList", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentEdit.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ReplenishmentEdit.prototype, "onInfoChange", null);

  ReplenishmentEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddReplenishDetail: add_replenish_detail["a" /* default */]
    }
  })], ReplenishmentEdit);
  return ReplenishmentEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var replenishment_editvue_type_script_lang_ts_ = (replenishment_editvue_type_script_lang_ts_ReplenishmentEdit);
// CONCATENATED MODULE: ./src/components/purchase/replenishment-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_replenishment_editvue_type_script_lang_ts_ = (replenishment_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/purchase/replenishment-edit.vue?vue&type=style&index=0&lang=css&
var replenishment_editvue_type_style_index_0_lang_css_ = __webpack_require__("0390");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/purchase/replenishment-edit.vue?vue&type=custom&index=0&blockType=i18n
var replenishment_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("0e94");

// CONCATENATED MODULE: ./src/components/purchase/replenishment-edit.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_replenishment_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof replenishment_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(replenishment_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var replenishment_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "b20b":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "fd34":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ })

}]);