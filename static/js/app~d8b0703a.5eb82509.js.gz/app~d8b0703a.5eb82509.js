(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~d8b0703a"],{

/***/ "007e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_demand_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9399");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_demand_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_demand_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_demand_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "0175":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Purchase Cost","columns":{"vendor_name":"Vendor","cn_category":"CN Category","cn_sub_category":"CN Sub Category","sku":"SKU","price":"Amount","qty":"QTY","season_1":"Quarter 1","season_2":"Quarter 2","season_3":"Quarter 3","season_4":"Quarter 4","month_1":"Jan","month_2":"Feb","month_3":"Mar","month_4":"Apl","month_5":"May","month_6":"Jun","month_7":"Jul","month_8":"Aug","month_9":"Sep","month_10":"Oct","month_11":"Nov","month_12":"Dec","query_type":"Calcuate Type","year":"Time"},"action":{"create":"新建","more":"更多操作"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"采购金额","columns":{"vendor_name":"供应商","cn_category":"中文分类","cn_sub_category":"中文子类","sku":"SKU","price":"金额","qty":"数量","season_1":"1季度","season_2":"2季度","season_3":"3季度","season_4":"4季度","month_1":"1月","month_2":"2月","month_3":"3月","month_4":"4月","month_5":"5月","month_6":"6月","month_7":"7月","month_8":"8月","month_9":"9月","month_10":"10月","month_11":"11月","month_12":"12月","query_type":"统计维度","year":"时间"},"action":{"create":"新建","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "041e":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"approved_user":"Approved user","change_give_date":"Change give date","give_date":"Give date","make_user":"Make user","merchandiser":"Merchandiser","name":"Ship Order No.","order_company_id":"Order company id","order_date":"Order date","purchase_requirement":"Purchase requirement","source_doc":"Source doc","state":"State","user_purchase":"User purchase","vendor_id":"Vendor id"},"action":{"action":"Action","create":"Create","download":"Download","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","sync_product_info":"Synchronize Product","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse","update_product_qty_code":"Update Product Qty&Code","download_manual":"Download Manual","download_specification":"Download Specification","download_batch_number":"Download Batch Number","download_purchase_contract":"Download Purchase Contract","verify_mome":"Memo","change_give_date":"Change Give Date","make_package_order":"Make Package Order","showlog":"View Log"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","page_name":"Purchase Ship Order Edit"},"zh-cn":{"desc":"这是订单页面1","columns":{"approved_user":"审核人","change_give_date":"更改交期","give_date":"合同交期","make_user":"制单员","merchandiser":"跟单员","name":"发货单号","order_company_id":"公司","order_date":"订单日期","purchase_requirement":"采购需求","source_doc":"实际发货合同号","state":"状态","user_purchase":"采购员","vendor_id":"供应商"},"action":{"action":"操作","create":"新建","download":"下载","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","sync_product_info":"同步产品信息","verify":"审核","reset":"重置","confirm":"确认","refuse":"确认拒绝","update_product_qty_code":"变更产品货号及数量","download_manual":"下载说明书","download_specification":"下载工艺单","download_batch_number":"下载批次号","download_purchase_contract":"下载采购合同","verify_mome":"备注","change_give_date":"修改采购交期","make_package_order":"创建货柜","showlog":"查看日志"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","page_name":"发货合同编辑"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "0848":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{},"zh-cn":{}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "097c":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "09a7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("daf3");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "0b2b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/logistics-providers-manage.vue?vue&type=template&id=07f3ab98&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":1,"labelCol":{ span: 3 },"wrapperCol":{ span: 16, offset: 0 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],staticStyle:{"width":"200px"},attrs:{"label":_vm.$t('columns.name'),"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['code']),expression:"['code']"}],staticStyle:{"width":"200px"},attrs:{"label":_vm.$t('columns.code'),"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.LogisticsProviderState),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.onCreate}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"index","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.onDetail(row)}}},[_vm._v(_vm._s(row.name ? row.name : ''))])]}},{key:"checkbox_ranger",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"prescription",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.prescription,'LogisticsProviderAging')))+" ")]}},{key:"currency_id",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.currency_id,_vm.currencyList))+" ")]}}],null,false,396565604)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.onDetail(row)}}},[_vm._v(_vm._s(row.name ? row.name : ''))])]}},{key:"checkbox_ranger",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"prescription",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.prescription,'LogisticsProviderAging')))+" ")]}},{key:"currency_id",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.currency_id,_vm.currencyList))+" ")]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/logistics-providers-manage.vue?vue&type=template&id=07f3ab98&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-contract.vue + 4 modules
var add_replenish_contract = __webpack_require__("fba3");

// EXTERNAL MODULE: ./src/components/purchase/purchase-return.vue + 4 modules
var purchase_return = __webpack_require__("fe3b");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// EXTERNAL MODULE: ./src/services/currency.service.ts
var currency_service = __webpack_require__("6a96");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/logistics-providers-manage.vue?vue&type=script&lang=ts&



























var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var logistics_providers_managevue_type_script_lang_ts_LogisticsProvidersManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](LogisticsProvidersManage, _super);

  function LogisticsProvidersManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.currencyService = new currency_service["a" /* CurrencyService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = [];
    _this.groupbyList = [];
    _this.allNameAuth = [];
    _this.currencyList = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.stateList = [{
      code: 'active',
      name: 'Active'
    }, {
      code: 'inactive',
      name: 'Inactive'
    }];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.editRow = {
      index: null
    };
    _this.queryUrl = '/logistics_providers/query_all';
    _this.needSaveNotes = [];
    return _this;
  }

  Object.defineProperty(LogisticsProvidersManage.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  LogisticsProvidersManage.prototype.created = function () {
    this.getSystemuser();
    this.getcurrency();
  };

  LogisticsProvidersManage.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  LogisticsProvidersManage.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };

  LogisticsProvidersManage.prototype.getcurrency = function () {
    var _this = this;

    this.currencyService.getCurrency(new http["RequestParams"]({})).subscribe(function (data) {
      _this.currencyList = data;
    }, function (err) {});
  };
  /**
   * 获取订单数据
   */


  LogisticsProvidersManage.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        name: 'in_or_like',
        code: 'like'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data.map(function (x) {
            x['index'] = uuid_default.a.generate();
            return x;
          });
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  LogisticsProvidersManage.prototype.onCreate = function () {
    this.$router.push({
      name: 'logistics-providers-detail'
    });
  };

  LogisticsProvidersManage.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  LogisticsProvidersManage.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  LogisticsProvidersManage.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  LogisticsProvidersManage.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  LogisticsProvidersManage.prototype.calcStyle = function (row) {
    this.$nextTick(function () {
      if (row.date_approve && !row.new_product) {
        var no_order_7day = row.no_order_7day;
        var no_order_3day = row.no_order_3day;
        var sp = document.getElementById('id' + row.id);
        var tr = sp.parentNode.parentNode;

        if (no_order_7day) {
          tr.style.color = 'red';
        } else if (no_order_3day) {
          tr.style.color = '#f90';
        }
      }
    });
  };

  LogisticsProvidersManage.prototype.onRowClick = function (row) {
    this.editRow = {
      index: row
    };
  };

  LogisticsProvidersManage.prototype.handleChange = function (e, row, column) {
    row[column] = e;
    var item = this.needSaveNotes.find(function (x) {
      return x.index == row.index;
    });

    if (item) {
      item[column] = e;
    } else {
      var note = {
        index: row.index,
        id: row.id,
        save_flag: 1
      };
      note[column] = e;
      this.needSaveNotes.push(note);
    }
  };

  LogisticsProvidersManage.prototype.changeNote = function (row) {
    var _this = this;

    var create_list = [];
    var edit_list = [];
    var delete_list = [];
    var params = JSON.parse(JSON.stringify(this.needSaveNotes));

    for (var _i = 0, params_1 = params; _i < params_1.length; _i++) {
      var i = params_1[_i];
      delete i.index;

      if (i.id > 0) {
        if (i.save_flag == 2) {
          delete_list.push(i.id);
        } else {
          edit_list.push(i);
        }
      } else {
        delete i.id;
        create_list.push(i);
      }
    }

    this.innerAction.setActionAPI('/overseas_warehouse_list/modify_record', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      create_list: create_list,
      edit_list: edit_list,
      delete_list: delete_list
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  LogisticsProvidersManage.prototype.onImport = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/overseas_warehouse_list/import_excel_batch_modify'
    }, {
      title: this.$t('action.import')
    }).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  LogisticsProvidersManage.prototype.onDetail = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('/logistics_providers/query_detail', common_service["a" /* CommonService */].getMenuCode('logistics-providers-detail'));
    this.publicService.query(new http["RequestParams"]({
      logistics_providers_id: row.logistics_providers_id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      // data[0]['state'] = row.state
      row['channel_list'] = data;
      var pm = [row];
      var index = 'LogisticsProvidersEdit' + row.logistics_providers_id;
      var params = {
        index: index,
        id: row.id,
        info: pm,
        component: 'LogisticsProvidersEdit'
      };

      _this.addCommonPageInfo(params);

      var baseName = _this.$t('page_name');

      _this.$router.push({
        name: 'common-page',
        path: "/common-page/" + index,
        params: {
          id: index,
          name: row.name + '-' + baseName
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], LogisticsProvidersManage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], LogisticsProvidersManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersManage.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersManage.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], LogisticsProvidersManage.prototype, "addCommonPageInfo", void 0);

  LogisticsProvidersManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'logistics-providers-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddReplenishContract: add_replenish_contract["a" /* default */],
      PurchaseReturn: purchase_return["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], LogisticsProvidersManage);
  return LogisticsProvidersManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var logistics_providers_managevue_type_script_lang_ts_ = (logistics_providers_managevue_type_script_lang_ts_LogisticsProvidersManage);
// CONCATENATED MODULE: ./src/pages/purchase/logistics-providers-manage.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_logistics_providers_managevue_type_script_lang_ts_ = (logistics_providers_managevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/logistics-providers-manage.vue?vue&type=custom&index=0&blockType=i18n
var logistics_providers_managevue_type_custom_index_0_blockType_i18n = __webpack_require__("a904");

// CONCATENATED MODULE: ./src/pages/purchase/logistics-providers-manage.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_logistics_providers_managevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof logistics_providers_managevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(logistics_providers_managevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var logistics_providers_manage = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "0d77":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-product-quality-rate.vue?vue&type=template&id=722db860&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('splitpanes',{staticClass:"default-theme",style:({ height: _vm.splitPanelHeight + 'px' }),attrs:{"horizontal":""},on:{"resize":function($event){return _vm.page_resize($event)},"resized":function($event){return _vm.page_resized($event)}}},[_c('pane',{attrs:{"max-size":"33"},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",style:({
                    'background-color': 'yellow',
                    height: _vm.panel1Height
                }),attrs:{"column":2},on:{"submit":_vm.getPurchaseProductQualityRateData},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'vendor_name',
                                { initialValue: '' }
                            ]),expression:"[\n                                'vendor_name',\n                                { initialValue: '' }\n                            ]"}],style:({
                                width: '100%',
                                'max-width': '300px'
                            }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'z_category',
                                { initialValue: '' }
                            ]),expression:"[\n                                'z_category',\n                                { initialValue: '' }\n                            ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'z_sub_category',
                                { initialValue: '' }
                            ]),expression:"[\n                                'z_sub_category',\n                                { initialValue: '' }\n                            ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.query_type')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'query_type',
                                { initialValue: 'month' }
                            ]),expression:"[\n                                'query_type',\n                                { initialValue: 'month' }\n                            ]"}],staticStyle:{"width":"110px"},attrs:{"size":"small"},on:{"change":function (e) { return _vm.onChangeQueryType(e); }}},[_c('a-select-option',{key:"year",attrs:{"value":"year","title":"By Year/按年"}},[_vm._v(" By Year/按年 ")]),_c('a-select-option',{key:"season",attrs:{"value":"season","title":"By Quarter/按季度"}},[_vm._v(" By Quarter/按季度 ")]),_c('a-select-option',{key:"month",attrs:{"value":"month","title":"By Month/按月"}},[_vm._v(" By Month/按月 ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.year')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['year', { initialValue: '2021' }]),expression:"['year', { initialValue: '2021' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1),(_vm.showToYear)?_c('span',{staticStyle:{"color":"red"}},[_vm._v(" ~ ")]):_vm._e(),(_vm.showToYear)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'to_year',
                                { initialValue: '2021' }
                            ]),expression:"[\n                                'to_year',\n                                { initialValue: '2021' }\n                            ]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1):_vm._e()],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.exportData}},[_vm._v("Export")])]},proxy:true}])})],1),_c('pane',{attrs:{"min-size":"20"}},[_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed","height":"100%","overflow":"auto"},attrs:{"stripe":true,"data":_vm.tableData,"page":_vm.pageService,"rowKey":"default_code","rowSelection":{
                        selectedRowKeys: _vm.selectedRowKeys,
                        onChange: function (keys, select_rows) {
                            _vm.selectedRows = select_rows
                            _vm.selectedRowKeys = keys
                            this$1.showProductQualityRateCharDataChart(
                                select_rows
                            )
                        }
                    },"columns":_vm.columnList,"scroll":{ x: 300, y: _vm.tableScrollHeight }},on:{"on-page-change":_vm.getPurchaseProductQualityRateData,"onClick":function (row) {
                            this$1.selectedRowKeys = [row]
                            var curRow = this$1.tableData.filter(
                                function (item) { return item.default_code === row; }
                            )
                            this$1.showProductQualityRateCharDataChart(curRow)
                        },"change":function (sorter) { return _vm.onTableChange(sorter); }}})],1)],1),_c('pane',{attrs:{"min-size":"20"}},[_c('a-card',{style:({ height: _vm.panel3Height }),attrs:{"title":"趋势图"}},[_c('ve-line',{attrs:{"data":_vm.productQualityRateCharData}})],1)],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-quality-rate.vue?vue&type=template&id=722db860&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__("a9e3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.to-fixed.js
var es_number_to_fixed = __webpack_require__("b680");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/product.purchase.service.ts
var product_purchase_service = __webpack_require__("b27d");

// EXTERNAL MODULE: ./src/services/purchase.service.ts
var purchase_service = __webpack_require__("0d91");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/splitpanes/dist/splitpanes.common.js
var splitpanes_common = __webpack_require__("512e");

// EXTERNAL MODULE: ./node_modules/splitpanes/dist/splitpanes.css
var splitpanes = __webpack_require__("c1ea");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-product-quality-rate.vue?vue&type=script&lang=ts&






















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_product_quality_ratevue_type_script_lang_ts_PurchaseProductQualityRateReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseProductQualityRateReport, _super);

  function PurchaseProductQualityRateReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.productPurchaseService = new product_purchase_service["a" /* ProductPurchaseService */]();
    _this.purchaseService = new purchase_service["a" /* PurchaseService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.vender_data = [];
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.orderBy = '';
    _this.table_width = 350;
    _this.fixed_width = 350;
    _this.selectedRows = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.columnList = [];
    _this.tableData = [];
    _this.showToYear = false;
    _this.splitPanelHeight = 700;
    _this.panel1Height = 100;
    _this.panel2Height = 300;
    _this.panel3Height = 300;
    _this.tableScrollHeight = 275;
    _this.productQualityRateCharData = [];
    _this.query_type = 'year';
    return _this;
  }

  PurchaseProductQualityRateReport.prototype.page_resize = function (sizeArray) {
    this.panel1Height = Math.floor(this.splitPanelHeight * Number(sizeArray[0].size) / 100);
    this.panel2Height = Math.floor(this.splitPanelHeight * Number(sizeArray[1].size) / 100);
    this.panel3Height = Math.floor(this.splitPanelHeight * Number(sizeArray[2].size) / 100);
    this.tableScrollHeight = this.panel2Height - 145;
  };

  PurchaseProductQualityRateReport.prototype.page_resized = function (sizeArray) {
    this.panel1Height = Math.floor(this.splitPanelHeight * Number(sizeArray[0].size) / 100);
    this.panel2Height = Math.floor(this.splitPanelHeight * Number(sizeArray[1].size) / 100);
    this.panel3Height = Math.floor(this.splitPanelHeight * Number(sizeArray[2].size) / 100);
    this.tableScrollHeight = this.panel2Height - 145;
  };

  PurchaseProductQualityRateReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  PurchaseProductQualityRateReport.prototype.onChangeQueryType = function (value) {
    if (value == 'year') {
      this.showToYear = true;
    } else {
      this.showToYear = false;
    }
  };

  PurchaseProductQualityRateReport.prototype.created = function () {
    var _this = this;

    var h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    this.splitPanelHeight = h - 125;
    this.panel1Height = Math.floor(this.splitPanelHeight * 30 / 100);
    this.panel2Height = Math.floor(this.splitPanelHeight * 40 / 100);
    this.panel3Height = Math.floor(this.splitPanelHeight * 40 / 100);
    this.tableScrollHeight = this.panel2Height - 145;
    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  PurchaseProductQualityRateReport.prototype.mounted = function () {
    this.columnList = this.getBasicColumnInfo();
  };

  PurchaseProductQualityRateReport.prototype.getBasicColumnInfo = function () {
    return [{
      dataIndex: 'default_code',
      key: 'default_code',
      title: this.$t('columns.sku'),
      width: 100,
      align: 'left'
    }, {
      dataIndex: 'vendor_name',
      key: 'vendor_name',
      title: this.$t('columns.vendor_name'),
      width: 60,
      align: 'center'
    }, {
      dataIndex: 'z_category',
      key: 'z_category',
      title: this.$t('columns.cn_category'),
      width: 80,
      align: 'left'
    }, {
      dataIndex: 'z_sub_category',
      key: 'z_sub_category',
      title: this.$t('columns.cn_sub_category'),
      width: 110,
      align: 'left'
    }];
  };

  PurchaseProductQualityRateReport.prototype.showProductQualityRateCharDataChart = function (selectedRows) {
    var row_list = [];

    for (var column_index in this.columnList) {
      var column_info = this.columnList[column_index];

      if (column_info.children) {
        for (var children_index in column_info.children) {
          var columnName = column_info.children[children_index].key;

          if (this.isFilterColumn(columnName)) {
            continue;
          }

          columnName = columnName.replace('_month', '').replace('_problem_qty', '').replace('_', '-');
          var row = {
            data_date: columnName
          };
          row_list.push(row);
        }
      } else {
        var columnName = this.columnList[column_index].key;

        if (this.isFilterColumn(columnName)) {
          continue;
        }

        var row = {
          data_date: columnName
        };
        row_list.push(row);
      }
    }

    this.productQualityRateCharData = {
      columns: ['data_date'],
      rows: row_list
    };

    for (var _i = 0, selectedRows_1 = selectedRows; _i < selectedRows_1.length; _i++) {
      var row = selectedRows_1[_i];
      var default_code = row['default_code'];

      if (this.productQualityRateCharData.columns.indexOf(default_code) < 0) {
        this.productQualityRateCharData.columns.push(default_code);
        var cell_index = 0;

        for (var column_index in this.columnList) {
          var column_info = this.columnList[column_index];

          if (column_info.children) {
            for (var children_index in column_info.children) {
              var columnName = column_info.children[children_index].key;

              if (this.isFilterColumn(columnName)) {
                continue;
              }

              this.productQualityRateCharData.rows[cell_index][default_code] = row[columnName];
              cell_index += 1;
            }
          } else {
            var columnName = this.columnList[column_index].key;

            if (this.isFilterColumn(columnName)) {
              continue;
            }

            this.productQualityRateCharData.rows[column_index][default_code] = row[columnName];
            cell_index += 1;
          }
        }
      }
    }
  };

  PurchaseProductQualityRateReport.prototype.isFilterColumn = function (columnName) {
    var fixed_column = ['default_code', 'vendor_name', 'z_category', 'z_sub_category'];

    if (columnName.indexOf('_problem_count') != -1) {
      return true;
    }

    if (columnName.indexOf('_problem_qty') != -1) {
      return true;
    }

    if (columnName.indexOf('_sale_sum') != -1) {
      return true;
    }

    if (fixed_column.indexOf(columnName) != -1) {
      return true;
    }

    return false;
  };

  PurchaseProductQualityRateReport.prototype.getPurchaseProductQualityRateData = function () {
    var _this = this;

    this.columnList = this.getBasicColumnInfo();
    this.getQueryCondition().then(function (params) {
      _this.purchaseService.query_all_quality_pass_ratio_report(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        var new_data = [];
        var year_list = [];

        var new_data_dict = _this.getMonthNewData(data);

        new_data = new_data_dict.data;
        year_list = new_data_dict.date;
        var other_width = 0;

        if (_this.query_type == 'month') {
          other_width = _this.getMonthOtherColumns(year_list);
        } else if (_this.query_type == 'year') {
          other_width = _this.getYearOtherColumns(year_list);
        } else {
          other_width = _this.getSeasonOtherColumns(year_list);
        }

        _this.table_width = other_width + _this.fixed_width;
        _this.tableData = new_data;
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  PurchaseProductQualityRateReport.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        if (values['vendor_name'] == '' || values['vendor_name'].length == 0) {
          delete values['vendor_name'];
        }

        if (values['z_category'] == '' || values['z_category'].length == 0) {
          delete values['z_category'];
        }

        if (values['z_sub_category'] == '' || values['z_sub_category'].length == 0) {
          delete values['z_sub_category'];
        }

        var params = common_service["a" /* CommonService */].createQueryCondition(values, {
          year: '=',
          vendor_name: 'in',
          z_sub_category: 'in'
        });
        _this.query_type = '';
        var query_condition = params['query_condition'];
        var new_query_condition = [];

        for (var index in query_condition) {
          if (query_condition[index]['query_name'] == 'query_type') {
            _this.query_type = query_condition[index]['value'];
            params['query_type'] = _this.query_type;
            continue;
          }

          new_query_condition.push(query_condition[index]);
        }

        if (_this.query_type == '') {
          _this.$message.info('请选择数据查询类型! ');

          return;
        }

        params['query_condition'] = new_query_condition;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        reslove(params);
      }).catch(function (err) {// 异常处理
      });
    });
  };

  PurchaseProductQualityRateReport.prototype.getMonthNewData = function (data) {
    var new_data = [];
    var year_list = [];

    for (var index in data) {
      var item = data[index];

      for (var year_data_index in item.year_data) {
        var year_data_item = item.year_data[year_data_index];
        var tmpl_year = year_data_item.year;

        if (year_list.includes(tmpl_year) == false) {
          year_list.push(tmpl_year);
        }

        for (var key in year_data_item) {
          if (key == 'year') {
            continue;
          }

          item[tmpl_year + '_' + key] = year_data_item[key];
        }
      }

      delete item.year_data;
      new_data.push(item);
    }

    return {
      data: new_data,
      date: year_list
    };
  };

  PurchaseProductQualityRateReport.prototype.getChildrenColumns = function (year, current_type, currenct_value) {
    var problem_count_width = 80;
    var problem_qty_width = 80;
    var sale_sum_width = 80;
    var pass_ratio_width = 90;
    var children_info = [{
      dataIndex: year + current_type + currenct_value + '_problem_count',
      key: year + current_type + currenct_value + '_problem_count',
      title: this.$t('columns.problem_count'),
      align: 'right',
      width: problem_count_width,
      customRender: function customRender(value, row, index) {
        if (!value) {
          return 0;
        }

        return value.toFixed(2);
      }
    }, {
      dataIndex: year + current_type + currenct_value + '_problem_qty',
      key: year + current_type + currenct_value + '_problem_qty',
      title: this.$t('columns.problem_qty'),
      align: 'right',
      width: problem_qty_width,
      customRender: function customRender(value, row, index) {
        if (!value) {
          return 0;
        }

        return value.toFixed(2);
      }
    }, {
      dataIndex: year + current_type + currenct_value + '_sale_sum',
      key: year + current_type + currenct_value + '_sale_sum',
      title: this.$t('columns.sale_sum'),
      align: 'right',
      width: sale_sum_width,
      customRender: function customRender(value, row, index) {
        if (!value) {
          return 0;
        }

        return value.toFixed(2);
      }
    }, {
      dataIndex: year + current_type + currenct_value + '_pass_ratio',
      key: year + current_type + currenct_value + '_pass_ratio',
      title: this.$t('columns.pass_ratio'),
      align: 'right',
      width: pass_ratio_width,
      customRender: function customRender(value, row, index) {
        if (!value) {
          return 0;
        }

        return value.toFixed(2);
      }
    }];
    return children_info;
  };

  PurchaseProductQualityRateReport.prototype.getSeasonOtherColumns = function (year_list) {
    var problem_count_width = 80;
    var problem_qty_width = 80;
    var sale_sum_width = 80;
    var pass_ratio_width = 90;
    var season_list = ['1', '2', '3', '4'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var season_index in season_list) {
        var season = season_list[season_index];
        var column_info = {
          title: this.$t('columns.season_' + season) + '/' + year,
          children: this.getChildrenColumns(year, '_season_', season)
        };
        this.columnList.push(column_info);
      }
    }

    return (problem_count_width + problem_qty_width + sale_sum_width + pass_ratio_width) * year_list.length * season_list.length;
  };

  PurchaseProductQualityRateReport.prototype.getMonthOtherColumns = function (year_list) {
    var problem_count_width = 80;
    var problem_qty_width = 80;
    var sale_sum_width = 80;
    var pass_ratio_width = 90;
    var month_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var month_index in month_list) {
        var month = month_list[month_index];
        var column_info = {
          title: this.$t('columns.month_' + month) + '/' + year,
          children: this.getChildrenColumns(year, '_month_', month)
        };
        this.columnList.push(column_info);
      }
    }

    return (problem_count_width + problem_qty_width + sale_sum_width + pass_ratio_width) * year_list.length * month_list.length;
  };

  PurchaseProductQualityRateReport.prototype.getYearOtherColumns = function (year_list) {
    var problem_count_width = 80;
    var problem_qty_width = 80;
    var sale_sum_width = 80;
    var pass_ratio_width = 90;

    for (var year_index in year_list) {
      var year = year_list[year_index];
      var column_info = {
        title: year,
        children: this.getChildrenColumns(year, '', '')
      };
      this.columnList.push(column_info);
    }

    return (problem_count_width + problem_qty_width + sale_sum_width + pass_ratio_width) * year_list.length;
  };

  PurchaseProductQualityRateReport.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getPurchaseProductQualityRateData();
  };

  PurchaseProductQualityRateReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseProductQualityRateReport.prototype.exportData = function () {
    this.getQueryCondition().then(function (x) {
      common_service["a" /* CommonService */].exportData('/purchase_requirement/export_quality_pass_ratio_report', {
        query_condition: x.query_condition
      });
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseProductQualityRateReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseProductQualityRateReport.prototype, "pageContainer", void 0);

  PurchaseProductQualityRateReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-product-quality-rate'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      Splitpanes: splitpanes_common["Splitpanes"],
      Pane: splitpanes_common["Pane"]
    }
  })], PurchaseProductQualityRateReport);
  return PurchaseProductQualityRateReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_product_quality_ratevue_type_script_lang_ts_ = (purchase_product_quality_ratevue_type_script_lang_ts_PurchaseProductQualityRateReport);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-quality-rate.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_product_quality_ratevue_type_script_lang_ts_ = (purchase_product_quality_ratevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-product-quality-rate.vue?vue&type=custom&index=0&blockType=i18n
var purchase_product_quality_ratevue_type_custom_index_0_blockType_i18n = __webpack_require__("1714");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-quality-rate.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_product_quality_ratevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_product_quality_ratevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_product_quality_ratevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_product_quality_rate = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "0e5f":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"contact_no":"Contact No.","order_name":"Order Name","vendor_id":"Vendor","order_date":"Order Date","give_date":"Give Date","warehouse_id":"Warehouse","exists_attention":"Need Attention","finish_yn":"Trace Finish","factory_finish":"Factory Finish","is_purchase_changed":"Split Line","default_code":"SKU","new_product":"New Product","product_qty":"Purchase QTY","ist_box_qty":"Is Box","cancel_attention_memo":"Cancel Attention Memo","finish_qty":"Finish QTY","date_expected":"Date Expected","factory_finish_time":"Factory Finish Date","factory_finish_qty":"Factory Finish QTY","note":"Note","sales_change_give_date":"Sales Give Date","sales_change_give_date_memo":"Sales Give Date Memo","buyer_change_give_date":"Purchase Give Date","buyer_change_give_date_memo":"Purchase Give Date Memo","latest_give_date":"Latest Give Date","ac_approved":"QC Confirm Ship","user_purchase":"Purchase","merchandiser":"Merchandiser","un_finish_qty":"Unfinish QTY"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","save":"Save","cancel":"Cancel","confirm":"Confirm","export":"Export Excel","import":"Import Excel","view_logs":"Logs","more":"More","discard":"Discard","export_unfinish_line":"Export Unfinish","edit_finish_qty_vendor":"Multi Edit Finish Qty and Vendor","change_purchase_info":"Multi Change Purchase Info","export_product_specification":"Export Manual Specification","view_purchase_change_log":"Logs","update_btn":"More","cancel_attention":"Cancel Attention","force_finish_trace":"Finish Purchase Item","unfinish_trace":"Unfinish Purchase Item","qc_confirm_ship":"QC Confirm Ship","purchase_finish_dlg":"Finish Item","cancel_attention_dlg":"Cancel Attention Item","add_trace_memo_dlg":"Add Trace Memo","import_trace_memo_dlg":"Import Trace Memo","sync_product_supplier":"Sync Product Supplier","showlog":"View Log"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"contact_no":"合同号","order_name":"订单号","vendor_id":"供应商","order_date":"订单日期","give_date":"合同交期","warehouse_id":"仓库","exists_attention":"需要关注","finish_yn":"跟踪完成","factory_finish":"生产完成","is_purchase_changed":"拆分明细","default_code":"SKU","new_product":"新品","product_qty":"采购数量","ist_box_qty":"按箱","cancel_attention_memo":"取消关注备注","finish_qty":"完成数量","date_expected":"期望入库","factory_finish_time":"工厂完成时间","factory_finish_qty":"工厂完成数量","note":"Note","sales_change_give_date":"运营交期","sales_change_give_date_memo":"运营交期变更备注","buyer_change_give_date":"采购交期","buyer_change_give_date_memo":"采购交期变更备注","latest_give_date":"最终交期","ac_approved":"QC确认发货","user_purchase":"采购员","merchandiser":"跟单员","un_finish_qty":"未完成数量"},"action":{"create":"新建","edit":"编辑","delete":"删除","ok":"确定","save":"保存","cancel":"取消","confirm":"确认","export":"导出Excel","import":"导入Excel","view_logs":"日志","more":"更多操作","discard":"丢弃","export_unfinish_line":"导出未完成","edit_finish_qty_vendor":"批量变更发货数量和供应商","change_purchase_info":"批量修改采购信息","export_product_specification":"导出说明书和工艺单","view_purchase_change_log":"日志","update_btn":"更多","cancel_attention":"取消关注","force_finish_trace":"设置跟踪完成","unfinish_trace":"设置跟踪未完成","qc_confirm_ship":"QC质检完成","purchase_finish_dlg":"强制完成","cancel_attention_dlg":"取消关注","add_trace_memo_dlg":"添加跟踪备注","import_trace_memo_dlg":"导入跟踪备注","sync_product_supplier":"Sync Product Supplier","showlog":"查看日志"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "1714":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_quality_rate_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("2f12");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_quality_rate_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_quality_rate_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_quality_rate_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "183a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-contract-manage.vue?vue&type=template&id=976b3058&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 0 },"actions":true},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_company_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_company_id', { initialValue: '' }]),expression:"['order_company_id', { initialValue: '' }]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-select-option',{key:"woltu",attrs:{"value":"woltu"}},[_vm._v(" Woltu ")]),_c('a-select-option',{key:"eugad",attrs:{"value":"eugad"}},[_vm._v(" EUGAD ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_date']),expression:"['order_date']"}],style:({ width: '240px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.give_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['give_date']),expression:"['give_date']"}],style:({ width: '240px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.make_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['make_user']),expression:"['make_user']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PurchaseContractState),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.purchase_requirement')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['purchase_requirement']),expression:"['purchase_requirement']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.source_doc1')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['source_doc1']),expression:"['source_doc1']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.is_manual_url')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'product_manual_url',
                        { initialValue: '' }
                    ]),expression:"[\n                        'product_manual_url',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{key:true,attrs:{"value":true}},[_vm._v(_vm._s(_vm.$t('action.yes'))+" ")]),_c('a-radio-button',{key:false,attrs:{"value":false}},[_vm._v(_vm._s(_vm.$t('action.no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.is_specification_url')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'product_specification_url',
                        { initialValue: '' }
                    ]),expression:"[\n                        'product_specification_url',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{key:true,attrs:{"value":true}},[_vm._v(_vm._s(_vm.$t('action.yes'))+" ")]),_c('a-radio-button',{key:false,attrs:{"value":false}},[_vm._v(_vm._s(_vm.$t('action.no'))+" ")])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onSyncProduct()}}},[_vm._v(_vm._s(_vm.$t('action.sync_product_info'))+" ")]),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('change_give_date'),expression:"'change_give_date'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onChangeGiveDate()}}},[_vm._v(_vm._s(_vm.$t('action.change_give_date'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left","disabled":!_vm.selectedRowKeys.length},on:{"confirm":function($event){return _vm.onBatchDelete()}}},[_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('delete'),expression:"'delete'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('update'),expression:"'update'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.updateProduct}},[_vm._v(_vm._s(_vm.$t('action.update_product_qty_code'))+" ")]),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('export_contract'),expression:"'export_contract'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.exportContract}},[_vm._v(_vm._s(_vm.$t('action.export_contract'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.downloadManual}},[_vm._v(_vm._s(_vm.$t('action.download_manual'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.downloadSpecification}},[_vm._v(_vm._s(_vm.$t('action.download_specification'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.downloadRmbNewContract}},[_vm._v(_vm._s(_vm.$t('action.download_rmb_new_contract'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.downloadUsdNewContract}},[_vm._v(_vm._s(_vm.$t('action.download_usd_new_contract'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.downloadRmbContract}},[_vm._v(_vm._s(_vm.$t('action.download_rmb_contract'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.downloadUsdContract}},[_vm._v(_vm._s(_vm.$t('action.download_usd_contract'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v(_vm._s(_vm.$t('action.download'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.showLog}},[_vm._v(_vm._s(_vm.$t('action.showlog'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"name",fn:function(text, row){return _c('span',{},[_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])])}},{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"state",fn:function(text, row){return _c('span',{},[_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'PurchaseContractState'))))])])}},{key:"company",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getCompanyName(text)))])]}},{key:"vendor",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getVendorName(text)))])]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'confirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.verifyWithMemo(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(row.state == 'refuse')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(row.state == 'confirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.verifyWithMemo(row, 'refuse')}}},[_vm._v(" "+_vm._s(_vm.$t('action.refuse'))+" ")]):_vm._e(),_c('a-menu-item',{on:{"click":function($event){return _vm.downloadBatchNumber(row)}}},[_vm._v(" "+_vm._s(_vm.$t('action.download_batch_number'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}],null,false,1173662600)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":1500,"scrollY":400},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"name",fn:function(text, row){return _c('span',{},[_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])])}},{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"state",fn:function(text, row){return _c('span',{},[_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'PurchaseContractState'))))])])}},{key:"company",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getCompanyName(text)))])]}},{key:"vendor",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getVendorName(text)))])]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'confirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.verifyWithMemo(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(row.state == 'refuse')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(row.state == 'confirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.verifyWithMemo(row, 'refuse')}}},[_vm._v(" "+_vm._s(_vm.$t('action.refuse'))+" ")]):_vm._e(),_c('a-menu-item',{on:{"click":function($event){return _vm.downloadBatchNumber(row)}}},[_vm._v(" "+_vm._s(_vm.$t('action.download_batch_number'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-contract-manage.vue?vue&type=template&id=976b3058&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/purchase/update-product-qty-code.vue + 4 modules
var update_product_qty_code = __webpack_require__("6d3c");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/components/cs_email_return/chat-modify-memo.vue + 4 modules
var chat_modify_memo = __webpack_require__("439a");

// EXTERNAL MODULE: ./src/components/purchase/change-give-date-form.vue + 4 modules
var change_give_date_form = __webpack_require__("7aba");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-contract-manage.vue?vue&type=script&lang=ts&



























var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var purchase_contract_managevue_type_script_lang_ts_PurchaseContractManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseContractManage, _super);

  function PurchaseContractManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.orderBy = 'create_date desc';
    _this.current = null;
    _this.columnList = [];
    _this.allNameAuth = [];
    _this.groupbyList = [];
    _this.queryConsition = [];
    _this.queryUrl = 'purchase_management/query_all_purchase_order';
    return _this;
  }

  PurchaseContractManage.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  Object.defineProperty(PurchaseContractManage.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchaseContractManage.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
  };

  PurchaseContractManage.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseContractManage.prototype.getVendorName = function (code) {
    var ret = code;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseContractManage.prototype.getCompanyName = function (code) {
    var ret = code;
    var item = this.companyList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };
  /**
   * 获取订单数据
   */


  PurchaseContractManage.prototype.getDataList = function () {
    var _this = this;

    var params = {};
    this.getQueryCondition().then(function (nowConditions) {
      _this.queryConsition = nowConditions;

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseContractManage.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
          name: 'in_or_like',
          default_code: 'in_or_like',
          purchase_requirement: 'in_or_like',
          source_doc1: 'in_or_like'
        }, form_config["a" /* formConfig */].condition));
        var nowConditions = [];

        for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
          var item = _a[_i];

          if (item.value.constructor == Array && item.operate !== 'in') {
            if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '>=',
                value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
              });
            }

            if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '<=',
                value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
              });
            }
          } else {
            nowConditions.push(item);
          }
        }

        reslove(nowConditions);
      }).catch(function (err) {
        _this.$message.error(JSON.stringify(err));
      });
    });
  };

  PurchaseContractManage.prototype.onCreate = function () {
    this.$router.push({
      name: 'replenishment-edit'
    });
  };

  PurchaseContractManage.prototype.exportInfo = function () {};

  PurchaseContractManage.prototype.onSyncProduct = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/sync_purchase_order_product_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      order_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.onRowClick = function (record) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/query_purchase_order_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      order_id: record.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      data[0]['id'] = record.id; // data[0]['state'] = record.state

      var index = 'purchasecontractedit' + record.id;
      var params = {
        index: index,
        id: record.id,
        info: data,
        component: 'PurchaseContractEdit'
      };

      _this.addCommonPageInfo(params);

      var baseName = _this.$t('page_name');

      _this.$router.push({
        name: 'common-page',
        path: "/common-page/" + index,
        params: {
          id: index,
          name: record.name + '-' + baseName
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.onBatchDelete = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_purchase_order', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      order_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.onDelete = function (record) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_purchase_order', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      order_id_list: [record.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.onVerify = function (record, state) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/update_purchase_order_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      order_id_list: [record.id],
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      var item = _this.data.find(function (x) {
        return x.id == record.id;
      });

      if (item) {
        item.state = state;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.updateProduct = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只能选择一条数据进行拆分');
      return;
    }

    var item = this.data.find(function (x) {
      return x.id == _this.selectedRowKeys[0];
    });

    if (item && item.state == 'draft') {
      this.$message.error('只能选择已审核的数据进行拆分');
      return;
    }

    this.innerAction.setActionAPI('purchase_management/query_purchase_order_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      order_id: this.selectedRowKeys[0]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var row = _this.data.find(function (x) {
        return x.id == _this.selectedRowKeys[0];
      });

      if (row) {
        data[0]['state'] = row.state;
        data[0]['id'] = row.id;
      }

      _this.$modal.open(update_product_qty_code["a" /* default */], {
        info: data[0],
        systemUsers: _this.systemUsers,
        vendorList: _this.vendorFullNameList
      }, {
        title: _this.$t('action.update_product_qty_code'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.downloadBatchNumber = function (row) {
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/download_batch_number&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&order_id=' + row.id);
  };

  PurchaseContractManage.prototype.downloadSpecification = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/download_product_specification&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&order_id_list=' + urlParams);
  };

  PurchaseContractManage.prototype.downloadManual = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/download_product_manual&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&order_id_list=' + urlParams);
  };

  PurchaseContractManage.prototype.downloadRmbContract = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_purchase_order_excel&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&export_type=RMB&order_id_list=' + urlParams + '&use_product_link=false');
  };

  PurchaseContractManage.prototype.downloadRmbNewContract = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_purchase_order_excel&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&export_type=RMB&order_id_list=' + urlParams + '&use_product_link=true');
  };

  PurchaseContractManage.prototype.downloadUsdContract = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_purchase_order_excel&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&export_type=USD&order_id_list=' + urlParams + '&use_product_link=false');
  };

  PurchaseContractManage.prototype.downloadUsdNewContract = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_purchase_order_excel&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&export_type=USD&order_id_list=' + urlParams + '&use_product_link=true');
  };

  PurchaseContractManage.prototype.exportContract = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_purchase_order&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&order_ids=' + urlParams);
  };

  PurchaseContractManage.prototype.verifyWithMemo = function (record, state) {
    var _this = this;

    this.$modal.open(chat_modify_memo["a" /* default */], {}, {
      title: this.$t('action.verify_mome')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('purchase_management/update_purchase_order_state', common_service["a" /* CommonService */].getMenuCode());

      _this.publicService.modify(new http["RequestParams"]({
        order_id_list: [record.id],
        state: state,
        approve_memo: data
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');

        var item = _this.data.find(function (x) {
          return x.id == record.id;
        });

        if (item) {
          item.state = state;
        }
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.onChangeGiveDate = function () {
    var _this = this;

    this.$modal.open(change_give_date_form["a" /* default */], {}, {
      title: this.$t('action.change_give_date')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('purchase_management/update_purchase_order_give_date', common_service["a" /* CommonService */].getMenuCode());

      _this.publicService.modify(new http["RequestParams"]({
        order_id_list: _this.selectedRowKeys,
        change_give_date: data.change_give_date,
        change_give_date_memo: data.change_give_date_memo
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseContractManage.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseContractManage.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  PurchaseContractManage.prototype.showLog = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('每次只能查看一条数据的日志');
      return;
    }

    this.$modal.open(log_view["a" /* default */], {
      object_name: 'order',
      is_special_table: true,
      record_code: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showlog'),
      width: '1000px'
    }).subscribe(function () {//
    }, function (err) {
      _this.$message.error('error');
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseContractManage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseContractManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractManage.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractManage.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractManage.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractManage.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractManage.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractManage.prototype, "getVendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseContractManage.prototype, "addCommonPageInfo", void 0);

  PurchaseContractManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-contract-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      UpdateProductQtyCode: update_product_qty_code["a" /* default */],
      CommonPage: common_page["a" /* default */],
      LogView: log_view["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */]
    }
  })], PurchaseContractManage);
  return PurchaseContractManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_contract_managevue_type_script_lang_ts_ = (purchase_contract_managevue_type_script_lang_ts_PurchaseContractManage);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-contract-manage.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_contract_managevue_type_script_lang_ts_ = (purchase_contract_managevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-contract-manage.vue?vue&type=custom&index=0&blockType=i18n
var purchase_contract_managevue_type_custom_index_0_blockType_i18n = __webpack_require__("c624");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-contract-manage.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_contract_managevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_contract_managevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_contract_managevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_contract_manage = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "203a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("041e");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "2eaf":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0848");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "2f12":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Purchase Reduce Cost","columns":{"vendor_name":"Vendor","cn_category":"CN Category","cn_sub_category":"CN Sub Category","sku":"SKU","problem_count":"Problem Count","problem_qty":"Problem QTY","sale_sum":"Sales Total","pass_ratio":"Pass Rate","season_1":"Quarter 1","season_2":"Quarter 2","season_3":"Quarter 3","season_4":"Quarter 4","month_1":"Jan","month_2":"Feb","month_3":"Mar","month_4":"Apl","month_5":"May","month_6":"Jun","month_7":"Jul","month_8":"Aug","month_9":"Sep","month_10":"Oct","month_11":"Nov","month_12":"Dec","query_type":"Calcuate Type","year":"Time"},"action":{"create":"新建","more":"更多操作"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"采购降本","columns":{"vendor_name":"供应商","cn_category":"中文分类","cn_sub_category":"中文子类","sku":"SKU","problem_count":"客诉次数","problem_qty":"客诉产品数量","sale_sum":"销售总数","pass_ratio":"质量合格率","season_1":"1季度","season_2":"2季度","season_3":"3季度","season_4":"4季度","month_1":"1月","month_2":"2月","month_3":"3月","month_4":"4月","month_5":"5月","month_6":"6月","month_7":"7月","month_8":"8月","month_9":"9月","month_10":"10月","month_11":"11月","month_12":"12月","query_type":"统计维度","year":"时间"},"action":{"create":"新建","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "3775":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"name":"Name","code":"Code","state":"State"},"action":{"create":"Add Item","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","save":"Save"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","page_name":"Logistics Provider Detail"},"zh-cn":{"desc":"这是订单页面1","columns":{"name":"物流商名称","code":"物流商编码","state":"状态"},"action":{"create":"新建","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","save":"保存"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","page_name":"物流商详情"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "3b70":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "3bcb":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"actual_give_date":"Actual Give Date","actual_give_date_memo":"Actual Give Date Memo","box_qty":"Box Qty","container_group":"Container Group","currency_unit":"Currency Unit","default_code":"Default Code","gewicht":"Gewicht","height":"Height","id":"Id","is_fba":"Is Fba","length":"Length","name":"Name","note":"Note","out_number":"Out Number","pack_qty":"Pack Qty","price_subtotal":"Price Subtotal","price_unit":"Price Unit","prod_name":"Prod Name","product_cate":"Product Cate","product_qty":"Product Qty","product_volume":"Product Volume","product_weight":"Product Weight","state":"State","user_purchase":"User Purchase","warehouse_id":"warehouse_id","width":"Width","source_doc":"Source Doc","give_date":"Give Date","vendor_id":"vendor","order_date":"Order Date","make_user":"Make User"},"action":{"order_detail":"Order Detail","other_form":"Other Form","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","today":"Today","yestoday":"Yestoday","3day":"3 Day","send_email":"Send Email","refund":"Refund Supplement Wizard","modify_cp":"Modify CP","other_info":"Other Info","save":"Save","sync_product_info":"Synchronize Product","change_give_date":"Change Give Date","import":"Import","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse","verify_mome":"Memo"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"actual_give_date":"实际交期","actual_give_date_memo":"实际交期说明","box_qty":"箱数","container_group":"Container Group","currency_unit":"币种","default_code":"货号","gewicht":"毛重","height":"高","id":"Id","is_fba":"是否Fba","length":"长","name":"Name","note":"Note","out_number":"Out Number","pack_qty":"Pack Qty","price_subtotal":"Price Subtotal","price_unit":"Price Unit","prod_name":"产品名称","product_cate":"产品分类","product_qty":"产品数量","product_volume":"产品体积","product_weight":"产品宽度","state":"状态","user_purchase":"采购员","warehouse_id":"仓库","width":"宽","source_doc":"发票号","give_date":"合同交期","vendor_id":"供应商","order_date":"订单日期","make_user":"制单员"},"action":{"order_detail":"订单明细","other_form":"其它信息","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","today":"前一天","yestoday":"前两天","3day":"前三天","send_email":"发送邮件","refund":"退款管理","modify_cp":"修改CP","other_info":"其它信息","save":"保存","sync_product_info":"同步产品信息","change_give_date":"修改采购交期","import":"导入","verify":"审核","reset":"重置","confirm":"确认","refuse":"确认拒绝","verify_mome":"备注"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "4681":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Purchase Give Date","columns":{"vendor_name":"Vendor","cn_category":"CN Category","cn_sub_category":"CN Sub Category","sku":"SKU","ratio":"Ratio(%)","count":"Count","season_1":"Quarter 1","season_2":"Quarter 2","season_3":"Quarter 3","season_4":"Quarter 4","month_1":"Jan","month_2":"Feb","month_3":"Mar","month_4":"Apl","month_5":"May","month_6":"Jun","month_7":"Jul","month_8":"Aug","month_9":"Sep","month_10":"Oct","month_11":"Nov","month_12":"Dec","query_type":"Calcuate Type","year":"Time"},"action":{"create":"新建","more":"更多操作"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"采购交期","columns":{"vendor_name":"供应商","cn_category":"中文分类","cn_sub_category":"中文子类","sku":"SKU","ratio":"比例(%)","count":"数量","season_1":"1季度","season_2":"2季度","season_3":"3季度","season_4":"4季度","month_1":"1月","month_2":"2月","month_3":"3月","month_4":"4月","month_5":"5月","month_6":"6月","month_7":"7月","month_8":"8月","month_9":"9月","month_10":"10月","month_11":"11月","month_12":"12月","query_type":"统计维度","year":"时间"},"action":{"create":"新建","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "5174":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"approved_user":"Approved user","change_give_date":"Change give date","give_date":"Give date","make_user":"Make user","merchandiser":"Merchandiser","name":"Order No.","order_company_id":"Order company id","order_date":"Order date","purchase_requirement":"Purchase requirement","source_doc1":"Source doc1","state":"State","user_purchase":"User purchase","vendor_id":"Vendor id","warehouse_id":"Warehouse","is_specification_url":"Have specification url","is_manual_url":"Have Manual url"},"action":{"action":"Action","create":"Create","download":"Download","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","sync_product_info":"Synchronize Product","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse","update_product_qty_code":"Update Product Qty&Code","download_manual":"Download Manual","download_specification":"Download Specification","download_batch_number":"Download Batch Number","download_rmb_contract":"Download RMB Make Order","download_rmb_new_contract":"Download RMB Make Order new(Use Product Lick)","download_usd_contract":"Download USD Make Order","download_usd_new_contract":"Download USD Make Order New(Use Product Lick)","export_contract":"Export Contract","verify_mome":"Memo","change_give_date":"Change Give Date","showlog":"View Log","yes":"Yes","no":"No"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","page_name":"Purchase Contract Edit"},"zh-cn":{"desc":"这是订单页面1","columns":{"approved_user":"审核人","change_give_date":"更改交期","give_date":"合同交期","make_user":"制单员","merchandiser":"跟单员","name":"订单号","order_company_id":"公司","order_date":"订单日期","purchase_requirement":"采购需求","source_doc1":"发票号","state":"状态","user_purchase":"采购员","vendor_id":"供应商","warehouse_id":"仓库","is_specification_url":"是否有工艺单附件","is_manual_url":"是否有说明书附件"},"action":{"action":"操作","create":"新建","download":"下载","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","sync_product_info":"同步产品信息","verify":"审核","reset":"重置","confirm":"确认","refuse":"确认拒绝","update_product_qty_code":"变更产品货号及数量","download_manual":"下载说明书","download_specification":"下载工艺单","download_batch_number":"下载批次号","download_rmb_contract":"人民币采购合同","download_rmb_new_contract":"人民币采购合同(使用产品链接)","download_usd_contract":"美元采购合同","download_usd_new_contract":"美元采购合同(使用产品链接)","export_contract":"导出采购合同","verify_mome":"备注","change_give_date":"修改采购交期","showlog":"查看日志","yes":"是","no":"否"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","page_name":"采购合同编辑"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "5270":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0175");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "52b0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-ship-order.vue?vue&type=template&id=c9e7dc7e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 },"actions":true},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],style:({ width: '240px' }),attrs:{"size":"small","placeholder":_vm.$t('plzInput')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_date']),expression:"['order_date']"}],style:({ width: '240px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.give_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['give_date']),expression:"['give_date']"}],style:({ width: '240px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.make_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['make_user']),expression:"['make_user']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PurchaseShipOrderState),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.source_doc')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['source_doc']),expression:"['source_doc']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.onCreate()}}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onMakePackageOrder()}}},[_vm._v(_vm._s(_vm.$t('action.make_package_order'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left","disabled":!_vm.selectedRowKeys.length},on:{"confirm":function($event){return _vm.onBatchDelete()}}},[_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('delete'),expression:"'delete'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.showLog}},[_vm._v(_vm._s(_vm.$t('action.showlog'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 1000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])]}},{key:"vendor",fn:function(text){return [_vm._v(" "+_vm._s(_vm.getVendorName(text))+" ")]}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"state",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PurchaseShipOrderState'))))])]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'confirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(
                                    row.state == 'confirm' ||
                                        row.state == 'approved'
                                )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}],null,false,2756191885)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":1500,"scrollY":400},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])]}},{key:"vendor",fn:function(text){return [_vm._v(" "+_vm._s(_vm.getVendorName(text))+" ")]}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"state",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PurchaseShipOrderState'))))])]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'confirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(
                                row.state == 'confirm' ||
                                    row.state == 'approved'
                            )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-ship-order.vue?vue&type=template&id=c9e7dc7e&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/purchase/update-product-qty-code.vue + 4 modules
var update_product_qty_code = __webpack_require__("6d3c");

// EXTERNAL MODULE: ./src/components/cs_email_return/chat-modify-memo.vue + 4 modules
var chat_modify_memo = __webpack_require__("439a");

// EXTERNAL MODULE: ./src/components/purchase/make-package-order.vue + 4 modules
var make_package_order = __webpack_require__("9c26");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-ship-order.vue?vue&type=script&lang=ts&



























var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var purchase_ship_ordervue_type_script_lang_ts_PurchaseShipOrder =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseShipOrder, _super);

  function PurchaseShipOrder() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = 'create_date desc';
    _this.columnList = [];
    _this.allNameAuth = [];
    _this.groupbyList = [];
    _this.queryConsition = [];
    _this.queryUrl = 'ship_order/query_all_ship_orders';
    return _this;
  }

  Object.defineProperty(PurchaseShipOrder.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchaseShipOrder.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
  };

  PurchaseShipOrder.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  PurchaseShipOrder.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseShipOrder.prototype.getVendorName = function (code) {
    var ret = code;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseShipOrder.prototype.getCompanyName = function (code) {
    var ret = code;
    var item = this.companyList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };
  /**
   * 获取订单数据
   */


  PurchaseShipOrder.prototype.getDataList = function () {
    var _this = this;

    var params = {};
    this.getQueryCondition().then(function (nowConditions) {
      _this.queryConsition = nowConditions;

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseShipOrder.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
          name: 'like',
          source_doc: 'in_or_like',
          default_code: 'in_or_like'
        }, form_config["a" /* formConfig */].condition));
        var nowConditions = [];

        for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
          var item = _a[_i];

          if (item.value.constructor == Array && item.operate !== 'in') {
            if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '>=',
                value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
              });
            }

            if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '<=',
                value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
              });
            }
          } else {
            nowConditions.push(item);
          }
        }

        reslove(nowConditions);
      }).catch(function (err) {
        _this.$message.error(JSON.stringify(err));
      });
    });
  };

  PurchaseShipOrder.prototype.onCreate = function () {
    this.$router.push({
      name: 'purchase-ship-order-edit'
    });
  };

  PurchaseShipOrder.prototype.exportInfo = function () {};

  PurchaseShipOrder.prototype.onSyncProduct = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/sync_purchase_order_product_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      order_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrder.prototype.onRowClick = function (record) {
    var _this = this;

    this.innerAction.setActionAPI('ship_order/query_one_ship_orders', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      order_id: record.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      data[0]['id'] = record.id;
      data[0]['product_volume'] = parseInt(record.sum_product_volume);
      var index = 'purchaseshiporderedit' + record.id;
      var params = {
        index: index,
        id: record.id,
        info: data,
        component: 'PurchaseShipOrderEdit'
      };

      _this.addCommonPageInfo(params);

      var baseName = _this.$t('page_name');

      _this.$router.push({
        name: 'common-page',
        path: "/common-page/" + index,
        params: {
          id: index,
          name: record.name + '-' + baseName
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrder.prototype.onBatchDelete = function () {
    var _this = this;

    this.innerAction.setActionAPI('ship_order/delete_ship_order', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrder.prototype.onDelete = function (record) {
    var _this = this;

    this.innerAction.setActionAPI('ship_order/delete_ship_order', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      ids: [record.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrder.prototype.onVerify = function (record, state) {
    var _this = this;

    this.innerAction.setActionAPI('ship_order/change_ship_order_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      order_ids: [record.id],
      old_state: record.state,
      new_state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      var item = _this.data.find(function (x) {
        return x.id == record.id;
      });

      if (item) {
        item.state = state;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrder.prototype.downloadContract = function () {};

  PurchaseShipOrder.prototype.verifyWithMemo = function (record, state) {
    var _this = this;

    this.$modal.open(chat_modify_memo["a" /* default */], {}, {
      title: this.$t('action.verify_mome')
    }).subscribe(function (data) {
      _this.innerAction.setActionAPI('ship_order/change_ship_order_state', common_service["a" /* CommonService */].getMenuCode());

      _this.publicService.modify(new http["RequestParams"]({
        order_ids: [record.id],
        old_state: record.state,
        new_state: state,
        approve_memo: data
      }, {
        loading: _this.loadingService,
        innerAction: _this.innerAction
      })).subscribe(function (data) {
        _this.$message.success('操作成功');

        var item = _this.data.find(function (x) {
          return x.id == record.id;
        });

        if (item) {
          item.state = state;
        }
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseShipOrder.prototype.onMakePackageOrder = function () {
    return tslib_es6["b" /* __awaiter */](this, void 0, void 0, function () {
      var _loop_1, this_1, i, state_1;

      var _this = this;

      return tslib_es6["e" /* __generator */](this, function (_a) {
        _loop_1 = function _loop_1(i) {
          var item = this_1.data.find(function (x) {
            return x.id == _this.selectedRowKeys[i];
          });

          if (item && item.state !== 'approved' && item && item.state !== 'approved/package') {
            this_1.$message.error('采购合同状态必须是 approved 或者 approved/package');
            return {
              value: void 0
            };
          }
        };

        this_1 = this;

        for (i in this.selectedRowKeys) {
          state_1 = _loop_1(i);
          if (Object(esm_typeof["a" /* default */])(state_1) === "object") return [2
          /*return*/
          , state_1.value];
        }

        this.innerAction.setActionAPI('ship_order/query_ship_order_items', common_service["a" /* CommonService */].getMenuCode());
        this.publicService.query(new http["RequestParams"]({
          order_ids: this.selectedRowKeys
        }, {
          loading: this.loadingService,
          innerAction: this.innerAction
        })).subscribe(function (data) {
          _this.$modal.open(make_package_order["a" /* default */], {
            lines: data,
            ids: _this.selectedRowKeys
          }, {
            title: _this.$t('action.make_package_order'),
            width: '1300px'
          }).subscribe(function (data) {
            _this.$message.success('Create Success');
          }, function (err) {
            _this.$message.error(err.message);
          });
        }, function (err) {
          _this.$message.error(err.message);
        });
        return [2
        /*return*/
        ];
      });
    });
  };

  PurchaseShipOrder.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseShipOrder.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  PurchaseShipOrder.prototype.showLog = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('每次只能查看一条数据的日志');
      return;
    }

    this.$modal.open(log_view["a" /* default */], {
      object_name: 'order2',
      is_special_table: true,
      record_code: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showlog'),
      width: '1000px'
    }).subscribe(function () {//
    }, function (err) {
      _this.$message.error('error');
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseShipOrder.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseShipOrder.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrder.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrder.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrder.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrder.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrder.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrder.prototype, "getVendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseShipOrder.prototype, "addCommonPageInfo", void 0);

  PurchaseShipOrder = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-ship-order'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      UpdateProductQtyCode: update_product_qty_code["a" /* default */],
      CommonPage: common_page["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */]
    }
  })], PurchaseShipOrder);
  return PurchaseShipOrder;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_ship_ordervue_type_script_lang_ts_ = (purchase_ship_ordervue_type_script_lang_ts_PurchaseShipOrder);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-ship-order.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_ship_ordervue_type_script_lang_ts_ = (purchase_ship_ordervue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-ship-order.vue?vue&type=custom&index=0&blockType=i18n
var purchase_ship_ordervue_type_custom_index_0_blockType_i18n = __webpack_require__("203a");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-ship-order.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_ship_ordervue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_ship_ordervue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_ship_ordervue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_ship_order = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "581a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-ship-order-edit.vue?vue&type=template&id=6520d8bb&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('PurchaseShipOrderEdit',{attrs:{"info":[]}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-ship-order-edit.vue?vue&type=template&id=6520d8bb&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/components/purchase/purchase-ship-order-edit.vue + 4 modules
var purchase_ship_order_edit = __webpack_require__("cda4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-ship-order-edit.vue?vue&type=script&lang=ts&






var purchase_ship_order_editvue_type_script_lang_ts_PurchaseShipOrderEditPage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseShipOrderEditPage, _super);

  function PurchaseShipOrderEditPage() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], PurchaseShipOrderEditPage.prototype, "pageContainer", void 0);

  PurchaseShipOrderEditPage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-ship-order-edit'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      PurchaseShipOrderEdit: purchase_ship_order_edit["a" /* default */]
    }
  })], PurchaseShipOrderEditPage);
  return PurchaseShipOrderEditPage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_ship_order_editvue_type_script_lang_ts_ = (purchase_ship_order_editvue_type_script_lang_ts_PurchaseShipOrderEditPage);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-ship-order-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_ship_order_editvue_type_script_lang_ts_ = (purchase_ship_order_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/purchase/purchase-ship-order-edit.vue?vue&type=style&index=0&lang=css&
var purchase_ship_order_editvue_type_style_index_0_lang_css_ = __webpack_require__("6271");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-ship-order-edit.vue?vue&type=custom&index=0&blockType=i18n
var purchase_ship_order_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("f820");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-ship-order-edit.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_ship_order_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_ship_order_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_ship_order_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_purchase_ship_order_edit = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "5a79":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipping_plan_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d74e");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipping_plan_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipping_plan_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipping_plan_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "61ae":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-package-manage.vue?vue&type=template&id=c4599328&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":3,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 },"actions":true},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.source_doc1')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['source_doc1']),expression:"['source_doc1']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.package_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['package_code']),expression:"['package_code']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.company_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['company_name', { initialValue: '' }]),expression:"['company_name', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-select-option',{key:"woltu",attrs:{"value":"woltu"}},[_vm._v(" Woltu ")]),_c('a-select-option',{key:"eugad",attrs:{"value":"eugad"}},[_vm._v(" EUGAD ")]),_c('a-select-option',{key:"situ",attrs:{"value":"situ"}},[_vm._v(" Situ ")]),_c('a-select-option',{key:"elight",attrs:{"value":"elight"}},[_vm._v(" Elight ")]),_c('a-select-option',{key:"wowo",attrs:{"value":"wowo"}},[_vm._v(" Wowo ")]),_c('a-select-option',{key:"meteorsrain",attrs:{"value":"meteorsrain"}},[_vm._v(" Meteorsrain ")]),_c('a-select-option',{key:"brichimon",attrs:{"value":"brichimon"}},[_vm._v(" BRICHIMON LIMITED ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PackageOrderState),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.create_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['create_date']),expression:"['create_date']"}],style:({ width: '200px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.out_number')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['out_number']),expression:"['out_number']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.bl_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['bl_code']),expression:"['bl_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.yd_memo')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['yd_memo', { initialValue: '' }]),expression:"['yd_memo', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{key:"not_null",attrs:{"value":"not_null"}},[_vm._v(_vm._s(_vm.$t('action.not_null')))]),_c('a-radio-button',{key:"null",attrs:{"value":"null"}},[_vm._v(_vm._s(_vm.$t('action.null')))])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.bl_finish_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['bl_finish_date']),expression:"['bl_finish_date']"}],style:({ width: '200px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.bl_finish_date')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'is_bl_finish_date',
                        { initialValue: '' }
                    ]),expression:"[\n                        'is_bl_finish_date',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{key:"not_null",attrs:{"value":"not_null"}},[_vm._v(_vm._s(_vm.$t('action.not_null')))]),_c('a-radio-button',{key:"null",attrs:{"value":"null"}},[_vm._v(_vm._s(_vm.$t('action.null')))])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onBatchModify()}}},[_vm._v(_vm._s(_vm.$t('action.batch_modify')))]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onUpdateState()}}},[_vm._v(_vm._s(_vm.$t('action.update_state')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.onCalcNumber()}}},[_vm._v(_vm._s(_vm.$t('action.calc_number')))]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onFlagPd()}}},[_vm._v(_vm._s(_vm.$t('action.flag_pd')))]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onSyncEta()}}},[_vm._v(_vm._s(_vm.$t('action.sync_eta')))]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.updatePackageLogistics()}}},[_vm._v(_vm._s(_vm.$t('action.updatePackageLogistics')))]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.exportPackageOrder}},[_vm._v(_vm._s(_vm.$t('action.export_package_order')))]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.exportPackageOrderSales}},[_vm._v(_vm._s(_vm.$t('action.export_package_order_sales')))]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.exportPackageCheckOutData}},[_vm._v(_vm._s(_vm.$t('action.export_package_checkout_data')))])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v(_vm._s(_vm.$t('action.export'))),_c('a-icon',{attrs:{"type":"down"}})],1)],1),_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onUpdateEta()}}},[_vm._v(_vm._s(_vm.$t('action.update_eta')))]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.onImportEta()}}},[_vm._v(_vm._s(_vm.$t('action.import_eta')))])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v(_vm._s(_vm.$t('action.eta_operate'))),_c('a-icon',{attrs:{"type":"down"}})],1)],1),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left","disabled":!_vm.selectedRowKeys.length},on:{"confirm":function($event){return _vm.onBatchDelete()}}},[_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length}},[_vm._v(_vm._s(_vm.$t('action.delete')))])],1),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.showLog}},[_vm._v(_vm._s(_vm.$t('action.showlog'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"state",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PackageOrderState'))))])]}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(row.state == 'comfirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(
                                    [
                                        'approved',
                                        'process',
                                        'waiting',
                                        'wait'
                                    ].includes(row.state)
                                )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'ship')}}},[_vm._v(" "+_vm._s(_vm.$t('action.ship'))+" ")]):_vm._e(),(row.state == 'ship')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'process')}}},[_vm._v(" "+_vm._s(_vm.$t('action.process_clearance'))+" ")]):_vm._e(),(row.state == 'process')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'waiting')}}},[_vm._v(" "+_vm._s(_vm.$t('action.waiting_arrange_in'))+" ")]):_vm._e(),(row.state == 'waiting')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'wait')}}},[_vm._v(" "+_vm._s(_vm.$t('action.waiting_in'))+" ")]):_vm._e(),(row.state == 'wait')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'land')}}},[_vm._v(" "+_vm._s(_vm.$t('action.land'))+" ")]):_vm._e(),(row.state == 'cancel')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.set_to_draft'))+" ")]):_vm._e(),(
                                    [
                                        'approved',
                                        'confirm',
                                        'ship'
                                    ].includes(row.state)
                                )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'cancel')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete')))])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}],null,false,4233814371)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":1500,"scrollY":400},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"state",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'PackageOrderState'))))])]}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])]}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'confirm')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(row.state == 'comfirm')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(
                                [
                                    'approved',
                                    'process',
                                    'waiting',
                                    'wait'
                                ].includes(row.state)
                            )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'ship')}}},[_vm._v(" "+_vm._s(_vm.$t('action.ship'))+" ")]):_vm._e(),(row.state == 'ship')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'process')}}},[_vm._v(" "+_vm._s(_vm.$t('action.process_clearance'))+" ")]):_vm._e(),(row.state == 'process')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'waiting')}}},[_vm._v(" "+_vm._s(_vm.$t('action.waiting_arrange_in'))+" ")]):_vm._e(),(row.state == 'waiting')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'wait')}}},[_vm._v(" "+_vm._s(_vm.$t('action.waiting_in'))+" ")]):_vm._e(),(row.state == 'wait')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'land')}}},[_vm._v(" "+_vm._s(_vm.$t('action.land'))+" ")]):_vm._e(),(row.state == 'cancel')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.set_to_draft'))+" ")]):_vm._e(),(
                                ['approved', 'confirm', 'ship'].includes(
                                    row.state
                                )
                            )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'cancel')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete')))])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-package-manage.vue?vue&type=template&id=c4599328&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-contract.vue + 4 modules
var add_replenish_contract = __webpack_require__("fba3");

// EXTERNAL MODULE: ./src/components/purchase/purchase-return.vue + 4 modules
var purchase_return = __webpack_require__("fe3b");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/purchase/modify-package-order.vue + 4 modules
var modify_package_order = __webpack_require__("81eb");

// EXTERNAL MODULE: ./src/components/purchase/modify-package-logistic.vue + 4 modules
var modify_package_logistic = __webpack_require__("fb21");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/components/purchase/update-eta.vue + 4 modules
var update_eta = __webpack_require__("121b");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-package-manage.vue?vue&type=script&lang=ts&
































var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var purchase_package_managevue_type_script_lang_ts_PurchasePackageManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchasePackageManage, _super);

  function PurchasePackageManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = 'create_date desc';
    _this.columnList = [];
    _this.allNameAuth = [];
    _this.groupbyList = [];
    _this.queryConsition = [];
    _this.queryUrl = 'purchase_management/query_all_package_order';
    return _this;
  }

  Object.defineProperty(PurchasePackageManage.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchasePackageManage.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
  };

  PurchasePackageManage.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };
  /**
   * 获取订单数据
   */


  PurchasePackageManage.prototype.getDataList = function () {
    var _this = this;

    var params = {};
    this.getQueryCondition().then(function (nowConditions) {
      _this.queryConsition = nowConditions;

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data.map(function (x) {
            x.ship_date = x.ship_date ? x.ship_date.toString().substr(0, 10) : '';
            x.land_date = x.land_date ? x.land_date.toString().substr(0, 10) : '';
            x.etd_date = x.etd_date ? x.etd_date.toString().substr(0, 10) : '';
            x.af_date = x.af_date ? x.af_date.toString().substr(0, 10) : '';
            return x;
          });
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchasePackageManage.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
          package_code: 'like',
          source_doc1: 'in_or_like',
          name: 'in_or_like',
          warehouse_id: 'like',
          default_code: 'in_or_like',
          out_number: 'like',
          bl_code: 'in_or_like'
        }, form_config["a" /* formConfig */].condition));
        var nowConditions = [];

        for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
          var item = _a[_i];

          if (item.value.constructor == Array && item.operate !== 'in') {
            if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '>=',
                value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
              });
            }

            if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '<=',
                value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
              });
            }
          } else {
            nowConditions.push(item);
          }
        }

        for (var _b = 0, nowConditions_1 = nowConditions; _b < nowConditions_1.length; _b++) {
          var i = nowConditions_1[_b];

          if (i.query_name == 'is_bl_finish_date') {
            i.operate = i.value == 'null' ? 'null' : i.value == 'not_null' ? 'not null' : '=';

            if (i.operate != '=') {
              i.value = i.operate;
            }

            i.query_name = 'bl_finish_date';
          }

          if (i.query_name == 'yd_memo') {
            i.operate = i.value == 'null' ? 'null' : i.value == 'not_null' ? 'not null' : '=';

            if (i.operate != '=') {
              i.value = i.operate;
            }
          }
        }

        reslove(nowConditions);
      }).catch(function (err) {
        _this.$message.error(JSON.stringify(err));
      });
    });
  };

  PurchasePackageManage.prototype.onCreate = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_requirement/query_pre_make_order_lines', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$modal.open(add_replenish_contract["a" /* default */], {
        info: data,
        systemUsers: _this.systemUsers,
        vendorList: _this.vendorFullNameList
      }, {
        title: _this.$t('action.add_replenishment_contract'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.returnPurchase = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_requirement/query_pre_make_order_lines', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$modal.open(purchase_return["a" /* default */], {
        info: data
      }, {
        title: _this.$t('action.purchase_return'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePackageManage.prototype.getVendorName = function (code) {
    var ret = code;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePackageManage.prototype.getCompanyName = function (code) {
    var ret = code;
    var item = this.companyList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePackageManage.prototype.onRowClick = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/query_package_order_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      package_id: row.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      data[0].id = row.id;
      data[0].package_lines = data[0].package_lines.map(function (x) {
        x['is_change_sku'] = x.is_change_sku ? true : false;
        return x;
      });
      var index = 'purchasepackageedit' + row.id;
      var params = {
        index: index,
        id: row.id,
        info: data,
        component: 'PurchasePackageEdit'
      };

      _this.addCommonPageInfo(params);

      var baseName = _this.$t('page_name');

      _this.$router.push({
        name: 'common-page',
        path: "/common-page/" + index,
        params: {
          id: index,
          name: row.name + '-' + baseName
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchasePackageManage.prototype.onBatchModify = function () {
    var _this = this;

    this.$modal.open(modify_package_order["a" /* default */], {
      ids: this.selectedRowKeys
    }, {
      title: this.$t('action.batch_modify'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('Update Success');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onUpdateEta = function () {
    var _this = this;

    this.$modal.open(update_eta["a" /* default */], {
      ids: this.selectedRowKeys
    }, {
      title: this.$t('action.update_eta'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('Update Success');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onDelete = function (record) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_package_order', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      package_id_list: [record.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onBatchDelete = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_package_order', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      package_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onVerify = function (record, state) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/update_package_order_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      package_id_list: [record.id],
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      var item = _this.data.find(function (x) {
        return x.id == record.id;
      });

      if (item) {
        item.state = state;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.exportPackageOrderSales = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_package_order_for_operation&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&package_id_list=' + urlParams);
  };

  PurchasePackageManage.prototype.exportPackageOrder = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_package_order&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&package_id_list=' + urlParams);
  };

  PurchasePackageManage.prototype.exportPackageCheckOutData = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_management/export_need_purchase_checkout&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&package_id_list=' + urlParams);
  };

  PurchasePackageManage.prototype.onSyncEta = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/sync_package_eta_date', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      package_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onFlagPd = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/mass_mark_as_is_pd', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      package_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onCalcNumber = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/calculate_package_need_checkout', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onUpdateState = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/change_package_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      package_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onImportEta = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/system_api/upload?inner_action=purchase_management/import_package_eta_clearance_bl_finish_date&menu_code=' + common_service["a" /* CommonService */].getMenuCode()
    }, {
      title: '导入ETA,电放, 清关资料时间',
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  PurchasePackageManage.prototype.updatePackageLogistics = function () {
    var _this = this;

    this.$modal.open(modify_package_logistic["a" /* default */], {
      ids: this.selectedRowKeys
    }, {
      title: this.$t('action.updatePackageLogistics'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('Update Success');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePackageManage.prototype.showLog = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('每次只能查看一条数据的日志');
      return;
    }

    this.$modal.open(log_view["a" /* default */], {
      object_name: 'package',
      is_special_table: true,
      record_code: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showlog'),
      width: '1000px'
    }).subscribe(function () {//
    }, function (err) {
      _this.$message.error('error');
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchasePackageManage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchasePackageManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageManage.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageManage.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageManage.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageManage.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageManage.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageManage.prototype, "getVendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackageManage.prototype, "addCommonPageInfo", void 0);

  PurchasePackageManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-package-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddReplenishContract: add_replenish_contract["a" /* default */],
      PurchaseReturn: purchase_return["a" /* default */],
      CommonPage: common_page["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */]
    }
  })], PurchasePackageManage);
  return PurchasePackageManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_package_managevue_type_script_lang_ts_ = (purchase_package_managevue_type_script_lang_ts_PurchasePackageManage);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-package-manage.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_package_managevue_type_script_lang_ts_ = (purchase_package_managevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-package-manage.vue?vue&type=custom&index=0&blockType=i18n
var purchase_package_managevue_type_custom_index_0_blockType_i18n = __webpack_require__("f7b9");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-package-manage.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_package_managevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_package_managevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_package_managevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_package_manage = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "6271":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f7a8");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "65a5":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "65d1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_de_po_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("6a89");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_de_po_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_de_po_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_de_po_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "6a89":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"name":"Name","vendor":"Vendor","company_name":"Company Name","state":"State"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","save":"Save","cancel":"Cancel","confirm":"Confirm","export":"Export Excel","import":"Import Excel","view_logs":"Logs","more":"More","discard":"Discard","export_unfinish_line":"Export Unfinish","edit_finish_qty_vendor":"Multi Edit Finish Qty and Vendor","change_purchase_info":"Multi Change Purchase Info","export_product_specification":"Export Manual Specification","view_purchase_change_log":"Logs","update_btn":"More","cancel_attention":"Cancel Attention","force_finish_trace":"Finish Purchase Item","unfinish_trace":"Unfinish Purchase Item","qc_confirm_ship":"QC Confirm Ship","purchase_finish_dlg":"Finish Item","cancel_attention_dlg":"Cancel Attention Item","add_trace_memo_dlg":"Add Trace Memo","import_trace_memo_dlg":"Import Trace Memo","sync_product_supplier":"Sync Product Supplier","showlog":"View Log"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"name":"Name","vendor":"供应商","company_name":"公司","state":"状态"},"action":{"create":"新建","edit":"编辑","delete":"删除","ok":"确定","save":"保存","cancel":"取消","confirm":"确认","export":"导出Excel","import":"导入Excel","view_logs":"日志","more":"更多操作","discard":"丢弃","export_unfinish_line":"导出未完成","edit_finish_qty_vendor":"批量变更发货数量和供应商","change_purchase_info":"批量修改采购信息","export_product_specification":"导出说明书和工艺单","view_purchase_change_log":"日志","update_btn":"更多","cancel_attention":"取消关注","force_finish_trace":"设置跟踪完成","unfinish_trace":"设置跟踪未完成","qc_confirm_ship":"QC质检完成","purchase_finish_dlg":"强制完成","cancel_attention_dlg":"取消关注","add_trace_memo_dlg":"添加跟踪备注","import_trace_memo_dlg":"导入跟踪备注","sync_product_supplier":"Sync Product Supplier","showlog":"查看日志"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "6e00":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-cost-report.vue?vue&type=template&id=efe8087a&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onCreateSaleTrend}},[_vm._v(_vm._s(_vm.$t('action.create')))])]},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2},on:{"submit":_vm.getPurchaseCostData},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_name', { initialValue: '' }]),expression:"['vendor_name', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category', { initialValue: '' }]),expression:"['z_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category', { initialValue: '' }]),expression:"['z_sub_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.query_type')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['query_type', { initialValue: 'month' }]),expression:"['query_type', { initialValue: 'month' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small"},on:{"change":function (e) { return _vm.onChangeQueryType(e); }}},[_c('a-select-option',{key:"year",attrs:{"value":"year","title":"By Year/按年"}},[_vm._v(" By Year/按年 ")]),_c('a-select-option',{key:"season",attrs:{"value":"season","title":"By Quarter/按季度"}},[_vm._v(" By Quarter/按季度 ")]),_c('a-select-option',{key:"month",attrs:{"value":"month","title":"By Month/按月"}},[_vm._v(" By Month/按月 ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.year')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['year', { initialValue: '2021' }]),expression:"['year', { initialValue: '2021' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1),(_vm.showToYear)?_c('span',{staticStyle:{"color":"red"}},[_vm._v(" ~ ")]):_vm._e(),(_vm.showToYear)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['to_year', { initialValue: '2021' }]),expression:"['to_year', { initialValue: '2021' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1):_vm._e()],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.exportData}},[_vm._v("Export")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.tableData,"page":_vm.pageService,"rowKey":"default_code","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, select_rows) {
                    _vm.selectedRows = select_rows
                    _vm.selectedRowKeys = keys
                    this$1.showCostChart(select_rows)
                }
            },"columns":_vm.columnList,"scroll":{ y: 390, x: _vm.table_width }},on:{"on-page-change":_vm.getPurchaseCostData,"onClick":function (row) {
                    this$1.selectedRowKeys = [row]
                    var curRow = this$1.tableData.filter(
                        function (item) { return item.default_code === row; }
                    )
                    this$1.showCostChart(curRow)
                },"change":function (sorter) { return _vm.onTableChange(sorter); }}})],1),_c('a-card',{attrs:{"title":"趋势图"}},[_c('ve-line',{attrs:{"data":_vm.purchaseCostCharData}})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-cost-report.vue?vue&type=template&id=efe8087a&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.to-fixed.js
var es_number_to_fixed = __webpack_require__("b680");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/product.purchase.service.ts
var product_purchase_service = __webpack_require__("b27d");

// EXTERNAL MODULE: ./src/services/purchase.service.ts
var purchase_service = __webpack_require__("0d91");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-cost-report.vue?vue&type=script&lang=ts&



















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_cost_reportvue_type_script_lang_ts_PurchaseCostReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseCostReport, _super);

  function PurchaseCostReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.productPurchaseService = new product_purchase_service["a" /* ProductPurchaseService */]();
    _this.purchaseService = new purchase_service["a" /* PurchaseService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.vender_data = [];
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.orderBy = '';
    _this.table_width = 350;
    _this.fixed_width = 350;
    _this.selectedRows = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.columnList = [];
    _this.tableData = [];
    _this.showToYear = false;
    _this.purchaseCostCharData = [];
    _this.query_type = 'year';
    return _this;
  }

  PurchaseCostReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  PurchaseCostReport.prototype.onChangeQueryType = function (value) {
    if (value == 'year') {
      this.showToYear = true;
    } else {
      this.showToYear = false;
    }
  };

  PurchaseCostReport.prototype.created = function () {
    var _this = this;

    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  PurchaseCostReport.prototype.mounted = function () {
    this.columnList = this.getBasicColumnInfo();
  };

  PurchaseCostReport.prototype.getBasicColumnInfo = function () {
    return [{
      dataIndex: 'default_code',
      key: 'default_code',
      title: this.$t('columns.sku'),
      width: 100,
      align: 'left'
    }, {
      dataIndex: 'vendor_name',
      key: 'vendor_name',
      title: this.$t('columns.vendor_name'),
      width: 60,
      align: 'center'
    }, {
      dataIndex: 'z_category',
      key: 'z_category',
      title: this.$t('columns.cn_category'),
      width: 80,
      align: 'left'
    }, {
      dataIndex: 'z_sub_category',
      key: 'z_sub_category',
      title: this.$t('columns.cn_sub_category'),
      width: 110,
      align: 'left'
    }];
  };

  PurchaseCostReport.prototype.showCostChart = function (selectedRows) {
    var row_list = [];

    for (var column_index in this.columnList) {
      var column_info = this.columnList[column_index];

      if (column_info.children) {
        for (var children_index in column_info.children) {
          var columnName = column_info.children[children_index].key;

          if (this.isFilterColumn(columnName)) {
            continue;
          }

          columnName = columnName.replace('_month', '').replace('_price', '').replace('_', '-');
          var row = {
            data_date: columnName
          };
          row_list.push(row);
        }
      } else {
        var columnName = this.columnList[column_index].key;

        if (this.isFilterColumn(columnName)) {
          continue;
        }

        var row = {
          data_date: columnName
        };
        row_list.push(row);
      }
    }

    this.purchaseCostCharData = {
      columns: ['data_date'],
      rows: row_list
    };

    for (var _i = 0, selectedRows_1 = selectedRows; _i < selectedRows_1.length; _i++) {
      var row = selectedRows_1[_i];
      var default_code = row['default_code'];

      if (this.purchaseCostCharData.columns.indexOf(default_code) < 0) {
        this.purchaseCostCharData.columns.push(default_code);
        var cell_index = 0;

        for (var column_index in this.columnList) {
          var column_info = this.columnList[column_index];

          if (column_info.children) {
            for (var children_index in column_info.children) {
              var columnName = column_info.children[children_index].key;

              if (this.isFilterColumn(columnName)) {
                continue;
              }

              this.purchaseCostCharData.rows[cell_index][default_code] = row[columnName];
              cell_index += 1;
            }
          } else {
            var columnName = this.columnList[column_index].key;

            if (this.isFilterColumn(columnName)) {
              continue;
            }

            this.purchaseCostCharData.rows[column_index][default_code] = row[columnName];
            cell_index += 1;
          }
        }
      }
    }
  };

  PurchaseCostReport.prototype.isFilterColumn = function (columnName) {
    var fixed_column = ['default_code', 'vendor_name', 'z_category', 'z_sub_category'];

    if (columnName.indexOf('_qty') != -1) {
      return true;
    }

    if (fixed_column.indexOf(columnName) != -1) {
      return true;
    }

    return false;
  };

  PurchaseCostReport.prototype.getPurchaseCostData = function () {
    var _this = this;

    this.columnList = this.getBasicColumnInfo();
    this.getQueryCondition().then(function (params) {
      _this.purchaseService.query_all_purchase_price_report(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        var new_data = [];
        var year_list = [];

        var new_data_dict = _this.getMonthNewData(data);

        new_data = new_data_dict.data;
        year_list = new_data_dict.date;
        var other_width = 0;

        if (_this.query_type == 'month') {
          other_width = _this.getMonthOtherColumns(year_list);
        } else if (_this.query_type == 'year') {
          other_width = _this.getYearOtherColumns(year_list);
        } else {
          other_width = _this.getSeasonOtherColumns(year_list);
        }

        _this.table_width = other_width + _this.fixed_width;
        _this.tableData = new_data;
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  PurchaseCostReport.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        if (values['vendor_name'] == '' || values['vendor_name'].length == 0) {
          delete values['vendor_name'];
        }

        if (values['z_category'] == '' || values['z_category'].length == 0) {
          delete values['z_category'];
        }

        if (values['z_sub_category'] == '' || values['z_sub_category'].length == 0) {
          delete values['z_sub_category'];
        }

        var params = common_service["a" /* CommonService */].createQueryCondition(values, {
          year: '=',
          vendor_name: 'in',
          z_sub_category: 'in'
        });
        _this.query_type = '';
        var query_condition = params['query_condition'];
        var new_query_condition = [];

        for (var index in query_condition) {
          if (query_condition[index]['query_name'] == 'query_type') {
            _this.query_type = query_condition[index]['value'];
            params['query_type'] = _this.query_type;
            continue;
          }

          new_query_condition.push(query_condition[index]);
        }

        if (_this.query_type == '') {
          _this.$message.info('请选择数据查询类型! ');

          return;
        }

        params['query_condition'] = new_query_condition;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        reslove(params);
      }).catch(function (err) {// 异常处理
      });
    });
  };

  PurchaseCostReport.prototype.getMonthNewData = function (data) {
    var new_data = [];
    var year_list = [];

    for (var index in data) {
      var item = data[index];

      for (var year_data_index in item.year_data) {
        var year_data_item = item.year_data[year_data_index];
        var tmpl_year = year_data_item.year;

        if (year_list.includes(tmpl_year) == false) {
          year_list.push(tmpl_year);
        }

        for (var key in year_data_item) {
          if (key == 'year') {
            continue;
          }

          item[tmpl_year + '_' + key] = year_data_item[key];
        }
      }

      delete item.year_data;
      new_data.push(item);
    }

    return {
      data: new_data,
      date: year_list
    };
  };

  PurchaseCostReport.prototype.getSeasonOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;
    var season_list = ['1', '2', '3', '4'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var season_index in season_list) {
        var season = season_list[season_index];
        var column_info = {
          title: this.$t('columns.season_' + season) + '/' + year,
          children: [{
            dataIndex: year + '_season_' + season + '_price',
            key: year + '_season_' + season + '_price',
            title: this.$t('columns.price'),
            align: 'right',
            width: unit_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }, {
            dataIndex: year + '_season_' + season + '_qty',
            key: year + '_season_' + season + '_qty',
            title: this.$t('columns.qty'),
            align: 'right',
            width: reduce_cost_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }]
        };
        this.columnList.push(column_info);
      }
    }

    return (unit_width + reduce_cost_width) * year_list.length * season_list.length;
  };

  PurchaseCostReport.prototype.getMonthOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;
    var month_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var month_index in month_list) {
        var month = month_list[month_index];
        var column_info = {
          title: this.$t('columns.month_' + month) + '/' + year,
          children: [{
            dataIndex: year + '_month_' + month + '_price',
            key: year + '_month_' + month + '_price',
            title: this.$t('columns.price'),
            align: 'right',
            width: unit_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }, {
            dataIndex: year + '_month_' + month + '_qty',
            key: year + '_month_' + month + '_qty',
            title: this.$t('columns.qty'),
            align: 'right',
            width: reduce_cost_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }]
        };
        this.columnList.push(column_info);
      }
    }

    return (unit_width + reduce_cost_width) * year_list.length * month_list.length;
  };

  PurchaseCostReport.prototype.getYearOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;

    for (var year_index in year_list) {
      var year = year_list[year_index];
      var column_info = {
        title: year,
        children: [{
          dataIndex: year + '_price',
          key: year + '_price',
          title: this.$t('columns.price'),
          align: 'right',
          width: unit_width,
          customRender: function customRender(value, row, index) {
            if (!value) {
              return 0;
            }

            return value.toFixed(2);
          }
        }, {
          dataIndex: year + '_qty',
          key: year + '_qty',
          title: this.$t('columns.qty'),
          align: 'right',
          width: reduce_cost_width,
          customRender: function customRender(value, row, index) {
            if (!value) {
              return 0;
            }

            return value.toFixed(2);
          }
        }]
      };
      this.columnList.push(column_info);
    }

    return (unit_width + reduce_cost_width) * year_list.length;
  };

  PurchaseCostReport.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getPurchaseCostData();
  };

  PurchaseCostReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseCostReport.prototype.exportData = function () {
    this.getQueryCondition().then(function (x) {
      common_service["a" /* CommonService */].exportData('/purchase_requirement/export_purchase_price_report', {
        query_condition: x.query_condition
      });
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseCostReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseCostReport.prototype, "pageContainer", void 0);

  PurchaseCostReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-cost-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseCostReport);
  return PurchaseCostReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_cost_reportvue_type_script_lang_ts_ = (purchase_cost_reportvue_type_script_lang_ts_PurchaseCostReport);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-cost-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_cost_reportvue_type_script_lang_ts_ = (purchase_cost_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-cost-report.vue?vue&type=custom&index=0&blockType=i18n
var purchase_cost_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("5270");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-cost-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_cost_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_cost_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_cost_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_cost_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "7a3a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_pre_make_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9fa8");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_pre_make_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_pre_make_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_pre_make_order_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "8015":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/replenishment-demand.vue?vue&type=template&id=2dbe5fee&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 1 },"actions":true},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.req_type')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['req_type', { initialValue: '' }]),expression:"['req_type', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.ReplenishmentType),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.company_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['company_id', { initialValue: '' }]),expression:"['company_id', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.companyList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.user_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_id']),expression:"['user_id']"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.date_req')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['date_req']),expression:"['date_req']"}],style:({ width: '240px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.ReplenishmentState),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.is_change_give_date')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'is_change_give_date',
                        { initialValue: '' }
                    ]),expression:"[\n                        'is_change_give_date',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category', { initialValue: '' }]),expression:"['z_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category', { initialValue: '' }]),expression:"['z_sub_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('new'),expression:"'new'"}],attrs:{"type":"primary"},on:{"click":_vm.onCreate}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")]),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('audit'),expression:"'audit'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.onBatchVerify('approved')}}},[_vm._v(_vm._s(_vm.$t('action.verify'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onSplit()}}},[_vm._v("补货明细拆分 ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left","disabled":!_vm.selectedRowKeys.length},on:{"confirm":function($event){return _vm.onBatchDelete()}}},[_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('delete'),expression:"'delete'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('import'),expression:"'import'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.importInfo}},[_vm._v(_vm._s(_vm.$t('action.import'))+" ")]),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('show_log'),expression:"'show_log'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.showLog}},[_vm._v(_vm._s(_vm.$t('action.showlog'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"name",fn:function(text, row){return _c('span',{},[_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])])}},{key:"company",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getCompanyName(text)))])]}},{key:"state",fn:function(text, row){return _c('span',{},[_c('span',{class:row.state == 'refuse' ? 'refuse' : ''},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'ReplenishmentState'))))])])}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'to approve')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(row.state == 'cancel')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'to approve')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(
                                    row.state == 'to approve' ||
                                        row.state == 'draft'
                                )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'cancel')}}},[_vm._v(" "+_vm._s(_vm.$t('action.cancel'))+" ")]):_vm._e(),(row.state == 'refuse')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'refuse')}}},[_vm._v(" "+_vm._s(_vm.$t('action.refuse'))+" ")]):_vm._e(),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}],null,false,624805296)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":1500,"scrollY":400},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"name",fn:function(text, row){return _c('span',{},[_c('a',{on:{"click":function($event){$event.stopPropagation();return _vm.onRowClick(row)}}},[_vm._v(_vm._s(row.name))])])}},{key:"company",fn:function(text){return [_c('span',[_vm._v(_vm._s(_vm.getCompanyName(text)))])]}},{key:"state",fn:function(text, row){return _c('span',{},[_c('span',{class:row.state == 'refuse' ? 'refuse' : ''},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'ReplenishmentState'))))])])}},{key:"operation",fn:function(row){return [_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":function($event){return _vm.onRowClick(row)}}},[_vm._v(" "+_vm._s(_vm.$t('columns.detail'))+" ")]),(row.state == 'to approve')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'approved')}}},[_vm._v(" "+_vm._s(_vm.$t('action.verify'))+" ")]):_vm._e(),(row.state == 'cancel')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'draft')}}},[_vm._v(" "+_vm._s(_vm.$t('action.reset'))+" ")]):_vm._e(),(row.state == 'draft')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'to approve')}}},[_vm._v(" "+_vm._s(_vm.$t('action.confirm'))+" ")]):_vm._e(),(
                                row.state == 'to approve' ||
                                    row.state == 'draft'
                            )?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'cancel')}}},[_vm._v(" "+_vm._s(_vm.$t('action.cancel'))+" ")]):_vm._e(),(row.state == 'refuse')?_c('a-menu-item',{on:{"click":function($event){return _vm.onVerify(row, 'refuse')}}},[_vm._v(" "+_vm._s(_vm.$t('action.refuse'))+" ")]):_vm._e(),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelete(row)}}},[_c('a-menu-item',{staticClass:"btnDel",staticStyle:{"cursor":"pointer","margin-left":"12px"}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1)],1),_c('a-button',[_vm._v(" "+_vm._s(_vm.$t('action.more'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/replenishment-demand.vue?vue&type=template&id=2dbe5fee&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/purchase/replenish-split.vue + 4 modules
var replenish_split = __webpack_require__("5c69");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/replenishment-demand.vue?vue&type=script&lang=ts&


























var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var replenishment_demandvue_type_script_lang_ts_ReplenishmentDemand =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ReplenishmentDemand, _super);

  function ReplenishmentDemand() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.reportService = new report_service["a" /* ReportService */](); // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.orderBy = 'create_date desc';
    _this.current = null;
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.columnList = [];
    _this.allNameAuth = [];
    _this.groupbyList = [];
    _this.queryConsition = [];
    _this.queryUrl = 'purchase/query_all_purchase_requirement';
    return _this;
  }

  ReplenishmentDemand.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  Object.defineProperty(ReplenishmentDemand.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ReplenishmentDemand.prototype.created = function () {
    var _this = this;

    this.getcompany();
    this.getSystemuser();
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ReplenishmentDemand.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  ReplenishmentDemand.prototype.calcStyle = function () {
    this.$nextTick(function () {
      var doms = window.document.getElementsByClassName('refuse');

      if (doms.length) {
        for (var x in doms) {
          if (doms[x] != undefined && doms[x].parentNode != undefined && doms[x].parentNode.parentNode != undefined && doms[x].parentNode.parentNode.parentNode != undefined) {
            var trDom = doms[x].parentNode.parentNode.parentNode;
            var cells = trDom.getElementsByTagName('td');

            for (var c = 0; c < cells.length; c++) {
              cells[c].style.color = '#d708da';
            }
          }
        }
      }
    });
  };

  ReplenishmentDemand.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  ReplenishmentDemand.prototype.getCompanyName = function (code) {
    var ret = code;
    var item = this.companyList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };
  /**
   * 获取订单数据
   */


  ReplenishmentDemand.prototype.getDataList = function () {
    var _this = this;

    var params = {};
    this.getQueryCondition().then(function (nowConditions) {
      _this.queryConsition = nowConditions;

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];

          _this.calcStyle();
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ReplenishmentDemand.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        if (_this.selectedList.length > 0) {
          values['z_sub_category'] = _this.selectedList;
        } else {
          delete values['z_sub_category'];
        }

        if (!values['z_category']) {
          delete values['z_category'];
        }

        var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
          name: 'like',
          default_code: 'in_or_like',
          z_sub_category: 'in'
        }, form_config["a" /* formConfig */].condition));
        var nowConditions = [];

        for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
          var item = _a[_i];

          if (item.value.constructor == Array && item.operate !== 'in') {
            if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '>=',
                value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
              });
            }

            if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
              nowConditions.push({
                query_name: item.query_name,
                operate: '<=',
                value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
              });
            }
          } else {
            nowConditions.push(item);
          }
        }

        reslove(nowConditions);
      }).catch(function (err) {
        _this.$message.error(JSON.stringify(err));
      });
    });
  };

  ReplenishmentDemand.prototype.onCreate = function () {
    this.$router.push({
      name: 'replenishment-edit'
    });
  };

  ReplenishmentDemand.prototype.exportInfo = function () {};

  ReplenishmentDemand.prototype.importInfo = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/system_api/upload?inner_action=purchase_management/import_purchase_requirement&menu_code=' + common_service["a" /* CommonService */].getMenuCode(),
      attachmentUrlPath: '/system/download_import_template?type=PurchaseRequirementImport'
    }, {
      title: 'Import',
      width: '1000px'
    }).subscribe(function (data) {// this.$message.success('操作成功')
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentDemand.prototype.onSplit = function () {
    var _this = this; // if(this.selectedRowKeys.length>1) {
    //     this.$message.error('只能选中一条信息进行拆分')
    // }


    var item = this.data.find(function (x) {
      return x.id == _this.selectedRowKeys[0];
    });

    if (!item) {
      return;
    }

    if (item.state != 'draft') {
      this.$message.error('只有草稿状态的数据才能进行拆分');
      return;
    }

    this.innerAction.setActionAPI('purchase_management/query_purchase_requirement_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      req_id: this.selectedRowKeys[0]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var row = _this.data.find(function (x) {
        return x.id == _this.selectedRowKeys[0];
      });

      if (row) {
        data[0]['user_purchase'] = row.user_purchase;
        data[0]['state'] = row.state;
        data[0]['purchase_date'] = row.purchase_date;
        data[0]['id'] = row.id;
      }

      _this.$modal.open(replenish_split["a" /* default */], {
        info: data[0],
        systemUsers: _this.systemUsers
      }, {
        title: _this.$t('action.replenish_split'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentDemand.prototype.onRowClick = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/query_purchase_requirement_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      req_id: row.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      data[0]['id'] = row.id; // data[0]['state'] = row.state

      var index = 'replenishmentedit' + row.id;
      var params = {
        index: index,
        id: row.id,
        info: data,
        component: 'ReplenishmentEdit'
      };

      _this.addCommonPageInfo(params);

      var baseName = _this.$t('page_name');

      _this.$router.push({
        name: 'common-page',
        path: "/common-page/" + index,
        params: {
          id: index,
          name: row.name + '-' + baseName
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentDemand.prototype.onBatchDelete = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_purchase_requirement', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      req_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentDemand.prototype.onDelete = function (record) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/delete_purchase_requirement', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      req_id_list: [record.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentDemand.prototype.onVerify = function (record, state) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/update_purchase_requirement_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      req_id_list: [record.id],
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      var item = _this.data.find(function (x) {
        return x.id == record.id;
      });

      if (item) {
        item.state = state;
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentDemand.prototype.onBatchVerify = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/update_purchase_requirement_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      req_id_list: this.selectedRowKeys,
      state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      var _loop_1 = function _loop_1(i) {
        var item = _this.data.find(function (x) {
          return x.id == i;
        });

        if (item) {
          item.state = state;
        }
      };

      for (var _i = 0, _a = _this.selectedRowKeys; _i < _a.length; _i++) {
        var i = _a[_i];

        _loop_1(i);
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReplenishmentDemand.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ReplenishmentDemand.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ReplenishmentDemand.prototype.showLog = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('每次只能查看一条数据的日志');
      return;
    }

    this.$modal.open(log_view["a" /* default */], {
      object_name: 'requirement',
      is_special_table: true,
      record_code: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showlog'),
      width: '1000px'
    }).subscribe(function () {//
    }, function (err) {
      _this.$message.error('error');
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ReplenishmentDemand.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ReplenishmentDemand.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentDemand.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentDemand.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentDemand.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentDemand.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('changeReplenish'), tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentDemand.prototype, "changeReplenish", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], ReplenishmentDemand.prototype, "addCommonPageInfo", void 0);

  ReplenishmentDemand = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'replenishment-demand'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      ReplenishSplit: replenish_split["a" /* default */],
      CommonPage: common_page["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */]
    }
  })], ReplenishmentDemand);
  return ReplenishmentDemand;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var replenishment_demandvue_type_script_lang_ts_ = (replenishment_demandvue_type_script_lang_ts_ReplenishmentDemand);
// CONCATENATED MODULE: ./src/pages/purchase/replenishment-demand.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_replenishment_demandvue_type_script_lang_ts_ = (replenishment_demandvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/replenishment-demand.vue?vue&type=custom&index=0&blockType=i18n
var replenishment_demandvue_type_custom_index_0_blockType_i18n = __webpack_require__("007e");

// CONCATENATED MODULE: ./src/pages/purchase/replenishment-demand.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_replenishment_demandvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof replenishment_demandvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(replenishment_demandvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var replenishment_demand = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "8429":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Package info","columns":{"package_name":"Package No.","warehouse":"Warehouse","default_code":"Product","package_qty":"数量","aktu_package_qty":"Aktu 数量","box_qty":"箱数","aktu_box_qty":"Aktu 箱数"},"action":{"create":"新建","more":"更多操作"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"货柜信息","columns":{"package_name":"货柜号","warehouse":"仓库","default_code":"Product","package_qty":"数量","aktu_package_qty":"Aktu 数量","box_qty":"箱数","aktu_box_qty":"Aktu 箱数"},"action":{"create":"新建","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "8595":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-give-date-report.vue?vue&type=template&id=3eaad7c6&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onCreateSaleTrend}},[_vm._v(_vm._s(_vm.$t('action.create')))])]},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2},on:{"submit":_vm.getPurchaseGiveDateData},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_name', { initialValue: '' }]),expression:"['vendor_name', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category', { initialValue: '' }]),expression:"['z_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category', { initialValue: '' }]),expression:"['z_sub_category', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.query_type')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['query_type', { initialValue: 'month' }]),expression:"['query_type', { initialValue: 'month' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small"},on:{"change":function (e) { return _vm.onChangeQueryType(e); }}},[_c('a-select-option',{key:"year",attrs:{"value":"year","title":"By Year/按年"}},[_vm._v(" By Year/按年 ")]),_c('a-select-option',{key:"season",attrs:{"value":"season","title":"By Quarter/按季度"}},[_vm._v(" By Quarter/按季度 ")]),_c('a-select-option',{key:"month",attrs:{"value":"month","title":"By Month/按月"}},[_vm._v(" By Month/按月 ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.year')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['year', { initialValue: '2021' }]),expression:"['year', { initialValue: '2021' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1),(_vm.showToYear)?_c('span',{staticStyle:{"color":"red"}},[_vm._v(" ~ ")]):_vm._e(),(_vm.showToYear)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['to_year', { initialValue: '2021' }]),expression:"['to_year', { initialValue: '2021' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1):_vm._e()],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.exportData}},[_vm._v("Export")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.tableData,"page":_vm.pageService,"rowKey":"default_code","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, select_rows) {
                    _vm.selectedRows = select_rows
                    _vm.selectedRowKeys = keys
                    this$1.showGiveDateChart(select_rows)
                }
            },"columns":_vm.columnList,"scroll":{ y: 390, x: _vm.table_width }},on:{"on-page-change":_vm.getPurchaseGiveDateData,"onClick":function (row) {
                    this$1.selectedRowKeys = [row]
                    var curRow = this$1.tableData.filter(
                        function (item) { return item.default_code === row; }
                    )
                    this$1.showGiveDateChart(curRow)
                },"change":function (sorter) { return _vm.onTableChange(sorter); }}})],1),_c('a-card',{attrs:{"title":"趋势图"}},[_c('ve-line',{attrs:{"data":_vm.purchaseGiveDateCharData}})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-give-date-report.vue?vue&type=template&id=3eaad7c6&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.to-fixed.js
var es_number_to_fixed = __webpack_require__("b680");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/product.purchase.service.ts
var product_purchase_service = __webpack_require__("b27d");

// EXTERNAL MODULE: ./src/services/purchase.service.ts
var purchase_service = __webpack_require__("0d91");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-give-date-report.vue?vue&type=script&lang=ts&



















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_give_date_reportvue_type_script_lang_ts_PurchaseGiveDateReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseGiveDateReport, _super);

  function PurchaseGiveDateReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.productPurchaseService = new product_purchase_service["a" /* ProductPurchaseService */]();
    _this.purchaseService = new purchase_service["a" /* PurchaseService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.vender_data = [];
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.orderBy = '';
    _this.table_width = 350;
    _this.fixed_width = 350;
    _this.selectedRows = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.columnList = [];
    _this.tableData = [];
    _this.showToYear = false;
    _this.purchaseGiveDateCharData = [];
    _this.query_type = 'year';
    return _this;
  }

  PurchaseGiveDateReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  PurchaseGiveDateReport.prototype.onChangeQueryType = function (value) {
    if (value == 'year') {
      this.showToYear = true;
    } else {
      this.showToYear = false;
    }
  };

  PurchaseGiveDateReport.prototype.created = function () {
    var _this = this;

    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  PurchaseGiveDateReport.prototype.mounted = function () {
    this.columnList = this.getBasicColumnInfo();
  };

  PurchaseGiveDateReport.prototype.getBasicColumnInfo = function () {
    return [{
      dataIndex: 'default_code',
      key: 'default_code',
      title: this.$t('columns.sku'),
      width: 100,
      align: 'left'
    }, {
      dataIndex: 'vendor_name',
      key: 'vendor_name',
      title: this.$t('columns.vendor_name'),
      width: 60,
      align: 'center'
    }, {
      dataIndex: 'z_category',
      key: 'z_category',
      title: this.$t('columns.cn_category'),
      width: 80,
      align: 'left'
    }, {
      dataIndex: 'z_sub_category',
      key: 'z_sub_category',
      title: this.$t('columns.cn_sub_category'),
      width: 110,
      align: 'left'
    }];
  };

  PurchaseGiveDateReport.prototype.showGiveDateChart = function (selectedRows) {
    var row_list = [];

    for (var column_index in this.columnList) {
      var column_info = this.columnList[column_index];

      if (column_info.children) {
        for (var children_index in column_info.children) {
          var columnName = column_info.children[children_index].key;

          if (this.isFilterColumn(columnName)) {
            continue;
          }

          columnName = columnName.replace('_month', '').replace('_ratio', '').replace('_', '-');
          var row = {
            data_date: columnName
          };
          row_list.push(row);
        }
      } else {
        var columnName = this.columnList[column_index].key;

        if (this.isFilterColumn(columnName)) {
          continue;
        }

        var row = {
          data_date: columnName
        };
        row_list.push(row);
      }
    }

    this.purchaseGiveDateCharData = {
      columns: ['data_date'],
      rows: row_list
    };

    for (var _i = 0, selectedRows_1 = selectedRows; _i < selectedRows_1.length; _i++) {
      var row = selectedRows_1[_i];
      var default_code = row['default_code'];

      if (this.purchaseGiveDateCharData.columns.indexOf(default_code) < 0) {
        this.purchaseGiveDateCharData.columns.push(default_code);
        var cell_index = 0;

        for (var column_index in this.columnList) {
          var column_info = this.columnList[column_index];

          if (column_info.children) {
            for (var children_index in column_info.children) {
              var columnName = column_info.children[children_index].key;

              if (this.isFilterColumn(columnName)) {
                continue;
              }

              this.purchaseGiveDateCharData.rows[cell_index][default_code] = row[columnName];
              cell_index += 1;
            }
          } else {
            var columnName = this.columnList[column_index].key;

            if (this.isFilterColumn(columnName)) {
              continue;
            }

            this.purchaseGiveDateCharData.rows[column_index][default_code] = row[columnName];
            cell_index += 1;
          }
        }
      }
    }
  };

  PurchaseGiveDateReport.prototype.isFilterColumn = function (columnName) {
    var fixed_column = ['default_code', 'vendor_name', 'z_category', 'z_sub_category'];

    if (columnName.indexOf('_count') != -1) {
      return true;
    }

    if (fixed_column.indexOf(columnName) != -1) {
      return true;
    }

    return false;
  };

  PurchaseGiveDateReport.prototype.getPurchaseGiveDateData = function () {
    var _this = this;

    this.columnList = this.getBasicColumnInfo();
    this.getQueryCondition().then(function (params) {
      _this.purchaseService.query_all_purchase_give_date_report(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        var new_data = [];
        var year_list = [];

        var new_data_dict = _this.getMonthNewData(data);

        new_data = new_data_dict.data;
        year_list = new_data_dict.date;
        var other_width = 0;

        if (_this.query_type == 'month') {
          other_width = _this.getMonthOtherColumns(year_list);
        } else if (_this.query_type == 'year') {
          other_width = _this.getYearOtherColumns(year_list);
        } else {
          other_width = _this.getSeasonOtherColumns(year_list);
        }

        _this.table_width = other_width + _this.fixed_width;
        _this.tableData = new_data;
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  PurchaseGiveDateReport.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        if (values['vendor_name'] == '' || values['vendor_name'].length == 0) {
          delete values['vendor_name'];
        }

        if (values['z_category'] == '' || values['z_category'].length == 0) {
          delete values['z_category'];
        }

        if (values['z_sub_category'] == '' || values['z_sub_category'].length == 0) {
          delete values['z_sub_category'];
        }

        var params = common_service["a" /* CommonService */].createQueryCondition(values, {
          year: '=',
          vendor_name: 'in',
          z_sub_category: 'in'
        });
        _this.query_type = '';
        var query_condition = params['query_condition'];
        var new_query_condition = [];

        for (var index in query_condition) {
          if (query_condition[index]['query_name'] == 'query_type') {
            _this.query_type = query_condition[index]['value'];
            params['query_type'] = _this.query_type;
            continue;
          }

          new_query_condition.push(query_condition[index]);
        }

        if (_this.query_type == '') {
          _this.$message.info('请选择数据查询类型! ');

          return;
        }

        params['query_condition'] = new_query_condition;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        reslove(params);
      }).catch(function (err) {// 异常处理
      });
    });
  };

  PurchaseGiveDateReport.prototype.getMonthNewData = function (data) {
    var new_data = [];
    var year_list = [];

    for (var index in data) {
      var item = data[index];

      for (var year_data_index in item.year_data) {
        var year_data_item = item.year_data[year_data_index];
        var tmpl_year = year_data_item.year;

        if (year_list.includes(tmpl_year) == false) {
          year_list.push(tmpl_year);
        }

        for (var key in year_data_item) {
          if (key == 'year') {
            continue;
          }

          item[tmpl_year + '_' + key] = year_data_item[key];
        }
      }

      delete item.year_data;
      new_data.push(item);
    }

    return {
      data: new_data,
      date: year_list
    };
  };

  PurchaseGiveDateReport.prototype.getSeasonOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;
    var season_list = ['1', '2', '3', '4'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var season_index in season_list) {
        var season = season_list[season_index];
        var column_info = {
          title: this.$t('columns.season_' + season) + '/' + year,
          children: [{
            dataIndex: year + '_season_' + season + '_ratio',
            key: year + '_season_' + season + '_ratio',
            title: this.$t('columns.ratio'),
            align: 'right',
            width: unit_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }, {
            dataIndex: year + '_season_' + season + '_count',
            key: year + '_season_' + season + '_count',
            title: this.$t('columns.count'),
            align: 'right',
            width: reduce_cost_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }]
        };
        this.columnList.push(column_info);
      }
    }

    return (unit_width + reduce_cost_width) * year_list.length * season_list.length;
  };

  PurchaseGiveDateReport.prototype.getMonthOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;
    var month_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var month_index in month_list) {
        var month = month_list[month_index];
        var column_info = {
          title: this.$t('columns.month_' + month) + '/' + year,
          children: [{
            dataIndex: year + '_month_' + month + '_ratio',
            key: year + '_month_' + month + '_ratio',
            title: this.$t('columns.ratio'),
            align: 'right',
            width: unit_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }, {
            dataIndex: year + '_month_' + month + '_count',
            key: year + '_month_' + month + '_count',
            title: this.$t('columns.count'),
            align: 'right',
            width: reduce_cost_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }]
        };
        this.columnList.push(column_info);
      }
    }

    return (unit_width + reduce_cost_width) * year_list.length * month_list.length;
  };

  PurchaseGiveDateReport.prototype.getYearOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;

    for (var year_index in year_list) {
      var year = year_list[year_index];
      var column_info = {
        title: year,
        children: [{
          dataIndex: year + '_ratio',
          key: year + '_ratio',
          title: this.$t('columns.ratio'),
          align: 'right',
          width: unit_width,
          customRender: function customRender(value, row, index) {
            if (!value) {
              return 0;
            }

            return value.toFixed(2);
          }
        }, {
          dataIndex: year + '_count',
          key: year + '_count',
          title: this.$t('columns.count'),
          align: 'right',
          width: reduce_cost_width,
          customRender: function customRender(value, row, index) {
            if (!value) {
              return 0;
            }

            return value.toFixed(2);
          }
        }]
      };
      this.columnList.push(column_info);
    }

    return (unit_width + reduce_cost_width) * year_list.length;
  };

  PurchaseGiveDateReport.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getPurchaseGiveDateData();
  };

  PurchaseGiveDateReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseGiveDateReport.prototype.exportData = function () {
    this.getQueryCondition().then(function (x) {
      common_service["a" /* CommonService */].exportData('/purchase_requirement/export_purchase_give_date_report', {
        query_condition: x.query_condition
      });
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseGiveDateReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseGiveDateReport.prototype, "pageContainer", void 0);

  PurchaseGiveDateReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-give-date-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseGiveDateReport);
  return PurchaseGiveDateReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_give_date_reportvue_type_script_lang_ts_ = (purchase_give_date_reportvue_type_script_lang_ts_PurchaseGiveDateReport);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-give-date-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_give_date_reportvue_type_script_lang_ts_ = (purchase_give_date_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-give-date-report.vue?vue&type=custom&index=0&blockType=i18n
var purchase_give_date_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("e526");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-give-date-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_give_date_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_give_date_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_give_date_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_give_date_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "8a0e":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Purchase Reduce Cost","columns":{"cn_category":"CN Category","cn_sub_category":"CN Sub Category","cur_month":"Current Month","de_cur_month":"De Current Month","de_next_month":"De Next Month","de_product_qty":"De Product Qty","de_third_month":"De Third Month","default_code":"Default Code","department":"Department","next_month":"Next Month","operator":"Operator","product_qty":"Product Qty","stock_de_available_qty":"Stock De Available Qty","stock_uk_available_qty":"Stock Uk Available Qty","third_month":"Third Month","uk_cur_month":"Uk Current Month","uk_next_month":"Uk Next Month","uk_product_qty":"Uk Product Qty","uk_third_month":"Uk Third Month","total":"Total","stock_available_qty":"Stock Available Qty","prod_status":"Prod Status","prod_status_sale":"Sale","prod_status_stop":"Stop","prod_status_waiting":"Waiting","prod_status_sz_prod":"SZ Prod","prod_status_uk_sale":"UK Sale","prod_status_tort_stop":"Tort Stop"},"action":{"create":"新建","more":"更多操作"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"货柜信息","columns":{"vendor_name":"供应商","cn_category":"中文分类","cn_sub_category":"中文子类","default_code":"基础货号","cur_month":"本月在途数量","de_cur_month":"本月德仓在途数量","de_next_month":"次月德仓在途数量","de_product_qty":"德仓在厂数量","de_third_month":"第三月德仓在途数量","department":"部门","next_month":"次月在途数量","operator":"运营","product_qty":"在厂数量","stock_de_available_qty":"德线在仓数量","stock_uk_available_qty":"英线在仓数量","third_month":"第三月在途数量","uk_cur_month":"本月英仓在途数量","uk_next_month":"次月英仓在途数量","uk_product_qty":"英仓在厂数量","uk_third_month":"第三月英仓在途数量","total":"总计","stock_available_qty":"在仓数量","prod_status":"产品状态","prod_status_sale":"正常在售","prod_status_stop":"淘汰停售","prod_status_waiting":"待观察","prod_status_sz_prod":"深圳产品","prod_status_uk_sale":"UK正常在售","prod_status_tort_stop":"侵权停售"},"action":{"create":"新建","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "9268":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-de-po-manage.vue?vue&type=template&id=0d03eb60&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 0 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{attrs:{"label":_vm.$t('columns.state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.DePoState),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.toPageDetail(row.id, row.name)}}},[_vm._v(_vm._s(row.name))])]}},{key:"vendor",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("dict2")(text,_vm.vendorList))+" ")]}},{key:"company",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("dict2")(text,_vm.companyList))+" ")]}},{key:"state",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(text,'DePoState')))+" ")]}}],null,false,337925532)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.toPageDetail(row.id, row.name)}}},[_vm._v(_vm._s(row.name))])]}},{key:"vendor",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("dict2")(text,_vm.vendorList))+" ")]}},{key:"company",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("dict2")(text,_vm.companyList))+" ")]}},{key:"state",fn:function(text){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(text,'DePoState')))+" ")]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-de-po-manage.vue?vue&type=template&id=0d03eb60&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/purchase/purchase-cancel-attention.vue + 4 modules
var purchase_cancel_attention = __webpack_require__("fc12");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-de-po-manage.vue?vue&type=script&lang=ts&























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_de_po_managevue_type_script_lang_ts_PurchaseDePoManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseDePoManage, _super);

  function PurchaseDePoManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.orderBy = 'id desc';
    _this.queryUrl = 'purchase_management/query_all_de_purchase_order';
    _this.moment = moment_default.a;
    _this.groupbyList = [];
    _this.columnList = [];
    _this.allNameAuth = [];
    _this.companyList = [];
    _this.fromPortList = [];
    _this.toPortList = [];
    _this.vendorList = [];
    _this.shipmentItemList = [];
    return _this;
  }

  Object.defineProperty(PurchaseDePoManage.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchaseDePoManage.prototype.created = function () {
    this.getSystemuser();
  };

  PurchaseDePoManage.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
    this.companyList = [{
      code: 'woltu',
      name: 'Woltu'
    }, {
      code: 'eugad',
      name: 'Eugad'
    }, {
      code: 'situ',
      name: 'Situ'
    }, {
      code: 'elight',
      name: 'Elight'
    }, {
      code: 'wowo',
      name: 'WoWo'
    }, {
      code: 'meteorsRain',
      name: 'MeteorsRain'
    }, {
      code: 'brichimon',
      name: 'BRICHIMON LIMITED'
    }];
    this.fromPortList = [{
      code: 'QINGDAO',
      name: 'QINGDAO'
    }, {
      code: 'TIANJIN',
      name: 'TIANJIN'
    }, {
      code: 'XIAMEN',
      name: 'XIAMEN'
    }, {
      code: 'FUZHOU',
      name: 'FUZHOU'
    }, {
      code: 'NINGBO',
      name: 'NINGBO'
    }, {
      code: 'YANTIAN',
      name: 'YANTIAN'
    }, {
      code: 'SHANGHAI',
      name: 'SHANGHAI'
    }, {
      code: 'XIAOLAN',
      name: 'XIAOLAN'
    }, {
      code: 'SHENZHEN',
      name: 'SHENZHEN'
    }];
    this.toPortList = [{
      code: 'FELIXSTOWE',
      name: 'FELIXSTOWE'
    }, {
      code: 'ROTTERDAM',
      name: 'ROTTERDAM'
    }, {
      code: 'SOUTHAMPTON',
      name: 'SOUTHAMPTON'
    }, {
      code: 'DUISBURG',
      name: 'DUISBURG'
    }, {
      code: 'NEUSS',
      name: 'NEUSS'
    }];
    this.vendorList = [{
      code: 'wawa',
      name: 'WAWAHOME'
    }, {
      code: 'ye',
      name: 'YEMELEK'
    }, {
      code: 'situ',
      name: 'ST-SITU'
    }, {
      code: 'runheng',
      name: 'RH-RUNHENG'
    }, {
      code: 'andong',
      name: 'AD-ANDONG'
    }, {
      code: 'cheng',
      name: 'OH-ORANGE'
    }, {
      code: 'dy',
      name: 'DY-DEALCRAFTS'
    }, {
      code: 'ice',
      name: 'ICE-ICEBERG'
    }, {
      code: 'kd',
      name: 'KD-KENDA'
    }, {
      code: 'wt',
      name: 'WT-HENAN PROSPER SKINS AND LEATHER'
    }, {
      code: 'yt',
      name: 'YT-YUTONG'
    }, {
      code: 'zl',
      name: 'ZL-JINHUA RUNCHN'
    }, {
      code: 'ykzh',
      name: 'YKZH-YONGKANG ZEHUI'
    }, {
      code: 'anji',
      name: 'BY-BAOYOU'
    }, {
      code: 'wj',
      name: 'WJ-WORKING'
    }];
    this.shipmentItemList = [{
      code: 'FOB',
      name: 'FOB'
    }, {
      code: 'CIF',
      name: 'CIF'
    }];
  };

  PurchaseDePoManage.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  PurchaseDePoManage.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: 'in_or_like',
        order_name: 'like'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            var startDate = {};

            for (var key in item.value[0]) {
              startDate[key] = item.value[0][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(startDate.utc())
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            var endDate = {};

            for (var key in item.value[1]) {
              endDate[key] = item.value[1][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(endDate.utc())
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseDePoManage.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  PurchaseDePoManage.prototype.onRowClick = function (row) {
    var info = this.data.find(function (x) {
      return x.id === row;
    });
  };

  PurchaseDePoManage.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  PurchaseDePoManage.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseDePoManage.prototype.toPageDetail = function (id, name) {
    this.$router.push({
      name: 'depo-detail',
      path: "/purchase/depo-detail/" + id,
      params: {
        id: id,
        name: name
      }
    });
  };

  PurchaseDePoManage.prototype.onDetail = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/query_de_purchase_order_detail_by_id', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      de_po_id: row.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {}, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseDePoManage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseDePoManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseDePoManage.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseDePoManage.prototype, "getSystemuser", void 0);

  PurchaseDePoManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-de-po-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      PurchaseCancelAtentioin: purchase_cancel_attention["a" /* default */],
      CommonPage: common_page["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], PurchaseDePoManage);
  return PurchaseDePoManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_de_po_managevue_type_script_lang_ts_ = (purchase_de_po_managevue_type_script_lang_ts_PurchaseDePoManage);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-de-po-manage.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_de_po_managevue_type_script_lang_ts_ = (purchase_de_po_managevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-de-po-manage.vue?vue&type=custom&index=0&blockType=i18n
var purchase_de_po_managevue_type_custom_index_0_blockType_i18n = __webpack_require__("65d1");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-de-po-manage.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_de_po_managevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_de_po_managevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_de_po_managevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_de_po_manage = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "9399":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"company_id":"Company","date_approve":"Approve Date","date_expected":"Expected Date","sales_expected_give_date":"Expected Give Date","date_req":"Req Date","create_date":"Create Date","id":"Id","merchandiser":"Merchandiser","name":"Name","real_state":"Real State","req_type":"Req Type","state":"State","user_approve":"Approve User","user_id":"Requiremnet User","user_purchase":"Purchase User","warehouse_id":"Warehouse","is_change_give_date":"Give Date Changed","is_together_purchase":"Together Purchase","together_require_name":"Together Require Name"},"action":{"action":"Action","create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","verify":"Verify","reset":"Reset","confirm":"Confirm","refuse":"Refuse","showlog":"View Log"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","page_name":"Requirement Edit"},"zh-cn":{"desc":"这是订单页面1","columns":{"company_id":"公司","date_approve":"审批日期","date_expected":"期望入库","sales_expected_give_date":"期望交期","date_req":"需求日期","create_date":"创建日期","id":"Id","merchandiser":"跟单员","name":"需求编号","real_state":"Real State","req_type":"补货类型","state":"状态","user_approve":"审批人","user_id":"需求人","user_purchase":"采购员","warehouse_id":"仓库","is_change_give_date":"交期变更","is_together_purchase":"合并补货","together_require_name":"合并补货编号"},"action":{"action":"操作","create":"新建","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","verify":"审核","reset":"重置","confirm":"确认","refuse":"确认拒绝","showlog":"查看日志"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","page_name":"补货需求编辑"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "952a":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"Purchase Reduce Cost","columns":{"vendor_name":"Vendor","cn_category":"CN Category","cn_sub_category":"CN Sub Category","sku":"SKU","avg_price":"AVG Price","reduct_cost":"Reduce Cost","season_1":"Quarter 1","season_2":"Quarter 2","season_3":"Quarter 3","season_4":"Quarter 4","month_1":"Jan","month_2":"Feb","month_3":"Mar","month_4":"Apl","month_5":"May","month_6":"Jun","month_7":"Jul","month_8":"Aug","month_9":"Sep","month_10":"Oct","month_11":"Nov","month_12":"Dec","query_type":"Calcuate Type","year":"Time"},"action":{"create":"新建","more":"更多操作"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"采购降本","columns":{"vendor_name":"供应商","cn_category":"中文分类","cn_sub_category":"中文子类","sku":"SKU","avg_price":"平均价格","reduct_cost":"降本额","season_1":"1季度","season_2":"2季度","season_3":"3季度","season_4":"4季度","month_1":"1月","month_2":"2月","month_3":"3月","month_4":"4月","month_5":"5月","month_6":"6月","month_7":"7月","month_8":"8月","month_9":"9月","month_10":"10月","month_11":"11月","month_12":"12月","query_type":"统计维度","year":"时间"},"action":{"create":"新建","more":"更多操作"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "9848":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_plan_vue_vue_type_style_index_0_id_6b4ced9d_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3b70");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_plan_vue_vue_type_style_index_0_id_6b4ced9d_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_plan_vue_vue_type_style_index_0_id_6b4ced9d_scoped_true_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "9fa8":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"date_approve":"date_approve","date_expected":"date_expected","default_code":"default_code","ist_box_qty":"ist_box_qty","merchandiser":"merchandiser","new_product":"new_product","pack_material":"pack_material","product_color":"product_color","product_id":"product_id","product_min_order":"product_min_order","product_qty":"product_qty","product_ve":"product_ve","req_id":"req_id","sales_expected_give_date":"sales_expected_give_date","state":"state","stock_onhand_quantity":"stock_onhand_quantity","user_purchase":"user_purchase","user_require":"user_require","vendor_id":"vendor_id","warehouse_id":"warehouse_id","z_sub_category":"z_sub_category","req_name":"Req Name"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","return_purchase":"Return Purchase","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","save":"Save","changePurchaseInfo":"Change Purchase Info","syncSupplierProductSupplierInfo":"Sync Supplier Product/Info"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","columns":{"date_approve":"运营下单日期","date_expected":"期望入库","default_code":"产品","ist_box_qty":"是否箱数","merchandiser":"跟单员","new_product":"新品","pack_material":"包裹材质","product_color":"产品颜色","product_id":"产品id","product_min_order":"最小订购数量","product_qty":"产品数量","product_ve":"装箱率","req_id":"req_id","sales_expected_give_date":"运营期望交期","state":"状态","stock_onhand_quantity":"实际库存","user_purchase":"采购员","user_require":"需求人","vendor_id":"供货商","warehouse_id":"仓库","z_sub_category":"中文子类","req_name":"需求编号"},"action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","save":"保存","changePurchaseInfo":"修改待补货信息","syncSupplierProductSupplierInfo":"同步供应商产品"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a053":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/logistics-providers-detail.vue?vue&type=template&id=2bef3627&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('LogisticsProvidersEdit',{attrs:{"info":[]}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/logistics-providers-detail.vue?vue&type=template&id=2bef3627&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/components/purchase/logistics-providers-edit.vue + 4 modules
var logistics_providers_edit = __webpack_require__("aa60");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/logistics-providers-detail.vue?vue&type=script&lang=ts&






var logistics_providers_detailvue_type_script_lang_ts_LogisticsProvidersDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](LogisticsProvidersDetail, _super);

  function LogisticsProvidersDetail() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], LogisticsProvidersDetail.prototype, "pageContainer", void 0);

  LogisticsProvidersDetail = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'logistics-providers-detail'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogisticsProvidersEdit: logistics_providers_edit["a" /* default */]
    }
  })], LogisticsProvidersDetail);
  return LogisticsProvidersDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var logistics_providers_detailvue_type_script_lang_ts_ = (logistics_providers_detailvue_type_script_lang_ts_LogisticsProvidersDetail);
// CONCATENATED MODULE: ./src/pages/purchase/logistics-providers-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_logistics_providers_detailvue_type_script_lang_ts_ = (logistics_providers_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/purchase/logistics-providers-detail.vue?vue&type=style&index=0&lang=css&
var logistics_providers_detailvue_type_style_index_0_lang_css_ = __webpack_require__("f12d");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/logistics-providers-detail.vue?vue&type=custom&index=0&blockType=i18n
var logistics_providers_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("09a7");

// CONCATENATED MODULE: ./src/pages/purchase/logistics-providers-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_logistics_providers_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof logistics_providers_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(logistics_providers_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var logistics_providers_detail = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "a904":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3775");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "bbbf":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-package.vue?vue&type=template&id=57147d77&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onCreateSaleTrend}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")])]},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2},on:{"submit":_vm.getPackageData},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.package_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['package_name']),expression:"['package_name']"}],style:({ width: '240px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub1 W")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub2 M")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub3 S")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub4 UK")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub5 J")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub6 E")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub7 T")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub8 R")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("Sub9 F")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("FBA-S")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("FBA-R")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("FBA-T")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("FBA-W")]),_c('a-button',{attrs:{"type":"primary"}},[_vm._v("FBA-UK")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex"},[_c('table',{staticStyle:{"width":"800px"}},[_c('tr',[_c('td',{staticStyle:{"width":"50px"}},[_vm._v(" "+_vm._s(_vm.$t('columns.package_name'))+": "+_vm._s(_vm.packageName)+" ")]),_c('td',{staticStyle:{"width":"50px"}},[_vm._v("DE PO: "+_vm._s(_vm.packageData.de_po))]),_c('td',{staticStyle:{"width":"40px"}},[_vm._v(" "+_vm._s(_vm.$t('columns.warehouse'))+": "+_vm._s(_vm.packageData.warehouse_id)+" ")]),_c('td',{staticStyle:{"width":"50px"}},[_vm._v("ETD: "+_vm._s(_vm.packageData.etd_date))])])]),_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.packageDataDetail,"page":_vm.pageService,"rowKey":"id","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, select_rows) {
                    _vm.selectedRows = select_rows
                    _vm.selectedRowKeys = keys
                }
            },"scroll":{ y: 490, x: 400 }},on:{"on-page-change":_vm.getPackageData,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                },"change":function (sorter) { return _vm.onTableChange(sorter); }}},[_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('columns.default_code'),"data-index":"default_code","width":"20%","align":"center","sorter":true}}),_c('a-table-column',{key:"package_qty",attrs:{"title":_vm.$t('columns.package_qty'),"data-index":"package_qty","width":"20%","align":"right"}}),_c('a-table-column',{key:"aktu_package_qty",attrs:{"title":_vm.$t('columns.aktu_package_qty'),"data-index":"aktu_package_qty","width":"20%","align":"right"}}),_c('a-table-column',{key:"box_qty",attrs:{"title":_vm.$t('columns.box_qty'),"data-index":"box_qty","width":"20%","align":"right"}}),_c('a-table-column',{key:"aktu_box_qty",attrs:{"title":_vm.$t('columns.aktu_box_qty'),"data-index":"aktu_box_qty","width":"20%","align":"right"}})],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-package.vue?vue&type=template&id=57147d77&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/product.purchase.service.ts
var product_purchase_service = __webpack_require__("b27d");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-package.vue?vue&type=script&lang=ts&













var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_packagevue_type_script_lang_ts_PurchasePackage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchasePackage, _super);

  function PurchasePackage() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.packageName = '';
    _this.packageData = ''; // 表格数据源

    _this.packageDataDetail = [];
    _this.selectedRows = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.productPurchaseService = new product_purchase_service["a" /* ProductPurchaseService */]();
    _this.orderBy = '';
    return _this;
  }

  PurchasePackage.prototype.created = function () {
    this.getSystemuser();
  };

  PurchasePackage.prototype.getPackageData = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (values['package_name'] == undefined) {
        _this.$message.error('Please input package name.');

        return;
      }

      _this.packageName = values['package_name'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        package_name: 'in_or_=',
        name: '='
      });

      if (_this.orderBy) {
        params['order_by'] = _this.orderBy;
      }

      _this.productPurchaseService.queryRequirementPackage(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        if (data.length > 0) {
          _this.packageData = data[0];
          _this.packageDataDetail = data;
        }
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {// 异常处理
    });
  };

  PurchasePackage.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getPackageData();
  };

  PurchasePackage.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchasePackage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchasePackage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackage.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePackage.prototype, "getSystemuser", void 0);

  PurchasePackage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-package'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchasePackage);
  return PurchasePackage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_packagevue_type_script_lang_ts_ = (purchase_packagevue_type_script_lang_ts_PurchasePackage);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-package.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_packagevue_type_script_lang_ts_ = (purchase_packagevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-package.vue?vue&type=custom&index=0&blockType=i18n
var purchase_packagevue_type_custom_index_0_blockType_i18n = __webpack_require__("e0dd");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-package.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_packagevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_packagevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_packagevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_package = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "c04c":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"af_date":"AF Date","bl_code":"BL Code","carrier_name":"Carrier Name","check_package_status":"Check Package Status","company_name":"Company Name","display_product":"Display Product","etd_date":"ETD Date","land_date":"Land Date","name":"Name","package_code":"Package Code","predict_eta":"Predict ETA","ship_date":"Ship Date","source_doc1":"Source Doc1","state":"State","warehouse_id":"Warehouse","vendor_id":"Vendor","out_number":"Out Number","bl_finish_date":"BL Finish Date","yd_memo":"YD Memo"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","batch_modify":"Batch Modify","updatePackageLogistics":"Update Package Logistic","update_eta":"变更货柜ETA,电放, 清关资料时间","confirm":"Confirm","reset":"Reset","ship":"Ship","land":"Land","approved":"Approved","process_clearance":"Process Clearance","waiting_arrange_in":"Waiting Arrange In","waiting_in":"Waiting In","import_eta":"导入ETA,电放, 清关资料时间","eta_operate":"ETA,电放, 清关资料时间","sync_eta":"同步货柜ETA时间","flag_pd":"标记盘点","calc_number":"计算货柜产品数量出入","update_state":"Modify State","export_package_order":"Export Package Order","export_package_order_sales":"Export Package Order(for Sales)","set_to_draft":"To Draft","showlog":"View Log","export_package_checkout_data":"Export Package Checkout Order","not_null":"Not Null","null":"Null"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","page_name":"Purchase Package Edit"},"zh-cn":{"desc":"这是订单页面1","columns":{"af_date":"AF Date","bl_code":"提单号","carrier_name":"运输公司","check_package_status":"检查包裹状态","company_name":"公司","display_product":"Display Product","etd_date":"ETD Date","land_date":"Land Date","name":"货柜号","package_code":"集装箱号","predict_eta":"变更ETA","ship_date":"发货日期","source_doc1":"发票号","state":"状态","warehouse_id":"仓库","vendor_id":"供应商","out_number":"外箱合同号","bl_finish_date":"电放完成时间","yd_memo":"YD Memo"},"action":{"create":"新建补货合同","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建补货合同","purchase_return":"退回补货","batch_modify":"批量修改货柜信息","updatePackageLogistics":"调整物流信息","update_eta":"变更货柜ETA,电放, 清关资料时间","eta_operate":"ETA,电放, 清关资料时间","confirm":"确认","reset":"重置","ship":"Ship","land":"Land","approved":"Approved","process_clearance":"Process Clearance","waiting_arrange_in":"Waiting Arrange In","waiting_in":"Waiting In","import_eta":"导入ETA,电放, 清关资料时间","sync_eta":"同步货柜ETA时间","flag_pd":"标记盘点","calc_number":"计算货柜产品数量出入","update_state":"修改货柜状态","export_package_order":"导出货柜合同","export_package_order_sales":"导出货柜合同(运营)","set_to_draft":"设为草稿","showlog":"查看日志","export_package_checkout_data":"导出货柜差异数据","not_null":"已设置","null":"未设置"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","page_name":"货柜信息编辑"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "c624":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5174");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_contract_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "d4bf":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/replenishment-edit.vue?vue&type=template&id=fb563e2e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('ReplenishmentEdit',{attrs:{"info":[]}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/replenishment-edit.vue?vue&type=template&id=fb563e2e&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/components/purchase/replenishment-edit.vue + 4 modules
var replenishment_edit = __webpack_require__("b1fb");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/replenishment-edit.vue?vue&type=script&lang=ts&






var replenishment_editvue_type_script_lang_ts_ReplenishmentEditPage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ReplenishmentEditPage, _super);

  function ReplenishmentEditPage() {
    return _super !== null && _super.apply(this, arguments) || this;
  }

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _a : Object)], ReplenishmentEditPage.prototype, "pageContainer", void 0);

  ReplenishmentEditPage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'replenishment-edit'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      ReplenishmentEdit: replenishment_edit["a" /* default */]
    }
  })], ReplenishmentEditPage);
  return ReplenishmentEditPage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var replenishment_editvue_type_script_lang_ts_ = (replenishment_editvue_type_script_lang_ts_ReplenishmentEditPage);
// CONCATENATED MODULE: ./src/pages/purchase/replenishment-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_replenishment_editvue_type_script_lang_ts_ = (replenishment_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/purchase/replenishment-edit.vue?vue&type=style&index=0&lang=css&
var replenishment_editvue_type_style_index_0_lang_css_ = __webpack_require__("f78e");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/replenishment-edit.vue?vue&type=custom&index=0&blockType=i18n
var replenishment_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("2eaf");

// CONCATENATED MODULE: ./src/pages/purchase/replenishment-edit.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_replenishment_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof replenishment_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(replenishment_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_replenishment_edit = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "d681":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-reduce-cost-report.vue?vue&type=template&id=30c90b7b&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false}},[_c('splitpanes',{staticClass:"default-theme",style:({ height: _vm.splitPanelHeight + 'px' }),attrs:{"horizontal":""},on:{"resize":function($event){return _vm.page_resize($event)},"resized":function($event){return _vm.page_resized($event)}}},[_c('pane',{attrs:{"max-size":"30"},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",style:({
                    'background-color': 'yellow',
                    height: _vm.panel1Height
                }),attrs:{"column":2},on:{"submit":_vm.getPurchaseReduceCostData},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'vendor_name',
                                { initialValue: '' }
                            ]),expression:"[\n                                'vendor_name',\n                                { initialValue: '' }\n                            ]"}],style:({
                                width: '100%',
                                'max-width': '300px'
                            }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'z_category',
                                { initialValue: '' }
                            ]),expression:"[\n                                'z_category',\n                                { initialValue: '' }\n                            ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'z_sub_category',
                                { initialValue: '' }
                            ]),expression:"[\n                                'z_sub_category',\n                                { initialValue: '' }\n                            ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.query_type')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'query_type',
                                { initialValue: 'month' }
                            ]),expression:"[\n                                'query_type',\n                                { initialValue: 'month' }\n                            ]"}],staticStyle:{"width":"110px"},attrs:{"size":"small"},on:{"change":function (e) { return _vm.onChangeQueryType(e); }}},[_c('a-select-option',{key:"year",attrs:{"value":"year","title":"By Year/按年"}},[_vm._v(" By Year/按年 ")]),_c('a-select-option',{key:"season",attrs:{"value":"season","title":"By Quarter/按季度"}},[_vm._v(" By Quarter/按季度 ")]),_c('a-select-option',{key:"month",attrs:{"value":"month","title":"By Month/按月"}},[_vm._v(" By Month/按月 ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.year')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['year', { initialValue: '2021' }]),expression:"['year', { initialValue: '2021' }]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1),(_vm.showToYear)?_c('span',{staticStyle:{"color":"red"}},[_vm._v(" ~ ")]):_vm._e(),(_vm.showToYear)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'to_year',
                                { initialValue: '2021' }
                            ]),expression:"[\n                                'to_year',\n                                { initialValue: '2021' }\n                            ]"}],staticStyle:{"width":"110px"},attrs:{"size":"small","allowClear":""}},[_c('a-select-option',{key:"year_2018",attrs:{"value":"2018"}},[_vm._v(" 2018 ")]),_c('a-select-option',{key:"year_2019",attrs:{"value":"2019"}},[_vm._v(" 2019 ")]),_c('a-select-option',{key:"year_2020",attrs:{"value":"2020"}},[_vm._v(" 2020 ")]),_c('a-select-option',{key:"year_2021",attrs:{"value":"2021"}},[_vm._v(" 2021 ")])],1):_vm._e()],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.exportData}},[_vm._v("Export")])]},proxy:true}])})],1),_c('pane',{attrs:{"min-size":"20"}},[_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed","height":"100%","overflow":"auto"},attrs:{"stripe":true,"data":_vm.tableData,"page":_vm.pageService,"rowKey":"default_code","rowSelection":{
                        selectedRowKeys: _vm.selectedRowKeys,
                        onChange: function (keys, select_rows) {
                            _vm.selectedRows = select_rows
                            _vm.selectedRowKeys = keys
                            this$1.showReduceCostChart(select_rows)
                        }
                    },"columns":_vm.columnList,"scroll":{ x: 300, y: _vm.tableScrollHeight }},on:{"on-page-change":_vm.getPurchaseReduceCostData,"onClick":function (row) {
                            this$1.selectedRowKeys = [row]
                            var curRow = this$1.tableData.filter(
                                function (item) { return item.default_code === row; }
                            )
                            this$1.showReduceCostChart(curRow)
                        },"change":function (sorter) { return _vm.onTableChange(sorter); }}})],1)],1),_c('pane',{attrs:{"min-size":"20"}},[_c('a-card',{style:({ height: _vm.panel3Height }),attrs:{"title":"趋势图"}},[_c('ve-line',{attrs:{"data":_vm.reduceCostCharData}})],1)],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-reduce-cost-report.vue?vue&type=template&id=30c90b7b&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__("a9e3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.to-fixed.js
var es_number_to_fixed = __webpack_require__("b680");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/product.purchase.service.ts
var product_purchase_service = __webpack_require__("b27d");

// EXTERNAL MODULE: ./src/services/purchase.service.ts
var purchase_service = __webpack_require__("0d91");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/splitpanes/dist/splitpanes.common.js
var splitpanes_common = __webpack_require__("512e");

// EXTERNAL MODULE: ./node_modules/splitpanes/dist/splitpanes.css
var splitpanes = __webpack_require__("c1ea");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-reduce-cost-report.vue?vue&type=script&lang=ts&






















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_reduce_cost_reportvue_type_script_lang_ts_PurchaseReduceCostReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseReduceCostReport, _super);

  function PurchaseReduceCostReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.productPurchaseService = new product_purchase_service["a" /* ProductPurchaseService */]();
    _this.purchaseService = new purchase_service["a" /* PurchaseService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.vender_data = [];
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.orderBy = '';
    _this.table_width = 350;
    _this.fixed_width = 350;
    _this.selectedRows = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.columnList = [];
    _this.tableData = [];
    _this.showToYear = false;
    _this.splitPanelHeight = 700;
    _this.panel1Height = 130;
    _this.panel2Height = 300;
    _this.panel3Height = 300;
    _this.tableScrollHeight = 275;
    _this.reduceCostCharData = [];
    _this.query_type = 'year';
    return _this;
  }

  PurchaseReduceCostReport.prototype.page_resize = function (sizeArray) {
    this.panel1Height = Math.floor(this.splitPanelHeight * Number(sizeArray[0].size) / 100);
    this.panel2Height = Math.floor(this.splitPanelHeight * Number(sizeArray[1].size) / 100);
    this.panel3Height = Math.floor(this.splitPanelHeight * Number(sizeArray[2].size) / 100);
    this.tableScrollHeight = this.panel2Height - 145;
  };

  PurchaseReduceCostReport.prototype.page_resized = function (sizeArray) {
    this.panel1Height = Math.floor(this.splitPanelHeight * Number(sizeArray[0].size) / 100);
    this.panel2Height = Math.floor(this.splitPanelHeight * Number(sizeArray[1].size) / 100);
    this.panel3Height = Math.floor(this.splitPanelHeight * Number(sizeArray[2].size) / 100);
    this.tableScrollHeight = this.panel2Height - 145;
  };

  PurchaseReduceCostReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  PurchaseReduceCostReport.prototype.onChangeQueryType = function (value) {
    if (value == 'year') {
      this.showToYear = true;
    } else {
      this.showToYear = false;
    }
  };

  PurchaseReduceCostReport.prototype.created = function () {
    var _this = this;

    var h = window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight;
    this.splitPanelHeight = h - 125;
    this.panel1Height = Math.floor(this.splitPanelHeight * 30 / 100);
    this.panel2Height = Math.floor(this.splitPanelHeight * 40 / 100);
    this.panel3Height = Math.floor(this.splitPanelHeight * 40 / 100);
    this.tableScrollHeight = this.panel2Height - 145;
    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  PurchaseReduceCostReport.prototype.mounted = function () {
    this.columnList = this.getBasicColumnInfo();
  };

  PurchaseReduceCostReport.prototype.getBasicColumnInfo = function () {
    return [{
      dataIndex: 'default_code',
      key: 'default_code',
      title: this.$t('columns.sku'),
      width: 100,
      align: 'left'
    }, {
      dataIndex: 'vendor_name',
      key: 'vendor_name',
      title: this.$t('columns.vendor_name'),
      width: 60,
      align: 'center'
    }, {
      dataIndex: 'z_category',
      key: 'z_category',
      title: this.$t('columns.cn_category'),
      width: 80,
      align: 'left'
    }, {
      dataIndex: 'z_sub_category',
      key: 'z_sub_category',
      title: this.$t('columns.cn_sub_category'),
      width: 110,
      align: 'left'
    }];
  };

  PurchaseReduceCostReport.prototype.showReduceCostChart = function (selectedRows) {
    var row_list = [];

    for (var column_index in this.columnList) {
      var column_info = this.columnList[column_index];

      if (column_info.children) {
        for (var children_index in column_info.children) {
          var columnName = column_info.children[children_index].key;

          if (this.isFilterColumn(columnName)) {
            continue;
          }

          columnName = columnName.replace('_month', '').replace('_reduce_costs', '').replace('_', '-');
          var row = {
            data_date: columnName
          };
          row_list.push(row);
        }
      } else {
        var columnName = this.columnList[column_index].key;

        if (this.isFilterColumn(columnName)) {
          continue;
        }

        var row = {
          data_date: columnName
        };
        row_list.push(row);
      }
    }

    this.reduceCostCharData = {
      columns: ['data_date'],
      rows: row_list
    };

    for (var _i = 0, selectedRows_1 = selectedRows; _i < selectedRows_1.length; _i++) {
      var row = selectedRows_1[_i];
      var default_code = row['default_code'];

      if (this.reduceCostCharData.columns.indexOf(default_code) < 0) {
        this.reduceCostCharData.columns.push(default_code);
        var cell_index = 0;

        for (var column_index in this.columnList) {
          var column_info = this.columnList[column_index];

          if (column_info.children) {
            for (var children_index in column_info.children) {
              var columnName = column_info.children[children_index].key;

              if (this.isFilterColumn(columnName)) {
                continue;
              }

              this.reduceCostCharData.rows[cell_index][default_code] = row[columnName];
              cell_index += 1;
            }
          } else {
            var columnName = this.columnList[column_index].key;

            if (this.isFilterColumn(columnName)) {
              continue;
            }

            this.reduceCostCharData.rows[column_index][default_code] = row[columnName];
            cell_index += 1;
          }
        }
      }
    }
  };

  PurchaseReduceCostReport.prototype.isFilterColumn = function (columnName) {
    var fixed_column = ['default_code', 'vendor_name', 'z_category', 'z_sub_category'];

    if (columnName.indexOf('_unit') != -1) {
      return true;
    }

    if (fixed_column.indexOf(columnName) != -1) {
      return true;
    }

    return false;
  };

  PurchaseReduceCostReport.prototype.getPurchaseReduceCostData = function () {
    var _this = this;

    this.columnList = this.getBasicColumnInfo();
    this.getQueryCondition().then(function (params) {
      _this.purchaseService.query_all_purchase_reduce_costs_report(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        var new_data = [];
        var year_list = [];

        var new_data_dict = _this.getMonthNewData(data);

        new_data = new_data_dict.data;
        year_list = new_data_dict.date;
        var other_width = 0;

        if (_this.query_type == 'month') {
          other_width = _this.getMonthOtherColumns(year_list);
        } else if (_this.query_type == 'year') {
          other_width = _this.getYearOtherColumns(year_list);
        } else {
          other_width = _this.getSeasonOtherColumns(year_list);
        }

        _this.table_width = other_width + _this.fixed_width;
        _this.tableData = new_data;
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  PurchaseReduceCostReport.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        if (values['vendor_name'] == '' || values['vendor_name'].length == 0) {
          delete values['vendor_name'];
        }

        if (values['z_category'] == '' || values['z_category'].length == 0) {
          delete values['z_category'];
        }

        if (values['z_sub_category'] == '' || values['z_sub_category'].length == 0) {
          delete values['z_sub_category'];
        }

        var params = common_service["a" /* CommonService */].createQueryCondition(values, {
          year: '=',
          vendor_name: 'in',
          z_sub_category: 'in'
        });
        _this.query_type = '';
        var query_condition = params['query_condition'];
        var new_query_condition = [];

        for (var index in query_condition) {
          if (query_condition[index]['query_name'] == 'query_type') {
            _this.query_type = query_condition[index]['value'];
            params['query_type'] = _this.query_type;
            continue;
          }

          new_query_condition.push(query_condition[index]);
        }

        if (_this.query_type == '') {
          _this.$message.info('请选择数据查询类型! ');

          return;
        }

        params['query_condition'] = new_query_condition;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        reslove(params);
      }).catch(function (err) {// 异常处理
      });
    });
  };

  PurchaseReduceCostReport.prototype.getMonthNewData = function (data) {
    var new_data = [];
    var year_list = [];

    for (var index in data) {
      var item = data[index];

      for (var year_data_index in item.year_data) {
        var year_data_item = item.year_data[year_data_index];
        var tmpl_year = year_data_item.year;

        if (year_list.includes(tmpl_year) == false) {
          year_list.push(tmpl_year);
        }

        for (var key in year_data_item) {
          if (key == 'year') {
            continue;
          }

          item[tmpl_year + '_' + key] = year_data_item[key];
        }
      }

      delete item.year_data;
      new_data.push(item);
    }

    return {
      data: new_data,
      date: year_list
    };
  };

  PurchaseReduceCostReport.prototype.getSeasonOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;
    var season_list = ['1', '2', '3', '4'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var season_index in season_list) {
        var season = season_list[season_index];
        var column_info = {
          title: this.$t('columns.season_' + season) + '/' + year,
          children: [{
            dataIndex: year + '_season_' + season + '_unit',
            key: year + '_season_' + season + '_unit',
            title: this.$t('columns.avg_price'),
            align: 'right',
            width: unit_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }, {
            dataIndex: year + '_season_' + season + '_reduce_costs',
            key: year + '_season_' + season + '_reduce_costs',
            title: this.$t('columns.reduct_cost'),
            align: 'right',
            width: reduce_cost_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }]
        };
        this.columnList.push(column_info);
      }
    }

    return (unit_width + reduce_cost_width) * year_list.length * season_list.length;
  };

  PurchaseReduceCostReport.prototype.getMonthOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;
    var month_list = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];

    for (var year_index in year_list) {
      var year = year_list[year_index];

      for (var month_index in month_list) {
        var month = month_list[month_index];
        var column_info = {
          title: this.$t('columns.month_' + month) + '/' + year,
          children: [{
            dataIndex: year + '_month_' + month + '_unit',
            key: year + '_month_' + month + '_unit',
            title: this.$t('columns.avg_price'),
            align: 'right',
            width: unit_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }, {
            dataIndex: year + '_month_' + month + '_reduce_costs',
            key: year + '_month_' + month + '_reduce_costs',
            title: this.$t('columns.reduct_cost'),
            align: 'right',
            width: reduce_cost_width,
            customRender: function customRender(value, row, index) {
              if (!value) {
                return 0;
              }

              return value.toFixed(2);
            }
          }]
        };
        this.columnList.push(column_info);
      }
    }

    return (unit_width + reduce_cost_width) * year_list.length * month_list.length;
  };

  PurchaseReduceCostReport.prototype.getYearOtherColumns = function (year_list) {
    var unit_width = 80;
    var reduce_cost_width = 90;

    for (var year_index in year_list) {
      var year = year_list[year_index];
      var column_info = {
        title: year,
        children: [{
          dataIndex: year + '_unit',
          key: year + '_unit',
          title: this.$t('columns.avg_price'),
          align: 'right',
          width: unit_width,
          customRender: function customRender(value, row, index) {
            if (!value) {
              return 0;
            }

            return value.toFixed(2);
          }
        }, {
          dataIndex: year + '_reduce_costs',
          key: year + '_reduce_costs',
          title: this.$t('columns.reduct_cost'),
          align: 'right',
          width: reduce_cost_width,
          customRender: function customRender(value, row, index) {
            if (!value) {
              return 0;
            }

            return value.toFixed(2);
          }
        }]
      };
      this.columnList.push(column_info);
    }

    return (unit_width + reduce_cost_width) * year_list.length;
  };

  PurchaseReduceCostReport.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getPurchaseReduceCostData();
  };

  PurchaseReduceCostReport.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseReduceCostReport.prototype.exportData = function () {
    this.getQueryCondition().then(function (x) {
      common_service["a" /* CommonService */].exportData('/purchase_requirement/export_purchase_reduce_costs_report', {
        query_condition: x.query_condition
      });
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseReduceCostReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseReduceCostReport.prototype, "pageContainer", void 0);

  PurchaseReduceCostReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-reduce-cost-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      Splitpanes: splitpanes_common["Splitpanes"],
      Pane: splitpanes_common["Pane"]
    }
  })], PurchaseReduceCostReport);
  return PurchaseReduceCostReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_reduce_cost_reportvue_type_script_lang_ts_ = (purchase_reduce_cost_reportvue_type_script_lang_ts_PurchaseReduceCostReport);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-reduce-cost-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_reduce_cost_reportvue_type_script_lang_ts_ = (purchase_reduce_cost_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-reduce-cost-report.vue?vue&type=custom&index=0&blockType=i18n
var purchase_reduce_cost_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("e056");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-reduce-cost-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_reduce_cost_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_reduce_cost_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_reduce_cost_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_reduce_cost_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "d74e":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"common_sku":"SKU","ship_date":"Ship Date","give_date":"Give Date","code":"Ship Plan Code","purchase_num":"Purchase No.","logistics_proveder_name":"Logistics Provider","state":"State"},"action":{"create":"Add Item","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","save":"Save","assign_provider":"Assign Provider"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","page_name":"Logistics Provider Detail"},"zh-cn":{"desc":"这是订单页面1","columns":{"common_sku":"SKU","ship_date":"发货日期","give_date":"订单交期","code":"发货计划编号","purchase_num":"采购订单编号","logistics_proveder_name":"物流商","state":"状态"},"action":{"create":"新建","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","save":"保存","assign_provider":"分配物流商"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","page_name":"物流商详情"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "daf3":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{},"zh-cn":{}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "e056":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_reduce_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("952a");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_reduce_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_reduce_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_reduce_cost_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "e0dd":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("8429");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "e526":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_give_date_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4681");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_give_date_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_give_date_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_give_date_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "e54e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-product-qty-report.vue?vue&type=template&id=2b28b7cb&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2},on:{"submit":_vm.getDetailList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.default_code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.prod_status')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['prod_status']),expression:"['prod_status']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Select Type"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-select-option',{key:"sale",attrs:{"value":"sale"}},[_vm._v(_vm._s(_vm.$t('columns.prod_status_sale'))+" ")]),_c('a-select-option',{key:"stop",attrs:{"value":"stop"}},[_vm._v(_vm._s(_vm.$t('columns.prod_status_stop'))+" ")]),_c('a-select-option',{key:"waiting",attrs:{"value":"waiting"}},[_vm._v(_vm._s(_vm.$t('columns.prod_status_waiting'))+" ")]),_c('a-select-option',{key:"sz_prod",attrs:{"value":"sz_prod"}},[_vm._v(_vm._s(_vm.$t('columns.prod_status_sz_prod'))+" ")]),_c('a-select-option',{key:"uk_sale",attrs:{"value":"uk_sale"}},[_vm._v(_vm._s(_vm.$t('columns.prod_status_uk_sale'))+" ")]),_c('a-select-option',{key:"tort_stop",attrs:{"value":"tort_stop"}},[_vm._v(_vm._s(_vm.$t('columns.prod_status_tort_stop'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.cn_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category']),expression:"['z_category']"}],staticStyle:{"width":"110px"},attrs:{"placeholder":"品类","size":"small","allowClear":""},on:{"change":_vm.handleFatherCateChange}},_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1),_c('a-select',{staticStyle:{"width":"220px","margin-left":"25px"},attrs:{"mode":"multiple","placeholder":"子类","size":"small"},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.exportData}},[_vm._v("Export")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex"},[_c('AutoColumnTable',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"id","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
            },"columns":_vm.columnList,"scroll":{ x: 1750, y: 600 }},on:{"on-page-change":_vm.getDetailList,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                }},scopedSlots:_vm._u([{key:"prod_status_render",fn:function(row){return [(row.prod_status == 'sale')?_c('span',[_vm._v(_vm._s(_vm.$t('columns.prod_status_sale')))]):(row.prod_status == 'stop')?_c('span',[_vm._v(_vm._s(_vm.$t('columns.prod_status_stop')))]):(row.prod_status == 'waiting')?_c('span',[_vm._v(_vm._s(_vm.$t('columns.prod_status_waiting')))]):(row.prod_status == 'sz_prod')?_c('span',[_vm._v(_vm._s(_vm.$t('columns.prod_status_sz_prod')))]):(row.prod_status == 'uk_sale')?_c('span',[_vm._v(_vm._s(_vm.$t('columns.prod_status_uk_sale')))]):(row.prod_status == 'tort_stop')?_c('span',[_vm._v(_vm._s(_vm.$t('columns.prod_status_tort_stop')))]):_vm._e()]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-qty-report.vue?vue&type=template&id=2b28b7cb&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/services/purchase.service.ts
var purchase_service = __webpack_require__("0d91");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-product-qty-report.vue?vue&type=script&lang=ts&















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_product_qty_reportvue_type_script_lang_ts_PurchaseProdQtyReport =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseProdQtyReport, _super);

  function PurchaseProdQtyReport() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.purchaseService = new purchase_service["a" /* PurchaseService */](); // 表格选择项

    _this.selectedRowKeys = [];
    _this.columnList = [];
    _this.data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  PurchaseProdQtyReport.prototype.created = function () {
    this.columnList = this.getBasicColumnInfo();
    this.getCn_cate();
  };

  PurchaseProdQtyReport.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  PurchaseProdQtyReport.prototype.getBasicColumnInfo = function () {
    return [{
      dataIndex: 'default_code',
      key: 'default_code',
      title: this.$t('columns.default_code'),
      width: 100,
      align: 'left'
    }, {
      key: 'prod_status',
      title: this.$t('columns.prod_status'),
      width: 80,
      align: 'center',
      scopedSlots: {
        customRender: 'prod_status_render'
      }
    }, {
      dataIndex: 'z_category',
      key: 'z_category',
      title: this.$t('columns.cn_category'),
      width: 80,
      align: 'left'
    }, {
      dataIndex: 'z_sub_category',
      key: 'z_sub_category',
      title: this.$t('columns.cn_sub_category'),
      width: 110,
      align: 'left'
    }, {
      dataIndex: 'department',
      key: 'department',
      title: this.$t('columns.department'),
      width: 80,
      align: 'left'
    }, {
      dataIndex: 'operator',
      key: 'operator',
      title: this.$t('columns.operator'),
      width: 80,
      align: 'center'
    }, {
      dataIndex: 'stock_de_available_qty',
      key: 'stock_de_available_qty',
      title: this.$t('columns.stock_de_available_qty'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'stock_uk_available_qty',
      key: 'stock_uk_available_qty',
      title: this.$t('columns.stock_uk_available_qty'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'stock_available_qty',
      key: 'stock_available_qty',
      title: this.$t('columns.stock_available_qty'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'de_cur_month',
      key: 'de_cur_month',
      title: this.$t('columns.de_cur_month'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'de_next_month',
      key: 'de_next_month',
      title: this.$t('columns.de_next_month'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'de_third_month',
      key: 'de_third_month',
      title: this.$t('columns.de_third_month'),
      width: 90,
      align: 'right'
    }, {
      dataIndex: 'uk_cur_month',
      key: 'uk_cur_month',
      title: this.$t('columns.uk_cur_month'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'uk_next_month',
      key: 'uk_next_month',
      title: this.$t('columns.uk_next_month'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'uk_third_month',
      key: 'uk_third_month',
      title: this.$t('columns.uk_third_month'),
      width: 90,
      align: 'right'
    }, {
      dataIndex: 'cur_month',
      key: 'cur_month',
      title: this.$t('columns.cur_month'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'next_month',
      key: 'next_month',
      title: this.$t('columns.next_month'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'third_month',
      key: 'third_month',
      title: this.$t('columns.third_month'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'de_product_qty',
      key: 'de_product_qty',
      title: this.$t('columns.de_product_qty'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'uk_product_qty',
      key: 'uk_product_qty',
      title: this.$t('columns.uk_product_qty'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'product_qty',
      key: 'product_qty',
      title: this.$t('columns.product_qty'),
      width: 80,
      align: 'right'
    }, {
      dataIndex: 'total',
      key: 'total',
      title: this.$t('columns.total'),
      width: 80,
      align: 'right'
    }];
  };

  PurchaseProdQtyReport.prototype.getQueryCondition = function () {
    var _this = this;

    return new Promise(function (reslove, reject) {
      _this.dataForm.validateFields().then(function (values) {
        if (_this.selectedList.length > 0) {
          values['z_sub_category'] = _this.selectedList;
        }

        var params = common_service["a" /* CommonService */].createQueryCondition(values, {
          default_code: 'like',
          z_sub_category: 'in'
        });
        reslove(params);
      }).catch(function (err) {// 异常处理
      });
    });
  };

  PurchaseProdQtyReport.prototype.getDetailList = function () {
    var _this = this;

    this.getQueryCondition().then(function (params) {
      _this.purchaseService.query_all_purchase_prod_qty_info(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.data = data.map(function (x, i) {
          x['id'] = i + 1;
          x['stock_available_qty'] = x.stock_de_available_qty + x.stock_uk_available_qty;
          x['total'] = x.product_qty + x.cur_month + x.next_month + x.third_month + x.stock_available_qty;
          return x;
        });
        _this.selectedRowKeys = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  PurchaseProdQtyReport.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  PurchaseProdQtyReport.prototype.exportData = function () {
    this.getQueryCondition().then(function (x) {
      common_service["a" /* CommonService */].exportData('/purchase_requirement/export_purchase_prod_qty_info', {
        query_condition: x.query_condition
      });
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseProdQtyReport.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseProdQtyReport.prototype, "pageContainer", void 0);

  PurchaseProdQtyReport = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-product-qty-report'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], PurchaseProdQtyReport);
  return PurchaseProdQtyReport;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_product_qty_reportvue_type_script_lang_ts_ = (purchase_product_qty_reportvue_type_script_lang_ts_PurchaseProdQtyReport);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-qty-report.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_product_qty_reportvue_type_script_lang_ts_ = (purchase_product_qty_reportvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-product-qty-report.vue?vue&type=custom&index=0&blockType=i18n
var purchase_product_qty_reportvue_type_custom_index_0_blockType_i18n = __webpack_require__("f379");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-qty-report.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_product_qty_reportvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_product_qty_reportvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_product_qty_reportvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_product_qty_report = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "e89c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-product-plan.vue?vue&type=template&id=6b4ced9d&scoped=true&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 0 }},on:{"submit":_vm.getPurchaseLineList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],staticStyle:{"width":"300px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.contact_no')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['real_pre_purchase_order']),expression:"['real_pre_purchase_order']"}],staticStyle:{"width":"300px"},attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_name']),expression:"['order_name']"}],staticStyle:{"width":"300px"},attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '300px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please select","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['order_date']),expression:"['order_date']"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"show-time":"","size":"small","format":"YYYY-MM-DD"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.give_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['give_date']),expression:"['give_date']"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"show-time":"","size":"small","format":"YYYY-MM-DD"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.un_finish_qty')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['un_finish_qty_from']),expression:"['un_finish_qty_from']"}],staticStyle:{"width":"100px"},attrs:{"size":"small","min":0,"precision":0,"placeholder":_vm.$t('plzInput'),"formatter":_vm.limitNumber,"parser":_vm.limitNumber}}),_vm._v(" ~ "),_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['un_finish_qty_to']),expression:"['un_finish_qty_to']"}],staticStyle:{"width":"100px"},attrs:{"size":"small","min":0,"precision":0,"formatter":_vm.limitNumber,"placeholder":_vm.$t('plzInput'),"parser":_vm.limitNumber}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.exists_attention')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'exists_attention',
                        { initialValue: _vm.defaultBoolValue }
                    ]),expression:"[\n                        'exists_attention',\n                        { initialValue: defaultBoolValue }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.finish_yn')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['finish_yn', { initialValue: false }]),expression:"['finish_yn', { initialValue: false }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.factory_finish')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'factory_finish',
                        { initialValue: _vm.defaultBoolValue }
                    ]),expression:"[\n                        'factory_finish',\n                        { initialValue: defaultBoolValue }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.is_purchase_changed')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'is_purchase_changed',
                        { initialValue: '' }
                    ]),expression:"[\n                        'is_purchase_changed',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.new_product')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['new_product', { initialValue: '' }]),expression:"['new_product', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.need_save_data_list.length},on:{"click":function($event){return _vm.save_changed_data()}}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left","disabled":!_vm.need_save_data_list.length},on:{"confirm":function($event){return _vm.discard_changed_data()}}},[_c('a-button',{attrs:{"type":"primary"}},[_vm._v(_vm._s(_vm.$t('action.discard'))+" ")])],1),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.export_unfinish_line()}}},[_vm._v(_vm._s(_vm.$t('action.export_unfinish_line'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.export_product_specification()}}},[_vm._v(_vm._s(_vm.$t('action.export_product_specification'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.edit_finish_qty_vendor}},[_vm._v(_vm._s(_vm.$t('action.edit_finish_qty_vendor'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.change_purchase_info}},[_vm._v(_vm._s(_vm.$t('action.change_purchase_info'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.cancel_attention}},[_vm._v(_vm._s(_vm.$t('action.cancel_attention'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.force_finish_trace}},[_vm._v(_vm._s(_vm.$t('action.force_finish_trace'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.unfinish_trace}},[_vm._v(_vm._s(_vm.$t('action.unfinish_trace'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.qc_confirm_ship}},[_vm._v(_vm._s(_vm.$t('action.qc_confirm_ship'))+" ")]),_c('a-menu-item',{on:{"click":_vm.import_trace_memo}},[_vm._v(_vm._s(_vm.$t('action.import_trace_memo_dlg'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.add_trace_memo}},[_vm._v(_vm._s(_vm.$t('action.add_trace_memo_dlg'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.sync_product_supplier}},[_vm._v(_vm._s(_vm.$t('action.sync_product_supplier'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v(_vm._s(_vm.$t('action.update_btn'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":_vm.showLog}},[_vm._v(_vm._s(_vm.$t('action.showlog'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"row-class-name":_vm.tableRowClass,"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getPurchaseLineList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"vendor_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm.getVendorName(text))+" ")])}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}},{key:"note",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.getEditTextChangedStyle(row, 'note')),attrs:{"size":"small","rows":"2","cols":"40","value":row.note ? row.note : ''},on:{"change":function (e) { return _vm.handleChange(e.target, row, 'note'); }}}):_c('span',{style:(_vm.getEditTextChangedStyle(row, 'note')),attrs:{"title":row.note}},[_vm._v(_vm._s(row.note ? row.note.length > 24 ? row.note.substr(0, 27) + '...' : row.note : ''))])]}},{key:"factory_finish",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-checkbox',{style:(_vm.getEditTextChangedStyle(row, 'factory_finish')),attrs:{"checked":row.factory_finish ? true : false},on:{"change":function (e) { return _vm.handleChange(e, row, 'factory_finish'); }}}):_c('a-checkbox',{style:(_vm.getEditTextChangedStyle(row, 'factory_finish')),attrs:{"checked":row.factory_finish ? true : false,"disabled":"disabled"}})]}},{key:"factory_finish_time",fn:function(text, row){return _c('span',{},[(_vm.editRow.id == row.id)?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.getEditTextChangedStyle(
                                row,
                                'factory_finish_time'
                            )),attrs:{"value":row.factory_finish_time
                                ? _vm.moment(
                                      row.factory_finish_time,
                                      'YYYY-MM-DD'
                                  )
                                : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.handleChange(e, row, 'factory_finish_time'); }}}):_c('span',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.getEditTextChangedStyle(
                                row,
                                'factory_finish_time'
                            ))},[_vm._v(_vm._s(row.factory_finish_time ? _vm.moment(row.factory_finish_time).format( 'YYYY-MM-DD' ) : null))])],1)}},{key:"factory_finish_qty",fn:function(text, row){return _c('span',{},[(_vm.editRow.id == row.id)?_c('input',{staticStyle:{"width":"90%","margin":"3px 0","border":"0px","text-align":"right"},style:(_vm.getEditTextChangedStyle(
                                row,
                                'factory_finish_qty'
                            )),domProps:{"value":row.factory_finish_qty},on:{"change":function (e) { return _vm.handleChange(
                                    e.target,
                                    row,
                                    'factory_finish_qty'
                                ); }}}):_c('span',{staticStyle:{"width":"90%","margin":"3px 0","border":"0px","text-align":"right"},style:(_vm.getEditTextChangedStyle(
                                row,
                                'factory_finish_qty'
                            ))},[_vm._v(_vm._s(row.factory_finish_qty)+" ")])])}}],null,false,2524999244)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"row-class-name":_vm.tableRowClass,"urlStr":"purchase_order_plan/query_all"},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"vendor_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm.getVendorName(text))+" ")])}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}},{key:"note",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.getEditTextChangedStyle(row, 'note')),attrs:{"size":"small","rows":"2","cols":"40","value":row.note ? row.note : ''},on:{"change":function (e) { return _vm.handleChange(e.target, row, 'note'); }}}):_c('span',{style:(_vm.getEditTextChangedStyle(row, 'note')),attrs:{"title":row.note}},[_vm._v(_vm._s(row.note ? row.note.length > 24 ? row.note.substr(0, 27) + '...' : row.note : ''))])]}},{key:"factory_finish",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-checkbox',{style:(_vm.getEditTextChangedStyle(row, 'factory_finish')),attrs:{"checked":row.factory_finish ? true : false},on:{"change":function (e) { return _vm.handleChange(e, row, 'factory_finish'); }}}):_c('a-checkbox',{style:(_vm.getEditTextChangedStyle(row, 'factory_finish')),attrs:{"checked":row.factory_finish ? true : false,"disabled":"disabled"}})]}},{key:"factory_finish_time",fn:function(text, row){return _c('span',{},[(_vm.editRow.id == row.id)?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.getEditTextChangedStyle(row, 'factory_finish_time')),attrs:{"value":row.factory_finish_time
                            ? _vm.moment(row.factory_finish_time, 'YYYY-MM-DD')
                            : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.handleChange(e, row, 'factory_finish_time'); }}}):_c('span',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.getEditTextChangedStyle(row, 'factory_finish_time'))},[_vm._v(_vm._s(row.factory_finish_time ? _vm.moment(row.factory_finish_time).format( 'YYYY-MM-DD' ) : null))])],1)}},{key:"factory_finish_qty",fn:function(text, row){return _c('span',{},[(_vm.editRow.id == row.id)?_c('input',{staticStyle:{"width":"90%","margin":"3px 0","border":"0px","text-align":"right"},style:(_vm.getEditTextChangedStyle(row, 'factory_finish_qty')),domProps:{"value":row.factory_finish_qty},on:{"change":function (e) { return _vm.handleChange(
                                e.target,
                                row,
                                'factory_finish_qty'
                            ); }}}):_c('span',{staticStyle:{"width":"90%","margin":"3px 0","border":"0px","text-align":"right"},style:(_vm.getEditTextChangedStyle(row, 'factory_finish_qty'))},[_vm._v(_vm._s(row.factory_finish_qty)+" ")])])}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-plan.vue?vue&type=template&id=6b4ced9d&scoped=true&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__("a9e3");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/components/common-page.vue + 4 modules
var common_page = __webpack_require__("b232");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-contract.vue + 4 modules
var add_replenish_contract = __webpack_require__("fba3");

// EXTERNAL MODULE: ./src/components/purchase/purchase-finish-item.vue + 4 modules
var purchase_finish_item = __webpack_require__("57fb4");

// EXTERNAL MODULE: ./src/components/purchase/add-purchase-product-plan-memo.vue + 4 modules
var add_purchase_product_plan_memo = __webpack_require__("e186");

// EXTERNAL MODULE: ./src/components/purchase/import-purchase-product-plan-memo.vue + 4 modules
var import_purchase_product_plan_memo = __webpack_require__("36ec");

// EXTERNAL MODULE: ./src/components/purchase/purchase-cancel-attention.vue + 4 modules
var purchase_cancel_attention = __webpack_require__("fc12");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/components/purchase/edit-finish-qty-vendor.vue + 4 modules
var edit_finish_qty_vendor = __webpack_require__("ac1c");

// EXTERNAL MODULE: ./src/components/purchase/change-purchase-info.vue + 4 modules
var change_purchase_info = __webpack_require__("2086");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-product-plan.vue?vue&type=script&lang=ts&



































var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_product_planvue_type_script_lang_ts_PurchaseProductPlan =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseProductPlan, _super);

  function PurchaseProductPlan() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.defaultBoolValue = '';
    _this.record_code = 0;
    _this.orderBy = 'create_date desc';
    _this.need_save_data_list = [];
    _this.moment = moment_default.a;
    _this.editRow = {
      id: null
    };
    _this.groupbyList = [];
    _this.columnList = [];
    _this.allNameAuth = [];
    return _this;
  }

  Object.defineProperty(PurchaseProductPlan.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchaseProductPlan.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
  };

  PurchaseProductPlan.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  PurchaseProductPlan.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  PurchaseProductPlan.prototype.getPurchaseLineList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: 'in_or_like',
        order_name: 'like',
        real_pre_purchase_order: 'like'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            var startDate = {};

            for (var key in item.value[0]) {
              startDate[key] = item.value[0][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(startDate.utc())
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            var endDate = {};

            for (var key in item.value[1]) {
              endDate[key] = item.value[1][key];
            }

            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(endDate.utc())
            });
          }
        } else {
          if (item.query_name == 'un_finish_qty_from') {
            item.query_name = 'un_finish_qty';
            item.operate = '>=';
          } else if (item.query_name == 'un_finish_qty_to') {
            item.query_name = 'un_finish_qty';
            item.operate = '<=';
          }

          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI('purchase_order_plan/query_all', common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchaseProductPlan.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseProductPlan.prototype.getVendorName = function (code) {
    var cd = Object(esm_typeof["a" /* default */])(code) == 'object' ? code[0] : code;
    var ret = cd;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == cd;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchaseProductPlan.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getPurchaseLineList();
  };

  PurchaseProductPlan.prototype.onRowClick = function (row) {
    var info = this.data.find(function (x) {
      return x.id === row;
    });
    this.editRow = {
      id: row
    };
    this.record_code = row;
  };

  PurchaseProductPlan.prototype.getEditTextChangedStyle = function (row, column) {
    if (column == 'note' || column == 'factory_finish' || column == 'factory_finish_qty' || column == 'factory_finish_time') {
      if (row.hasOwnProperty(column + '_changed')) {
        return 'text-align:right;background-color:yellow;font-weight:bolder';
      }

      return 'text-align:right';
    }

    return 'text-align:right';
  };

  PurchaseProductPlan.prototype.save_changed_data = function () {
    var _this = this;

    if (this.need_save_data_list.length == 0) {
      this.$message.info('没有需要保存的数据。');
      return;
    }

    this.innerAction.setActionAPI('purchase_order_plan/batch_save', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      change_schedule_data_list: this.need_save_data_list
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.reset_data();

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  PurchaseProductPlan.prototype.handleChange = function (value, row, column) {
    if (Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target != undefined && value.target.value != undefined) {
        value = value.target.value;
      } else if (value.target != undefined && value.target.checked != undefined) {
        value = value.target.checked;
      }
    } else {
      value = value.value;
    }

    if (row[column] != value) {
      row[column] = value;

      if (column == 'note') {
        row.note_changed = true;
        var exists_item_1 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_1) {
          exists_item_1['note'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            note: value
          });
        }
      } else if (column == 'factory_finish') {
        row.factory_finish_changed = true;
        var exists_item_2 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_2) {
          exists_item_2['factory_finish'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            factory_finish: value
          });
        }
      } else if (column == 'factory_finish_time') {
        row.factory_finish_time_changed = true;
        var exists_item_3 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_3) {
          exists_item_3['factory_finish_time'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            factory_finish_time: value
          });
        }
      } else if (column == 'factory_finish_qty') {
        row.factory_finish_qty_changed = true;
        var exists_item_4 = this.need_save_data_list.find(function (x) {
          return x.id == row.id;
        });

        if (exists_item_4) {
          exists_item_4['factory_finish_qty'] = value;
        } else {
          this.need_save_data_list.push({
            id: row.id,
            factory_finish_qty: value
          });
        }
      }
    }

    var newdata = tslib_es6["a" /* __assign */]({}, this.editRow);

    newdata[column] = value;
    this.editRow = newdata;
  };

  PurchaseProductPlan.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchaseProductPlan.prototype.reset_data = function () {
    for (var index in this.need_save_data_list) {
      var item = this.need_save_data_list[index];
      var obj = this.data.find(function (x) {
        return x.id === item.id;
      });

      if (obj && obj.hasOwnProperty('note_changed')) {
        delete obj.note_changed;
      }

      if (obj && obj.hasOwnProperty('factory_finish_changed')) {
        delete obj.factory_finish_changed;
      }

      if (obj && obj.hasOwnProperty('factory_finish_time_changed')) {
        delete obj.factory_finish_time_changed;
      }

      if (obj && obj.hasOwnProperty('factory_finish_qty_changed')) {
        delete obj.factory_finish_qty_changed;
      }
    }

    this.need_save_data_list = [];
  };

  PurchaseProductPlan.prototype.discard_changed_data = function () {
    this.reset_data();
  };

  PurchaseProductPlan.prototype.edit_finish_qty_vendor = function () {
    var _this = this;

    this.$modal.open(edit_finish_qty_vendor["a" /* default */], {
      data: this.data.filter(function (x) {
        return _this.selectedRowKeys.indexOf(x.id) !== -1;
      })
    }, {
      title: this.$t('action.edit_finish_qty_vendor'),
      width: '1000px'
    }).subscribe(function (data) {
      if (data) {
        _this.$message.success('修改成功');

        _this.reset_data();
      }
    });
  };

  PurchaseProductPlan.prototype.change_purchase_info = function () {
    var _this = this;

    this.$modal.open(change_purchase_info["a" /* default */], {
      id_list: this.selectedRowKeys,
      userList: this.systemUsers,
      vendorList: this.vendorFullNameList
    }, {
      title: this.$t('action.change_purchase_info'),
      width: '1000px'
    }).subscribe(function (data) {
      if (data) {
        _this.$message.success('修改成功');

        _this.reset_data();
      }
    });
  };

  PurchaseProductPlan.prototype.export_unfinish_line = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_order_plan/export_unfinish_make_order&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&id_list=' + urlParams);
  };

  PurchaseProductPlan.prototype.export_product_specification = function () {
    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/system_api/download?inner_action=purchase_order_plan/export_manual_requirement&menu_code=' + common_service["a" /* CommonService */].getMenuCode() + '&id_list=' + urlParams);
  };

  PurchaseProductPlan.prototype.cancel_attention = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_order_plan/query_purchase_requirement_line', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$modal.open(purchase_cancel_attention["a" /* default */], {
        info: data
      }, {
        title: _this.$t('action.cancel_attention_dlg'),
        width: '1000px'
      }).subscribe(function (data) {
        var _loop_1 = function _loop_1(key) {
          obj = _this.data.find(function (x) {
            return x.id === key;
          });
          obj.exists_attention = false;
        };

        var obj;

        for (var _i = 0, _a = _this.selectedRowKeys; _i < _a.length; _i++) {
          var key = _a[_i];

          _loop_1(key);
        }

        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseProductPlan.prototype.force_finish_trace = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_order_plan/query_purchase_requirement_line', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$modal.open(purchase_finish_item["a" /* default */], {
        info: data
      }, {
        title: _this.$t('action.purchase_finish_dlg'),
        width: '1000px'
      }).subscribe(function (data) {
        var _loop_2 = function _loop_2(key) {
          obj = _this.data.find(function (x) {
            return x.id === key;
          });
          obj.exists_attention = false;
        };

        var obj;

        for (var _i = 0, _a = _this.selectedRowKeys; _i < _a.length; _i++) {
          var key = _a[_i];

          _loop_2(key);
        }

        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseProductPlan.prototype.unfinish_trace = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_order_plan/unfinish_purchase_item', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.reset_data();

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  PurchaseProductPlan.prototype.qc_confirm_ship = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_order_plan/qc_confirm_state', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.reset_data();

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  PurchaseProductPlan.prototype.sync_product_supplier = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_order_plan/sync_product_supplier', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.reset_data();

      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);

      return;
    });
  };

  PurchaseProductPlan.prototype.add_trace_memo = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_order_plan/query_purchase_requirement_line', common_service["a" /* CommonService */].getMenuCode());
    var contact_no = this.data.find(function (x) {
      return x.id == _this.selectedRowKeys[0];
    }).real_pre_purchase_order;
    this.publicService.query(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (line_data) {
      _this.$modal.open(add_purchase_product_plan_memo["a" /* default */], {
        info: line_data,
        contact_no: contact_no
      }, {
        title: _this.$t('action.add_trace_memo_dlg'),
        width: '1000px'
      }).subscribe(function (data) {
        var _loop_3 = function _loop_3(key) {
          obj = _this.data.find(function (x) {
            return x.id === key;
          });
          obj.exists_attention = false;
        };

        var obj;

        for (var _i = 0, _a = _this.selectedRowKeys; _i < _a.length; _i++) {
          var key = _a[_i];

          _loop_3(key);
        }

        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseProductPlan.prototype.import_trace_memo = function () {
    var _this = this;

    this.$modal.open(import_purchase_product_plan_memo["a" /* default */], {}, {
      title: this.$t('action.import_trace_memo_dlg'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('导入成功');
    });
  };

  PurchaseProductPlan.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  PurchaseProductPlan.prototype.showLog = function () {
    var _this = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('每次只能查看一条数据的日志');
      return;
    }

    this.$modal.open(log_view["a" /* default */], {
      object_name: 'req_line',
      is_special_table: true,
      record_code: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.showlog'),
      width: '1000px'
    }).subscribe(function () {//
    }, function (err) {
      _this.$message.error('error');
    });
  }; //更换行数据样式


  PurchaseProductPlan.prototype.tableRowClass = function (record) {
    if (record.exists_attention) {
      if (record.attention_item === 'produce') {
        return 'redRow';
      }

      if (record.attention_item === 'package') {
        return 'greenRow';
      }

      if (record.attention_item === 'materials') {
        return 'blueRow';
      }
    }

    if (record.is_purchase_changed) {
      return 'purpleRow';
    }

    return '';
  }; //限制数字输入框只能输入整数


  PurchaseProductPlan.prototype.limitNumber = function (value) {
    if (typeof value === 'string') {
      return !isNaN(Number(value)) ? value.replace(/\./g, '') : 0;
    } else if (typeof value === 'number') {
      return !isNaN(value) ? String(value).replace(/\./g, '') : 0;
    } else {
      return 0;
    }
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchaseProductPlan.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchaseProductPlan.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseProductPlan.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseProductPlan.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseProductPlan.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseProductPlan.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseProductPlan.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseProductPlan.prototype, "getVendorFullNameList", void 0);

  PurchaseProductPlan = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-product-plan'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddReplenishContract: add_replenish_contract["a" /* default */],
      EditFinishQtyVendor: edit_finish_qty_vendor["a" /* default */],
      ChangePurchaseInfo: change_purchase_info["a" /* default */],
      PurchaseFinishItem: purchase_finish_item["a" /* default */],
      AddTraceMemoDlg: add_purchase_product_plan_memo["a" /* default */],
      PurchaseCancelAtentioin: purchase_cancel_attention["a" /* default */],
      CommonPage: common_page["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], PurchaseProductPlan);
  return PurchaseProductPlan;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_product_planvue_type_script_lang_ts_ = (purchase_product_planvue_type_script_lang_ts_PurchaseProductPlan);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-plan.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_product_planvue_type_script_lang_ts_ = (purchase_product_planvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/pages/purchase/purchase-product-plan.vue?vue&type=style&index=0&id=6b4ced9d&scoped=true&lang=css&
var purchase_product_planvue_type_style_index_0_id_6b4ced9d_scoped_true_lang_css_ = __webpack_require__("9848");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-product-plan.vue?vue&type=custom&index=0&blockType=i18n
var purchase_product_planvue_type_custom_index_0_blockType_i18n = __webpack_require__("fb47");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-product-plan.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_product_planvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  "6b4ced9d",
  null
  
)

/* custom blocks */

if (typeof purchase_product_planvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_product_planvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_product_plan = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "f12d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("65a5");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_logistics_providers_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "f379":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_qty_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("8a0e");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_qty_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_qty_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_qty_report_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "f762":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/shipping-plan-manage.vue?vue&type=template&id=982e6dc2&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 6 },"wrapperCol":{ span: 15, offset: 0 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.common_sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['common_sku']),expression:"['common_sku']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.code')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['code']),expression:"['code']"}],staticStyle:{"width":"300px"},attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.ship_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_date']),expression:"['ship_date']"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.logistics_proveder_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['logistics_id', { initialValue: '' }]),expression:"['logistics_id', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.providerList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.give_date')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['give_date']),expression:"['give_date']"}],staticStyle:{"width":"200px"},attrs:{"format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.purchase_num')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['purchase_num']),expression:"['purchase_num']"}],staticStyle:{"width":"300px"},attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.state')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"size":"small","placeholder":"Please Select","mode":"multiple"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.ShippingPlanState),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.needSaveNotes.length},on:{"click":_vm.changeNote}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.onAssignProvider}},[_vm._v(_vm._s(_vm.$t('action.assign_provider'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('delete'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left","disabled":!_vm.selectedRowKeys.length},on:{"confirm":function($event){return _vm.onDelete()}}},[_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"index","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"available_ship_qty",fn:function(text, row){return [_vm._v(" "+_vm._s(Math.max(0, row.product_qty - row.shipped_qty))+" ")]}},{key:"date_ranger",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_ranger",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers))+" ")])}},{key:"ship_aging",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'LogisticsProviderAging')))+" ")])}},{key:"product_name",fn:function(text, row){return [_c('span',{attrs:{"title":row.product_name}},[_vm._v(_vm._s(row.product_name ? row.product_name.length > 24 ? row.product_name.substr(0, 27) + '...' : row.product_name : ''))])]}},{key:"ship_qty",fn:function(text, row){return [(_vm.editRow.index == row.index)?_c('a-input-number',{attrs:{"size":"small","value":row.ship_qty,"min":1},on:{"change":function (e) { return _vm.handleChange(e, row, 'ship_qty'); }}}):_c('span',[_vm._v(_vm._s(row.ship_qty))])]}},{key:"state",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'ShippingPlanState')))+" ")]}}],null,false,2372663458)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"available_ship_qty",fn:function(text, row){return [_vm._v(" "+_vm._s(Math.max(0, row.product_qty - row.shipped_qty))+" ")]}},{key:"date_ranger",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"user_ranger",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers))+" ")])}},{key:"product_name",fn:function(text, row){return [_c('span',{attrs:{"title":row.product_name}},[_vm._v(_vm._s(row.product_name ? row.product_name.length > 24 ? row.product_name.substr(0, 27) + '...' : row.product_name : ''))])]}},{key:"ship_qty",fn:function(text, row){return [(_vm.editRow.index == row.index)?_c('a-input-number',{attrs:{"size":"small","value":row.ship_qty},on:{"change":function (e) { return _vm.handleChange(e, row, 'ship_qty'); }}}):_c('span',[_vm._v(_vm._s(row.ship_qty))])]}},{key:"state",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'ShippingPlanState')))+" ")]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/shipping-plan-manage.vue?vue&type=template&id=982e6dc2&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-contract.vue + 4 modules
var add_replenish_contract = __webpack_require__("fba3");

// EXTERNAL MODULE: ./src/components/purchase/purchase-return.vue + 4 modules
var purchase_return = __webpack_require__("fe3b");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/components/purchase/assign_provider.vue + 4 modules
var assign_provider = __webpack_require__("0873");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/shipping-plan-manage.vue?vue&type=script&lang=ts&





























var datasModule = Object(lib["c" /* namespace */])('datasModule');
var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var shipping_plan_managevue_type_script_lang_ts_ShippingPlanManage =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ShippingPlanManage, _super);

  function ShippingPlanManage() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.stateList = [{
      code: 'active',
      name: 'Active'
    }, {
      code: 'inactive',
      name: 'Inactive'
    }];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.editRow = {
      index: null
    };
    _this.providerList = [];
    _this.queryUrl = '/shipping_plan/query_all';
    _this.needSaveNotes = [];
    return _this;
  }

  Object.defineProperty(ShippingPlanManage.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ShippingPlanManage.prototype.created = function () {
    this.getSystemuser();
    this.getcurrency();
    this.getProviders();
  };

  ShippingPlanManage.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  ShippingPlanManage.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  ShippingPlanManage.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        name: 'in_or_like',
        code: 'like'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data.map(function (x) {
            x['index'] = uuid_default.a.generate();
            return x;
          });
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ShippingPlanManage.prototype.onAssignProvider = function () {
    var _this = this;

    var info = this.data.filter(function (x) {
      return _this.selectedRowKeys.includes(x.index);
    });
    this.$modal.open(assign_provider["a" /* default */], {
      info: info,
      systemUsers: this.systemUsers
    }, {
      title: this.$t('action.assign_provider'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.getDataList();
    });
  };

  ShippingPlanManage.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  ShippingPlanManage.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ShippingPlanManage.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ShippingPlanManage.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  ShippingPlanManage.prototype.calcStyle = function (row) {
    this.$nextTick(function () {
      if (row.date_approve && !row.new_product) {
        var no_order_7day = row.no_order_7day;
        var no_order_3day = row.no_order_3day;
        var sp = document.getElementById('id' + row.id);
        var tr = sp.parentNode.parentNode;

        if (no_order_7day) {
          tr.style.color = 'red';
        } else if (no_order_3day) {
          tr.style.color = '#f90';
        }
      }
    });
  };

  ShippingPlanManage.prototype.onRowClick = function (row) {
    this.editRow = {
      index: row
    };
  };

  ShippingPlanManage.prototype.handleChange = function (e, row, column) {
    row[column] = e;
    var item = this.needSaveNotes.find(function (x) {
      return x.index == row.index;
    });

    if (item) {
      item[column] = e;
    } else {
      var note = {
        index: row.index,
        id: row.id
      };
      note[column] = e;
      this.needSaveNotes.push(note);
    }
  };

  ShippingPlanManage.prototype.changeNote = function (row) {
    var _this = this;

    var data_list = [];
    var params = JSON.parse(JSON.stringify(this.needSaveNotes.filter(function (x) {
      return _this.selectedRowKeys.includes(x.index);
    })));

    if (!params.length) {
      this.$message.error('请先选择要保存的行');
      return;
    }

    for (var _i = 0, params_1 = params; _i < params_1.length; _i++) {
      var i = params_1[_i];
      delete i.index;
    }

    this.innerAction.setActionAPI('/shipping_plan/confirm_action', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      data_list: params
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShippingPlanManage.prototype.onDelete = function () {
    var _this = this;

    var ids = [];

    var _loop_1 = function _loop_1(i) {
      var item = this_1.data.find(function (x) {
        return x.index == i;
      });

      if (item) {
        ids.push(item.id);
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      _loop_1(i);
    }

    this.innerAction.setActionAPI('/shipping_plan/delete_shipping_plan', common_service["a" /* CommonService */].getMenuCode('shipping-plan-manage'));
    this.publicService.modify(new http["RequestParams"]({
      id_list: ids
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.data = _this.data.filter(function (x) {
        return !_this.selectedRowKeys.includes(x.index);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShippingPlanManage.prototype.getProviders = function () {
    var _this = this;

    this.innerAction.setActionAPI('/logistics_providers/query_logistics_code', common_service["a" /* CommonService */].getMenuCode('shipping-plan-manage'));
    this.publicService.query(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.providerList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ShippingPlanManage.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ShippingPlanManage.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShippingPlanManage.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ShippingPlanManage.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShippingPlanManage.prototype, "currencyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ShippingPlanManage.prototype, "getcurrency", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], ShippingPlanManage.prototype, "addCommonPageInfo", void 0);

  ShippingPlanManage = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'shipping-plan-manage'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddReplenishContract: add_replenish_contract["a" /* default */],
      PurchaseReturn: purchase_return["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ShippingPlanManage);
  return ShippingPlanManage;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var shipping_plan_managevue_type_script_lang_ts_ = (shipping_plan_managevue_type_script_lang_ts_ShippingPlanManage);
// CONCATENATED MODULE: ./src/pages/purchase/shipping-plan-manage.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_shipping_plan_managevue_type_script_lang_ts_ = (shipping_plan_managevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/shipping-plan-manage.vue?vue&type=custom&index=0&blockType=i18n
var shipping_plan_managevue_type_custom_index_0_blockType_i18n = __webpack_require__("5a79");

// CONCATENATED MODULE: ./src/pages/purchase/shipping-plan-manage.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_shipping_plan_managevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof shipping_plan_managevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(shipping_plan_managevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var shipping_plan_manage = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "f78e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("097c");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_replenishment_edit_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "f7a8":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "f7b9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c04c");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_package_manage_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "f820":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3bcb");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_ship_order_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "fac9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-pre-make-order.vue?vue&type=template&id=1efdbddc&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('page-container',{ref:"pageContainer",attrs:{"showHeader":false},scopedSlots:_vm._u([{key:"header-action",fn:function(){return undefined},proxy:true}])},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16, offset: 0 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.req_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['req_name']),expression:"['req_name']"}],staticStyle:{"width":"240px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],staticStyle:{"width":"240px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.date_expected')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['date_expected']),expression:"['date_expected']"}],style:({ width: '240px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.sales_expected_give_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sales_expected_give_date']),expression:"['sales_expected_give_date']"}],style:({ width: '240px' }),attrs:{"show-time":"","format":"YYYY-MM-DD","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_id', { initialValue: '' }]),expression:"['vendor_id', { initialValue: '' }]"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vendorFullNameList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ width: '240px' }),attrs:{"size":"small","placeholder":_vm.$t('plzSelect')}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.user_purchase')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['user_purchase']),expression:"['user_purchase']"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.merchandiser')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['merchandiser']),expression:"['merchandiser']"}],style:({ width: '240px' }),attrs:{"showSearch":"","size":"small","placeholder":_vm.$t('plzSelect'),"filterOption":_vm.filterSelectOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.needSaveNotes.length},on:{"click":_vm.changeNote}},[_vm._v(_vm._s(_vm.$t('action.save'))+" ")]),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('new'),expression:"'new'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.onCreate}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")]),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('return'),expression:"'return'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.returnPurchase}},[_vm._v(_vm._s(_vm.$t('action.return_purchase'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.syncSupplierProductSupplierInfo}},[_vm._v(_vm._s(_vm.$t('action.syncSupplierProductSupplierInfo'))+" ")]),_c('a-button',{directives:[{name:"auth",rawName:"v-auth",value:('edit'),expression:"'edit'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.changePurchaseInfo}},[_vm._v(_vm._s(_vm.$t('action.changePurchaseInfo'))+" ")])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 400 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"vendor",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm.getVendorName(text))+" ")])}},{key:"date_approve",fn:function(text, row){return [_c('span',{attrs:{"id":'id' + row.id}},[_vm._v(_vm._s(text ? text : '')+" "+_vm._s(_vm.calcStyle(row)))])]}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}},{key:"no_process_note",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"2","cols":"40","value":row.no_process_note ? row.no_process_note : ''},on:{"change":function (e) { return _vm.handleChange(e, row, 'no_process_note'); }}}):_c('span',{attrs:{"title":row.no_process_note}},[_vm._v(_vm._s(row.no_process_note ? row.no_process_note.length > 24 ? row.no_process_note.substr(0, 27) + '...' : row.no_process_note : ''))])]}}],null,false,1487648539)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"vendor",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm.getVendorName(text))+" ")])}},{key:"date_approve",fn:function(text, row){return [_c('span',{attrs:{"id":'id' + row.id}},[_vm._v(_vm._s(text ? text : '')+" "+_vm._s(_vm.calcStyle(row)))])]}},{key:"warehouse_render",fn:function(text){return [(text == 'de')?_c('span',[_vm._v("DE")]):(text == 'uk')?_c('span',[_vm._v("UK")]):_c('span',[_vm._v(_vm._s(text))])]}},{key:"no_process_note",fn:function(text, row){return [(_vm.editRow.id == row.id)?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"2","cols":"40","value":row.no_process_note ? row.no_process_note : ''},on:{"change":function (e) { return _vm.handleChange(e, row, 'no_process_note'); }}}):_c('span',{attrs:{"title":row.no_process_note}},[_vm._v(_vm._s(row.no_process_note ? row.no_process_note.length > 24 ? row.no_process_note.substr(0, 27) + '...' : row.no_process_note : ''))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/pages/purchase/purchase-pre-make-order.vue?vue&type=template&id=1efdbddc&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/components/purchase/add-replenish-contract.vue + 4 modules
var add_replenish_contract = __webpack_require__("fba3");

// EXTERNAL MODULE: ./src/components/purchase/purchase-return.vue + 4 modules
var purchase_return = __webpack_require__("fe3b");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/components/purchase/purchase-modify-purchase-info.vue + 4 modules
var purchase_modify_purchase_info = __webpack_require__("1b27");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/pages/purchase/purchase-pre-make-order.vue?vue&type=script&lang=ts&
























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var purchase_pre_make_ordervue_type_script_lang_ts_PurchasePreMakeOrder =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchasePreMakeOrder, _super);

  function PurchasePreMakeOrder() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.reasonList = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.current = null;
    _this.orderBy = 'create_date desc';
    _this.columnList = [];
    _this.editRow = {
      id: null
    };
    _this.queryUrl = '/purchase_requirement/pre_make_order';
    _this.needSaveNotes = [];
    return _this;
  }

  Object.defineProperty(PurchasePreMakeOrder.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PurchasePreMakeOrder.prototype.created = function () {
    this.getcompany();
    this.getSystemuser();
    this.getVendorFullNameList();
  };

  PurchasePreMakeOrder.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
  };

  PurchasePreMakeOrder.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  PurchasePreMakeOrder.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: 'in_or_like',
        req_name: 'in_or_like'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  PurchasePreMakeOrder.prototype.onCreate = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_requirement/query_pre_make_order_lines', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var item = _this.data.find(function (x) {
        return x.id == _this.selectedRowKeys[0];
      });

      _this.$modal.open(add_replenish_contract["a" /* default */], {
        info: data,
        systemUsers: _this.systemUsers,
        vendorList: _this.vendorFullNameList
      }, {
        title: _this.$t('action.add_replenishment_contract'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('操作成功');

        _this.getDataList();
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePreMakeOrder.prototype.returnPurchase = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_requirement/query_pre_make_order_lines', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.query(new http["RequestParams"]({
      line_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$modal.open(purchase_return["a" /* default */], {
        info: data
      }, {
        title: _this.$t('action.purchase_return'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('操作成功');

        _this.getDataList();
      }, function (err) {
        _this.$message.error(err.message);
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePreMakeOrder.prototype.getUserName = function (code) {
    var ret = code;
    var item = this.systemUsers.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePreMakeOrder.prototype.getVendorName = function (code) {
    var cd = Object(esm_typeof["a" /* default */])(code) == 'object' ? code[0] : code;
    var ret = cd;
    var item = this.vendorFullNameList.find(function (x) {
      return x.code == cd;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePreMakeOrder.prototype.getCompanyName = function (code) {
    var ret = code;
    var item = this.companyList.find(function (x) {
      return x.code == code;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PurchasePreMakeOrder.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PurchasePreMakeOrder.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  PurchasePreMakeOrder.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  PurchasePreMakeOrder.prototype.calcStyle = function (row) {
    this.$nextTick(function () {
      if (row.date_approve && !row.new_product) {
        var no_order_7day = row.no_order_7day;
        var no_order_3day = row.no_order_3day;
        var sp = document.getElementById('id' + row.id);
        var tr = sp.parentNode.parentNode;

        if (no_order_7day) {
          tr.style.color = 'red';
        } else if (no_order_3day) {
          tr.style.color = '#f90';
        }
      }
    });
  };

  PurchasePreMakeOrder.prototype.onRowClick = function (row) {
    this.editRow = {
      id: row
    };
  };

  PurchasePreMakeOrder.prototype.handleChange = function (e, row, column) {
    row[column] = e.target.value;
    var item = this.needSaveNotes.find(function (x) {
      return x.id == row.id;
    });

    if (item) {
      item.no_process_note = e.target.value;
    } else {
      this.needSaveNotes.push({
        id: row.id,
        no_process_note: e.target.value
      });
    }
  };

  PurchasePreMakeOrder.prototype.changeNote = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('purchase_management/save_pre_make_order_purchase_line', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      req_line_list: this.needSaveNotes
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePreMakeOrder.prototype.changePurchaseInfo = function () {
    var _this = this;

    this.$modal.open(purchase_modify_purchase_info["a" /* default */], {
      ids: this.selectedRowKeys,
      userList: this.systemUsers
    }, {
      title: this.$t('action.changePurchaseInfo'),
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('Update Success');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePreMakeOrder.prototype.syncSupplierProductSupplierInfo = function () {
    var _this = this;

    this.innerAction.setActionAPI('purchase_requirement/sync_supplier_product_supplier_info', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      line_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PurchasePreMakeOrder.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PurchasePreMakeOrder.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePreMakeOrder.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePreMakeOrder.prototype, "getcompany", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePreMakeOrder.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePreMakeOrder.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePreMakeOrder.prototype, "vendorFullNameList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePreMakeOrder.prototype, "getVendorFullNameList", void 0);

  PurchasePreMakeOrder = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'purchase-pre-make-order'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      AddReplenishContract: add_replenish_contract["a" /* default */],
      PurchaseReturn: purchase_return["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], PurchasePreMakeOrder);
  return PurchasePreMakeOrder;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_pre_make_ordervue_type_script_lang_ts_ = (purchase_pre_make_ordervue_type_script_lang_ts_PurchasePreMakeOrder);
// CONCATENATED MODULE: ./src/pages/purchase/purchase-pre-make-order.vue?vue&type=script&lang=ts&
 /* harmony default export */ var purchase_purchase_pre_make_ordervue_type_script_lang_ts_ = (purchase_pre_make_ordervue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/pages/purchase/purchase-pre-make-order.vue?vue&type=custom&index=0&blockType=i18n
var purchase_pre_make_ordervue_type_custom_index_0_blockType_i18n = __webpack_require__("7a3a");

// CONCATENATED MODULE: ./src/pages/purchase/purchase-pre-make-order.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  purchase_purchase_pre_make_ordervue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_pre_make_ordervue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_pre_make_ordervue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_pre_make_order = __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "fb47":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0e5f");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_product_plan_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ })

}]);