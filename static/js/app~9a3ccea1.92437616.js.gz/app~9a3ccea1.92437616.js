(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~9a3ccea1"],{

/***/ "0092":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-unsalable-report-content.vue?vue&type=template&id=75b349e3&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('data-form',{ref:"dataForm",attrs:{"column":2,"labelCol":{ span: 5 },"wrapperCol":{ span: 16 }},on:{"submit":_vm.getDataList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.sku')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'sku_type',
                        { initialValue: 'default_code' }
                    ]),expression:"[\n                        'sku_type',\n                        { initialValue: 'default_code' }\n                    ]"}],style:({ width: '120px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":"default_code"}},[_vm._v(" "+_vm._s(_vm.$t('forms.base_sku'))+" ")]),_c('a-select-option',{attrs:{"value":"common_sku"}},[_vm._v(" "+_vm._s(_vm.$t('forms.common_sku'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sku']),expression:"['sku']"}],staticStyle:{"width":"200px"},attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_main_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_main_category']),expression:"['z_main_category']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('fuzzy_search')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse', { initialValue: '' }]),expression:"['warehouse', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{key:"DE",attrs:{"value":"DE"}},[_vm._v("DE")]),_c('a-radio-button',{key:"UK",attrs:{"value":"UK"}},[_vm._v("UK")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_category']),expression:"['z_category']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('fuzzy_search')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.operator')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator']),expression:"['operator']"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category']),expression:"['z_sub_category']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":_vm.$t('fuzzy_search')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.month')}},[_c('a-month-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['month', { initialValue: _vm.currentMonth }]),expression:"['month', { initialValue: currentMonth }]"}],attrs:{"size":"small"}})],1)]},proxy:true},{key:"collapse",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.origin_prod_status')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'product_origin_state',
                        { initialValue: '' }
                    ]),expression:"[\n                        'product_origin_state',\n                        { initialValue: '' }\n                    ]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.is_need_manual_intervetion')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['is_manual_review', { initialValue: '' }]),expression:"['is_manual_review', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(_vm._s(_vm.$t('forms.yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(_vm._s(_vm.$t('forms.no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.final_result')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['final_result', { initialValue: '' }]),expression:"['final_result', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2)],1),_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.page_flag == 'leader'),expression:"page_flag == 'leader'"}],staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.approve_state')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['approve_state', { initialValue: '' }]),expression:"['approve_state', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","placeholder":"Please Select","filterOption":_vm.filterSelectOption,"size":"small","allowClear":""}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.UnsalableApproveState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2)],1),_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.page_flag == 'leader'),expression:"page_flag == 'leader'"}],staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.unsalable_judgment')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'unsalable_judgment',
                        { initialValue: '' }
                    ]),expression:"[\n                        'unsalable_judgment',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{key:"not_null",attrs:{"value":"not_null"}},[_vm._v(_vm._s(_vm.$t('forms.yes'))+" ")]),_c('a-radio-button',{key:"null",attrs:{"value":"null"}},[_vm._v(_vm._s(_vm.$t('forms.no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.department')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dept_id']),expression:"['dept_id']"}],style:({ width: '180px' }),attrs:{"showSearch":"","dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"filterOption":_vm.filterSelectOption,"size":"small","mode":"multiple","allowClear":""}},_vm._l((_vm.topDepartmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])}),1)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.changeNote()}}},[_vm._v(" "+_vm._s(_vm.$t('action.save'))+" ")]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.page_flag == ''),expression:"page_flag == ''"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.applyDiscount()}}},[_vm._v(" "+_vm._s(_vm.$t('action.apply_discount'))+" ")]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.page_flag == 'leader'),expression:"page_flag == 'leader'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.onApprove()}}},[_vm._v(" "+_vm._s(_vm.$t('action.approve'))+" ")]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.page_flag == ''),expression:"page_flag == ''"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.importUnsaleable()}}},[_vm._v(" "+_vm._s(_vm.$t('action.importUnsaleable'))+" ")]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.page_flag == 'leader'),expression:"page_flag == 'leader'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"},on:{"click":function($event){return _vm.importLeaderUnsaleable()}}},[_vm._v(" "+_vm._s(_vm.$t('action.importUnsaleable'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('action.confirm_cancel'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.directApprove()}}},[_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.page_flag == 'leader'),expression:"page_flag == 'leader'"},{name:"auth",rawName:"v-auth",value:('direct_approve'),expression:"'direct_approve'"}],staticStyle:{"margin-left":"2px"},attrs:{"type":"primary"}},[_vm._v(" "+_vm._s(_vm.$t('action.directApprove'))+" ")])],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"queryUrl":_vm.queryUrl,"menu_code":_vm.menu_code,"queryCondition":_vm.queryConsition,"rowSelection":{
                    selectedRowKeys: _vm.selectedRowKeys,
                    onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                },"scroll":{ x: 2000, y: 500 }},on:{"on-page-change":_vm.getDataList,"onClick":function (record) {
                        _vm.selectedRowKeys = [record]
                        _vm.onRowClick(record)
                    },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_vm._v(" "+_vm._s(_vm._f("translate")(text))+" ")])}},{key:"is_danger",fn:function(text){return _c('span',{},[_c('a-popover',[_c('template',{slot:"content"},[_c('p',[_vm._v("3个月内无法将产品全部售出为危险")])]),_vm._v(" "+_vm._s(_vm._f("translate")(text))+" ")],2)],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"dept_id",fn:function(text){return _c('span',{},[_vm._v(_vm._s(typeof text == 'object' && text.length == 2 ? text[1] : '')+" ")])}},{key:"state_range",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'SaleState')))+" ")])}},{key:"state_range_edit",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                row.approve_state === 'wait_approve'
                        )?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'unsalable_judgment',
                            { initialValue: '' }
                        ]),expression:"[\n                            'unsalable_judgment',\n                            { initialValue: '' }\n                        ]"}],style:({ width: '100%' }),attrs:{"placeholder":"Please Select","size":"small","value":row.unsalable_judgment},on:{"change":function (e) { return _vm.handleChange(e, row, 'unsalable_judgment'); }}},[_c('a-select-option',{attrs:{"value":null}},[_vm._v(" "+_vm._s(_vm.$t('action.null'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2):_c('span',[_vm._v(_vm._s(row.unsalable_judgment))])]}},{key:"memo",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                row.approve_state === 'wait_approve'
                        )?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"1","value":row.memo ? row.memo : ''},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'memo'); }}}):_c('span',{attrs:{"title":row.memo}},[_vm._v(_vm._s(row.memo ? row.memo.length > 24 ? row.memo.substr(0, 27) + '...' : row.memo : ''))])]}},{key:"reason",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                row.approve_state === 'wait_approve'
                        )?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"1","value":row.reason ? row.reason : ''},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'reason'); }}}):_c('span',{attrs:{"title":row.reason}},[_vm._v(_vm._s(row.reason ? row.reason.length > 24 ? row.reason.substr(0, 27) + '...' : row.reason : ''))])]}},{key:"discount",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                row.approve_state === 'wait_approve'
                        )?_c('a-input',{attrs:{"size":"small"},model:{value:(row.discount),callback:function ($$v) {_vm.$set(row, "discount", $$v)},expression:"row.discount"}}):_c('span',[_vm._v(" "+_vm._s(text)+" ")])]}},{key:"discount_start",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                row.approve_state === 'wait_approve'
                        )?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":row.discount_start
                                ? _vm.moment(row.discount_start, 'YYYY-MM-DD')
                                : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.handleChange(e, row, 'discount_start'); }}}):_c('span',[_vm._v(_vm._s(row.discount_start ? _vm.moment(row.discount_start).format( 'YYYY-MM-DD' ) : null))])]}},{key:"discount_end",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                row.approve_state === 'wait_approve'
                        )?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":row.discount_end
                                ? _vm.moment(row.discount_end, 'YYYY-MM-DD')
                                : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.handleChange(e, row, 'discount_end'); }}}):_c('span',[_vm._v(_vm._s(row.discount_end ? _vm.moment(row.discount_end).format('YYYY-MM-DD') : null))])]}},{key:"approve_state",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.approve_state,'UnsalableApproveState')))+" ")]}},{key:"department_review",fn:function(text, row){return [(
                            _vm.editRow.id == row.id &&
                                row.approve_state === 'wait_approve'
                        )?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'department_review',
                            { initialValue: '' }
                        ]),expression:"[\n                            'department_review',\n                            { initialValue: '' }\n                        ]"}],style:({ width: '100%' }),attrs:{"placeholder":"Please Select","size":"small","value":row.department_review},on:{"change":function (e) { return _vm.handleChange(e, row, 'department_review'); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('action.null'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2):_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.department_review,'SaleState'))))])]}}],null,false,3903373547)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onRowClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_vm._v(" "+_vm._s(_vm._f("translate")(text))+" ")])}},{key:"is_danger",fn:function(text){return _c('span',{},[_c('a-popover',[_c('template',{slot:"content"},[_c('p',[_vm._v("3个月内无法将产品全部售出为危险")])]),_vm._v(" "+_vm._s(_vm._f("translate")(text))+" ")],2)],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"state_renge",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(text,'SaleState')))+" ")])}},{key:"discount",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            row.approve_state === 'wait_approve'
                    )?_c('a-input',{attrs:{"size":"small"},model:{value:(row.discount),callback:function ($$v) {_vm.$set(row, "discount", $$v)},expression:"row.discount"}}):_c('span',[_vm._v(" "+_vm._s(text)+" ")])]}},{key:"discount_start",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            row.approve_state === 'wait_approve'
                    )?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":row.discount_start
                            ? _vm.moment(row.discount_start, 'YYYY-MM-DD')
                            : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.handleChange(e, row, 'discount_start'); }}}):_c('span',[_vm._v(_vm._s(row.discount_start ? _vm.moment(row.discount_start).format('YYYY-MM-DD') : null))])]}},{key:"discount_end",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            row.approve_state === 'wait_approve'
                    )?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":row.discount_end
                            ? _vm.moment(row.discount_end, 'YYYY-MM-DD')
                            : null,"size":"small","format":"YYYY-MM-DD"},on:{"change":function (e) { return _vm.handleChange(e, row, 'discount_end'); }}}):_c('span',[_vm._v(_vm._s(row.discount_end ? _vm.moment(row.discount_end).format('YYYY-MM-DD') : null))])]}},{key:"state_range_edit",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            row.approve_state === 'wait_approve'
                    )?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'unsalable_judgment',
                        { initialValue: '' }
                    ]),expression:"[\n                        'unsalable_judgment',\n                        { initialValue: '' }\n                    ]"}],style:({ width: '100%' }),attrs:{"placeholder":"Please Select","size":"small","value":row.unsalable_judgment},on:{"change":function (e) { return _vm.handleChange(e, row, 'unsalable_judgment'); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('action.null'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2):_c('span',[_vm._v(_vm._s(row.unsalable_judgment))])]}},{key:"memo",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            row.approve_state === 'wait_approve'
                    )?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"2","cols":"40","value":row.memo ? row.memo : ''},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'memo'); }}}):_c('span',{attrs:{"title":row.memo}},[_vm._v(_vm._s(row.memo ? row.memo.length > 24 ? row.memo.substr(0, 27) + '...' : row.memo : ''))])]}},{key:"reason",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            row.approve_state === 'wait_approve'
                    )?_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"size":"small","rows":"2","cols":"40","value":row.reason ? row.reason : ''},on:{"change":function (e) { return _vm.handleChange(e.target.value, row, 'reason'); }}}):_c('span',{attrs:{"title":row.reason}},[_vm._v(_vm._s(row.reason ? row.reason.length > 24 ? row.reason.substr(0, 27) + '...' : row.reason : ''))])]}},{key:"approve_state",fn:function(text, row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.approve_state,'UnsalableApproveState')))+" ")]}},{key:"department_review",fn:function(text, row){return [(
                        _vm.editRow.id == row.id &&
                            row.approve_state === 'wait_approve'
                    )?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'department_review',
                        { initialValue: '' }
                    ]),expression:"[\n                        'department_review',\n                        { initialValue: '' }\n                    ]"}],style:({ width: '100%' }),attrs:{"placeholder":"Please Select","size":"small","value":row.department_review},on:{"change":function (e) { return _vm.handleChange(e, row, 'department_review'); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('action.null'))+" ")]),_vm._l((_vm.$dict.SaleState),function(cate){return _c('a-select-option',{key:cate.value},[_vm._v(" "+_vm._s(_vm.$t(cate.label))+" ")])})],2):_c('span',[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.department_review,'SaleState'))))])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-unsalable-report-content.vue?vue&type=template&id=75b349e3&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/components/product/apply-discount.vue + 4 modules
var apply_discount = __webpack_require__("0fbd");

// EXTERNAL MODULE: ./src/shared/common/upload-excel.vue + 3 modules
var upload_excel = __webpack_require__("935a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-unsalable-report-content.vue?vue&type=script&lang=ts&





























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_unsalable_report_contentvue_type_script_lang_ts_ProductUnsalableReportContent =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductUnsalableReportContent, _super);

  function ProductUnsalableReportContent() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */](); // 表格数据源

    _this.data = [];
    _this.groupbyList = [];
    _this.allNameAuth = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.queryConsition = [];
    _this.current = null;
    _this.orderBy = '';
    _this.columnList = [];
    _this.menu_code = '';
    _this.editRow = {
      id: null
    };
    _this.queryUrl = '/report/query_product_unsalable_report';
    _this.vender_data = [];
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.yearPickShow = false;
    _this.moment = moment_default.a;
    _this.topDepartmentList = [];
    _this.currentMonth = '';
    _this.needSaveNotes = [];
    return _this;
  }

  ProductUnsalableReportContent.prototype.handleOpenChange = function (status) {
    this.yearPickShow = status;
  }; // 得到年份选择器的值


  ProductUnsalableReportContent.prototype.handlePanelChange = function (value) {
    var values = this.dataForm.getValues();
    values['years'] = value.format('YYYY');
    this.dataForm.setValues(values);
    this.yearPickShow = false;
  };

  Object.defineProperty(ProductUnsalableReportContent.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  ProductUnsalableReportContent.prototype.created = function () {
    this.getSystemuser();
    this.getVendorList();
    this.getDepartmentList();
    this.currentMonth = moment_default()(Date.now()).subtract(1, 'months');
    this.topDepartmentList = this.departmentList.filter(function (x) {
      return x.dept_type == 30;
    });
  };

  ProductUnsalableReportContent.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;
    this.menu_code = common_service["a" /* CommonService */].getMenuCode();
  };

  ProductUnsalableReportContent.prototype.onRowClick = function (row) {
    this.editRow = {
      id: row
    };
  };

  ProductUnsalableReportContent.prototype.onGroupbyListChange = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
  };
  /**
   * 获取订单数据
   */


  ProductUnsalableReportContent.prototype.getDataList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var sku_type = values['sku_type'];
      values[sku_type] = values['sku'];
      delete values['sku_type'];
      delete values['sku'];
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        default_code: 'in_or_like',
        z_main_category: 'like',
        z_category: 'like',
        z_sub_category: 'like',
        dept_id: 'in'
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: new Date(item.value[0].format('YYYY-MM-DD') + ' 00:00:00')
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: new Date(item.value[1].format('YYYY-MM-DD') + ' 23:59:59.999999')
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      for (var _b = 0, nowConditions_1 = nowConditions; _b < nowConditions_1.length; _b++) {
        var i = nowConditions_1[_b];

        if (i.query_name == 'unsalable_judgment') {
          i.operate = i.value == 'null' ? 'null' : i.value == 'not_null' ? 'not null' : '=';

          if (i.operate != '=') {
            i.value = '';
          }
        }
      }

      _this.queryConsition = nowConditions;

      if (_this.groupbyList.length) {
        var groupbyTable = _this.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this.orderBy) {
          params['order_by'] = _this.orderBy;
        }

        _this.innerAction.setActionAPI(_this.queryUrl, common_service["a" /* CommonService */].getMenuCode());

        _this.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this.pageService,
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          var msg = _this.$t('tips.save_success');

          _this.data = data;
          _this.selectedRowKeys = [];
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  ProductUnsalableReportContent.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductUnsalableReportContent.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getDataList();
  };

  ProductUnsalableReportContent.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  ProductUnsalableReportContent.prototype.onApprove = function () {
    var _this = this;

    this.innerAction.setActionAPI('/report/approve_product_unsalable_report', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.selectedRowKeys = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductUnsalableReportContent.prototype.applyDiscount = function () {
    var _this = this;

    this.$modal.open(apply_discount["a" /* default */], {
      ids: this.selectedRowKeys
    }, {
      title: this.$t('action.apply_discount'),
      width: '60%'
    }).subscribe(function (data) {
      _this.selectedRowKeys = [];
    });
  };

  ProductUnsalableReportContent.prototype.handleChange = function (e, row, column) {
    row[column] = e;
    var item = this.needSaveNotes.find(function (x) {
      return x.id == row.id;
    });

    if (item) {
      item[column] = e;
    } else {
      var param = {
        id: row.id
      };
      param[column] = e;
      this.needSaveNotes.push(param);
    }
  };

  ProductUnsalableReportContent.prototype.changeNote = function () {
    var _this = this;

    var rows = this.data.filter(function (x) {
      return _this.selectedRowKeys.includes(x.id) && x.approve_state === 'wait_approve';
    });

    if (!rows.length) {
      this.$message.error('请选择待审核的数据');
      return;
    }

    var _loop_1 = function _loop_1(i) {
      if (rows[i].reason != undefined && rows[i].reason == '') {
        rows[i].reason = null;
      }

      if (rows[i].memo != undefined && rows[i].memo == '') {
        rows[i].memo = null;
      }

      if (rows[i].reason !== undefined || rows[i].unsalable_judgment !== undefined) {
        var item = this_1.data.find(function (x) {
          return x.id == rows[i].id;
        });

        if (!item.reason && item.unsalable_judgment || item.reason && !item.unsalable_judgment) {
          this_1.$message.error('原因和该月滞销判断(运营)必须同时填写');
          return {
            value: void 0
          };
        }
      }
    };

    var this_1 = this;

    for (var i in rows) {
      var state_1 = _loop_1(i);

      if (Object(esm_typeof["a" /* default */])(state_1) === "object") return state_1.value;
    }

    var parmas = rows.map(function (x) {
      return {
        id: x.id,
        unsalable_judgment: x.unsalable_judgment,
        memo: x.memo,
        reason: x.reason,
        department_review: x.department_review,
        discount: x.discount,
        discount_start: x.discount_start,
        discount_end: x.discount_end
      };
    });
    this.innerAction.setActionAPI('/report/modify_product_unsalable_report', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({
      update_data: parmas
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductUnsalableReportContent.prototype.onCreateReport = function () {
    var _this = this;

    this.innerAction.setActionAPI('/report/create_product_unsalable_report', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.needSaveNotes = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductUnsalableReportContent.prototype.importUnsaleable = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/system_api/upload?inner_action=/report/import_product_unsalable_report&menu_code=' + common_service["a" /* CommonService */].getMenuCode('product-unsalable-report'),
      uploadParams: {},
      attachmentUrlPath: '/system/download_import_template?type=ProductUnsaleableImport'
    }, {
      title: 'Import',
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      if (data.message.create_msg) {
        _this.$message.warning(data.message.create_msg);
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductUnsalableReportContent.prototype.importLeaderUnsaleable = function () {
    var _this = this;

    this.$modal.open(upload_excel["a" /* default */], {
      urlPath: '/system_api/upload?inner_action=/report/import_leader_product_unsalable_report&menu_code=' + common_service["a" /* CommonService */].getMenuCode('product-unsalable-report-leader'),
      uploadParams: {},
      attachmentUrlPath: '/system/download_import_template?type=ProductUnsaleableImport_leader'
    }, {
      title: 'Import',
      width: '1000px'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      if (data.message.create_msg) {
        _this.$message.warning(data.message.create_msg);
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductUnsalableReportContent.prototype.directApprove = function () {
    var _this = this;

    this.innerAction.setActionAPI('/report/one_click_approve_product_unsalable', common_service["a" /* CommonService */].getMenuCode());
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getDataList();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductUnsalableReportContent.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductUnsalableReportContent.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUnsalableReportContent.prototype, "page_flag", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUnsalableReportContent.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUnsalableReportContent.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUnsalableReportContent.prototype, "vendorList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUnsalableReportContent.prototype, "getVendorList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUnsalableReportContent.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductUnsalableReportContent.prototype, "getDepartmentList", void 0);

  ProductUnsalableReportContent = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], ProductUnsalableReportContent);
  return ProductUnsalableReportContent;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_unsalable_report_contentvue_type_script_lang_ts_ = (product_unsalable_report_contentvue_type_script_lang_ts_ProductUnsalableReportContent);
// CONCATENATED MODULE: ./src/components/product/product-unsalable-report-content.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_unsalable_report_contentvue_type_script_lang_ts_ = (product_unsalable_report_contentvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-unsalable-report-content.vue?vue&type=custom&index=0&blockType=i18n
var product_unsalable_report_contentvue_type_custom_index_0_blockType_i18n = __webpack_require__("9f4f");

// CONCATENATED MODULE: ./src/components/product/product-unsalable-report-content.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_unsalable_report_contentvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_unsalable_report_contentvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_unsalable_report_contentvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_unsalable_report_content = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "00b1":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","cancel":"Cancel","more":"More","export":"Export","import":"Import","replenish_split":"ReplenishSplit","add_replenishment_contract":"Add Replenishment Contract","purchase_return":"Purchase Return","apply_discount":"Apply For Discount","save":"Save","approve":"Approve","null":"Null","importUnsaleable":"Import","directApprove":"Directly Approve","confirm_cancel":"Are you sure aprrove?"},"columns":{"z_main_category":"Main Category","z_category":"Category","z_sub_category":"Sub Category","warehouse_id":"Warehouse","year":"Year","month":"Month","week":"Week","order_id":"Order No.","contact_no":"Contact No.","default_code":"Default Code","operator":"Operator","is_need_manual_intervetion":"Need Manual Intervetion","origin_prod_status":"Product Origin State","final_result":"Final Result","approve_state":"Approve State","unsalable_judgment":"Unsalable Judgment"},"rules":{"date_range_error":"start date can\u0027t later start date"},"forms":{"quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search","operator_list":"Multi Search","sku":"SKU","common_sku":"Common SKU","base_sku":"Base SKU","yes":"Yes","no":"No"},"delete":"Are you sure delete?","cancel":"Are you sure cancel?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success"},"zh-cn":{"desc":"这是订单页面1","action":{"create":"新建采购合同","edit":"编辑","delete":"删除","ok":"确认","cancel":"取消","more":"更多操作","export":"导出","import":"导入","replenish_split":"拆分补货需求","return_purchase":"退回补货","add_replenishment_contract":"新建采购合同","purchase_return":"退回补货","apply_discount":"折扣申请","save":"保存","approve":"审批","null":"无","importUnsaleable":"导入","directApprove":"一键审批","confirm_cancel":"确认审批吗?"},"columns":{"z_main_category":"中文大类","z_category":"中文分类","z_sub_category":"中文子类","warehouse_id":"仓库","year":"年度","month":"月度","week":"周次","order_id":"订单号","contact_no":"合同号","default_code":"货号","operator":"运营","is_need_manual_intervetion":"是否需要人工干预","origin_prod_status":"产品原状态","final_result":"最终结果","approve_state":"审批状态","unsalable_judgment":"该月滞销判断(运营)"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"forms":{"quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找","operator_list":"批量查询","sku":"货号","common_sku":"通用货号","base_sku":"基础货号","yes":"是","no":"否"},"delete":"是否确认删除?","cancel":"是否确认取消?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "0e53":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d027");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "10f1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_apply_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f430");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_apply_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_apply_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_apply_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "12df":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_create_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("acb1");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_create_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_create_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_create_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1432":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_copy_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("497f");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_copy_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_copy_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_copy_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1875":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("752f");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "19bd":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9761");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "200a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-purchase-predict.vue?vue&type=template&id=e5f84880&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('data-form',{ref:"dataForm",attrs:{"extends":_vm.extendItems,"column":2,"showHeader":false},on:{"submit":_vm.getPurchasePredictList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['status', { initialValue: '' }]),expression:"['status', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all')))]),_vm._l((_vm.purchaseStatus),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label)))])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.week_avg_sales')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['week_avg_sales']),expression:"['week_avg_sales']"}],style:({ width: '80px' }),attrs:{"size":"small","min":0,"decimalSeparator":","}}),_c('span',{staticStyle:{"margin":"0 5px"}},[_vm._v("~")]),_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['week_avg_sales_max']),expression:"['week_avg_sales_max']"}],style:({ width: '80px' }),attrs:{"size":"small","min":0,"decimalSeparator":","}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['z_sub_category']),expression:"['z_sub_category']"}],style:({ width: '300px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '300px' }),attrs:{"placeholder":_vm.$t('fuzzy_search'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.include_presale_order')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'include_presale_order',
                        { initialValue: '' }
                    ]),expression:"[\n                        'include_presale_order',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small"}},[_c('a-radio',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all')))]),_c('a-radio',{attrs:{"value":"1"}},[_vm._v(_vm._s(_vm.$t('yes')))]),_c('a-radio',{attrs:{"value":"0"}},[_vm._v(_vm._s(_vm.$t('no')))])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.is_presale')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['is_presale', { initialValue: '' }]),expression:"['is_presale', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small"}},[_c('a-radio',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all')))]),_c('a-radio',{attrs:{"value":"1"}},[_vm._v(_vm._s(_vm.$t('yes')))]),_c('a-radio',{attrs:{"value":"0"}},[_vm._v(_vm._s(_vm.$t('no')))])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.is_second_presale')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'is_second_presale',
                        { initialValue: '' }
                    ]),expression:"[\n                        'is_second_presale',\n                        { initialValue: '' }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small"}},[_c('a-radio',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all')))]),_c('a-radio',{attrs:{"value":"1"}},[_vm._v(_vm._s(_vm.$t('yes')))]),_c('a-radio',{attrs:{"value":"0"}},[_vm._v(_vm._s(_vm.$t('no')))])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.calculate_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['calculate_date']),expression:"['calculate_date']"}],attrs:{"size":"small"}})],1),_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(!_vm.info),expression:"!info"}],staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id', { initialValue: '' }]),expression:"['warehouse_id', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all')))]),_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label)))])})],2)],1),_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(!_vm.info),expression:"!info"}],staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.exists_exception')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['exists_exception', { initialValue: '' }]),expression:"['exists_exception', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small"}},[_c('a-radio',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all')))]),_c('a-radio',{attrs:{"value":"1"}},[_vm._v(_vm._s(_vm.$t('yes')))]),_c('a-radio',{attrs:{"value":"0"}},[_vm._v(_vm._s(_vm.$t('no')))])],1)],1),_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(!_vm.info),expression:"!info"}],staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.purchase_status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['purchase_status', { initialValue: '' }]),expression:"['purchase_status', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all')))]),_vm._l((_vm.$dict.PurchaseStatus),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label)))])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.vendor_name')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['vendor_name', { initialValue: '' }]),expression:"['vendor_name', { initialValue: '' }]"}],style:({
                        width: '100%',
                        'max-width': '300px'
                    }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filterOption":_vm.filterSelectOption}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.vender_data),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.onPurchaseApply()}}},[_vm._v(_vm._s(_vm.$t('action.purchase_apply')))]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.exportRows()}}},[_vm._v(_vm._s(_vm.$t('action.export')))]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.reCalculate()}}},[_vm._v(_vm._s(_vm.$t('action.edit')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(!_vm.info),expression:"!info"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.verify_sales()}}},[_vm._v(_vm._s(_vm.$t('action.active')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.info === 'predict-confirm'),expression:"info === 'predict-confirm'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.verify_sales_manager()}}},[_vm._v(_vm._s(_vm.$t('action.confirm')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.info === 'predict-approve'),expression:"info === 'predict-approve'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.verify_sales_director()}}},[_vm._v(_vm._s(_vm.$t('action.verify')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(!_vm.info),expression:"!info"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.confirm_sales()}}},[_vm._v(_vm._s(_vm.$t('action.to_draft')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.info === 'predict-confirm'),expression:"info === 'predict-confirm'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.confirm_sales_manager()}}},[_vm._v(_vm._s(_vm.$t('action.confirm_refuse')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.info === 'predict-confirm'),expression:"info === 'predict-confirm'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.return_sales_manager()}}},[_vm._v(_vm._s(_vm.$t('action.return')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.info === 'predict-confirm'),expression:"info === 'predict-confirm'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.confirm_return_sales_manager()}}},[_vm._v(_vm._s(_vm.$t('action.confirm_return_sales_manager')))]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.info === 'predict-approve'),expression:"info === 'predict-approve'"}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.refuse_sales_director()}}},[_vm._v(_vm._s(_vm.$t('action.refuse')))])]},proxy:true}])}),_c('a-card',{staticClass:"margin-y"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"calculate_code","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, select_rows) {
                    _vm.selectedRows = select_rows
                    _vm.selectedRowKeys = keys
                }
            },"scroll":{ y: 320, x: 3600 },"size":"small"},on:{"on-page-change":_vm.getPurchasePredictList,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                    _vm.onTrClick(record)
                },"change":function (sorter) { return _vm.onTableChange(sorter); }}},[_c('a-table-column',{key:"default_code",attrs:{"title":"SKU","width":"4.4%","align":"left","sorter":true},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(_vm._s(row.default_code))])]}}])}),_c('a-table-column',{key:"purchase_sku",attrs:{"title":_vm.$t('columns.purchase_sku'),"width":"4.4%","align":"left","sorter":true},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',{attrs:{"title":row.purchase_sku}},[_vm._v(_vm._s(row.purchase_sku ? row.purchase_sku.substr(0, 10) + '...' : ''))])]}}])}),_c('a-table-column',{key:"de_available_qty",staticClass:"minWidth160",style:({ 'min-width': '500px !important' }),attrs:{"title":_vm.$t('columns.de_available_qty'),"width":"3.2%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" DE:"+_vm._s(row.de_available_qty)+" "),_c('br'),_c('span',{staticStyle:{"color":"red"}},[_vm._v("UK:")]),_vm._v(_vm._s(row.uk_available_qty)+" ")]}}])}),_c('a-table-column',{key:"month_1_transit_qty",attrs:{"title":_vm.$t('columns.month_1_transit_qty'),"data-index":"month_1_transit_qty","width":"2.2%","align":"right"}}),_c('a-table-column',{key:"month_2_transit_qty",attrs:{"title":_vm.$t('columns.month_2_transit_qty'),"data-index":"month_2_transit_qty","width":"2.2%","align":"right"}}),_c('a-table-column',{key:"transit_qty",attrs:{"title":_vm.$t('columns.transit_qty'),"data-index":"transit_qty","width":"2.2%","align":"right"}}),_c('a-table-column',{key:"month_1_unship_qty",attrs:{"title":_vm.$t('columns.month_1_unship_qty'),"data-index":"month_1_unship_qty","width":"2.2%","align":"right"}}),_c('a-table-column',{key:"month_2_unship_qty",attrs:{"title":_vm.$t('columns.month_2_unship_qty'),"data-index":"month_2_unship_qty","width":"2.2%","align":"right"}}),_c('a-table-column',{key:"month_3_unship_qty",attrs:{"title":_vm.$t('columns.month_3_unship_qty'),"data-index":"month_3_unship_qty","width":"2.2%","align":"right"}}),_c('a-table-column',{key:"unship_qty",attrs:{"title":_vm.$t('columns.unship_qty'),"data-index":"unship_qty","width":"2.2%","align":"right"}}),_c('a-table-column',{key:"week_1_sales",attrs:{"title":_vm.$t('columns.week_sales') + '一',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_1_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_1_sales}},[_vm._v(_vm._s(row.week_1_sales))]):(row.presale_week_1_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_1_sales))]):_c('span',[_vm._v(_vm._s(row.week_1_sales))])]}}])}),_c('a-table-column',{key:"week_2_sales",attrs:{"title":_vm.$t('columns.week_sales') + '二',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_2_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_2_sales}},[_vm._v(_vm._s(row.week_2_sales))]):(row.presale_week_2_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_2_sales))]):_c('span',[_vm._v(_vm._s(row.week_2_sales))])]}}])}),_c('a-table-column',{key:"week_3_sales",attrs:{"title":_vm.$t('columns.week_sales') + '三',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_3_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_3_sales}},[_vm._v(_vm._s(row.week_3_sales))]):(row.presale_week_3_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_3_sales))]):_c('span',[_vm._v(_vm._s(row.week_3_sales))])]}}])}),_c('a-table-column',{key:"week_4_sales",attrs:{"title":_vm.$t('columns.week_sales') + '四',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_4_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_4_sales}},[_vm._v(_vm._s(row.week_4_sales))]):(row.presale_week_4_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_4_sales))]):_c('span',[_vm._v(_vm._s(row.week_4_sales))])]}}])}),_c('a-table-column',{key:"week_5_sales",attrs:{"title":_vm.$t('columns.week_sales') + '五',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_5_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_5_sales}},[_vm._v(_vm._s(row.week_5_sales))]):(row.presale_week_5_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_5_sales))]):_c('span',[_vm._v(_vm._s(row.week_5_sales))])]}}])}),_c('a-table-column',{key:"week_6_sales",attrs:{"title":_vm.$t('columns.week_sales') + '六',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_6_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_6_sales}},[_vm._v(_vm._s(row.week_6_sales))]):(row.presale_week_6_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_6_sales))]):_c('span',[_vm._v(_vm._s(row.week_6_sales))])]}}])}),_c('a-table-column',{key:"week_7_sales",attrs:{"title":_vm.$t('columns.week_sales') + '七',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_7_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_7_sales}},[_vm._v(_vm._s(row.week_7_sales))]):(row.presale_week_7_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_7_sales))]):_c('span',[_vm._v(_vm._s(row.week_7_sales))])]}}])}),_c('a-table-column',{key:"week_8_sales",attrs:{"title":_vm.$t('columns.week_sales') + '八',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_8_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_8_sales}},[_vm._v(_vm._s(row.week_8_sales))]):(row.presale_week_8_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_8_sales))]):_c('span',[_vm._v(_vm._s(row.week_8_sales))])]}}])}),_c('a-table-column',{key:"week_9_sales",attrs:{"title":_vm.$t('columns.week_sales') + '九',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_9_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_9_sales}},[_vm._v(_vm._s(row.week_9_sales))]):(row.presale_week_9_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_9_sales))]):_c('span',[_vm._v(_vm._s(row.week_9_sales))])]}}])}),_c('a-table-column',{key:"week_10_sales",attrs:{"title":_vm.$t('columns.week_sales') + '十',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_10_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_10_sales}},[_vm._v(_vm._s(row.week_10_sales))]):(row.presale_week_10_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_10_sales))]):_c('span',[_vm._v(_vm._s(row.week_10_sales))])]}}])}),_c('a-table-column',{key:"week_11_sales",attrs:{"title":_vm.$t('columns.week_sales') + '十一',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_11_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_11_sales}},[_vm._v(_vm._s(row.week_11_sales))]):(row.presale_week_11_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_11_sales))]):_c('span',[_vm._v(_vm._s(row.week_11_sales))])]}}])}),_c('a-table-column',{key:"week_12_sales",attrs:{"title":_vm.$t('columns.week_sales') + '十二',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_12_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_12_sales}},[_vm._v(_vm._s(row.week_12_sales))]):(row.presale_week_12_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_12_sales))]):_c('span',[_vm._v(_vm._s(row.week_12_sales))])]}}])}),_c('a-table-column',{key:"week_0_sales",attrs:{"title":_vm.$t('columns.week_0_sales'),"width":"3%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.presale_week_0_sales > 0)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.presale_week_0_sales}},[_vm._v(_vm._s(row.week_0_sales))]):(row.presale_week_0_sales == -1)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(row.week_0_sales))]):_c('span',[_vm._v(_vm._s(row.week_0_sales))])]}}])}),_c('a-table-column',{key:"week_avg_sales",attrs:{"title":_vm.$t('columns.week_avg_sales'),"data-index":"week_avg_sales","width":"3%","align":"right","sorter":true},scopedSlots:_vm._u([{key:"default",fn:function(week_avg_sales, row){return [(row.include_presale_order)?_c('span',{staticStyle:{"color":"red"}},[_vm._v(" "+_vm._s(week_avg_sales.toFixed(1))+" ")]):_c('span',{staticStyle:{"color":"gray"}},[_vm._v(" "+_vm._s(week_avg_sales.toFixed(1))+" ")])]}}])}),_c('a-table-column',{key:"cp_qty_ratio",attrs:{"title":_vm.$t('columns.cp_qty_ratio'),"width":"3%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.cp_qty_ratio > 0 ? row.cp_qty_ratio.toFixed(1) : 0))]}}])}),_c('a-table-column',{key:"cp_order_ratio",attrs:{"title":_vm.$t('columns.cp_order_ratio'),"width":"3%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.cp_order_ratio > 0 ? row.cp_order_ratio.toFixed(1) : 0))]}}])}),_c('a-table-column',{key:"will_1_sales",attrs:{"title":_vm.$t('columns.pre_week_sales') + '一',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.will_1_sales.toFixed(1)))]}}])}),_c('a-table-column',{key:"will_2_sales",attrs:{"title":_vm.$t('columns.pre_week_sales') + '二',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.will_2_sales.toFixed(1)))]}}])}),_c('a-table-column',{key:"will_3_sales",attrs:{"title":_vm.$t('columns.pre_week_sales') + '三',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.will_3_sales.toFixed(1)))]}}])}),_c('a-table-column',{key:"will_4_sales",attrs:{"title":_vm.$t('columns.pre_week_sales') + '四',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.will_4_sales.toFixed(1)))]}}])}),_c('a-table-column',{key:"will_5_sales",attrs:{"title":_vm.$t('columns.pre_week_sales') + '五',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.will_5_sales.toFixed(1)))]}}])}),_c('a-table-column',{key:"will_6_sales",attrs:{"title":_vm.$t('columns.pre_week_sales') + '六',"width":"2%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(row.will_6_sales.toFixed(1)))]}}])}),_c('a-table-column',{key:"status",attrs:{"title":_vm.$t('columns.status'),"width":"3%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.status == 100)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.approve_memo}},[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.status,'PredictStatus')))+" ")]):(row.status == 200)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":_vm.info === 'predict-approve'
                                ? row.return_memo
                                : row.refuse_memo}},[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.status,'PredictStatus')))+" ")]):_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.status,'PredictStatus')))+" ")])]}}])}),_c('a-table-column',{key:"purchase_cycle",attrs:{"title":_vm.$t('columns.purchase_cycle'),"width":"3%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s((row.purchase_cycle / 7).toFixed(1)))]}}])}),_c('a-table-column',{key:"sale_cycle",attrs:{"title":_vm.$t('columns.sale_cycle'),"width":"3%","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s((row.sale_cycle / 7).toFixed(1)))]}}])}),_c('a-table-column',{key:"increase_ratio_text",attrs:{"title":_vm.$t('columns.increase_ratio_text'),"data-index":"increase_ratio_text","width":"9%","align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(increase_ratio_text, row){return [(row.increase_ratio_changed)?_c('span',{staticStyle:{"color":"red"},attrs:{"title":row.change_increase_memo}},[_vm._v(" "+_vm._s(increase_ratio_text)+" ")]):_c('span',{staticStyle:{"color":"gray"},attrs:{"title":row.change_increase_memo}},[_vm._v(" "+_vm._s(increase_ratio_text)+" ")])]}}])}),_c('a-table-column',{key:"predict_detail1",staticClass:"minWidth160",style:({ 'min-width': '500px !important' }),attrs:{"title":_vm.$t('columns.predict_detail') + 1,"width":"5.5%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" 销量："+_vm._s(row.first_period_sales.toFixed(1))+" "),_c('br'),_vm._v(" 期末库存："+_vm._s(row.first_period_end_stock.toFixed(1))+" ")]}}])}),_c('a-table-column',{key:"predict_detail2",staticClass:"minWidth160",style:({ 'min-width': '500px !important' }),attrs:{"title":_vm.$t('columns.predict_detail') + 2,"width":"5.5%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" 销量："+_vm._s(row.second_period_sales.toFixed(1))+" "),_c('br'),_vm._v(" 需求量："+_vm._s(row.second_period_need_stock.toFixed(1))+" ")]}}])}),_c('a-table-column',{key:"need_date",staticClass:"minWidth160",style:({ 'min-width': '500px !important' }),attrs:{"title":_vm.$t('columns.need_date'),"width":"6.5%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" 开始："+_vm._s(_vm.moment(row.calculate_date, 'YYYY-MM-DD') .add(row.purchase_cycle, 'd') .format('YYYY-MM-DD'))+" "),_c('br'),_vm._v(" 结束："+_vm._s(_vm.moment(row.calculate_date, 'YYYY-MM-DD') .add(row.purchase_cycle + row.sale_cycle, 'd') .format('YYYY-MM-DD'))+" ")]}}])}),_c('a-table-column',{key:"purchase_status",attrs:{"title":_vm.$t('columns.purchase_status'),"data-index":"purchase_status","width":"3%","align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(purchase_status){return [(purchase_status == 10)?_c('span',{staticStyle:{"color":"gray"}},[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(purchase_status,'PurchaseStatus')))+" ")]):(purchase_status == 20)?_c('span',{staticStyle:{"color":"blue"}},[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(purchase_status,'PurchaseStatus')))+" ")]):(purchase_status == 30)?_c('span',{staticStyle:{"color":"#333"}},[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(purchase_status,'PurchaseStatus')))+" ")]):(purchase_status == 40)?_c('span',{staticStyle:{"color":"red"}},[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(purchase_status,'PurchaseStatus')))+" ")]):_vm._e()]}}])}),_c('a-table-column',{key:"alarm_qty",attrs:{"title":_vm.$t('columns.alarm_qty'),"data-index":"alarm_qty","width":"3%","align":"right"}}),_c('a-table-column',{key:"vendor_name",attrs:{"title":_vm.$t('columns.vendor_name'),"data-index":"vendor_name","width":"5%","align":"center"}}),_c('a-table-column',{key:"min_qty",attrs:{"title":_vm.$t('columns.min_qty'),"data-index":"min_qty","width":"3%","align":"right"}}),_c('a-table-column',{key:"calculate_date",attrs:{"title":_vm.$t('columns.calculate_date'),"data-index":"calculate_date","width":"5%","align":"center"}}),_c('a-table-column',{key:"warehouse_id",attrs:{"title":_vm.$t('columns.warehouse_id'),"data-index":"warehouse_id","width":"3%"},scopedSlots:_vm._u([{key:"default",fn:function(warehouse_id){return [_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(warehouse_id,'WarehouseId')))+" ")])]}}])}),_c('a-table-column',{key:"presale_ratio",attrs:{"title":_vm.$t('columns.presale_ratio'),"data-index":"presale_ratio","width":"3%","align":"right"}}),_c('a-table-column',{key:"presale_days",attrs:{"title":_vm.$t('columns.presale_days'),"data-index":"presale_days","width":"3%","align":"right"}}),_c('a-table-column',{key:"all_is_presale",attrs:{"title":_vm.$t('columns.all_is_presale'),"width":"3%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" 一: "),(row.is_presale)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})]),_c('br'),_vm._v("二: "),(row.is_second_presale)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}}])}),_c('a-table-column',{key:"is_uk_purchase",attrs:{"title":_vm.$t('columns.is_uk_purchase'),"data-index":"is_uk_purchase","width":"3%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(is_uk_purchase){return [(is_uk_purchase)?_c('span',[_c('input',{attrs:{"type":"checkbox","checked":"","disabled":""}})]):_c('span',[_c('input',{attrs:{"type":"checkbox","disabled":""}})])]}}])}),_c('a-table-column',{key:"write_uid",attrs:{"title":_vm.$t('columns.write_uid'),"data-index":"write_uid","width":"3%","align":"center"}}),_c('a-table-column',{key:"write_date",attrs:{"title":_vm.$t('columns.write_date'),"width":"6%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.write_date))+" ")]}}])})],1)],1),(_vm.selectedRows[0])?_c('a-card',{},[_c('PurchasePredictView',{attrs:{"detail":_vm.selectedRows[0],"systemUsers":_vm.systemUsers}})],1):_vm._e()],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-purchase-predict.vue?vue&type=template&id=e5f84880&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__("a15b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.split.js
var es_string_split = __webpack_require__("1276");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.set.js
var es_set = __webpack_require__("6062");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.iterator.js
var es_string_iterator = __webpack_require__("3ca3");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.iterator.js
var web_dom_collections_iterator = __webpack_require__("ddb0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/purchase-apply.vue?vue&type=template&id=08bd1759&
var purchase_applyvue_type_template_id_08bd1759_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component customer-detail"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.warehouse_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["warehouse_id"]),expression:"[`warehouse_id`]"}],attrs:{"size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.req_type'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["req_type"]),expression:"[`req_type`]"}],attrs:{"default-value":"development"}},[_c('a-select-option',{key:"operational",attrs:{"value":"operational"}},[_vm._v("Operational")]),_c('a-select-option',{key:"development",attrs:{"value":"development"}},[_vm._v("Development")])],1)],1)],1),_c('a-col',{attrs:{"span":10}},[_vm._v(" 期望交期（批量） "),_c('a-date-picker',{attrs:{"default-value":_vm.batch_give_date,"size":"small"},on:{"change":_vm.onChangeGiveDate}})],1),_c('a-col',{attrs:{"span":10}},[_vm._v(" 期望入库日期（批量） "),_c('a-date-picker',{attrs:{"default-value":_vm.batch_date_expected,"size":"small"},on:{"change":_vm.onChangeDateExpected}})],1),_c('a-col',{attrs:{"span":4}},[_c('a-button',{on:{"click":_vm.batchEditDate}},[_vm._v("批量修改")])],1)],1)],1),_c('a-card',{staticClass:"margin-y"},[_c('a-table',{staticClass:"components-table-demo-nested",attrs:{"columns":_vm.columns,"data-source":_vm.rows,"rowKey":"default_code","scroll":{ y: 500 }},on:{"expand":_vm.expand},scopedSlots:_vm._u([{key:"expandedRowRender",fn:function(record){return _c('a-table',{attrs:{"columns":_vm.innerColumns,"rowKey":record.default_code,"data-source":_vm.innerData[record.default_code],"pagination":false},scopedSlots:_vm._u([{key:"sales_expected_give_date",fn:function(sales_expected_give_date, row){return [_c('a-date-picker',{attrs:{"value":sales_expected_give_date,"size":"small"},on:{"change":function (e) { return _vm.onInputChange(
                                    e,
                                    row,
                                    record,
                                    'sales_expected_give_date'
                                ); }}})]}},{key:"date_expected",fn:function(date_expected, row){return [_c('a-date-picker',{attrs:{"value":date_expected,"size":"small"},on:{"change":function (e) { return _vm.onInputChange(
                                    e,
                                    row,
                                    record,
                                    'date_expected'
                                ); }}})]}},{key:"coefficient",fn:function(coefficient, row){return [_c('a-input-number',{style:({ width: '100%' }),attrs:{"value":coefficient,"min":0,"size":"small","decimalSeparator":","},on:{"change":function (e) { return _vm.onInputChange(e, row, record, 'coefficient'); }}})]}},{key:"product_qty",fn:function(product_qty, row){return [_c('a-input-number',{style:({ width: '100%' }),attrs:{"value":product_qty,"min":0,"size":"small","decimalSeparator":","},on:{"change":function (e) { return _vm.onInputChange(e, row, record, 'product_qty'); }}})]}}])})}}])})],1),_c('div',{staticClass:"flex-row justify-content-end margin-y"},[_c('a-button',{staticClass:"margin-x",attrs:{"type":"primary"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(" "+_vm._s(_vm.$t('action.commit'))+" ")]),_c('a-button',{staticClass:"margin-x",on:{"click":function($event){return _vm.cancel()}}},[_vm._v(" "+_vm._s(_vm.$t('action.cancel'))+" ")])],1)],1)}
var purchase_applyvue_type_template_id_08bd1759_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/purchase-apply.vue?vue&type=template&id=08bd1759&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__("fb6a");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__("99af");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__("159b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__("a434");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.values.js
var es_object_values = __webpack_require__("07ac");

// EXTERNAL MODULE: ./src/services/purchase.service.ts
var purchase_service = __webpack_require__("0d91");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/purchase-apply.vue?vue&type=script&lang=ts&


















var purchase_applyvue_type_script_lang_ts_PurchaseApply =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchaseApply, _super);

  function PurchaseApply() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.moment = moment_default.a; // 里层数据{sku:[{},{}]}

    _this.innerData = {};
    _this.selectedRowKeys = []; // Loading服务

    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.purchaseService = new purchase_service["a" /* PurchaseService */]();
    _this.productService = new product_service["a" /* ProductService */]();
    _this.columns = [{
      title: 'sku',
      dataIndex: 'default_code',
      key: 'default_code'
    }, {
      title: _this.$t('columns.product_qty'),
      dataIndex: 'product_qty',
      key: 'product_qty'
    }, {
      title: _this.$t('columns.min_qty'),
      dataIndex: 'min_qty',
      key: 'min_qty'
    }];
    _this.innerColumns = [{
      title: 'sku',
      dataIndex: 'default_code',
      key: 'default_code'
    }, {
      title: _this.$t('columns.sales_expected_give_date'),
      dataIndex: 'sales_expected_give_date',
      format: 'YYYY-MM-DD',
      key: 'sales_expected_give_date',
      scopedSlots: {
        customRender: 'sales_expected_give_date'
      }
    }, {
      title: _this.$t('columns.date_expected'),
      // defaultValue: 'date_expected',
      dataIndex: 'date_expected',
      format: 'YYYY-MM-DD',
      scopedSlots: {
        customRender: 'date_expected'
      },
      key: 'date_expected'
    }, {
      title: _this.$t('columns.coefficient'),
      dataIndex: 'coefficient',
      key: 'coefficient',
      scopedSlots: {
        customRender: 'coefficient'
      }
    }, {
      title: _this.$t('columns.product_qty'),
      dataIndex: 'product_qty',
      scopedSlots: {
        customRender: 'product_qty'
      },
      key: 'product_qty'
    }];
    return _this;
  }

  PurchaseApply.prototype.submit = function () {
    return true;
  };

  PurchaseApply.prototype.cancel = function () {};

  PurchaseApply.prototype.mounted = function () {
    this.form.setFieldsValue(this.form_data);
  };

  PurchaseApply.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  PurchaseApply.prototype.onInputChange = function (e, row, record, column) {
    var data = this.innerData[record.default_code].slice();
    var target = data.filter(function (item) {
      return row.default_code === item.default_code;
    })[0];

    if (target) {
      target[column] = e;
    }

    this.innerData[record.default_code] = data;

    var _obj = JSON.stringify(this.innerData);

    this.innerData = JSON.parse(_obj);

    if (column === 'coefficient') {
      var sum = 0;
      var data2 = this.innerData[record.default_code].slice();

      for (var _i = 0, data2_1 = data2; _i < data2_1.length; _i++) {
        var sub = data2_1[_i];
        sum += sub.coefficient;
      }

      for (var _a = 0, data2_2 = data2; _a < data2_2.length; _a++) {
        var sub2 = data2_2[_a];
        sub2.product_qty = record.product_qty * (sub2.coefficient / sum);
      }

      this.innerData[record.default_code] = data2;

      var _obj_1 = JSON.stringify(this.innerData);

      this.innerData = JSON.parse(_obj_1);
    }
  };

  PurchaseApply.prototype.expand = function (expanded, record) {
    var _this = this;

    if (expanded && !this.innerData.hasOwnProperty(record.default_code)) {
      this.productService.queryProductPack(new http["RequestParams"]({
        default_code: record.default_code
      }, {
        loading: this.loadingService
      })).subscribe(function (data) {
        var sku_list = [];

        for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
          var sku = data_1[_i];
          sku_list.push({
            default_code: sku,
            date_expected: '',
            sales_expected_give_date: '',
            coefficient: 0,
            product_qty: 0,
            qty_uom: data[0].qty_uom
          });
        }

        _this.innerData[record.default_code] = sku_list;

        var _obj = JSON.stringify(_this.innerData);

        _this.innerData = JSON.parse(_obj);
      }, function (err) {
        _this.$message.error(err.message);
      });
    }
  };

  PurchaseApply.prototype.onSubmit = function () {
    var _this = this;

    var inner_data = this.innerData;
    var req_line_list = [];
    this.form.validateFields({}, function (err, values) {
      if (!err) {
        for (var item in inner_data) {
          req_line_list = req_line_list.concat(inner_data[item]);
        }

        req_line_list.forEach(function (item, index, arr) {
          if (item['product_qty'] == 0) {
            arr.splice(index, 1);
          }
        });

        var _loop_1 = function _loop_1(i) {
          var row = req_line_list[i];
          row.default_code = row.default_code.default_code;

          var calculate = _this.rows.find(function (x) {
            return x.default_code === row.default_code;
          });

          row['calculate_code'] = calculate.calculate_code;

          if (!row['date_expected'] || !row['sales_expected_give_date']) {
            _this.$message.error(row.default_code + ':请将时间填写完整');

            return {
              value: false
            };
          }

          if (row['date_expected'] < row['sales_expected_give_date']) {
            _this.$message.error(row.default_code + ':期望交期必须小于期望入库日期');

            return {
              value: false
            };
          }
        };

        for (var i = 0; i < req_line_list.length; i++) {
          var state_1 = _loop_1(i);

          if (Object(esm_typeof["a" /* default */])(state_1) === "object") return state_1.value;
        }

        var data = tslib_es6["a" /* __assign */]({
          req_line_list: req_line_list
        }, values);

        _this.saveCustomer(data);
      }
    });
  };

  PurchaseApply.prototype.saveCustomer = function (data) {
    var _this = this;

    this.purchaseService.save(new http["RequestParams"](data, {
      loading: this.loadingService
    })).subscribe(function () {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchaseApply.prototype.onChangeGiveDate = function (date, dateString) {
    this.batch_give_date = date;
  };

  PurchaseApply.prototype.onChangeDateExpected = function (date, dateString) {
    this.batch_date_expected = date;
  };

  PurchaseApply.prototype.batchEditDate = function () {
    if (!this.batch_give_date || !this.batch_date_expected) {
      this.$message.error('请填写批量时间');
      return;
    }

    var innerDataValues = Object.values(this.innerData);

    for (var sku_obj in innerDataValues) {
      var sku_obj_values = innerDataValues[sku_obj];

      for (var _i = 0, sku_obj_values_1 = sku_obj_values; _i < sku_obj_values_1.length; _i++) {
        var row = sku_obj_values_1[_i];
        row['date_expected'] = this.batch_date_expected;
        row['sales_expected_give_date'] = this.batch_give_date;
      }
    }

    var _obj = JSON.stringify(this.innerData);

    this.innerData = JSON.parse(_obj);
    this.$message.success('批量修改时间成功');
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseApply.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchaseApply.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseApply.prototype, "rows", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseApply.prototype, "warehouse_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchaseApply.prototype, "form_data", void 0);

  PurchaseApply = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchaseApply);
  return PurchaseApply;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_applyvue_type_script_lang_ts_ = (purchase_applyvue_type_script_lang_ts_PurchaseApply);
// CONCATENATED MODULE: ./src/components/product/purchase-apply.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_purchase_applyvue_type_script_lang_ts_ = (purchase_applyvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/purchase-apply.vue?vue&type=custom&index=0&blockType=i18n
var purchase_applyvue_type_custom_index_0_blockType_i18n = __webpack_require__("10f1");

// CONCATENATED MODULE: ./src/components/product/purchase-apply.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_purchase_applyvue_type_script_lang_ts_,
  purchase_applyvue_type_template_id_08bd1759_render,
  purchase_applyvue_type_template_id_08bd1759_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_applyvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_applyvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var purchase_apply = (component.exports);
// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/purchase-predict-view.vue?vue&type=template&id=5a4995e8&
var purchase_predict_viewvue_type_template_id_5a4995e8_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component customer-detail"},[_c('a-tabs',{attrs:{"defaultActiveKey":"first"},on:{"change":function (e) { return _vm.paneChange(e); }},model:{value:(_vm.activeKey),callback:function ($$v) {_vm.activeKey=$$v},expression:"activeKey"}},[_c('a-tab-pane',{key:"first",attrs:{"tab":_vm.$t('purchase_predict_detail_1')}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.detail_first,"page":_vm.pageService,"bordered":""}},[_c('a-table-column',{key:"cur_date",attrs:{"title":_vm.$t('columns.cur_date'),"data-index":"cur_date","align":"center"}}),_c('a-table-column',{key:"sales_trend",attrs:{"title":_vm.$t('columns.sales_trend'),"data-index":"sales_trend","align":"right"}}),_c('a-table-column',{key:"will_sales",attrs:{"title":_vm.$t('columns.will_sales'),"data-index":"will_sales","align":"right"}}),_c('a-table-column',{key:"transit_qty",attrs:{"title":_vm.$t('columns.transit_qty'),"data-index":"transit_qty","align":"right"}}),_c('a-table-column',{key:"unship_qty",attrs:{"title":_vm.$t('columns.unship_qty'),"data-index":"unship_qty","align":"right"}}),_c('a-table-column',{key:"stock_qty",attrs:{"title":_vm.$t('columns.stock_qty'),"data-index":"stock_qty","align":"right"}})],1)],1),_c('a-tab-pane',{key:"second",attrs:{"tab":_vm.$t('purchase_predict_detail_2')}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.detail_second,"page":_vm.pageService,"bordered":""}},[_c('a-table-column',{key:"cur_date",attrs:{"title":_vm.$t('columns.cur_date'),"data-index":"cur_date","align":"center"}}),_c('a-table-column',{key:"sales_trend",attrs:{"title":_vm.$t('columns.sales_trend'),"data-index":"sales_trend","align":"right"}}),_c('a-table-column',{key:"will_sales",attrs:{"title":_vm.$t('columns.will_sales'),"data-index":"will_sales","align":"right"}}),_c('a-table-column',{key:"transit_qty",attrs:{"title":_vm.$t('columns.transit_qty'),"data-index":"transit_qty","align":"right"}}),_c('a-table-column',{key:"unship_qty",attrs:{"title":_vm.$t('columns.unship_qty'),"data-index":"unship_qty","align":"right"}}),_c('a-table-column',{key:"stock_qty",attrs:{"title":_vm.$t('columns.stock_qty'),"data-index":"stock_qty","align":"right"}})],1)],1),_c('a-tab-pane',{key:"sale_history",attrs:{"tab":_vm.$t('half_year_sales')}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.sale_history,"page":_vm.pageService,"bordered":""}},[_c('a-table-column',{key:"order_date",attrs:{"title":_vm.$t('columns.order_date'),"data-index":"order_date","align":"center"}}),_c('a-table-column',{key:"order_qty",attrs:{"title":_vm.$t('columns.order_qty'),"data-index":"order_qty","align":"right"}}),_c('a-table-column',{key:"sales_qty",attrs:{"title":_vm.$t('columns.sales_qty'),"data-index":"sales_qty","align":"right"}}),_c('a-table-column',{key:"presale_order_qty",attrs:{"title":_vm.$t('columns.presale_order_qty'),"data-index":"presale_order_qty","align":"right"}}),_c('a-table-column',{key:"presale_sales_qty",attrs:{"title":_vm.$t('columns.presale_sales_qty'),"data-index":"presale_sales_qty","align":"right"}}),_c('a-table-column',{key:"uk_order_qty",attrs:{"title":_vm.$t('columns.uk_order_qty'),"data-index":"uk_order_qty","align":"right"}}),_c('a-table-column',{key:"uk_sales_qty",attrs:{"title":_vm.$t('columns.uk_sales_qty'),"data-index":"uk_sales_qty","align":"right"}}),_c('a-table-column',{key:"uk_presale_order_qty",attrs:{"title":_vm.$t('columns.uk_presale_order_qty'),"data-index":"uk_presale_order_qty","align":"right"}}),_c('a-table-column',{key:"uk_presale_sales_qty",attrs:{"title":_vm.$t('columns.uk_presale_sales_qty'),"data-index":"uk_presale_sales_qty","align":"right"}})],1)],1),_c('a-tab-pane',{key:"log",attrs:{"tab":_vm.$t('logs')}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.logs,"rowKey":"log_content","bordered":""}},[_c('a-table-column',{key:"log_content",attrs:{"title":_vm.$t('columns.log_content'),"data-index":"log_content","align":"left","width":"40%"}}),_c('a-table-column',{key:"log_type",attrs:{"title":_vm.$t('columns.log_type'),"data-index":"log_type","align":"center","width":"15%"}}),_c('a-table-column',{key:"who_log",attrs:{"title":_vm.$t('columns.who_log'),"data-index":"who_log","align":"center","width":"15%"}}),_c('a-table-column',{key:"log_date",attrs:{"title":_vm.$t('columns.log_date'),"data-index":"log_date","align":"center","width":"20%"}}),_c('a-table-column',{key:"log_ip",attrs:{"title":"IP","data-index":"log_ip","align":"left"}})],1)],1)],1)],1)}
var purchase_predict_viewvue_type_template_id_5a4995e8_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/purchase-predict-view.vue?vue&type=template&id=5a4995e8&

// EXTERNAL MODULE: ./src/services/purchasecal.service.ts
var purchasecal_service = __webpack_require__("8cd0");

// EXTERNAL MODULE: ./src/services/operatelog.service.ts
var operatelog_service = __webpack_require__("8934");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/purchase-predict-view.vue?vue&type=script&lang=ts&












var purchase_predict_viewvue_type_script_lang_ts_PurchasePredictView =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchasePredictView, _super);

  function PurchasePredictView() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.activeKey = 'first'; // 分页服务

    _this.pageService = new page_service["a" /* PageService */]();
    _this.purchaseCalService = new purchasecal_service["a" /* PurchaseCalService */]();
    _this.operateLogService = new operatelog_service["a" /* OperateLogService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.logs = [];
    _this.detail_first = [];
    _this.detail_second = [];
    _this.sale_history = [];
    return _this;
  }

  PurchasePredictView.prototype.created = function () {
    this.getdetail_first();
  };

  PurchasePredictView.prototype.onDetailChange = function () {
    this.logs = [];
    this.detail_first = [];
    this.detail_second = [];

    if (this.activeKey == 'log') {
      this.getLogs();
    } else if (this.activeKey == 'first') {
      this.getdetail_first();
    } else if (this.activeKey == 'second') {
      this.getdetail_second();
    } else if (this.activeKey == 'sale_history') {
      this.getsale_history();
    }
  };

  PurchasePredictView.prototype.paneChange = function (key) {
    if (key === 'log' && !this.logs.length) {
      this.getLogs();
    } else if (key === 'first' && !this.detail_first.length) {
      this.getdetail_first();
    } else if (key === 'second' && !this.detail_second.length) {
      this.getdetail_second();
    } else if (key === 'sale_history' && !this.sale_history.length) {
      this.getsale_history();
    }
  };

  PurchasePredictView.prototype.getLogs = function () {
    var _this = this;

    this.operateLogService.viewUserOperateChangedLog(new http["RequestParams"]({
      object_name: 'product_purchase_calculate_list',
      record_code: this.detail.calculate_code
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
        var item = data_1[_i];

        var sysuser = _this.systemUsers.find(function (x) {
          return x.code === item.who_log;
        });

        item['who_log'] = sysuser ? sysuser.name : item.who_log;
        var localTime = moment_default.a.utc(item['log_date']).toDate();
        item['log_date'] = moment_default()(localTime).format('YYYY-MM-DD HH:mm');
      }

      _this.logs = data;
    });
  };

  PurchasePredictView.prototype.getdetail_first = function () {
    var _this = this;

    this.purchaseCalService.queryDetail(new http["RequestParams"]({
      calculate_code: this.detail.calculate_code,
      period_times: 1
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.detail_first = data;
    });
  };

  PurchasePredictView.prototype.getdetail_second = function () {
    var _this = this;

    this.purchaseCalService.queryDetail(new http["RequestParams"]({
      calculate_code: this.detail.calculate_code,
      period_times: 2
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.detail_second = data;
    });
  };

  PurchasePredictView.prototype.getsale_history = function () {
    var _this = this;

    this.purchaseCalService.salesHistory(new http["RequestParams"]({
      default_code: this.detail.default_code,
      order_date: this.detail.calculate_date
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.sale_history = data;
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePredictView.prototype, "detail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePredictView.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('detail'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchasePredictView.prototype, "onDetailChange", null);

  PurchasePredictView = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchasePredictView);
  return PurchasePredictView;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_predict_viewvue_type_script_lang_ts_ = (purchase_predict_viewvue_type_script_lang_ts_PurchasePredictView);
// CONCATENATED MODULE: ./src/components/product/purchase-predict-view.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_purchase_predict_viewvue_type_script_lang_ts_ = (purchase_predict_viewvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/purchase-predict-view.vue?vue&type=custom&index=0&blockType=i18n
var purchase_predict_viewvue_type_custom_index_0_blockType_i18n = __webpack_require__("6f4d");

// CONCATENATED MODULE: ./src/components/product/purchase-predict-view.vue





/* normalize component */

var purchase_predict_view_component = Object(componentNormalizer["a" /* default */])(
  product_purchase_predict_viewvue_type_script_lang_ts_,
  purchase_predict_viewvue_type_template_id_5a4995e8_render,
  purchase_predict_viewvue_type_template_id_5a4995e8_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_predict_viewvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_predict_viewvue_type_custom_index_0_blockType_i18n["default"])(purchase_predict_view_component)

/* harmony default export */ var purchase_predict_view = (purchase_predict_view_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/purchase-predict-edit.vue?vue&type=template&id=915059ac&
var purchase_predict_editvue_type_template_id_915059ac_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":"sku","required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'default_code',
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'default_code',\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"showSearch":"","placeholder":"sku","size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.calculate_date'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'calculate_date',
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'calculate_date',\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"showSearch":"","placeholder":"统计日期","size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":20}},[_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(false),expression:"false"}],attrs:{"label":_vm.$t('columns.calculate_code'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'calculate_code',
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'calculate_code',\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"showSearch":"","placeholder":_vm.$t('columns.calculate_code'),"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.is_presale'),"required":""}},[_c('a-checkbox',{attrs:{"defaultChecked":_vm.is_presale},model:{value:(_vm.is_presale),callback:function ($$v) {_vm.is_presale=$$v},expression:"is_presale"}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.is_second_presale'),"required":""}},[_c('a-checkbox',{attrs:{"defaultChecked":_vm.is_second_presale},model:{value:(_vm.is_second_presale),callback:function ($$v) {_vm.is_second_presale=$$v},expression:"is_second_presale"}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.presale_ratio'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "presale_ratio",
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            `presale_ratio`,\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.week_avg_sales'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "week_avg_sales",
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            `week_avg_sales`,\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.use_history_week_sale'),"required":""}},[_c('a-checkbox',{attrs:{"defaultChecked":_vm.use_history_week_sale},model:{value:(_vm.use_history_week_sale),callback:function ($$v) {_vm.use_history_week_sale=$$v},expression:"use_history_week_sale"}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.use_history_ratio'),"required":""}},[_c('a-checkbox',{attrs:{"defaultChecked":_vm.use_history_ratio},model:{value:(_vm.use_history_ratio),callback:function ($$v) {_vm.use_history_ratio=$$v},expression:"use_history_ratio"}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.purchase_cycle'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "purchase_cycle",
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            `purchase_cycle`,\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["memo"]),expression:"[`memo`]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.sale_cycle'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "sale_cycle",
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            `sale_cycle`,\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.presale_days'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "presale_days",
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            `presale_days`,\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.use_history_ratio),expression:"use_history_ratio"}],attrs:{"label":_vm.$t('columns.increase_ratio_1')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["increase_ratio_1"]),expression:"[`increase_ratio_1`]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.use_history_ratio),expression:"use_history_ratio"}],attrs:{"label":_vm.$t('columns.increase_ratio_2')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["increase_ratio_2"]),expression:"[`increase_ratio_2`]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.use_history_ratio),expression:"use_history_ratio"}],attrs:{"label":_vm.$t('columns.increase_ratio_3')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["increase_ratio_3"]),expression:"[`increase_ratio_3`]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.use_history_ratio),expression:"use_history_ratio"}],attrs:{"label":_vm.$t('columns.increase_ratio_4')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(["increase_ratio_4"]),expression:"[`increase_ratio_4`]"}],attrs:{"size":"small","min":"0","placeholder":"需大于0","decimalSeparator":","}})],1)],1)],1)],1),(_vm.use_history_week_sale)?_c('a-card',{staticClass:"margin-y"},[[_c('a-input-number',{staticStyle:{"width":"50%"},attrs:{"placeholder":"填写以往周数来查看销量","min":"1","max":"100","decimalSeparator":","},on:{"change":function (value) { return (_vm.week_number = value); }}}),_c('a-button',{on:{"click":_vm.get_week_sales}},[_vm._v("查询")])],_c('data-table',{attrs:{"stripe":true,"data":_vm.history_week_sale,"page":_vm.pageService,"rowKey":"week","scroll":{ y: 300 },"rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys, select_rows) {
                    _vm.selectedRows = select_rows
                    _vm.selectedRowKeys = keys
                }
            }}},[_c('a-table-column',{key:"week",attrs:{"title":_vm.$t('columns.week'),"data-index":"week","width":"25%"}}),_c('a-table-column',{key:"sales",attrs:{"title":_vm.$t('columns.sales'),"data-index":"sales","width":"25%"}})],1)],2):_vm._e(),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.ok')))])],1)],1)}
var purchase_predict_editvue_type_template_id_915059ac_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/purchase-predict-edit.vue?vue&type=template&id=915059ac&

// EXTERNAL MODULE: ./src/services/presale.service.ts
var presale_service = __webpack_require__("d4a0");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/purchase-predict-edit.vue?vue&type=script&lang=ts&






var purchase_predict_editvue_type_script_lang_ts_PurchasePredictEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PurchasePredictEdit, _super);

  function PurchasePredictEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.history_week_sale = [];
    _this.is_presale = false;
    _this.is_second_presale = false;
    _this.use_history_week_sale = false;
    _this.use_history_ratio = false; // 表格选择项

    _this.selectedRowKeys = [];
    _this.selectedRows = [];
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.preSaleService = new presale_service["a" /* PreSaleService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }],
      requiredvalue: [{
        message: '请输入大于0的数',
        validator: _this.checkValue
      }]
    };
    return _this;
  }

  PurchasePredictEdit.prototype.submit = function () {
    return true;
  };

  PurchasePredictEdit.prototype.cancel = function () {
    return;
  };

  PurchasePredictEdit.prototype.checkValue = function (rule, value, callback) {
    if (value < 0) {
      callback('必须大于0');
    }
  };

  PurchasePredictEdit.prototype.mounted = function () {
    if (this.row) {
      // console.log(this.row)
      this.setFormValues();
      this.is_presale = this.row.is_presale;
      this.is_second_presale = this.row.is_second_presale;
    }
  };

  PurchasePredictEdit.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.row);
  };

  PurchasePredictEdit.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  PurchasePredictEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['is_presale'] = _this.is_presale;
        values['is_second_presale'] = _this.is_second_presale;
        values['use_history_week_sale'] = _this.use_history_week_sale;
        values['use_history_ratio'] = _this.use_history_ratio;
        values['week_sales_list'] = _this.selectedRows;

        if (!_this.use_history_ratio) {
          values['increase_ratio_1'] = 0;
          values['increase_ratio_2'] = 0;
          values['increase_ratio_3'] = 0;
          values['increase_ratio_4'] = 0;
        }

        _this.saveCustomer(values);
      }
    });
  };

  PurchasePredictEdit.prototype.saveCustomer = function (data) {
    var _this = this;

    this.preSaleService.re_calculate_purchase_predict(new http["RequestParams"](data, {
      loading: this.loadingService
    })).subscribe(function () {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PurchasePredictEdit.prototype.get_week_sales = function () {
    var _this = this;

    this.preSaleService.query_sku_week_sales(new http["RequestParams"]({
      calculate_code: this.row.calculate_code,
      week_number: this.week_number
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.history_week_sale = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchasePredictEdit.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PurchasePredictEdit.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePredictEdit.prototype, "row", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PurchasePredictEdit.prototype, "saveFlag", void 0);

  PurchasePredictEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PurchasePredictEdit);
  return PurchasePredictEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var purchase_predict_editvue_type_script_lang_ts_ = (purchase_predict_editvue_type_script_lang_ts_PurchasePredictEdit);
// CONCATENATED MODULE: ./src/components/product/purchase-predict-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_purchase_predict_editvue_type_script_lang_ts_ = (purchase_predict_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/purchase-predict-edit.vue?vue&type=custom&index=0&blockType=i18n
var purchase_predict_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("ae00");

// CONCATENATED MODULE: ./src/components/product/purchase-predict-edit.vue





/* normalize component */

var purchase_predict_edit_component = Object(componentNormalizer["a" /* default */])(
  product_purchase_predict_editvue_type_script_lang_ts_,
  purchase_predict_editvue_type_template_id_915059ac_render,
  purchase_predict_editvue_type_template_id_915059ac_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof purchase_predict_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(purchase_predict_editvue_type_custom_index_0_blockType_i18n["default"])(purchase_predict_edit_component)

/* harmony default export */ var purchase_predict_edit = (purchase_predict_edit_component.exports);
// EXTERNAL MODULE: ./src/services/user.service.ts
var user_service = __webpack_require__("2138");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/components/product/memo-edit.vue + 4 modules
var memo_edit = __webpack_require__("044e");

// EXTERNAL MODULE: ./src/services/vendor.service.ts
var vendor_service = __webpack_require__("ab38");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-purchase-predict.vue?vue&type=script&lang=ts&


































var userModule = Object(lib["c" /* namespace */])('userModule');
var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_purchase_predictvue_type_script_lang_ts_ProductPurchasePredict =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPurchasePredict, _super);

  function ProductPurchasePredict() {
    var _this = _super !== null && _super.apply(this, arguments) || this; // Loading服务


    _this.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */](); // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.selectedRows = [];
    _this.purchaseStatus = [];
    _this.orderBy = '';
    _this.moment = moment_default.a;
    _this.purchaseCalService = new purchasecal_service["a" /* PurchaseCalService */]();
    _this.presaleService = new presale_service["a" /* PreSaleService */]();
    _this.vendorService = new vendor_service["a" /* VendorService */]();
    _this.vender_data = []; // 详情项

    _this.current = null;
    return _this;
  }

  Object.defineProperty(ProductPurchasePredict.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });

  ProductPurchasePredict.prototype.mounted = function () {
    if (this.info === '') {
      this.purchaseStatus = this.$dict.PredictStatus;
    } else if (this.info === 'predict-confirm') {
      this.purchaseStatus = this.$dict.PredictStatusConfirm;
    } else if (this.info === 'predict-approve') {
      this.purchaseStatus = this.$dict.PredictStatusApprove;
    }
  };

  ProductPurchasePredict.prototype.created = function () {
    var _this = this; // this.getSystemuser()


    var userService = new user_service["a" /* UserService */]();
    userService.all(new http["RequestParams"]()).subscribe(function (data) {
      _this.systemUsers = data;
    });
    this.vendorService.get_vendor_ref_list(new http["RequestParams"]({}, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data.push({
        code: '未找到',
        name: '未找到'
      });
      _this.vender_data = data;
    }, function (err) {
      _this.$message.error(err.message);
    }); // var _that = this
    // document.onkeydown = function(e) {
    //     let event =
    //         e || window.event || arguments.callee.caller.arguments[0]
    //     if (event.ctrlKey && event.keyCode == 69) {
    //         console.log('Ctrl+E')
    //     }
    // }
  };

  ProductPurchasePredict.prototype.exportRows = function () {
    var calculate_date = this.selectedRows[0].calculate_date;

    for (var _i = 0, _a = this.selectedRows; _i < _a.length; _i++) {
      var item = _a[_i];

      if (item.calculate_date !== calculate_date) {
        this.$message.error('勾选日期必须一致');
        return;
      }
    }

    var urlParams = encodeURIComponent(JSON.stringify(this.selectedRowKeys));
    window.open(app_config["a" /* default */].server + '/product_purchase_predict/export_purchase_predict_excel?data_set=' + urlParams);
  };
  /**
   * 获取采购预测数据
   */


  ProductPurchasePredict.prototype.getPurchasePredictList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      if (!values['status'] && ['predict-confirm', 'predict-approve'].includes(_this.info)) {
        values['status'] = _this.purchaseStatus.map(function (x) {
          return x.value;
        }).join(',');
      }

      var params = common_service["a" /* CommonService */].createQueryCondition(values, {
        z_sub_category: 'like',
        default_code: 'like',
        week_avg_sales: '>=',
        status: '=',
        week_avg_sales_max: '<='
      });
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array) {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: item.value[0].format('YYYY-MM-DD 00:00:00').toString()
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: item.value[1].format('YYYY-MM-DD 23:59:59').toString()
            });
          }
        } else {
          nowConditions.push(item);
        }

        if (item.query_name == 'week_avg_sales_max') {
          item.query_name = 'week_avg_sales';
        }

        if (item.query_name == 'status' && item.value.toString().indexOf(',') > -1) {
          item.operate = 'in';
          var status = item.value.split(',');
          item.value = status.map(function (z) {
            return parseInt(z);
          });
        }
      }

      params.query_condition = nowConditions;

      if (_this.orderBy) {
        params['order_by'] = _this.orderBy;
      }

      _this.purchaseCalService.queryAll(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
          var item = data_1[_i];

          var sysuser = _this.systemUsers.find(function (x) {
            return x.code === item.write_uid;
          });

          item['write_uid'] = sysuser ? sysuser.name : item.write_uid;
          var localTime = moment_default.a.utc(item['log_date']).toDate();
          item['log_date'] = moment_default()(localTime).format('YYYY-MM-DD HH:mm');
        }

        _this.data = data;
        _this.selectedRowKeys = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    }).catch(function (err) {// 异常处理
    });
  };

  ProductPurchasePredict.prototype.onStatusChange = function (e) {
    this.$nextTick(function () {
      this.getPurchasePredictList();
    });
  };

  ProductPurchasePredict.prototype.onTrClick = function (record) {
    var info = this.data.find(function (x) {
      return x.calculate_code === record;
    });
    this.selectedRows = [info];
  };

  ProductPurchasePredict.prototype.onPurchaseApply = function () {
    var _this = this;

    var rows = [];
    var warehouse_id = this.selectedRows[0]['warehouse_id'];
    var default_code_set = new Set();
    var form_data = {
      warehouse_id: warehouse_id,
      req_type: 'operational'
    };

    for (var _i = 0, _a = this.selectedRows; _i < _a.length; _i++) {
      var row = _a[_i];

      if (row.warehouse_id != warehouse_id) {
        this.$message.error('勾选项来源仓库必须一致');
        return false;
      }

      if (!default_code_set.has(row.default_code)) {
        default_code_set.add(row.default_code);
      } else {
        this.$message.error('勾选sku不能重复');
        return false;
      }

      rows.push({
        default_code: row.default_code,
        date_expected: '',
        sales_expected_give_date: '',
        product_qty: row.second_period_need_stock,
        calculate_code: row.calculate_code,
        min_qty: row.min_qty
      });
    }

    this.$modal.open(purchase_apply, {
      rows: rows,
      warehouse_id: warehouse_id,
      form_data: form_data
    }, {
      title: '生成采购计划',
      width: '60%'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getPurchasePredictList();
    });
  };

  ProductPurchasePredict.prototype.reCalculate = function () {
    if (this.selectedRows.length > 1) {
      this.$message.error('只限选择一条进行重算');
      return;
    }

    this.onEdit(this.selectedRows[0]);
  };

  ProductPurchasePredict.prototype.onEdit = function (row) {
    var _this = this;

    this.$modal.open(purchase_predict_edit, {
      row: row
    }, {
      title: '编辑采购预测数据',
      width: '70%'
    }).subscribe(function (data) {
      _this.$message.success('操作成功');

      _this.getPurchasePredictList();
    });
  };

  ProductPurchasePredict.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getPurchasePredictList();
  };

  ProductPurchasePredict.prototype.verify_sales = function () {
    var _this = this; //product_pre_sale/active_purchase_predict


    this.presaleService.active_purchase_predict(new http["RequestParams"]({
      calculate_code_list: this.selectedRowKeys
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPurchasePredict.prototype.verify_sales_manager = function () {
    var _this = this; //product_pre_sale/confirm_purchase_predict
    // is_pass: true
    //memo


    this.$modal.open(memo_edit["a" /* default */], {}, {
      title: this.$t('edit-memo'),
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      _this.presaleService.confirm_purchase_predict(new http["RequestParams"]({
        calculate_code_list: _this.selectedRowKeys,
        is_pass: true,
        memo: data.memo
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ProductPurchasePredict.prototype.verify_sales_director = function () {
    var _this = this; //product_pre_sale/approve_purchase_predict
    //is_pass:true
    //memo


    this.$modal.open(memo_edit["a" /* default */], {}, {
      title: this.$t('edit-memo'),
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      _this.presaleService.approve_purchase_predict(new http["RequestParams"]({
        calculate_code_list: _this.selectedRowKeys,
        is_pass: true,
        memo: data.memo
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ProductPurchasePredict.prototype.confirm_sales = function () {
    var _this = this; ///product_pre_sale/renew_purchase_predict


    this.presaleService.renew_purchase_predict(new http["RequestParams"]({
      calculate_code_list: this.selectedRowKeys
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPurchasePredict.prototype.confirm_sales_manager = function () {
    var _this = this; //product_pre_sale/return_purchase_predict
    //"need_return": false,
    //"memo":"无需回退2"


    this.$modal.open(memo_edit["a" /* default */], {}, {
      title: this.$t('edit-memo'),
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      _this.presaleService.return_purchase_predict(new http["RequestParams"]({
        calculate_code_list: _this.selectedRowKeys,
        is_pass: false,
        need_return: false,
        memo: data.memo
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ProductPurchasePredict.prototype.confirm_return_sales_manager = function () {
    var _this = this; //product_pre_sale/return_purchase_predict
    //"need_return": false,
    //"memo":"无需回退2"


    this.$modal.open(memo_edit["a" /* default */], {}, {
      title: this.$t('edit-memo'),
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      _this.presaleService.return_purchase_predict(new http["RequestParams"]({
        calculate_code_list: _this.selectedRowKeys,
        is_pass: false,
        need_return: true,
        memo: data.memo
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ProductPurchasePredict.prototype.return_sales_manager = function () {
    var _this = this; //product_pre_sale/confirm_purchase_predict
    // is_pass: false
    //memo


    this.$modal.open(memo_edit["a" /* default */], {}, {
      title: this.$t('edit-memo'),
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      _this.presaleService.confirm_purchase_predict(new http["RequestParams"]({
        calculate_code_list: _this.selectedRowKeys,
        is_pass: false,
        memo: data.memo
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ProductPurchasePredict.prototype.refuse_sales_director = function () {
    var _this = this; //product_pre_sale/approve_purchase_predict
    //is_pass:false
    //memo


    this.$modal.open(memo_edit["a" /* default */], {}, {
      title: this.$t('edit-memo'),
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      _this.presaleService.approve_purchase_predict(new http["RequestParams"]({
        calculate_code_list: _this.selectedRowKeys,
        is_pass: false,
        memo: data.memo
      })).subscribe(function (data) {
        _this.$message.success('操作成功');
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ProductPurchasePredict.prototype.calcStyle = function (row) {
    if (row.exists_exception) {
      return 'red-text';
    } else {
      return 'default-text';
    }
  };

  ProductPurchasePredict.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ProductPurchasePredict.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], ProductPurchasePredict.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPurchasePredict.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPurchasePredict.prototype, "username", void 0);

  ProductPurchasePredict = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      PurchaseApply: purchase_apply,
      PurchasePredictView: purchase_predict_view,
      PurchasePredictEdit: purchase_predict_edit
    }
  })], ProductPurchasePredict);
  return ProductPurchasePredict;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_purchase_predictvue_type_script_lang_ts_ = (product_purchase_predictvue_type_script_lang_ts_ProductPurchasePredict);
// CONCATENATED MODULE: ./src/components/product/product-purchase-predict.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_purchase_predictvue_type_script_lang_ts_ = (product_purchase_predictvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/product-purchase-predict.vue?vue&type=style&index=0&lang=css&
var product_purchase_predictvue_type_style_index_0_lang_css_ = __webpack_require__("8b29");

// EXTERNAL MODULE: ./src/components/product/product-purchase-predict.vue?vue&type=custom&index=0&blockType=i18n
var product_purchase_predictvue_type_custom_index_0_blockType_i18n = __webpack_require__("fbeb");

// CONCATENATED MODULE: ./src/components/product/product-purchase-predict.vue






/* normalize component */

var product_purchase_predict_component = Object(componentNormalizer["a" /* default */])(
  product_product_purchase_predictvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_purchase_predictvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_purchase_predictvue_type_custom_index_0_blockType_i18n["default"])(product_purchase_predict_component)

/* harmony default export */ var product_purchase_predict = __webpack_exports__["a"] = (product_purchase_predict_component.exports);

/***/ }),

/***/ "22cd":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-extra-attr-edit.vue?vue&type=template&id=75e03c69&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component customer-detail"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 4 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":30}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.sub_category'),"required":""}},[_c('a-select',{staticStyle:{"width":"80%"},attrs:{"placeholder":"","size":"small","allowClear":"","disabled":true},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},_vm._l((_vm.subCates),function(cate){return _c('a-select-option',{key:cate.cn_sub_category},[_vm._v(" "+_vm._s(cate.cn_sub_category)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":30}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.sub_category_attr')}},[_vm._l((_vm.tags),function(tag,index){return [(tag.length > 20)?_c('a-tooltip',{key:tag,attrs:{"title":tag}},[_c('a-tag',{key:tag,attrs:{"closable":index !== 0},on:{"close":function () { return _vm.handleClose(tag); }}},[_vm._v(" "+_vm._s(((tag.slice(0, 20)) + "..."))+" ")])],1):_c('a-tag',{key:tag,attrs:{"closable":index !== 0},on:{"close":function () { return _vm.handleClose(tag); }}},[_vm._v(" "+_vm._s(tag)+" ")])]}),(_vm.inputVisible)?_c('a-input',{ref:"input",style:({ width: '78px' }),attrs:{"type":"text","size":"small","value":_vm.inputValue},on:{"change":_vm.handleInputChange,"blur":_vm.handleInputConfirm,"keyup":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.handleInputConfirm.apply(null, arguments)}}}):_c('a-tag',{staticStyle:{"background":"#fff","borderStyle":"dashed"},on:{"click":_vm.showInput}},[_c('a-icon',{attrs:{"type":"plus"}}),_vm._v(" New Tag ")],1)],2)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.commit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-extra-attr-edit.vue?vue&type=template&id=75e03c69&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__("99af");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-extra-attr-edit.vue?vue&type=script&lang=ts&
















var product_extra_attr_editvue_type_script_lang_ts_ProductExtraAttrEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductExtraAttrEdit, _super);

  function ProductExtraAttrEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.subCates = [];
    _this.selectedList = '';
    _this.originRow = '';
    _this.tags = [];
    _this.inputVisible = false;
    _this.inputValue = '';
    _this.sonCates = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadService = new loading_service["a" /* LoadingService */]();
    _this.index = 0; // 表格数据源

    _this.ruleData = [];
    return _this;
  }

  ProductExtraAttrEdit.prototype.submit = function () {
    return true;
  };

  ProductExtraAttrEdit.prototype.cancel = function () {};

  ProductExtraAttrEdit.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.originRow);
  };

  ProductExtraAttrEdit.prototype.created = function () {
    this.getSubCates();
    this.form = this.$form.createForm(this);
  };

  ProductExtraAttrEdit.prototype.mounted = function () {
    var objString = JSON.stringify(this.row);
    this.originRow = JSON.parse(objString);
    this.selectedList = this.originRow.cn_sub_category;

    if (this.saveFlag == 0) {
      delete this.originRow.id;

      if (this.originRow.extra_attributes) {
        this.selectedList = '';
      }
    }

    if (this.originRow.extra_attributes) {
      this.tags = JSON.parse(this.originRow.extra_attributes.replace(/'/g, '"'));
    }

    this.setFormValues();
  };

  ProductExtraAttrEdit.prototype.addRule = function () {
    var ruleParam = {
      query_name: '',
      operate: '=',
      value: '',
      index: uuid_default.a.generate()
    };
    this.ruleData.push(ruleParam);
  };

  ProductExtraAttrEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        // values['save_flag'] = this.saveFlag
        values['extra_attributes'] = _this.tags;
        values['cn_sub_category'] = _this.selectedList;
        values['cn_category'] = _this.row.cn_category;

        _this.saveInfo(values);
      }
    });
  };

  ProductExtraAttrEdit.prototype.saveInfo = function (params) {
    var _this = this;

    params.extra_attributes = JSON.stringify(params.extra_attributes).replace(/"/g, "'"); // this.productService
    //     .save_sub_category_attributes(new RequestParams(params))
    //     .subscribe(
    //         () => {
    //             this.submit()
    //         },
    //         err => {
    //             this.$message.error(err.message)
    //         }
    //     )

    this.innerAction.setActionAPI('category/save_category_extra_attributes', common_service["a" /* CommonService */].getMenuCode('product-category-manage'));
    this.publicService.modify(new http["RequestParams"](params, {
      loading: this.loadService,
      innerAction: this.innerAction
    })).subscribe(function (data2) {
      _this.submit();
    });
  };

  ProductExtraAttrEdit.prototype.handleClose = function (removedTag) {
    var tags = this.tags.filter(function (tag) {
      return tag !== removedTag;
    });
    this.tags = tags;
  };

  ProductExtraAttrEdit.prototype.showInput = function () {
    this.inputVisible = true;
    this.$nextTick(function () {
      var ipt = this.$refs.input;
      ipt.focus();
    });
  };

  ProductExtraAttrEdit.prototype.handleInputChange = function (e) {
    this.inputValue = e.target.value;
  };

  ProductExtraAttrEdit.prototype.handleInputConfirm = function () {
    var inputValue = this.inputValue;
    var tags = this.tags;

    if (inputValue && tags.indexOf(inputValue) === -1) {
      tags = tags.concat([inputValue]);
    }

    Object.assign(this, {
      tags: tags,
      inputVisible: false,
      inputValue: ''
    });
  };

  ProductExtraAttrEdit.prototype.getSubCates = function () {
    var _this = this;

    this.productService.query_all_sub_category_attributes(new http["RequestParams"]({
      page_index: 1,
      page_size: 1000
    })).subscribe(function (data) {
      _this.subCates = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductExtraAttrEdit.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductExtraAttrEdit.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductExtraAttrEdit.prototype, "row", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductExtraAttrEdit.prototype, "saveFlag", void 0);

  ProductExtraAttrEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductExtraAttrEdit);
  return ProductExtraAttrEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_extra_attr_editvue_type_script_lang_ts_ = (product_extra_attr_editvue_type_script_lang_ts_ProductExtraAttrEdit);
// CONCATENATED MODULE: ./src/components/product/product-extra-attr-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_extra_attr_editvue_type_script_lang_ts_ = (product_extra_attr_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-extra-attr-edit.vue?vue&type=custom&index=0&blockType=i18n
var product_extra_attr_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("5dca");

// CONCATENATED MODULE: ./src/components/product/product-extra-attr-edit.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_extra_attr_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_extra_attr_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_extra_attr_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_extra_attr_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "22f5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_cate_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("823a");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_cate_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_cate_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_cate_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "22fd":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"warehouse_id":"warehouse_id","calculate_date":"calculate_date","week_avg_sales":"week_avg_sales","is_presale":"is_presale","is_second_presale":"is_second_presale","presale_ratio":"presale_ratio","use_history_week_sale":"use_history_week_sale","purchase_cycle":"purchase_cycle","sale_cycle":"sale_cycle","presale_days":"presale_days","week":"week","sales":"sales","increase_ratio_1":"increase_ratio_1","increase_ratio_2":"increase_ratio_2","increase_ratio_3":"increase_ratio_3","increase_ratio_4":"increase_ratio_4","memo":"memo","use_history_ratio":"use_history_ratio"},"action":{"ok":"Ok","cancel":"Cancel"},"rules":{}},"zh-cn":{"desc":"","columns":{"warehouse_id":"仓库","calculate_date":"统计日期","week_avg_sales":"周均销量","is_presale":"第一期预售","is_second_presale":"第二期预售","presale_ratio":"预售系数","use_history_week_sale":"以往周销量","purchase_cycle":"采购周期","sale_cycle":"销售周期","presale_days":"预售天数","week":"前几周","sales":"销量","increase_ratio_1":"增长比率1","increase_ratio_2":"增长比率2","increase_ratio_3":"增长比率3","increase_ratio_4":"增长比率4","memo":"备注","use_history_ratio":"修改环比"},"action":{"ok":"重算","cancel":"取消"},"rules":{"date_range_error":"开始日期不能大于结束日期"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "26b0":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"title.purchaseStatus":"Purchase Status","title.saleStatus":"Sale Status","department":"Department","sub_depart":"Sub Department","buhuo_state":"Replenishment State","sale_state":"Sale State","saler":"Saler","warehouse_id":"Warehouse","action":{"create":"Create","save":"Save","delete":"Delete"}},"zh-cn":{"title.purchaseStatus":"补货状态","title.saleStatus":"销售状态","department":"部门","sub_depart":"子部门","buhuo_state":"补货状态","sale_state":"销售状态","saler":"运营","warehouse_id":"仓库","action":{"create":"新增","save":"保存","delete":"删除"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "3745":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"ae_commission_rate":"AE commission rate","after_refund_tax":"after_refund_tax","at_ae_lowest_price":"at_ae_lowest_price","at_mfn_shipment_fee":"at_mfn_shipment_fee","au_mfn_shipment_fee":"au_mfn_shipment_fee","be_ae_lowest_price":"be_ae_lowest_price","be_mfn_shipment_fee":"be_mfn_shipment_fee","cn_category":"cn_category","cn_sub_category":"cn_sub_category","compute_state":"compute_state","custom_fee":"custom_fee","custom_tax":"custom_tax","de_ae_lowest_price":"de_ae_lowest_price","de_b2c_lowest_price":"de_b2c_lowest_price","de_fba_fee":"de_fba_fee","de_fba_lowest_price":"de_fba_lowest_price","de_lowest_profit":"de_lowest_profit","de_mfn_lowest_price":"de_mfn_lowest_price","de_mfn_shipment_fee":"de_mfn_shipment_fee","de_prime_discount_price":"de_prime_discount_price","de_prime_fee":"DE Prime Fee","de_prime_normal_price":"de_prime_normal_price","discount_end":"discount_end","discount_percent":"discount_percent","discount_start":"discount_start","dollar_to_cn":"dollar_to_cn","ero_to_cn":"ero_to_cn","es_ae_lowest_price":"es_ae_lowest_price","es_b2c_lowest_price":"es_b2c_lowest_price","es_fba_fee":"es_fba_fee","es_fba_lowest_price":"es_fba_lowest_price","es_float_price":"es_float_price","es_mfn_lowest_price":"es_mfn_lowest_price","es_mfn_shipment_fee":"es_mfn_shipment_fee","float_platform":"float_platform","float_price":"float_price","fr_ae_lowest_price":"fr_ae_lowest_price","fr_b2c_lowest_price":"fr_b2c_lowest_price","fr_cd_fbc_fee":"FR CD FBC Fee","fr_cd_fbc_price":"fr_cd_fbc_price","fr_cd_mfn_price":"fr_cd_mfn_price","fr_fba_fee":"fr_fba_fee","fr_fba_lowest_price":"fr_fba_lowest_price","fr_float_price":"fr_float_price","fr_mfn_lowest_price":"fr_mfn_lowest_price","fr_mfn_shipment_fee":"fr_mfn_shipment_fee","gb_ae_lowest_price":"gb_ae_lowest_price","gb_b2c_lowest_price":"gb_b2c_lowest_price","gb_fba_fee":"gb_fba_fee","gb_fba_lowest_price":"gb_fba_lowest_price","gb_mfn_lowest_price":"gb_mfn_lowest_price","gb_mfn_shipment_fee":"gb_mfn_shipment_fee","gb_own_ae_lowest_price":"gb_own_ae_lowest_price","gb_own_fba_fee":"gb_own_fba_fee","gb_own_fba_lowest_price":"gb_own_fba_lowest_price","gb_own_lowest_price":"gb_own_lowest_price","girth":"girth","header_fee":"header_fee","id":"id","it_ae_lowest_price":"it_ae_lowest_price","it_b2c_lowest_price":"it_b2c_lowest_price","it_fba_fee":"it_fba_fee","it_fba_lowest_price":"it_fba_lowest_price","it_float_price":"it_float_price","it_mfn_lowest_price":"it_mfn_lowest_price","it_mfn_shipment_fee":"it_mfn_shipment_fee","latest_compute_time":"latest_compute_time","lu_ae_lowest_price":"lu_ae_lowest_price","lu_mfn_shipment_fee":"lu_mfn_shipment_fee","money_type":"money_type","nl_ae_lowest_price":"nl_ae_lowest_price","nl_b2c_lowest_price":"nl_b2c_lowest_price","nl_fba_fee":"nl_fba_fee","nl_fba_lowest_price":"nl_fba_lowest_price","nl_float_price":"nl_float_price","nl_mfn_lowest_price":"nl_mfn_lowest_price","nl_mfn_shipment_fee":"nl_mfn_shipment_fee","operator":"operator","other_fee":"other_fee","pack_num":"pack_num","pl_ae_lowest_price":"pl_ae_lowest_price","pl_fba_fee":"pl_fba_fee","pl_fba_lowest_price":"pl_fba_lowest_price","pl_float_price":"pl_float_price","pl_mfn_lowest_price":"pl_mfn_lowest_price","pl_mfn_shipment_fee":"pl_mfn_shipment_fee","refund_tax":"refund_tax","se_fba_fee":"se_fba_fee","se_fba_lowest_price":"se_fba_lowest_price","size1":"size1","size2":"size2","size3":"size3","package_size1":"package_size1","package_size2":"package_size2","package_size3":"package_size3","sku":"sku","uk_float_price":"uk_float_price","volume":"volume","purchase_price":"purchase_price","cost_price":"cost_price","change_reason":"Change Reason","warehouse":"Waerhouse","weight":"Weight","memo":"Memo","de_manomano_lowest_price":"de_manomano_lowest_price","fr_manomano_lowest_price":"fr_manomano_lowest_price","hs_lowest_price":"-hs-Lowest-Price","bhs_lowest_price":"-bhs-Lowest-Price","gb_own_shipment_fee":"GB own shipment fee"},"action":{"edit":"Edit","cancel":"Cancel","more":"More","action":"Action","add":"Add","export":"Export","save":"Save","pre_check":"Pre Check","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","please_choose":"Please Choose","sku":"SKU","check_type":"Check Type","memo":"Memo","check_date":"Check Date","approve_state":"Approve State","actions":"Action","view":"View"},"zh-cn":{"desc":"","columns":{"ae_commission_rate":"速卖通佣金率","after_refund_tax":"退后税","at_mfn_shipment_fee":"AT-MFN运费","au_mfn_shipment_fee":"AU-MFN运费","be_mfn_shipment_fee":"BE-MFN运费","cn_category":"中文分类","cn_sub_category":"中文子类","compute_state":"compute_state","custom_fee":"关税","custom_tax":"关税税率","de_fba_fee":"DE-FBA费用","de_lowest_profit":"DE-MFN最低毛利率","de_mfn_shipment_fee":"DE-MFN运费","de_prime_discount_price":"de_prime_discount_price","discount_end":"折扣结束时间","discount_percent":"折扣百分比","discount_start":"折扣开始时间","dollar_to_cn":"美金对人民币汇率","ero_to_cn":"欧元对人民币汇率","es_fba_fee":"ES-FBA费用","es_float_price":"ES站点浮动值","es_mfn_shipment_fee":"ES-MFN运费","float_platform":"平台","float_price":"DE站点浮动值","fr_cd_fbc_fee":"FR-CD-FBC费用","fr_cd_fbc_price":"FR-CD-FBC最低定价","fr_cd_mfn_price":"FR-CD-MFN最低定价","fr_fba_fee":"FR-FBA费用","fr_float_price":"FR站点浮动值","fr_mfn_shipment_fee":"FR-MFN运费","gb_fba_fee":"GB-FBA费用","gb_mfn_shipment_fee":"GB-MFN运费","gb_own_fba_fee":"英国仓发FBA费用","girth":"周长","header_fee":"头程","id":"id","it_fba_fee":"IT-FBA费用","it_float_price":"IT站点浮动值","it_mfn_shipment_fee":"IT-MFN运费","latest_compute_time":"latest_compute_time","lu_mfn_shipment_fee":"LU-MFN运费","money_type":"币种","nl_fba_fee":"NL-FBA费用","nl_float_price":"NL站点浮动值","nl_mfn_shipment_fee":"NL-MFN运费","operator":"运营","other_fee":"杂费","pack_num":"装箱率","pl_fba_fee":"PL-FBA费用","pl_float_price":"PL站点浮动值","pl_mfn_shipment_fee":"PL-MFN运费","refund_tax":"出口退税率","se_fba_fee":"SE-FBA费用","size1":"包装尺寸1","size2":"包装尺寸2","size3":"包装尺寸3","package_size1":"分摊尺寸1","package_size2":"分摊尺寸2","package_size3":"分摊尺寸3","sku":"sku","uk_float_price":"UK站点浮动值","volume":"体积","at_ae_lowest_price":"AT-速卖通最低定价","be_ae_lowest_price":"BE-速卖通最低定价","de_ae_lowest_price":"DE-速卖通最低定价","de_b2c_lowest_price":"DE-B2C最低定价","de_fba_lowest_price":"DE-FBA最低定价","de_mfn_lowest_price":"DE-MFN最低定价","de_prime_fee":"DE-Prime费用","de_prime_normal_price":"DE-Prime正常定价","es_ae_lowest_price":"ES-速卖通最低定价","es_b2c_lowest_price":"ES-B2C最低定价","es_fba_lowest_price":"ES-FBA最低定价","es_mfn_lowest_price":"ES-MFN最低定价","fr_ae_lowest_price":"FR-速卖通最低定价","fr_b2c_lowest_price":"FR-B2C最低定价","fr_fba_lowest_price":"FR-FBA最低定价","fr_mfn_lowest_price":"FR-最低定价","gb_ae_lowest_price":"GB-速卖通最低定价","gb_b2c_lowest_price":"GB-B2C最低定价","gb_own_ae_lowest_price":"GB英仓速卖通最低定价","gb_own_fba_lowest_price":"英国仓发FBA最低定价","gb_own_lowest_price":"GB-英仓最低定价","it_ae_lowest_price":"IT-速卖通最低定价","it_b2c_lowest_price":"IT-B2C最低定价","it_fba_lowest_price":"IT-FBA最低定价","it_mfn_lowest_price":"IT-MFN最低定价","lu_ae_lowest_price":"LU-速卖通最低定价","nl_b2c_lowest_price":"NL-B2C最低定价","nl_fba_lowest_price":"NL-FBA最低定价","nl_mfn_lowest_price":"NL-MFN最低定价","pl_fba_lowest_price":"PL-FBA最低定价","pl_mfn_lowest_price":"PL-MFN最低定价","se_fba_lowest_price":"SE-FBA最低定价","purchase_price":"采购价","cost_price":"成本价","change_reason":"浮动价格变动原因","warehouse":"仓库","weight":"重量","memo":"核价备注","de_manomano_lowest_price":"DE Manomano最低定价","fr_manomano_lowest_price":"FR Manomano最低定价","hs_lowest_price":"含税最低定价","bhs_lowest_price":"不含税最低定价","gb_own_shipment_fee":"GB英仓运费"},"action":{"edit":"编辑","cancel":"取消","more":"更多操作","action":"Action","add":"新增","export":"导出","save":"保存","pre_check":"预调价","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","please_choose":"请选择","sku":"产品SKU","check_type":"核价类型","memo":"备注","check_date":"核价时间","approve_state":"审核状况","actions":"操作","view":"查看"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "4562":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a742");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "497f":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"sub_category":"Sub Category","sub_category_attr":"Attributes","value":"Value"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","cancel":"Cancel","commit":"Commit"}},"zh-cn":{"desc":"","columns":{"sub_category":"子类","sub_category_attr":"属性","value":"值"},"action":{"create":"新建","edit":"编辑查询条件","delete":"删除","ok":"确定","cancel":"取消","commit":"提交"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "4bff":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"log":"Log","type":"Type","operater":"Operater","date":"Date"},"zh-cn":{"log":"日志","type":"类型","operater":"操作人","date":"日期"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "530a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-extra-attr-copy.vue?vue&type=template&id=cac3dc86&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component customer-detail"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 4 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":30}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.sub_category'),"required":""}},[_c('a-select',{staticStyle:{"width":"40%","float":"left","margin-top":"8px"},attrs:{"placeholder":"","size":"small","allowClear":""},on:{"change":function (e) { return _vm.onMainCateChange(e); }},model:{value:(_vm.cnCategory),callback:function ($$v) {_vm.cnCategory=$$v},expression:"cnCategory"}},_vm._l((_vm.cnCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1),_c('a-select',{staticStyle:{"width":"50%","margin-left":"5px"},attrs:{"placeholder":"","size":"small","allowClear":""},on:{"change":function (e) { return _vm.onRowChange(_vm.row, 'sub_category', e); }},model:{value:(_vm.selectedList),callback:function ($$v) {_vm.selectedList=$$v},expression:"selectedList"}},_vm._l((_vm.subCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)],1)],1),_c('a-transfer',{staticClass:"tree-transfer",attrs:{"data-source":_vm.tags,"target-keys":_vm.targetKeys,"show-select-all":false,"render":function (item) { return item.name; },"list-style":{
                width: '250px',
                height: '300px'
            }},on:{"change":_vm.onChange},scopedSlots:_vm._u([{key:"children",fn:function(ref){
                var ref_props = ref.props;
                var direction = ref_props.direction;
                var selectedKeys = ref_props.selectedKeys;
                var itemSelect = ref.on.itemSelect;
return [(direction === 'left')?_vm._l((_vm.tags),function(tag){return _c('a-tag',{key:tag.name,attrs:{"closable":tag.name !== '产品配置明细',"color":_vm.getColor(tag.checked)},on:{"close":function () { return _vm.leftHandleClose(tag.name); },"click":function($event){return _vm.onChecked(
                                tag,
                                selectedKeys.concat( _vm.targetKeys),
                                itemSelect
                            )}}},[_vm._v(" "+_vm._s(tag.name)+" ")])}):_vm._e(),(direction === 'right')?[_vm._l((_vm.targetKeys),function(tag){return _c('a-tag',{key:tag.name,attrs:{"closable":tag.name !== '产品配置明细'},on:{"close":function () { return _vm.rightHandleClose(tag); }}},[_vm._v(" "+_vm._s(tag.name)+" ")])}),(_vm.inputVisible)?_c('a-input',{ref:"input",style:({ width: '78px' }),attrs:{"type":"text","size":"small","value":_vm.inputValue},on:{"change":_vm.handleInputChange,"blur":_vm.handleInputConfirm,"keyup":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"enter",13,$event.key,"Enter")){ return null; }return _vm.handleInputConfirm.apply(null, arguments)}}}):_c('a-tag',{staticStyle:{"background":"#fff","borderStyle":"dashed"},on:{"click":_vm.showInput}},[_c('a-icon',{attrs:{"type":"plus"}}),_vm._v(" New Tag ")],1)]:_vm._e()]}}])})],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.commit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-extra-attr-copy.vue?vue&type=template&id=cac3dc86&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__("a434");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.concat.js
var es_array_concat = __webpack_require__("99af");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-extra-attr-copy.vue?vue&type=script&lang=ts&


















var product_extra_attr_copyvue_type_script_lang_ts_ProductExtraAttrCopy =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductExtraAttrCopy, _super);

  function ProductExtraAttrCopy() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.cnCates = [];
    _this.subCates = [];
    _this.cnCategory = '';
    _this.cnSubCategory = '';
    _this.selectedList = '';
    _this.originRow = '';
    _this.tags = [];
    _this.inputVisible = false;
    _this.inputValue = '';
    _this.sonCates = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadService = new loading_service["a" /* LoadingService */]();
    _this.index = 0; // 表格数据源

    _this.ruleData = [];
    _this.targetKeys = [];
    _this.dataSource = [];
    return _this;
  }

  ProductExtraAttrCopy.prototype.submit = function () {
    return true;
  };

  ProductExtraAttrCopy.prototype.cancel = function () {};

  ProductExtraAttrCopy.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.originRow);
  };

  ProductExtraAttrCopy.prototype.created = function () {
    this.getMainCates();
    this.form = this.$form.createForm(this);
  };

  ProductExtraAttrCopy.prototype.isChecked = function (selectedKeys, eventKey) {
    var flag = false;

    for (var _i = 0, selectedKeys_1 = selectedKeys; _i < selectedKeys_1.length; _i++) {
      var item = selectedKeys_1[_i];

      if (item.name == eventKey) {
        flag = true;
        break;
      }
    }

    return flag;
  };

  ProductExtraAttrCopy.prototype.getColor = function (checked) {
    if (checked) {
      return '#108ee9';
    } else {
      return '';
    }
  };

  ProductExtraAttrCopy.prototype.onChange = function (targetKeys) {
    this.targetKeys = targetKeys;

    for (var _i = 0, _a = this.targetKeys; _i < _a.length; _i++) {
      var item_2 = _a[_i];

      for (var i = 0; i < this.tags.length; i++) {
        if (item_2.key == this.tags[i].key) {
          this.tags.splice(i, 1);
          i = i - 1;
        }
      }
    }
  };

  ProductExtraAttrCopy.prototype.onChecked = function (tag, selectedKeys, itemSelect) {
    tag.checked = !this.isChecked(selectedKeys, tag.key);
    itemSelect(tag, !this.isChecked(selectedKeys, tag.key));
  };

  ProductExtraAttrCopy.prototype.onRightChecked = function (e, tag, selectedKeys, itemSelect) {
    tag.checked = !tag.checked;
  };

  ProductExtraAttrCopy.prototype.onRowChange = function (row, column, value) {
    var that = this;

    if (that.cnSubCategory !== '') {
      this.$confirm({
        title: '更换子类提示',
        content: '若切换子类则会丢失已有的改动，确认切换？',
        onOk: function onOk() {
          if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
            row[column] = value.target.value;
          } else {
            row[column] = value;
          }

          if (column === 'sub_category') {
            that.cnSubCategory = row[column];

            if (that.originRow.extra_attributes) {
              var tag_names = JSON.parse(that.originRow.extra_attributes.replace(/'/g, '"'));
              that.tags = [];

              for (var _i = 0, tag_names_1 = tag_names; _i < tag_names_1.length; _i++) {
                var item = tag_names_1[_i];
                that.tags.push({
                  checked: false,
                  name: item,
                  key: item,
                  title: item
                });
              }

              that.tags.splice(0, 0);
            }

            that.targetKeys = [];
          }
        },
        onCancel: function onCancel() {
          that.selectedList = that.cnSubCategory;
        }
      });
    } else {
      if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }

      if (column === 'sub_category') {
        that.cnSubCategory = row[column];
        that.targetKeys = [];
      }
    }
  };

  ProductExtraAttrCopy.prototype.mounted = function () {
    // for (var i = 0; i < this.subCates.length; i++) {
    //     if (this.tags[i].cn_sub_category == this.row.cn_sub_category) {
    //         this.subCates.splice(i, 1)
    //         break
    //     }
    // }
    var objString = JSON.stringify(this.row);
    this.originRow = JSON.parse(objString); // this.selectedList = this.originRow.cn_sub_category
    // this.originRow.cn_sub_category = ''
    // if (this.saveFlag == 0) {
    //     delete this.originRow.id
    //     if (this.originRow.extra_attributes) {
    //         this.selectedList = ''
    //     }
    // }

    if (this.originRow.extra_attributes) {
      var tag_names = JSON.parse(this.originRow.extra_attributes.replace(/'/g, '"'));

      for (var _i = 0, tag_names_2 = tag_names; _i < tag_names_2.length; _i++) {
        var item = tag_names_2[_i];
        this.tags.push({
          checked: false,
          name: item,
          key: item,
          title: item
        });
      }

      this.tags.splice(0, 0);
    }

    this.setFormValues();
  };

  ProductExtraAttrCopy.prototype.addRule = function () {
    var ruleParam = {
      query_name: '',
      operate: '=',
      value: '',
      index: uuid_default.a.generate()
    };
    this.ruleData.push(ruleParam);
  };

  ProductExtraAttrCopy.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['extra_attributes'] = [];

        for (var _i = 0, _a = _this.targetKeys; _i < _a.length; _i++) {
          var item = _a[_i];
          values['extra_attributes'].push(item.name);
        }

        values['cn_category'] = _this.cnCategory;
        values['cn_sub_category'] = _this.selectedList;

        _this.saveInfo(values);
      }
    });
  };

  ProductExtraAttrCopy.prototype.saveInfo = function (params) {
    var _this = this;

    params.extra_attributes = JSON.stringify(params.extra_attributes).replace(/"/g, "'");
    this.innerAction.setActionAPI('category/save_category_extra_attributes', common_service["a" /* CommonService */].getMenuCode('product-category-manage'));
    this.publicService.modify(new http["RequestParams"](params, {
      loading: this.loadService,
      innerAction: this.innerAction
    })).subscribe(function (data2) {
      _this.submit();
    });
  };

  ProductExtraAttrCopy.prototype.handleClose = function (removedTag) {
    var tags = this.tags.filter(function (tag) {
      return tag !== removedTag;
    });
    this.tags = tags;
  };

  ProductExtraAttrCopy.prototype.rightHandleClose = function (removedTag) {
    var tags = this.targetKeys.filter(function (tag) {
      return tag.key !== removedTag.key;
    });
    this.targetKeys = tags;
    removedTag.checked = false;
    var flag = true;

    for (var _i = 0, _a = this.tags; _i < _a.length; _i++) {
      var item = _a[_i];

      if (item.key == removedTag.key) {
        flag = false;
        break;
      }
    }

    if (flag) {
      this.tags.push(removedTag);
    }
  };

  ProductExtraAttrCopy.prototype.leftHandleClose = function (removedTag) {
    var tags = this.tags.filter(function (tag) {
      return tag.key !== removedTag;
    });
    this.tags = tags;
  };

  ProductExtraAttrCopy.prototype.showInput = function () {
    this.inputVisible = true;
    this.$nextTick(function () {
      var ipt = this.$refs.input;
      ipt.focus();
    });
  };

  ProductExtraAttrCopy.prototype.handleInputChange = function (e) {
    this.inputValue = e.target.value;
  };

  ProductExtraAttrCopy.prototype.handleInputConfirm = function () {
    var inputValue = this.inputValue;
    var targetKeys = this.targetKeys;
    var tags_list = [];

    for (var _i = 0, targetKeys_1 = targetKeys; _i < targetKeys_1.length; _i++) {
      var item = targetKeys_1[_i];
      tags_list.push(item.key);
    }

    if (inputValue && tags_list.indexOf(inputValue) === -1) {
      targetKeys = targetKeys.concat([{
        title: inputValue,
        key: inputValue,
        checked: false,
        name: inputValue
      }]);
    } else {
      this.$message.warning('添加的属性已存在！');
    }

    Object.assign(this, {
      targetKeys: targetKeys,
      inputVisible: false,
      inputValue: ''
    });
  };

  ProductExtraAttrCopy.prototype.getMainCates = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_category_for_dropdownlist', common_service["a" /* CommonService */].getMenuCode('product-category-manage'));
    this.publicService.query(new http["RequestParams"]({
      cn_main_category: 'all',
      cn_category: ''
    }, {
      loading: this.loadService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.cnCates = data.cn_category;
    });
  };

  ProductExtraAttrCopy.prototype.getSubCates = function (main) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_category_for_dropdownlist', common_service["a" /* CommonService */].getMenuCode('product-category-manage'));
    this.publicService.query(new http["RequestParams"]({
      cn_main_category: '',
      cn_category: main
    }, {
      loading: this.loadService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.subCates = data.cn_sub_category;
    });
  };

  ProductExtraAttrCopy.prototype.onMainCateChange = function (e) {
    this.cnCategory = e;
    this.getSubCates(e);
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductExtraAttrCopy.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductExtraAttrCopy.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductExtraAttrCopy.prototype, "row", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductExtraAttrCopy.prototype, "saveFlag", void 0);

  ProductExtraAttrCopy = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductExtraAttrCopy);
  return ProductExtraAttrCopy;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_extra_attr_copyvue_type_script_lang_ts_ = (product_extra_attr_copyvue_type_script_lang_ts_ProductExtraAttrCopy);
// CONCATENATED MODULE: ./src/components/product/product-extra-attr-copy.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_extra_attr_copyvue_type_script_lang_ts_ = (product_extra_attr_copyvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-extra-attr-copy.vue?vue&type=custom&index=0&blockType=i18n
var product_extra_attr_copyvue_type_custom_index_0_blockType_i18n = __webpack_require__("1432");

// CONCATENATED MODULE: ./src/components/product/product-extra-attr-copy.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_extra_attr_copyvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_extra_attr_copyvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_extra_attr_copyvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_extra_attr_copy = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "56f0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_inout_record_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b6d7");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_inout_record_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_inout_record_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_inout_record_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "5dca":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f127");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_extra_attr_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "62b8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-edit-detail.vue?vue&type=template&id=56357fa6&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 8 },"wrapperCol":{ span: 15, offset: 1 }}},[_c('a-card',[_c('div',{staticStyle:{"margin-top":"10px","font-weight":"600","color":"#222"}},[_vm._v(" 基础信息 ")]),_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":"SKU"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sku']),expression:"['sku']"}],attrs:{"size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":"product_tmpl_id"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_tmpl_id']),expression:"['product_tmpl_id']"}],attrs:{"size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.operator')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator']),expression:"['operator']"}],attrs:{"size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.z_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_category']),expression:"['cn_category']"}],staticStyle:{"width":"120px"},attrs:{"size":"small","disabled":""},on:{"change":_vm.handleFatherCateChange}},_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_sub_category']),expression:"['cn_sub_category']"}],staticStyle:{"width":"200px"},attrs:{"size":"small","disabled":""}},_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.weight')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['weight']),expression:"['weight']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.size1')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['size1']),expression:"['size1']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.size2')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['size2']),expression:"['size2']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.size3')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['size3']),expression:"['size3']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.package_size1')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['package_size1']),expression:"['package_size1']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.package_size2')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['package_size2']),expression:"['package_size2']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.package_size3')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['package_size3']),expression:"['package_size3']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.pack_num')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pack_num']),expression:"['pack_num']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.girth')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['girth']),expression:"['girth']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.volume')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['volume']),expression:"['volume']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1)],1)],1),_c('a-card',{staticStyle:{"margin-top":"5px"}},[_c('div',{staticStyle:{"margin-top":"10px","font-weight":"600","color":"#222"}},[_vm._v(" 采购信息 ")]),_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.purchase_price'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'purchase_price',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'purchase_price',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.money_type')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['money_type']),expression:"['money_type']"}],staticStyle:{"width":"120px"},attrs:{"size":"small","disabled":!_vm.editAble}},[_c('a-select-option',{key:"人民币",attrs:{"value":"人民币"}},[_vm._v(" 人民币 ")]),_c('a-select-option',{key:"欧元",attrs:{"value":"欧元"}},[_vm._v(" 欧元 ")]),_c('a-select-option',{key:"美金",attrs:{"value":"美金"}},[_vm._v(" 美金 ")])],1)],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.refund_tax')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['refund_tax']),expression:"['refund_tax']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.ero_to_cn')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ero_to_cn']),expression:"['ero_to_cn']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.dollar_to_cn')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dollar_to_cn']),expression:"['dollar_to_cn']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.custom_tax')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['custom_tax']),expression:"['custom_tax']"}],attrs:{"min":0,"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.cost_price')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cost_price']),expression:"['cost_price']"}],attrs:{"min":0,"size":"small","disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.memo'),"required":""}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'memo',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'memo',\n                                { rules: rules.required }\n                            ]"}],attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1)],1)],1)],1),_c('a-card',{staticStyle:{"margin-top":"5px"}},[_c('a-tabs',{attrs:{"defaultActiveKey":"shipment"},on:{"change":function (e) { return _vm.onPanelChange(e); }}},[_c('a-tab-pane',{key:"shipment",attrs:{"tab":"运费"}},[_c('div',{staticStyle:{"margin-top":"10px","font-weight":"600","color":"#222"}},[_vm._v(" MFN运费 ")]),_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form2,"labelCol":{ span: 8 },"wrapperCol":{ span: 15, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.de_lowest_profit')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['de_lowest_profit']),expression:"['de_lowest_profit']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.de_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['de_mfn_shipment_fee']),expression:"['de_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.gb_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['gb_mfn_shipment_fee']),expression:"['gb_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.fr_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fr_mfn_shipment_fee']),expression:"['fr_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.it_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['it_mfn_shipment_fee']),expression:"['it_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.gb_own_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['gb_own_shipment_fee']),expression:"['gb_own_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.es_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['es_mfn_shipment_fee']),expression:"['es_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.nl_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['nl_mfn_shipment_fee']),expression:"['nl_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.pl_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pl_mfn_shipment_fee']),expression:"['pl_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.at_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['at_mfn_shipment_fee']),expression:"['at_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.be_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['be_mfn_shipment_fee']),expression:"['be_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.lu_mfn_shipment_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['lu_mfn_shipment_fee']),expression:"['lu_mfn_shipment_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1)],1),_c('div',{staticStyle:{"margin-top":"10px","font-weight":"600","color":"#222"}},[_vm._v(" FBA运费 ")]),_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.de_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['de_fba_fee']),expression:"['de_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.fr_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fr_fba_fee']),expression:"['fr_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.gb_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['gb_fba_fee']),expression:"['gb_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.gb_own_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['gb_own_fba_fee']),expression:"['gb_own_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.it_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['it_fba_fee']),expression:"['it_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.es_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['es_fba_fee']),expression:"['es_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.nl_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['nl_fba_fee']),expression:"['nl_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.se_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['se_fba_fee']),expression:"['se_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.pl_fba_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pl_fba_fee']),expression:"['pl_fba_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.de_prime_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['de_prime_fee']),expression:"['de_prime_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.fr_cd_fbc_fee')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fr_cd_fbc_fee']),expression:"['fr_cd_fbc_fee']"}],attrs:{"size":"small","min":0,"disabled":""}})],1)],1)],1)],1)],1),_c('a-tab-pane',{key:"lowest",attrs:{"tab":"最低定价"}},[_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 基础信息 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed","width":"700px"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"after_refund_tax",attrs:{"title":_vm.$t('columns.after_refund_tax'),"data-index":"after_refund_tax","align":"center","width":"100px"}}),_c('a-table-column',{key:"header_fee",attrs:{"title":_vm.$t('columns.header_fee'),"data-index":"header_fee","align":"center","width":"100px"}}),_c('a-table-column',{key:"other_fee",attrs:{"title":_vm.$t('columns.other_fee'),"data-index":"other_fee","align":"center","width":"100px"}}),_c('a-table-column',{key:"custom_tax",attrs:{"title":_vm.$t('columns.custom_fee'),"data-index":"custom_fee","align":"center","width":"100px"}}),_c('a-table-column',{key:"custom_tax",attrs:{"title":_vm.$t('columns.ae_commission_rate'),"data-index":"ae_commission_rate","align":"center","width":"160px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" MFN最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed","max-width":"1100px"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_mfn_lowest_price",attrs:{"title":_vm.$t('columns.de_mfn_lowest_price'),"data-index":"de_mfn_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_own_lowest_price",attrs:{"title":_vm.$t('columns.gb_own_lowest_price'),"data-index":"gb_own_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_mfn_lowest_price",attrs:{"title":_vm.$t('columns.fr_mfn_lowest_price'),"data-index":"fr_mfn_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_mfn_lowest_price",attrs:{"title":_vm.$t('columns.it_mfn_lowest_price'),"data-index":"it_mfn_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_mfn_lowest_price",attrs:{"title":_vm.$t('columns.es_mfn_lowest_price'),"data-index":"es_mfn_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"nl_mfn_lowest_price",attrs:{"title":_vm.$t('columns.nl_mfn_lowest_price'),"data-index":"nl_mfn_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"pl_mfn_lowest_price",attrs:{"title":_vm.$t('columns.pl_mfn_lowest_price'),"data-index":"pl_mfn_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" FBA最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_fba_lowest_price",attrs:{"title":_vm.$t('columns.de_fba_lowest_price'),"data-index":"de_fba_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_fba_lowest_price",attrs:{"title":_vm.$t('columns.fr_fba_lowest_price'),"data-index":"fr_fba_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_own_fba_lowest_price",attrs:{"title":_vm.$t('columns.gb_own_fba_lowest_price'),"data-index":"gb_own_fba_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_fba_lowest_price",attrs:{"title":_vm.$t('columns.it_fba_lowest_price'),"data-index":"it_fba_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_fba_lowest_price",attrs:{"title":_vm.$t('columns.es_fba_lowest_price'),"data-index":"es_fba_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"nl_fba_lowest_price",attrs:{"title":_vm.$t('columns.nl_fba_lowest_price'),"data-index":"nl_fba_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"se_fba_lowest_price",attrs:{"title":_vm.$t('columns.se_fba_lowest_price'),"data-index":"se_fba_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"pl_fba_lowest_price",attrs:{"title":_vm.$t('columns.pl_fba_lowest_price'),"data-index":"pl_fba_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" B2C最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed","max-width":"900px"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_b2c_lowest_price",attrs:{"title":_vm.$t('columns.de_b2c_lowest_price'),"data-index":"de_b2c_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_b2c_lowest_price",attrs:{"title":_vm.$t('columns.fr_b2c_lowest_price'),"data-index":"fr_b2c_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_b2c_lowest_price",attrs:{"title":_vm.$t('columns.gb_b2c_lowest_price'),"data-index":"gb_b2c_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_b2c_lowest_price",attrs:{"title":_vm.$t('columns.it_b2c_lowest_price'),"data-index":"it_b2c_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_b2c_lowest_price",attrs:{"title":_vm.$t('columns.es_b2c_lowest_price'),"data-index":"es_b2c_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"nl_b2c_lowest_price",attrs:{"title":_vm.$t('columns.nl_b2c_lowest_price'),"data-index":"nl_b2c_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 速卖通最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_ae_lowest_price",attrs:{"title":_vm.$t('columns.de_ae_lowest_price'),"data-index":"de_ae_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_ae_lowest_price",attrs:{"title":_vm.$t('columns.fr_ae_lowest_price'),"data-index":"fr_ae_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_own_ae_lowest_price",attrs:{"title":_vm.$t('columns.gb_own_ae_lowest_price'),"data-index":"gb_own_ae_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_ae_lowest_price",attrs:{"title":_vm.$t('columns.it_ae_lowest_price'),"data-index":"it_ae_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_ae_lowest_price",attrs:{"title":_vm.$t('columns.es_ae_lowest_price'),"data-index":"es_ae_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"at_ae_lowest_price",attrs:{"title":_vm.$t('columns.at_ae_lowest_price'),"data-index":"at_ae_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"be_ae_lowest_price",attrs:{"title":_vm.$t('columns.be_ae_lowest_price'),"data-index":"be_ae_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"lu_ae_lowest_price",attrs:{"title":_vm.$t('columns.lu_ae_lowest_price'),"data-index":"lu_ae_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" Prime最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed","width":"300px"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_prime_normal_price",attrs:{"title":_vm.$t('columns.de_prime_normal_price'),"data-index":"de_prime_normal_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"de_prime_discount_price",attrs:{"title":_vm.$t('columns.de_prime_fee'),"data-index":"de_prime_discount_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" CD最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed","width":"300px"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"fr_cd_mfn_price",attrs:{"title":_vm.$t('columns.fr_cd_mfn_price'),"data-index":"fr_cd_mfn_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_cd_fbc_price",attrs:{"title":_vm.$t('columns.fr_cd_fbc_price'),"data-index":"fr_cd_fbc_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 速卖通不含税最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_ae_untax_lowest_price",attrs:{"title":'DE-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"de_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_ae_untax_lowest_price",attrs:{"title":'FR-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"fr_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_ae_untax_lowest_price",attrs:{"title":'GB英仓-速卖通' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"gb_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_ae_untax_lowest_price",attrs:{"title":'IT-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"it_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_ae_untax_lowest_price",attrs:{"title":'ES-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"es_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"at_ae_untax_lowest_price",attrs:{"title":'AT-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"at_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"be_ae_untax_lowest_price",attrs:{"title":'BE-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"be_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"lu_ae_untax_lowest_price",attrs:{"title":'LU-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"lu_ae_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"pl_ae_untax_lowest_price",attrs:{"title":'PL-速卖通' + _vm.$t('columns.bhs_lowest_price'),"data-index":"pl_ae_untax_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" Wish Express不含税最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_we_untax_lowest_price",attrs:{"title":'DE-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"de_we_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_we_untax_lowest_price",attrs:{"title":'FR-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"fr_we_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_we_untax_lowest_price",attrs:{"title":'GB英仓-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"gb_we_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_we_untax_lowest_price",attrs:{"title":'IT-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"it_we_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_we_untax_lowest_price",attrs:{"title":'ES-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"es_we_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"at_we_untax_lowest_price",attrs:{"title":'AT-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"at_we_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"nl_we_untax_lowest_price",attrs:{"title":'NL-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"nl_we_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"pl_we_untax_lowest_price",attrs:{"title":'PL-WishExpress' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"pl_we_untax_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" Wish Express含税最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_we_lowest_price",attrs:{"title":'DE-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"de_we_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_we_lowest_price",attrs:{"title":'FR-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"fr_we_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_we_lowest_price",attrs:{"title":'GB英仓-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"gb_we_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_we_lowest_price",attrs:{"title":'IT-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"it_we_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_we_lowest_price",attrs:{"title":'ES-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"es_we_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"at_we_lowest_price",attrs:{"title":'AT-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"at_we_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"nl_we_lowest_price",attrs:{"title":'NL-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"nl_we_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"pl_we_lowest_price",attrs:{"title":'PL-WishExpress' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"pl_we_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" Wish Standard不含税最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_ws_untax_lowest_price",attrs:{"title":'DE-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"de_ws_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_ws_untax_lowest_price",attrs:{"title":'FR-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"fr_ws_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_ws_untax_lowest_price",attrs:{"title":'GB英仓-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"gb_ws_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_ws_untax_lowest_price",attrs:{"title":'IT-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"it_ws_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_ws_untax_lowest_price",attrs:{"title":'ES-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"es_ws_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"at_ws_untax_lowest_price",attrs:{"title":'AT-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"at_ws_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"nl_ws_untax_lowest_price",attrs:{"title":'NL-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"nl_ws_untax_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"pl_ws_untax_lowest_price",attrs:{"title":'PL-WishStandard' +
                                    _vm.$t('columns.bhs_lowest_price'),"data-index":"pl_ws_untax_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" Wish Standard含税最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_ws_lowest_price",attrs:{"title":'DE-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"de_ws_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_ws_lowest_price",attrs:{"title":'FR-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"fr_ws_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"gb_ws_lowest_price",attrs:{"title":'GB英仓-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"gb_ws_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"it_ws_lowest_price",attrs:{"title":'IT-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"it_ws_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"es_ws_lowest_price",attrs:{"title":'ES-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"es_ws_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"at_ws_lowest_price",attrs:{"title":'AT-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"at_ws_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"nl_ws_lowest_price",attrs:{"title":'NL-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"nl_ws_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"pl_ws_lowest_price",attrs:{"title":'PL-WishStandard' +
                                    _vm.$t('columns.hs_lowest_price'),"data-index":"pl_ws_lowest_price","align":"center","width":"100px"}})],1)],1),_c('div',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" Manomano最低定价 ")]),_c('a-table',{staticStyle:{"table-layout":"fixed","width":"300px"},attrs:{"dataSource":[_vm.order],"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"de_mano_lowest_price",attrs:{"title":_vm.$t('columns.de_manomano_lowest_price'),"data-index":"de_mano_lowest_price","align":"center","width":"100px"}}),_c('a-table-column',{key:"fr_mano_lowest_price",attrs:{"title":_vm.$t('columns.fr_manomano_lowest_price'),"data-index":"fr_mano_lowest_price","align":"center","width":"100px"}})],1)],1)]),_c('a-tab-pane',{key:"discount",attrs:{"tab":"折扣"}},[_c('ProductPriceCheckDiscountForm',{ref:"discountForm",attrs:{"info":this.order,"edit":_vm.editAble,"showBtn":!_vm.history}})],1),(!_vm.history)?_c('a-tab-pane',{key:"float",attrs:{"tab":"浮动"}},[_c('SetPreProductFloatPrice',{attrs:{"row":_vm.order,"edit":_vm.editAble}})],1):_vm._e(),_c('a-tab-pane',{key:"log",attrs:{"tab":"日志"}},[_c('LogView',{attrs:{"object_name":"product_price_log","record_code":_vm.order.id,"is_special_table":true}})],1)],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-price-check-edit-detail.vue?vue&type=template&id=56357fa6&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.to-fixed.js
var es_number_to_fixed = __webpack_require__("b680");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/generate_code.service.ts
var generate_code_service = __webpack_require__("57db");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/components/product/set-pre-product-float-price.vue + 4 modules
var set_pre_product_float_price = __webpack_require__("3955");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-discount-form.vue?vue&type=template&id=990bb484&
var product_price_check_discount_formvue_type_template_id_990bb484_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.discount_price')}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_price']),expression:"['discount_price']"}],attrs:{"size":"small","min":0,"disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.discount_percent')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_percent']),expression:"['discount_percent']"}],attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.discount_warehouse')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_warehouse']),expression:"['discount_warehouse']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Please select","disabled":!_vm.editAble}},[_c('a-select-option',{key:"all",attrs:{"value":"all"}},[_vm._v(" ALL ")]),_vm._l((_vm.$dict.WarehouseId),function(version){return _c('a-select-option',{key:version.value,attrs:{"value":version.value}},[_vm._v(" "+_vm._s(_vm.$t(version.label))+" ")])})],2)],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.discount_start')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_start']),expression:"['discount_start']"}],attrs:{"format":"YYYY-MM-DD","size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.discount_end')}},[_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_end']),expression:"['discount_end']"}],attrs:{"format":"YYYY-MM-DD","size":"small","disabled":!_vm.editAble}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.discount_change_reason')}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(['discount_change_reason']),expression:"['discount_change_reason']"}],attrs:{"size":"small","disabled":!_vm.editAble}})],1)],1)],1)],1),(_vm.showBtn)?_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v("取消")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("提交")])],1):_vm._e()],1)}
var product_price_check_discount_formvue_type_template_id_990bb484_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-price-check-discount-form.vue?vue&type=template&id=990bb484&

// EXTERNAL MODULE: ./src/services/user.service.ts
var user_service = __webpack_require__("2138");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-discount-form.vue?vue&type=script&lang=ts&









var product_price_check_discount_formvue_type_script_lang_ts_ProductPriceCheckDiscountForm =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPriceCheckDiscountForm, _super);

  function ProductPriceCheckDiscountForm() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.editAble = false;
    _this.userService = new user_service["a" /* UserService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  ProductPriceCheckDiscountForm.prototype.submit = function (values) {
    return values;
  };

  ProductPriceCheckDiscountForm.prototype.cancel = function () {};

  ProductPriceCheckDiscountForm.prototype.onEditChange = function () {
    this.editAble = this.edit;
  };

  ProductPriceCheckDiscountForm.prototype.mounted = function () {
    this.editAble = this.edit;
    this.setFormValues();
  };

  ProductPriceCheckDiscountForm.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ProductPriceCheckDiscountForm.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.info);
  };

  ProductPriceCheckDiscountForm.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['id'] = _this.info.id;

        _this.innerAction.setActionAPI('product_management/update_product_discount_price', common_service["a" /* CommonService */].getMenuCode('product_price_check'));

        _this.publicService.modify(new http["RequestParams"](values, {
          loading: _this.loadingService,
          innerAction: _this.innerAction
        })).subscribe(function (data) {
          _this.$message.success('修改成功');
        }, function (err) {
          _this.$message.error(err.message);
        });
      }
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckDiscountForm.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckDiscountForm.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: false
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckDiscountForm.prototype, "edit", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: true
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckDiscountForm.prototype, "showBtn", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckDiscountForm.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('edit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckDiscountForm.prototype, "onEditChange", null);

  ProductPriceCheckDiscountForm = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductPriceCheckDiscountForm);
  return ProductPriceCheckDiscountForm;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_price_check_discount_formvue_type_script_lang_ts_ = (product_price_check_discount_formvue_type_script_lang_ts_ProductPriceCheckDiscountForm);
// CONCATENATED MODULE: ./src/components/product/product-price-check-discount-form.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_price_check_discount_formvue_type_script_lang_ts_ = (product_price_check_discount_formvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-price-check-discount-form.vue?vue&type=custom&index=0&blockType=i18n
var product_price_check_discount_formvue_type_custom_index_0_blockType_i18n = __webpack_require__("f3f3");

// CONCATENATED MODULE: ./src/components/product/product-price-check-discount-form.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_price_check_discount_formvue_type_script_lang_ts_,
  product_price_check_discount_formvue_type_template_id_990bb484_render,
  product_price_check_discount_formvue_type_template_id_990bb484_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_price_check_discount_formvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_price_check_discount_formvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_price_check_discount_form = (component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-edit-detail.vue?vue&type=script&lang=ts&











var product_price_check_edit_detailvue_type_script_lang_ts_ProductPriceCheckEditDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPriceCheckEditDetail, _super);

  function ProductPriceCheckEditDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.order = [];
    _this.originData = [];
    _this.save_flag = 1;
    _this.editAble = false;
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalCodeService = new generate_code_service["a" /* GeneralCodeService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    _this.activePanel = '';
    return _this;
  }

  ProductPriceCheckEditDetail.prototype.submit = function () {
    return true;
  };

  ProductPriceCheckEditDetail.prototype.cancel = function () {
    return;
  };

  ProductPriceCheckEditDetail.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckEditDetail.prototype.onEditChange = function () {
    this.editAble = this.edit;
  };

  ProductPriceCheckEditDetail.prototype.updateOrder = function (order) {
    var _this = this;

    order.volume = order.volume ? parseFloat(order.volume.toFixed(2)) : '';
    this.originData = order;
    this.form.setFieldsValue(order);
    this.form2.setFieldsValue(order);
    this.$nextTick(function () {
      _this.order = order;
      _this.save_flag = 1;
      _this.editAble = false;
    });
  };

  ProductPriceCheckEditDetail.prototype.created = function () {
    this.getCn_cate();
    this.form = this.$form.createForm(this);
    this.form2 = this.$form.createForm(this);
  };

  ProductPriceCheckEditDetail.prototype.mounted = function () {
    this.editAble = this.edit;

    if (this.info.length) {
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckEditDetail.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProductPriceCheckEditDetail.prototype.getFormData = function () {
    var values = this.form.getFieldsValue();
    this.form.validateFields({}, function (err, values) {
      if (!err) {//
      }
    });
    return values;
  };

  ProductPriceCheckEditDetail.prototype.saveInfo = function (data) {
    var _this = this;

    this.generalCodeService.createProductGenerateCode(new http["RequestParams"](data, {
      loading: this.loadingService
    })).subscribe(function () {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEditDetail.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  ProductPriceCheckEditDetail.prototype.onPanelChange = function (e) {
    this.activePanel = e;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckEditDetail.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckEditDetail.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckEditDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: false
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckEditDetail.prototype, "edit", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: false
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckEditDetail.prototype, "history", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckEditDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('edit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckEditDetail.prototype, "onEditChange", null);

  ProductPriceCheckEditDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */],
      SetPreProductFloatPrice: set_pre_product_float_price["a" /* default */],
      ProductPriceCheckDiscountForm: product_price_check_discount_form
    }
  })], ProductPriceCheckEditDetail);
  return ProductPriceCheckEditDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_price_check_edit_detailvue_type_script_lang_ts_ = (product_price_check_edit_detailvue_type_script_lang_ts_ProductPriceCheckEditDetail);
// CONCATENATED MODULE: ./src/components/product/product-price-check-edit-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_price_check_edit_detailvue_type_script_lang_ts_ = (product_price_check_edit_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/product-price-check-edit-detail.vue?vue&type=style&index=0&lang=css&
var product_price_check_edit_detailvue_type_style_index_0_lang_css_ = __webpack_require__("b265");

// EXTERNAL MODULE: ./src/components/product/product-price-check-edit-detail.vue?vue&type=custom&index=0&blockType=i18n
var product_price_check_edit_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("eef0");

// CONCATENATED MODULE: ./src/components/product/product-price-check-edit-detail.vue






/* normalize component */

var product_price_check_edit_detail_component = Object(componentNormalizer["a" /* default */])(
  product_product_price_check_edit_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_price_check_edit_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_price_check_edit_detailvue_type_custom_index_0_blockType_i18n["default"])(product_price_check_edit_detail_component)

/* harmony default export */ var product_price_check_edit_detail = __webpack_exports__["a"] = (product_price_check_edit_detail_component.exports);

/***/ }),

/***/ "693d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-history-edit.vue?vue&type=template&id=38382e65&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('ProductPriceCheckEditDetail',{ref:"fromDetail",attrs:{"info":_vm.order,"history":true}})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-price-check-history-edit.vue?vue&type=template&id=38382e65&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/generate_code.service.ts
var generate_code_service = __webpack_require__("57db");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/components/product/product-price-check-edit-detail.vue + 9 modules
var product_price_check_edit_detail = __webpack_require__("62b8");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-history-edit.vue?vue&type=script&lang=ts&









var product_price_check_history_editvue_type_script_lang_ts_ProductPriceCheckHistoryEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPriceCheckHistoryEdit, _super);

  function ProductPriceCheckHistoryEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.order = [];
    _this.originData = [];
    _this.historyList = [];
    _this.editAble = false;
    _this.activeKey = 'base';
    _this.save_flag = 1;
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalCodeService = new generate_code_service["a" /* GeneralCodeService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  ProductPriceCheckHistoryEdit.prototype.submit = function () {
    return true;
  };

  ProductPriceCheckHistoryEdit.prototype.cancel = function () {
    return;
  };

  ProductPriceCheckHistoryEdit.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckHistoryEdit.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.save_flag = 1;
      _this.editAble = false;
    });
  };

  ProductPriceCheckHistoryEdit.prototype.created = function () {
    this.getCn_cate();
    this.form = this.$form.createForm(this);
  };

  ProductPriceCheckHistoryEdit.prototype.mounted = function () {
    if (this.info.length) {
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckHistoryEdit.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProductPriceCheckHistoryEdit.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckHistoryEdit.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckHistoryEdit.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckHistoryEdit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckHistoryEdit.prototype, "onInfoChange", null);

  ProductPriceCheckHistoryEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */],
      ProductPriceCheckEditDetail: product_price_check_edit_detail["a" /* default */]
    }
  })], ProductPriceCheckHistoryEdit);
  return ProductPriceCheckHistoryEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_price_check_history_editvue_type_script_lang_ts_ = (product_price_check_history_editvue_type_script_lang_ts_ProductPriceCheckHistoryEdit);
// CONCATENATED MODULE: ./src/components/product/product-price-check-history-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_price_check_history_editvue_type_script_lang_ts_ = (product_price_check_history_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-price-check-history-edit.vue?vue&type=custom&index=0&blockType=i18n
var product_price_check_history_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("af45");

// CONCATENATED MODULE: ./src/components/product/product-price-check-history-edit.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_price_check_history_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_price_check_history_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_price_check_history_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_price_check_history_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "6f4d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_view_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7973");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_view_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_view_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_view_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "70aa":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-depart-info.vue?vue&type=template&id=3683bc52&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-product-detail"},[_c('a-card',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 1. "+_vm._s(_vm.$t('title.purchaseStatus'))+" ")]),(_vm.editAble)?_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.onCreate}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary"},on:{"click":_vm.onSave}},[_vm._v(_vm._s(_vm.$t('action.save')))]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"default","size":"small"},on:{"click":_vm.onDelete}},[_vm._v(_vm._s(_vm.$t('action.delete'))+" ")])],1):_vm._e(),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.purchaseData,"pagination":false,"rowKey":"index","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
            },"customRow":function (rowKey) { return ({
                    on: {
                        click: function () {
                            _vm.currentRow = rowKey.index
                        }
                    }
                }); },"bordered":""}},[_c('a-table-column',{key:"dept_id",attrs:{"title":_vm.$t('department'),"align":"left","width":"20%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editAble)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dept_id']),expression:"['dept_id']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"value":row.dept_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'dept_id', e); }}},_vm._l((_vm.topDepartmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm.getDepartName(row.dept_id))+" ")])]}}])}),_c('a-table-column',{key:"sub_depart",attrs:{"title":_vm.$t('sub_depart'),"align":"left","width":"20%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editAble)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['child_dept_id']),expression:"['child_dept_id']"}],style:({ width: '100%' }),attrs:{"value":row.child_dept_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'child_dept_id', e); }}},_vm._l((_vm.subDepartList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm.getSubDepartName(row.child_dept_id))+" ")])]}}])}),_c('a-table-column',{key:"purchase_status",attrs:{"title":_vm.$t('buhuo_state'),"align":"center","width":"15%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editAble)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['purchase_status']),expression:"['purchase_status']"}],style:({ width: '100%' }),attrs:{"value":row.purchase_status,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'purchase_status', e); }}},_vm._l((_vm.$dict.SkuReplenishState),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.purchase_status,'SkuReplenishState')))+" ")])]}}])}),_c('a-table-column',{key:"sale_list",attrs:{"title":_vm.$t('saler'),"align":"left","width":"30%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editAble)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_list']),expression:"['sale_list']"}],staticClass:"required",style:({ width: '100%' }),attrs:{"mode":"multiple","value":row.sale_list,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small","showSearch":"","filterOption":_vm.filterSelectOption},on:{"change":function (e) { return _vm.onRowChange(row, 'sale_list', e); }}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm.getSalerName(row.sale_list))+" ")])]}}])})],1)],1),_c('a-card',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 2. "+_vm._s(_vm.$t('title.saleStatus'))+" ")]),(_vm.editAble)?_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.onCreateSaleStatus}},[_vm._v(_vm._s(_vm.$t('action.create'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary"},on:{"click":_vm.onSaveSaleStatus}},[_vm._v(_vm._s(_vm.$t('action.save')))])],1):_vm._e(),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.prodStatusList,"pagination":false,"rowKey":"index","rowSelection":{
                selected2RowKeys: _vm.selected2RowKeys,
                onChange: function (keys) { return (_vm.selected2RowKeys = keys); }
            },"customRow":function (rowKey) { return ({
                    on: {
                        click: function () {
                            _vm.currentRow = rowKey.index
                        }
                    }
                }); },"bordered":""}},[_c('a-table-column',{key:"warehouse_id",attrs:{"title":_vm.$t('warehouse_id'),"align":"center","width":"30px"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                            _vm.currentRow == row.index &&
                                _vm.editAble &&
                                row.id == undefined &&
                                1 == 2
                        )?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_id']),expression:"['warehouse_id']"}],staticClass:"required",attrs:{"value":row.warehouse_id,"dropdown-match-select-width":false,"dropdown-style":{ width: '30px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'warehouse_id', e); }}},_vm._l((_vm.$dict.WarehouseId),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.warehouse_id,'WarehouseId')))+" ")])]}}])}),_c('a-table-column',{key:"sale_status",attrs:{"title":_vm.$t('sale_state'),"align":"center","width":"100px"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editAble)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_status']),expression:"['sale_status']"}],staticClass:"required",attrs:{"value":row.sale_status,"dropdown-match-select-width":false,"dropdown-style":{ width: '100px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'sale_status', e); }}},_vm._l((_vm.$dict.CheckProdStatus),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.sale_status,'CheckProdStatus')))+" ")])]}}])})],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-depart-info.vue?vue&type=template&id=3683bc52&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__("a15b");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-depart-info.vue?vue&type=script&lang=ts&


















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_depart_infovue_type_script_lang_ts_ProductDepartInfo =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductDepartInfo, _super);

  function ProductDepartInfo() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.topDepartmentList = [];
    _this.purchaseData = [];
    _this.prodStatusList = [];
    _this.currentRow = '';
    _this.selectedRowKeys = [];
    _this.selected2RowKeys = [];
    _this.subDepartList = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    return _this;
  }

  ProductDepartInfo.prototype.created = function () {
    this.getProductStatus();
    this.topDepartmentList = this.departmentList.filter(function (x) {
      return x.dept_type == 30;
    });
    this.getSubDepartmentList();
  };

  ProductDepartInfo.prototype.getProductStatus = function () {
    var _this = this;

    this.innerAction.setActionAPI('product/query_one_product_department_rel', common_service["a" /* CommonService */].getMenuCode('product-manage'));
    this.publicService.query(new http["RequestParams"]({
      prod_tmpl_id: parseInt(this.id)
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      if (data.length) {
        _this.purchaseData = data[0].purchase_status || [];
        _this.prodStatusList = data[0].sale_status || [];
      }

      _this.purchaseData = _this.purchaseData.map(function (x) {
        x.dept_id = x.dept_id[0];
        x.save_flag = 1;
        x.index = uuid_default.a.generate();
        return x;
      });
      _this.prodStatusList = _this.prodStatusList.map(function (x) {
        x.index = uuid_default.a.generate();
        return x;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductDepartInfo.prototype.onCreate = function () {
    this.purchaseData.push({
      index: uuid_default.a.generate(),
      dept_id: '',
      child_dept_id: '',
      purchase_status: 10,
      sale_status: 10,
      save_flag: 0,
      sale_list: []
    });
  };

  ProductDepartInfo.prototype.onCreateSaleStatus = function () {
    var item = this.prodStatusList.find(function (y) {
      return y.warehouse_id == 'de';
    });

    if (!item) {
      this.prodStatusList.push({
        index: uuid_default.a.generate(),
        warehouse_id: 'de',
        sale_status: 10
      });
    }

    item = this.prodStatusList.find(function (y) {
      return y.warehouse_id == 'uk';
    });

    if (!item) {
      this.prodStatusList.push({
        index: uuid_default.a.generate(),
        warehouse_id: 'uk',
        sale_status: 10
      });
    }

    item = this.prodStatusList.find(function (y) {
      return y.warehouse_id == 'us';
    });

    if (!item) {
      this.prodStatusList.push({
        index: uuid_default.a.generate(),
        warehouse_id: 'us',
        sale_status: 10
      });
    }
  };

  ProductDepartInfo.prototype.onSave = function () {
    var _this = this;

    var params = [];

    if (this.purchaseData.length == 0) {
      this.$message.error('the list has too few elements,min length is 1');
      return;
    }

    for (var i in this.purchaseData) {
      if (!this.purchaseData[i].dept_id) {
        this.$message.error('Department is required(部门为必填项)');
        return;
      }

      if (this.purchaseData[i].sale_list.length == 0) {
        this.$message.error('Operator is required(运营人员为必填项)');
        return;
      }

      var pm = {
        id: this.purchaseData[i].id ? this.purchaseData[i].id : 0,
        dept_id: this.purchaseData[i].dept_id,
        purchase_status: this.purchaseData[i].purchase_status,
        sale_status: this.purchaseData[i].sale_status,
        sale_list: this.purchaseData[i].sale_list.length ? this.purchaseData[i].sale_list : [],
        save_flag: this.purchaseData[i].save_flag,
        prod_tmpl_id: parseInt(this.id)
      };

      if (this.purchaseData[i].child_dept_id) {
        pm['child_dept_id'] = this.purchaseData[i].child_dept_id;
      }

      params.push(pm);
    }

    this.innerAction.setActionAPI('product/save_product_department_rel', common_service["a" /* CommonService */].getMenuCode('product-manage'));
    this.publicService.modify(new http["RequestParams"]({
      prod_tmpl_id: parseInt(this.id),
      prod_dept_list: params
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var _loop_1 = function _loop_1(i) {
        var item = _this.purchaseData.find(function (x) {
          return x.dept_id == i;
        });

        if (item) {
          item.id = data.message[i];
          item.save_flag = 1;
        }
      };

      for (var i in data.message) {
        _loop_1(i);
      }

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductDepartInfo.prototype.onSaveSaleStatus = function () {
    var _this = this;

    var params = [];

    for (var i in this.prodStatusList) {
      if (!this.prodStatusList[i].warehouse_id) {
        this.$message.error('Warehouse is required(仓库为必填项)');
        return;
      }

      if (this.prodStatusList[i].sale_status == 0) {
        this.$message.error('Product status is required(产品状态为必填项)');
        return;
      }

      var pm = {
        id: this.prodStatusList[i].id,
        warehouse_id: this.prodStatusList[i].warehouse_id,
        sale_status: this.prodStatusList[i].sale_status
      };
      params.push(pm);
    }

    this.innerAction.setActionAPI('product/save_product_warehouse_status_rel', common_service["a" /* CommonService */].getMenuCode('product-manage'));
    this.publicService.modify(new http["RequestParams"]({
      prod_tmpl_id: parseInt(this.id),
      prod_status_list: params
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var _loop_2 = function _loop_2(i) {
        var item = _this.prodStatusList.find(function (x) {
          return x.warehouse_id == i;
        });

        if (item) {
          item.id = data.message[i];
        }
      };

      for (var i in data.message) {
        _loop_2(i);
      }

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductDepartInfo.prototype.onDeleteSaleStatus = function () {
    var _this = this;

    if (this.selected2RowKeys.length == 0) {
      this.$message.error('Please select the data to be deleted first');
      return;
    }

    var ids = [];

    var _loop_3 = function _loop_3(i) {
      var item = this_1.prodStatusList.find(function (y) {
        return y.index == i;
      });

      if (item.id !== undefined && item.id) {
        ids.push(item.id);
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selected2RowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      _loop_3(i);
    }

    if (ids.length == 0) {
      var msg = this.$t('tips.delete_success');
      this.$message.success(msg);
      this.prodStatusList = this.prodStatusList.filter(function (x) {
        return !_this.selected2RowKeys.includes(x.index);
      });
      return;
    }

    this.innerAction.setActionAPI('product/delete_product_warehouse_status_rel', common_service["a" /* CommonService */].getMenuCode('product-manage'));
    this.publicService.modify(new http["RequestParams"]({
      delete_list: ids
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.prodStatusList = _this.prodStatusList.filter(function (x) {
        return !_this.selected2RowKeys.includes(x.index);
      });
      _this.selected2RowKeys = [];

      var msg = _this.$t('tips.delete_success');

      _this.$message.success(msg);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductDepartInfo.prototype.onDelete = function () {
    var _this = this;

    if (this.selectedRowKeys.length == 0) {
      this.$message.error('Please select the data to be deleted first');
      return;
    }

    var ids = [];

    var _loop_4 = function _loop_4(i) {
      var item = this_2.purchaseData.find(function (y) {
        return y.index == i;
      });

      if (item.id !== undefined && item.id) {
        ids.push(item.id);
      }
    };

    var this_2 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      _loop_4(i);
    }

    if (ids.length == 0) {
      var msg = this.$t('tips.delete_success');
      this.$message.success(msg);
      this.purchaseData = this.purchaseData.filter(function (x) {
        return !_this.selectedRowKeys.includes(x.index);
      });
      return;
    }

    this.innerAction.setActionAPI('product/delete_product_department_rel', common_service["a" /* CommonService */].getMenuCode('product-manage'));
    this.publicService.modify(new http["RequestParams"]({
      delete_list: ids
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this.$t('tips.delete_success');

      _this.$message.success(msg);

      _this.purchaseData = _this.purchaseData.filter(function (x) {
        return !_this.selectedRowKeys.includes(x.index);
      });
      _this.selectedRowKeys = [];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductDepartInfo.prototype.getDepartName = function (department) {
    var ret = department;
    var item = this.departmentList.find(function (x) {
      return x.id == department;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  ProductDepartInfo.prototype.getSubDepartName = function (department) {
    var ret = department;
    var item = this.subDepartList.find(function (x) {
      return x.id == department;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  ProductDepartInfo.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target && value.target.value) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }
  };

  ProductDepartInfo.prototype.getSalerName = function (saler) {
    var ret = [];

    var _loop_5 = function _loop_5(i) {
      var item = this_3.systemUsers.find(function (x) {
        return x.code == saler[i];
      });

      if (item) {
        ret.push(item.name);
      }
    };

    var this_3 = this;

    for (var i in saler) {
      _loop_5(i);
    }

    if (ret.length) {
      return ret.join(',');
    } else {
      return '';
    }
  };

  ProductDepartInfo.prototype.getSubDepartmentList = function () {
    this.subDepartList = this.departmentList.filter(function (x) {
      return x.dept_type == 100;
    });
  };

  ProductDepartInfo.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDepartInfo.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: false
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDepartInfo.prototype, "editAble", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDepartInfo.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDepartInfo.prototype, "systemUsers", void 0);

  ProductDepartInfo = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductDepartInfo);
  return ProductDepartInfo;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_depart_infovue_type_script_lang_ts_ = (product_depart_infovue_type_script_lang_ts_ProductDepartInfo);
// CONCATENATED MODULE: ./src/components/product/product-depart-info.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_depart_infovue_type_script_lang_ts_ = (product_depart_infovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/product-depart-info.vue?vue&type=style&index=0&lang=css&
var product_depart_infovue_type_style_index_0_lang_css_ = __webpack_require__("cbc9");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-depart-info.vue?vue&type=custom&index=0&blockType=i18n
var product_depart_infovue_type_custom_index_0_blockType_i18n = __webpack_require__("864b");

// CONCATENATED MODULE: ./src/components/product/product-depart-info.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_depart_infovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_depart_infovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_depart_infovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_depart_info = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "752f":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"ae_commission_rate":"ae_commission_rate","after_refund_tax":"after_refund_tax","at_ae_lowest_price":"at_ae_lowest_price","at_mfn_shipment_fee":"at_mfn_shipment_fee","au_mfn_shipment_fee":"au_mfn_shipment_fee","be_ae_lowest_price":"be_ae_lowest_price","be_mfn_shipment_fee":"be_mfn_shipment_fee","cn_category":"cn_category","cn_sub_category":"cn_sub_category","compute_state":"compute_state","custom_fee":"custom_fee","custom_tax":"custom_tax","de_ae_lowest_price":"de_ae_lowest_price","de_b2c_lowest_price":"de_b2c_lowest_price","de_fba_fee":"de_fba_fee","de_fba_lowest_price":"de_fba_lowest_price","de_lowest_profit":"de_lowest_profit","de_mfn_lowest_price":"de_mfn_lowest_price","de_mfn_shipment_fee":"de_mfn_shipment_fee","de_prime_discount_price":"de_prime_discount_price","de_prime_fee":"de_prime_fee","de_prime_normal_price":"de_prime_normal_price","discount_end":"discount_end","discount_percent":"discount_percent","discount_start":"discount_start","dollar_to_cn":"dollar_to_cn","ero_to_cn":"ero_to_cn","es_ae_lowest_price":"es_ae_lowest_price","es_b2c_lowest_price":"es_b2c_lowest_price","es_fba_fee":"es_fba_fee","es_fba_lowest_price":"es_fba_lowest_price","es_float_price":"es_float_price","es_mfn_lowest_price":"es_mfn_lowest_price","es_mfn_shipment_fee":"es_mfn_shipment_fee","float_platform":"float_platform","float_price":"float_price","fr_ae_lowest_price":"fr_ae_lowest_price","fr_b2c_lowest_price":"fr_b2c_lowest_price","fr_cd_fbc_fee":"fr_cd_fbc_fee","fr_cd_fbc_price":"fr_cd_fbc_price","fr_cd_mfn_price":"fr_cd_mfn_price","fr_fba_fee":"fr_fba_fee","fr_fba_lowest_price":"fr_fba_lowest_price","fr_float_price":"fr_float_price","fr_mfn_lowest_price":"fr_mfn_lowest_price","fr_mfn_shipment_fee":"fr_mfn_shipment_fee","gb_ae_lowest_price":"gb_ae_lowest_price","gb_b2c_lowest_price":"gb_b2c_lowest_price","gb_fba_fee":"gb_fba_fee","gb_fba_lowest_price":"gb_fba_lowest_price","gb_mfn_lowest_price":"gb_mfn_lowest_price","gb_mfn_shipment_fee":"gb_mfn_shipment_fee","gb_own_ae_lowest_price":"gb_own_ae_lowest_price","gb_own_fba_fee":"gb_own_fba_fee","gb_own_fba_lowest_price":"gb_own_fba_lowest_price","gb_own_lowest_price":"gb_own_lowest_price","girth":"girth","header_fee":"header_fee","id":"id","it_ae_lowest_price":"it_ae_lowest_price","it_b2c_lowest_price":"it_b2c_lowest_price","it_fba_fee":"it_fba_fee","it_fba_lowest_price":"it_fba_lowest_price","it_float_price":"it_float_price","it_mfn_lowest_price":"it_mfn_lowest_price","it_mfn_shipment_fee":"it_mfn_shipment_fee","latest_compute_time":"latest_compute_time","lu_ae_lowest_price":"lu_ae_lowest_price","lu_mfn_shipment_fee":"lu_mfn_shipment_fee","money_type":"money_type","nl_ae_lowest_price":"nl_ae_lowest_price","nl_b2c_lowest_price":"nl_b2c_lowest_price","nl_fba_fee":"nl_fba_fee","nl_fba_lowest_price":"nl_fba_lowest_price","nl_float_price":"nl_float_price","nl_mfn_lowest_price":"nl_mfn_lowest_price","nl_mfn_shipment_fee":"nl_mfn_shipment_fee","operator":"operator","other_fee":"other_fee","pack_num":"pack_num","pl_ae_lowest_price":"pl_ae_lowest_price","pl_fba_fee":"pl_fba_fee","pl_fba_lowest_price":"pl_fba_lowest_price","pl_float_price":"pl_float_price","pl_mfn_lowest_price":"pl_mfn_lowest_price","pl_mfn_shipment_fee":"pl_mfn_shipment_fee","refund_tax":"refund_tax","se_fba_fee":"se_fba_fee","se_fba_lowest_price":"se_fba_lowest_price","size1":"size1","size2":"size2","size3":"size3","sku":"sku","uk_float_price":"uk_float_price","volume":"volume"},"action":{"edit":"Edit","cancel":"Cancel","more":"More","action":"Action","add":"Add","export":"Export","save":"Save","pre_check":"Pre Check","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","please_choose":"Please Choose","sku":"SKU","check_type":"Check Type","memo":"Memo","check_date":"Check Date","approve_state":"Approve State","actions":"Action","view":"View","page_name":"ProdPriceCheckHistory"},"zh-cn":{"desc":"","columns":{"ae_commission_rate":"ae_commission_rate","after_refund_tax":"退后税","at_mfn_shipment_fee":"AT-MFN运费","au_mfn_shipment_fee":"AU-MFN运费","be_mfn_shipment_fee":"BE-MFN运费","cn_category":"中文分类","cn_sub_category":"中文子类","compute_state":"compute_state","custom_fee":"custom_fee","custom_tax":"custom_tax","de_fba_fee":"DE-FBA费用","de_lowest_profit":"DE-MFN最低毛利率","de_mfn_shipment_fee":"DE-MFN运费","de_prime_discount_price":"de_prime_discount_price","discount_end":"折扣结束时间","discount_percent":"折扣百分比","discount_start":"折扣开始时间","dollar_to_cn":"美金对人民币汇率","ero_to_cn":"欧元对人民币汇率","es_fba_fee":"ES-FBA费用","es_float_price":"ES站点浮动值","es_mfn_shipment_fee":"ES-MFN运费","float_platform":"平台","float_price":"float_price","fr_cd_fbc_fee":"fr_cd_fbc_fee","fr_cd_fbc_price":"FR-CD-FBC最低定价","fr_cd_mfn_price":"FR-CD-MFN最低定价","fr_fba_fee":"FR-FBA费用","fr_float_price":"FR站点浮动值","fr_mfn_shipment_fee":"FR-MFN运费","gb_fba_fee":"GB-FBA费用","gb_mfn_shipment_fee":"GB-MFN运费","gb_own_fba_fee":"英国仓发FBA费用","girth":"周长","header_fee":"头程","id":"id","it_fba_fee":"IT-FBA费用","it_float_price":"IT站点浮动值","it_mfn_shipment_fee":"IT-MFN运费","latest_compute_time":"latest_compute_time","lu_mfn_shipment_fee":"LU-MFN运费","money_type":"币种","nl_fba_fee":"NL-FBA费用","nl_float_price":"NL站点浮动值","nl_mfn_shipment_fee":"NL-MFN运费","operator":"运营","other_fee":"杂费","pack_num":"pack_num","pl_fba_fee":"PL-FBA费用","pl_float_price":"PL站点浮动值","pl_mfn_shipment_fee":"PL-MFN运费","refund_tax":"refund_tax","se_fba_fee":"SE-FBA费用","size1":"包装尺寸1","size2":"包装尺寸2","size3":"包装尺寸3","sku":"sku","uk_float_price":"uk_float_price","volume":"体积","at_ae_lowest_price":"AT-速卖通最低定价","be_ae_lowest_price":"BE-速卖通最低定价","de_ae_lowest_price":"DE-速卖通最低定价","de_b2c_lowest_price":"DE-B2C最低定价","de_fba_lowest_price":"DE-FBA最低定价","de_mfn_lowest_price":"DE-MFN最低定价","de_prime_fee":"DE-Prime折扣定价","de_prime_normal_price":"DE-Prime正常定价","es_ae_lowest_price":"ES-速卖通最低定价","es_b2c_lowest_price":"ES-B2C最低定价","es_fba_lowest_price":"ES-FBA最低定价","es_mfn_lowest_price":"ES-MFN最低定价","fr_ae_lowest_price":"FR-速卖通最低定价","fr_b2c_lowest_price":"FR-B2C最低定价","fr_fba_lowest_price":"FR-FBA最低定价","fr_mfn_lowest_price":"FR-最低定价","gb_ae_lowest_price":"GB-速卖通最低定价","gb_b2c_lowest_price":"GB-B2C最低定价","gb_own_ae_lowest_price":"GB英仓速卖通最低定价","gb_own_fba_lowest_price":"英国仓发FBA最低定价","gb_own_lowest_price":"GB-英仓最低定价","it_ae_lowest_price":"IT-速卖通最低定价","it_b2c_lowest_price":"IT-B2C最低定价","it_fba_lowest_price":"IT-FBA最低定价","it_mfn_lowest_price":"IT-MFN最低定价","lu_ae_lowest_price":"LU-速卖通最低定价","nl_b2c_lowest_price":"NL-B2C最低定价","nl_fba_lowest_price":"NL-FBA最低定价","nl_mfn_lowest_price":"NL-MFN最低定价","pl_fba_lowest_price":"PL-FBA最低定价","pl_mfn_lowest_price":"PL-MFN最低定价","se_fba_lowest_price":"SE-FBA最低定价"},"action":{"edit":"编辑","cancel":"取消","more":"更多操作","action":"Action","add":"新增","export":"导出","save":"保存","pre_check":"预调价","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","please_choose":"请选择","sku":"产品SKU","check_type":"核价类型","memo":"备注","check_date":"核价时间","approve_state":"审核状况","actions":"操作","view":"查看","page_name":"历史核价"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "7567":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"purchase_status":"purchase_status","include_presale_order":"Include Presale Order","calculate_date":"Calculate Date","warehouse_id":"Warehouse Id","week_sales":"Week Sales","week_0_sales":"Current Week","week_avg_sales":"Week Avg Sales","cp_qty_ratio":"CP Quantity Ratio","cp_order_ratio":"CP Order Ratio","pre_week_sales":"pre_week_sales","is_presale":"is_presale","is_second_presale":"is_second_presale","presale_ratio":"presale_ratio","presale_days":"presale_days","purchase_cycle":"purchase_cycle","predict_detail":"predict_detail","need_detail":"需求详情","all_is_presale":"all_is_presale","is_uk_purchase":"is_uk_purchase","alarm_qty":"alarm_qty","de_available_qty":"de_available_qty","operator_detail":"operator_detail","category_detail":"category_detail","month_1_transit_qty":"month_1_transit_qty","month_2_transit_qty":"month_2_transit_qty","month_1_unship_qty":"month_1_unship_qty","month_2_unship_qty":"month_2_unship_qty","month_3_unship_qty":"month_3_unship_qty","transit_qty":"transit_qty","increase_ratio":"increase_ratio","unship_qty":"unship_qty","increase_ratio_text":"increase_ratio_text","z_sub_category":"sub category","purchase_sku":"Purchase SKU","exists_exception":"Exception","vendor_name":"Vendor","min_qty":"Min Order QTY"},"action":{"create":"Create","purchase_apply":"Purchase Apply","export":"Export Excel","edit":"Edit","delete":"Delete","ok":"Ok","cancel":"Cancel","verify":"Verify","confirm":"Confirm","confirm_refuse":"Confirm Refuse","return":"Return","refuse":"Refuse","confirm_return_sales_manager":"Confirm Return","active":"Active","to_draft":"To Draft"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","edit-memo":"Edit Memo","yes":"Yes","no":"No"},"zh-cn":{"desc":"","columns":{"purchase_status":"补货状态","include_presale_order":"含预售单","calculate_date":"统计日期","warehouse_id":"仓库","week_sales":"销量","week_0_sales":"当周销量","week_avg_sales":"周均销量","cp_qty_ratio":"数量投诉率","cp_order_ratio":"订单投诉率","pre_week_sales":"预测","is_presale":"第一期预售","is_second_presale":"第二期预售","presale_ratio":"预售系数","presale_days":"预售天数","purchase_cycle":"采购周期/周","sale_cycle":"销售周期/周","predict_detail":"预测详情","need_date":"需求时间","all_is_presale":"预售","is_uk_purchase":"uk仓单独补货","alarm_qty":"警戒库存","de_available_qty":"库存详情","operator_detail":"运营详情","category_detail":"分类详情","month_1_transit_qty":"在途一","month_2_transit_qty":"在途二","month_1_unship_qty":"在厂一","month_2_unship_qty":"在厂二","month_3_unship_qty":"在厂三","transit_qty":"在途","increase_ratio":"环比","unship_qty":"在厂","increase_ratio_text":"增长率环比","z_sub_category":"中文子类","purchase_sku":"补货SKU","exists_exception":"异常","vendor_name":"供应商","min_qty":"起订量"},"action":{"create":"新建","purchase_apply":"生成采购单","export":"导出Excel","edit":"重算","delete":"删除","ok":"确定","cancel":"取消","verify":"审核","confirm":"确认","confirm_refuse":"确认拒绝","return":"退回","refuse":"拒绝","confirm_return_sales_manager":"确认退回","active":"激活","to_draft":"重置为草稿"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","edit-memo":"填写备注","yes":"是","no":"否"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "76da":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-cate-edit.vue?vue&type=template&id=601efb1b&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 7 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{staticStyle:{"position":"relative"},attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.cn_main_category'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'cn_main_category',
                            {
                                initialValue: _vm.row.cn_main_category
                            }
                        ]),expression:"[\n                            'cn_main_category',\n                            {\n                                initialValue: row.cn_main_category\n                            }\n                        ]"}],attrs:{"placeholder":"","size":"small","allowClear":"","disabled":!!_vm.saveFlag},on:{"change":function (e) { return _vm.onMainCateChange(e); }}},_vm._l((_vm.mainCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1),(!_vm.saveFlag)?_c('a',{on:{"click":function($event){return _vm.addCnMainCategory()}}},[_c('a-icon',{staticStyle:{"position":"absolute","top":"13px","right":"-5px","color":"#1890ff"},attrs:{"type":"plus-circle"}})],1):_vm._e()],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.sub_category_profit'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'sub_category_profit',
                            {
                                initialValue: _vm.row.sub_category_profit
                            },
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'sub_category_profit',\n                            {\n                                initialValue: row.sub_category_profit\n                            },\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{staticStyle:{"position":"relative"},attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.cn_category'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'cn_category',
                            {
                                initialValue: _vm.row.cn_category
                            }
                        ]),expression:"[\n                            'cn_category',\n                            {\n                                initialValue: row.cn_category\n                            }\n                        ]"}],attrs:{"placeholder":"","size":"small","allowClear":"","disabled":!!this.saveFlag},on:{"change":function (e) { return _vm.onCnCateChange(e); }}},_vm._l((_vm.cnCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1),(!_vm.saveFlag)?_c('a',{on:{"click":function($event){return _vm.addCnCategory()}}},[_c('a-icon',{staticStyle:{"position":"absolute","top":"13px","right":"-5px","color":"#1890ff"},attrs:{"type":"plus-circle"}})],1):_vm._e()],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.purchase_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'purchase_user',
                            {
                                initialValue: _vm.row.purchase_user
                            }
                        ]),expression:"[\n                            'purchase_user',\n                            {\n                                initialValue: row.purchase_user\n                            }\n                        ]"}],attrs:{"size":"small","placeholder":"Please select"}},_vm._l((_vm.purchase_list),function(item){return _c('a-select-option',{key:item.name,attrs:{"value":item.name}},[_vm._v(" "+_vm._s(_vm.$t(item.name))+" ")])}),1)],1)],1),_c('a-col',{staticStyle:{"position":"relative"},attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.cn_sub_category'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'cn_sub_category',
                            {
                                initialValue: _vm.row.cn_sub_category
                            },
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'cn_sub_category',\n                            {\n                                initialValue: row.cn_sub_category\n                            },\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","disabled":!!this.saveFlag}})],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.purchase_follower')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'purchase_follower',
                            {
                                initialValue: _vm.row.purchase_follower
                            }
                        ]),expression:"[\n                            'purchase_follower',\n                            {\n                                initialValue: row.purchase_follower\n                            }\n                        ]"}],attrs:{"size":"small","placeholder":"Please select"}},_vm._l((_vm.purchase_list),function(item){return _c('a-select-option',{key:item.name,attrs:{"value":item.name}},[_vm._v(" "+_vm._s(_vm.$t(item.name))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.de_category'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'de_category',
                            {
                                initialValue: _vm.row.de_category
                            },
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'de_category',\n                            {\n                                initialValue: row.de_category\n                            },\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"disabled":!!this.saveFlag,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.requirement_period')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'requirement_period',
                            {
                                initialValue: _vm.row.requirement_period
                            }
                        ]),expression:"[\n                            'requirement_period',\n                            {\n                                initialValue: row.requirement_period\n                            }\n                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.de_sub_category')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'de_sub_category',
                            {
                                initialValue: _vm.row.de_sub_category
                            }
                        ]),expression:"[\n                            'de_sub_category',\n                            {\n                                initialValue: row.de_sub_category\n                            }\n                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.purchase_period')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'purchase_period',
                            {
                                initialValue: _vm.row.purchase_period
                            }
                        ]),expression:"[\n                            'purchase_period',\n                            {\n                                initialValue: row.purchase_period\n                            }\n                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.department'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'department',
                            {
                                initialValue: _vm.row.department
                            },
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'department',\n                            {\n                                initialValue: row.department\n                            },\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","placeholder":"Please select"},on:{"change":function (e) { return _vm.onDeptChange(e); }}},_vm._l((_vm.sale_dept_list),function(item){return _c('a-select-option',{key:item.name,attrs:{"value":item.name}},[_vm._v(" "+_vm._s(_vm.$t(item.name))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.develop_team')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'develop_team',
                            {
                                initialValue: _vm.row.develop_team
                            }
                        ]),expression:"[\n                            'develop_team',\n                            {\n                                initialValue: row.develop_team\n                            }\n                        ]"}],attrs:{"size":"small","placeholder":"Please select"}},_vm._l((_vm.develop_team_list),function(item){return _c('a-select-option',{key:item.name,attrs:{"value":item.name}},[_vm._v(" "+_vm._s(_vm.$t(item.name))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.department_manager')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'department_manager',
                            {
                                initialValue: _vm.row.department_manager
                            }
                        ]),expression:"[\n                            'department_manager',\n                            {\n                                initialValue: row.department_manager\n                            }\n                        ]"}],attrs:{"size":"small","placeholder":"Please select"}},_vm._l((_vm.sale_dept_leader_list),function(item){return _c('a-select-option',{key:item,attrs:{"value":item}},[_vm._v(" "+_vm._s(_vm.$t(item))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.develop_month')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'develop_month',
                            {
                                initialValue: _vm.row.develop_month
                            }
                        ]),expression:"[\n                            'develop_month',\n                            {\n                                initialValue: row.develop_month\n                            }\n                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.operator'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'operator',
                            {
                                initialValue: _vm.row.operator
                            },
                            {
                                rules: _vm.rules.required
                            }
                        ]),expression:"[\n                            'operator',\n                            {\n                                initialValue: row.operator\n                            },\n                            {\n                                rules: rules.required\n                            }\n                        ]"}],attrs:{"size":"small","placeholder":"Please select"}},_vm._l((_vm.operator_list),function(item){return _c('a-select-option',{key:item,attrs:{"value":item}},[_vm._v(" "+_vm._s(_vm.$t(item))+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":11}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['status', { initialValue: 20 }]),expression:"['status', { initialValue: 20 }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('action.open'))+" ")]),_c('a-radio-button',{attrs:{"value":200}},[_vm._v(" "+_vm._s(_vm.$t('action.close'))+" ")])],1)],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-cate-edit.vue?vue&type=template&id=601efb1b&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/product/add-cn-main-category.vue + 4 modules
var add_cn_main_category = __webpack_require__("d2c1");

// EXTERNAL MODULE: ./src/components/product/add-cn-category.vue + 4 modules
var add_cn_category = __webpack_require__("6449");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-cate-edit.vue?vue&type=script&lang=ts&














var product_cate_editvue_type_script_lang_ts_ProductCateEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductCateEdit, _super);

  function ProductCateEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.sonCates = [];
    _this.mainCates = [];
    _this.cnCates = [];
    _this.cnSubCates = [];
    _this.sale_dept_leader_list = [];
    _this.operator_list = [];
    _this.mainCategory = '';
    _this.cnCategory = '';
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  ProductCateEdit.prototype.submit = function () {
    return true;
  };

  ProductCateEdit.prototype.cancel = function () {
    return;
  };

  ProductCateEdit.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.row);
  };

  ProductCateEdit.prototype.created = function () {
    this.getCnMainCates();

    if (this.row) {
      this.mainCategory = this.row.cn_main_category;
      this.cnCategory = this.row.cn_category;
      this.getCnCates(this.mainCategory);
    }

    this.form = this.$form.createForm(this);
  };

  ProductCateEdit.prototype.mounted = function () {
    this.setFormValues();
  };

  ProductCateEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['save_flag'] = _this.saveFlag;
        values['id'] = 0;

        if (_this.saveFlag) {
          values['id'] = _this.row.id;
        }

        _this.saveInfo(values);
      }
    });
  };

  ProductCateEdit.prototype.saveInfo = function (data) {
    var _this = this;

    this.innerAction.setActionAPI('category/save_product_category', common_service["a" /* CommonService */].getMenuCode('product-category-manage'));
    this.publicService.modify(new http["RequestParams"](data, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductCateEdit.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductCateEdit.prototype.addCnCategory = function () {
    var _this = this;

    if (this.mainCategory == '') {
      this.$message.error('请先选择一级分类');
      return;
    }

    this.$modal.open(add_cn_category["a" /* default */], {
      cn_main_category: this.mainCategory,
      cn_category: '',
      mainCates: this.mainCates
    }, {
      width: '660px',
      title: this.$t('action.add_cn_category')
    }).subscribe(function (data) {
      var values = _this.form.getFieldsValue();

      values['cn_main_category'] = data.cn_main_category;
      values['cn_category'] = data.cn_category;
      values['de_category'] = data.de_category;

      _this.form.setFieldsValue(values);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductCateEdit.prototype.addCnMainCategory = function () {
    var _this = this;

    this.$modal.open(add_cn_main_category["a" /* default */], {
      cn_main_category: ''
    }, {
      title: this.$t('action.add_cn_main_category')
    }).subscribe(function (data) {
      _this.mainCates.push(data.cn_main_category);

      _this.mainCategory = data.cn_main_category;

      var values = _this.form.getFieldsValue();

      values['cn_main_category'] = data.cn_main_category;

      _this.form.setFieldsValue(values);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductCateEdit.prototype.getCnMainCates = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_category_for_dropdownlist', common_service["a" /* CommonService */].getMenuCode('product-category-manage'));
    this.publicService.query(new http["RequestParams"]({
      cn_main_category: '',
      cn_category: ''
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.mainCates = data.cn_main_category;
    });
  };

  ProductCateEdit.prototype.getCnCates = function (main) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_category_for_dropdownlist', common_service["a" /* CommonService */].getMenuCode('product-category-manage'));
    this.publicService.query(new http["RequestParams"]({
      cn_main_category: main,
      cn_category: ''
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.cnCates = data.cn_category;
    });
  };

  ProductCateEdit.prototype.onMainCateChange = function (e) {
    this.mainCategory = e;
    this.getCnCates(e);
  };

  ProductCateEdit.prototype.onCnCateChange = function (e) {
    this.cnCategory = e;
  };

  ProductCateEdit.prototype.onDeptChange = function (e) {
    var _this = this;

    var item = this.sale_dept_list.find(function (x) {
      return x.name == e;
    });

    if (!item) {
      return;
    }

    this.innerAction.setActionAPI('common_management/query_dept_users', common_service["a" /* CommonService */].getMenuCode('department-management'));
    this.publicService.query(new http["RequestParams"]({
      dept_id: parseInt(item.code)
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      if (data.users.length) {
        _this.operator_list = data.users.map(function (x) {
          return x;
        });
      }

      if (data.leaders.length) {
        _this.sale_dept_leader_list = data.leaders.map(function (x) {
          return x;
        });
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductCateEdit.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductCateEdit.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductCateEdit.prototype, "saveFlag", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductCateEdit.prototype, "row", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: Array
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductCateEdit.prototype, "sale_dept_list", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: Array
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductCateEdit.prototype, "purchase_list", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: Array
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductCateEdit.prototype, "purchase_follower_list", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: Array
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductCateEdit.prototype, "develop_team_list", void 0);

  ProductCateEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductCateEdit);
  return ProductCateEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_cate_editvue_type_script_lang_ts_ = (product_cate_editvue_type_script_lang_ts_ProductCateEdit);
// CONCATENATED MODULE: ./src/components/product/product-cate-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_cate_editvue_type_script_lang_ts_ = (product_cate_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-cate-edit.vue?vue&type=custom&index=0&blockType=i18n
var product_cate_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("22f5");

// CONCATENATED MODULE: ./src/components/product/product-cate-edit.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_cate_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_cate_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_cate_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_cate_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "78cd":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"discount_warehouse":"Warehouse","discount_percent":"discount_percent","discount_price":"discount_price","discount_start":"discount_start","discount_end":"discount_end","discount_change_reason":"discount_change_reason"}},"zh-cn":{"columns":{"discount_warehouse":"折扣仓库","discount_percent":"折扣百分比","discount_price":"折扣价","discount_start":"折扣开始日期","discount_end":"折扣结束日期","discount_change_reason":"折扣变更备注"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "7973":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"search_code":"search_code","calculate_code":"calculate_code","cur_date":"cur_date","sales_trend":"sales_trend","will_sales":"will_sales","transit_qty":"transit_qty","unship_qty":"unship_qty","stock_qty":"stock_qty","order_date":"order_date","order_qty":"order_qty","sales_qty":"sales_qty","presale_order_qty":"presale_order_qty","presale_sales_qty":"presale_sales_qty","uk_order_qty":"uk_order_qty","uk_sales_qty":"uk_sales_qty","uk_presale_order_qty":"uk_presale_order_qty","uk_presale_sales_qty":"uk_presale_sales_qty","memo":"memo","log_content":"log_content","log_type":"log_type","who_log":"who_log","log_date":"log_date"},"action":{},"rules":{},"purchase_predict_detail_1":"purchase_predict_detail_1","purchase_predict_detail_2":"purchase_predict_detail_2","half_year_sales":"half_year_sales","logs":"logs"},"zh-cn":{"desc":"","columns":{"calculate_code":"统计编码","cur_date":"统计时间","sales_trend":"销售趋势","will_sales":"未来销量","transit_qty":"在途量","unship_qty":"未发货量","stock_qty":"当前库存数","order_date":"购买时间","order_qty":"订单量","sales_qty":"销量","presale_order_qty":"预售订单量","presale_sales_qty":"预售销量","uk_order_qty":"英线订单量","uk_sales_qty":"英线销量","uk_presale_order_qty":"英线预售订单量","uk_presale_sales_qty":"英线预售销量","memo":"备注","log_content":"日志","log_type":"类型","who_log":"操作人","log_date":"日期"},"action":{},"rules":{"date_range_error":"开始日期不能大于结束日期"},"purchase_predict_detail_1":"第一期预算详情","purchase_predict_detail_2":"第二期预算详情","half_year_sales":"近半年销售总量记录","logs":"操作日志"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "823a":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"requirement_period":"requirement_period","de_category":"de_category","category_state":"category_state","purchase_user":"purchase_user","operator":"operator","develop_team":"develop_team","cn_sub_category":"cn_sub_category","group_category":"group_category","purchase_period":"purchase_period","cn_category":"cn_category","department_manager":"department_manager","purchase_follower":"purchase_follower","de_sub_category":"de_sub_category","department":"department","sub_category_profit":"sub_category_profit","develop_month":"Develop Month","cn_main_category":"Cn Main Category"},"action":{"edit":"Edit","cancel":"Cancel","more":"More","open":"Enable","close":"Disable","add_cn_main_category":"Add Main Category","add_cn_category":"Add Cn Category"},"rules":{},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","please_choose":"Please Choose"},"zh-cn":{"desc":"","columns":{"requirement_period":"补货周期","de_category":"二级分类-DE","category_state":"启用状态","purchase_user":"采购人员","operator":"运营人员","develop_team":"开发团队","cn_sub_category":"三级分类","purchase_period":"采购周期","cn_category":"二级分类","department_manager":"部门经理","purchase_follower":"跟单人员","de_sub_category":"三级分类-DE","department":"运营部门","sub_category_profit":"毛利率","develop_month":"新上月份","cn_main_category":"一级分类"},"action":{"edit":"编辑","cancel":"取消","more":"更多操作","open":"启用","close":"停用","add_cn_main_category":"新增一级分类","add_cn_category":"新增二级分类"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","please_choose":"请选择"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "864b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_depart_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("26b0");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_depart_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_depart_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_depart_info_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "8b29":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b4f7");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "9475":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ab64");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "9761":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"instock":"Inventory Info","base":"Product Info","shipment":"Shipment Info","record":"In and Out Record","log":"Operate Log","depart":"Product Status","action":{"create":"Create","batch-create":"EXCEL Import","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Discard"}},"zh-cn":{"instock":"库存信息","base":"产品详情","shipment":"物流信息","record":"出入库记录","log":"日志","depart":"产品状态","action":{"create":"新建","batch-create":"EXCEL导入","edit":"编辑","delete":"删除","ok":"确定","cancel":"丢弃"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "9f4f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("00b1");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_unsalable_report_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "a18a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-edit.vue?vue&type=template&id=2591482e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[(!_vm.editAble)?_c('a-button',{attrs:{"type":"default","size":"small"},on:{"click":_vm.onEdit}},[_c('span',[_vm._v(_vm._s(_vm.$t('action.edit')))])]):_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save')))]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small"},on:{"click":function($event){return _vm.onPreCheck()}}},[_vm._v(" "+_vm._s(_vm.$t('action.pre_check'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":_vm.onDelete}},[_vm._v("Delete")]),_c('a-menu-item',{on:{"click":_vm.onDealUpdate}},[_vm._v(_vm._s(_vm.$t('action.deal_update_for_check')))]),_c('a-menu-item',{on:{"click":_vm.onDealNew}},[_vm._v(_vm._s(_vm.$t('action.deal_new')))]),_c('a-menu-item',{on:{"click":_vm.onDealAllNew}},[_vm._v(_vm._s(_vm.$t('action.deal_allnew')))]),_c('a-menu-item',{on:{"click":function($event){return _vm.onFlagToUpdate('update')}}},[_vm._v(_vm._s(_vm.$t('action.flag_to_update')))]),_c('a-menu-item',{on:{"click":function($event){return _vm.onFlagToUpdate('new')}}},[_vm._v(_vm._s(_vm.$t('action.flag_to_new')))]),_c('a-menu-item',{on:{"click":function($event){return _vm.onFlagToUpdate('allnew')}}},[_vm._v(_vm._s(_vm.$t('action.flag_to_allnew')))]),_c('a-menu-item',{on:{"click":_vm.onReCheckForShip}},[_vm._v(_vm._s(_vm.$t('action.recheck_for_ship')))]),_c('a-menu-item',{on:{"click":_vm.onReCheckForSku}},[_vm._v(_vm._s(_vm.$t('action.recheck_for_sku')))]),_c('a-menu-item',{on:{"click":_vm.onReCheckForUpdate}},[_vm._v(_vm._s(_vm.$t('action.recheck_for_update')))])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v("Action"),_c('a-icon',{attrs:{"type":"down"}})],1)],1)],1),_c('a-tabs',{attrs:{"defaultActiveKey":"base","v-model":_vm.activeKey,"type":"card"},on:{"change":function (e) { return _vm.onPanelChange(e); }}},[_c('a-tab-pane',{key:"base",attrs:{"tab":"当前核价"}},[_c('ProductPriceCheckEditDetail',{ref:"fromDetail",attrs:{"info":_vm.order,"edit":_vm.editAble}})],1),_c('a-tab-pane',{key:"history",attrs:{"tab":"历史核价"}},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.historyList,"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"sku",attrs:{"title":_vm.$t('sku'),"data-index":"sku","align":"center","width":"100px"}}),_c('a-table-column',{key:"check_type",attrs:{"title":_vm.$t('check_type'),"data-index":"check_type","align":"center","width":"100px"}}),_c('a-table-column',{key:"memo",attrs:{"title":_vm.$t('memo'),"data-index":"memo","align":"center","width":"100px"}}),_c('a-table-column',{key:"check_date",attrs:{"title":_vm.$t('check_date'),"data-index":"check_date","align":"center","width":"100px"}}),_c('a-table-column',{key:"approve_state",attrs:{"title":_vm.$t('approve_state'),"data-index":"approve_state","align":"center","width":"100px"}}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions'),"align":"center","width":"80px"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.onHistoryView(row)}}},[_vm._v(_vm._s(_vm.$t('view')))])]}}])})],1)],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-price-check-edit.vue?vue&type=template&id=2591482e&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/generate_code.service.ts
var generate_code_service = __webpack_require__("57db");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/components/product/product-price-check-edit-detail.vue + 9 modules
var product_price_check_edit_detail = __webpack_require__("62b8");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/components/product/pre-product-price-check.vue + 9 modules
var pre_product_price_check = __webpack_require__("2298");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-edit.vue?vue&type=script&lang=ts&













var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var product_price_check_editvue_type_script_lang_ts_ProductPriceCheckEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPriceCheckEdit, _super);

  function ProductPriceCheckEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.order = [];
    _this.originData = [];
    _this.historyList = [];
    _this.editAble = false;
    _this.activeKey = 'base';
    _this.save_flag = 1;
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalCodeService = new generate_code_service["a" /* GeneralCodeService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  ProductPriceCheckEdit.prototype.submit = function () {
    return true;
  };

  ProductPriceCheckEdit.prototype.cancel = function () {
    return;
  }; // public setFormValues(param) {
  //     this.form.setFieldsValue(param)
  // }


  ProductPriceCheckEdit.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckEdit.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.save_flag = 1;
      _this.editAble = false;
    });
  };

  ProductPriceCheckEdit.prototype.created = function () {
    this.getCn_cate();
    this.form = this.$form.createForm(this);
  };

  ProductPriceCheckEdit.prototype.mounted = function () {
    if (this.info.length) {
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckEdit.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProductPriceCheckEdit.prototype.onSubmit = function () {
    var fromDetail = this.$refs.fromDetail;
    var ret = fromDetail.getFormData();
    ret['save_flag'] = 1;
    ret['id'] = this.order.id;
    delete ret.cn_category;
    delete ret.cn_sub_category;
    delete ret.operator;

    if (!ret.purchase_price || !ret.memo) {
      return;
    }

    this.saveInfo(ret);
  };

  ProductPriceCheckEdit.prototype.saveInfo = function (param) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/save_product_price_check_info', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"](param, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');

      _this.getInfo();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onEdit = function () {
    this.editAble = true;
  };

  ProductPriceCheckEdit.prototype.onAdd = function () {//
  };

  ProductPriceCheckEdit.prototype.onPreCheck = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_product_price_check_for_try_calculate', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.query(new http["RequestParams"]({
      sku_list: [this.order.sku]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$modal.open(pre_product_price_check["a" /* default */], {
        detail: data
      }, {
        title: _this.$t('action.pre_check'),
        width: '1000px'
      }).subscribe(function (data) {
        _this.$message.success('修改成功');
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onExport = function () {//
  };

  ProductPriceCheckEdit.prototype.onPanelChange = function (e) {
    var _this = this;

    this.activeKey = e;

    if (e === 'history') {
      this.innerAction.setActionAPI('product_management/query_product_price_check_history_by_sku', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
      this.publicService.query(new http["RequestParams"]({
        sku: this.order.sku
      }, {
        loading: this.loadingService,
        innerAction: this.innerAction
      })).subscribe(function (data) {
        _this.historyList = data;
      }, function (err) {
        _this.$message.error(err.message);
      });
    }
  };

  ProductPriceCheckEdit.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  ProductPriceCheckEdit.prototype.onDelete = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/delete_product_price_check', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({
      price_id_list: [this.order.id]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('删除成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onDealUpdate = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/update_recompute_price', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onDealNew = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/new_recompute_price', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onDealAllNew = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/all_new_recompute_price', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onFlagToUpdate = function (state) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/update_product_price_check_state', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({
      price_id_list: [this.order.id],
      compute_state: state
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onReCheckForShip = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/recompute_all_shipment_fee', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onReCheckForSku = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/create_same_common_sku_price_info', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onReCheckForUpdate = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/sync_same_common_sku_price_info', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"]({}, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.onHistoryView = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_product_price_check_history_info', common_service["a" /* CommonService */].getMenuCode('product_price_check_history'));
    this.publicService.query(new http["RequestParams"]({
      history_id: row.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      data[0]['id'] = row.id; // data[0]['state'] = record.state

      var index = 'productpricecheckhistoryedit' + row.id;
      var params = {
        index: index,
        id: row.id,
        info: data,
        component: 'ProductPriceCheckHistoryEdit'
      };

      _this.addCommonPageInfo(params);

      var baseName = _this.$t('page_name');

      _this.$router.push({
        name: 'swap-page',
        path: "/swap-page/" + index,
        params: {
          id: index,
          name: row.sku + '-' + baseName
        }
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckEdit.prototype.getInfo = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_product_price_check_info', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.query(new http["RequestParams"]({
      price_id: this.order.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      data[0]['id'] = _this.order.id;

      _this.updateOrder(data);
    }, function (err) {});
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckEdit.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckEdit.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckEdit.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckEdit.prototype, "addCommonPageInfo", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckEdit.prototype, "onInfoChange", null);

  ProductPriceCheckEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */],
      ProductPriceCheckEditDetail: product_price_check_edit_detail["a" /* default */]
    }
  })], ProductPriceCheckEdit);
  return ProductPriceCheckEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_price_check_editvue_type_script_lang_ts_ = (product_price_check_editvue_type_script_lang_ts_ProductPriceCheckEdit);
// CONCATENATED MODULE: ./src/components/product/product-price-check-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_price_check_editvue_type_script_lang_ts_ = (product_price_check_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-price-check-edit.vue?vue&type=custom&index=0&blockType=i18n
var product_price_check_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("1875");

// CONCATENATED MODULE: ./src/components/product/product-price-check-edit.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_price_check_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_price_check_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_price_check_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_price_check_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "a742":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "ab64":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"edit":"Edit","save":"Save","change_category":"Change Category","add":"Add","operate":"Operate","delete":"Delete","cancel":"Discard","cancel_edit":"Cancel","frei_field_1":"Freifield1","frei_field_2":"Freifield2","frei_field_3":"Freifield3","frei_field_4":"Freifield4","frei_field_5":"Freifield5","frei_field_6":"Freifield6","frei_field_7":"Freifield7","frei_field_8":"Freifield8","frei_field_9":"Freifield9","frei_field_10":"Freifield10","product_attr":"Product Attr","product_value":"Product Value","default_code":"Default code","name":"Product Name","product_number":"Product number","common_sku":"Common sku","type":"Type","hs_code":"Hs code","category":"Category","z_category":"Chinese category","sub_category":"Sub category","z_sub_category":"Chinese sub category","department":"Department","operator":"Operator","product_color":"Product color","product_color_chinese":"Product color chinese","weight":"Weight","weight1":"Brutto Weight","basic_size":"Basic size","max_size":"Package size","carton_size":"Carton size","package_size_container":"Package size container","stock_calculated_time":"Stock calculated time","min_pack":"Min pack","pack_cate":"Pack cate","purchase_method":"Purchase method","location_code":"Location code","prime_group":"Prime group","pre_sale":"DE Pre sale","uk_pre_sale":"UK Pre sale","amazon_sale_only":"Amazon sale only","share_stock_country":"Share stock country","uk_warehouse":"Uk warehouse","pack_material":"Pack material","product_link":"Product link","product_ve":"Product ve","purchase_ve":"Purchase ve","product_storage_condition":"Product storage condition","china_hs_code":"China hs code","europe_hs_code":"Europe hs code","size1":"Size1","size2":"Size2","size3":"Size3","new_product":"New product","first_stock_time":"First stock time","sale_ok":"Can be Sold","purchase_ok":"Can be Purchased","on_sale":"On Sale","is_purchase_product":"Is Purchase Product","is_set":"Is Variant Set","is_pack":"Is Product Pack","is_to_switch":"Is W=Z","is_fba":"FBA Product","is_seasonal_product":"Seasonal Product","peek_season_month":"Peek Season Month","length":"length(cm)","width":"width(cm)","height":"height(cm)","is_edit_group":"Is Edit SKU","edit_group_sku":"Edit Group SKU","actions":{"part1_name":"General Infomation","part2_name":"Freifield","part3_name":"Product Extra Attributes","confirm_cancel":"Are you sure cancel?","ok":"Ok","cancel":"Cancel"},"columns":{"prod_status":"Prod Status","prod_status_sale":"Sale","prod_status_stop":"Stop","prod_status_waiting":"Waiting","prod_status_sz_prod":"SZ Prod","prod_status_uk_sale":"UK Sale","prod_status_tort_stop":"Tort Stop"}},"zh-cn":{"edit":"编辑","save":"保存","change_category":"修改产品品类","add":"新增","operate":"操作","delete":"删除","cancel":"丢弃","cancel_edit":"取消","frei_field_1":"Freifield1","frei_field_2":"Freifield2","frei_field_3":"Freifield3","frei_field_4":"Freifield4","frei_field_5":"Freifield5","frei_field_6":"Freifield6","frei_field_7":"Freifield7","frei_field_8":"Freifield8","frei_field_9":"Freifield9","frei_field_10":"Freifield10","product_attr":"产品属性","product_value":"属性值","default_code":"货号SKU","name":"产品名称","product_number":"Product number","common_sku":"通用货号","type":"类型","hs_code":"Hs Code","category":"德文分类","z_category":"中文分类","sub_category":"德文子类","z_sub_category":"中文子类","department":"主体部门","operator":"运营","product_color":"产品颜色","product_color_chinese":"产品颜色(中文)","weight":"净重","weight1":"毛重","basic_size":"Basic size","max_size":"Package size","carton_size":"Carton size","package_size_container":"Package Size Container","stock_calculated_time":"库存计算时间","min_pack":"最大混合数","pack_cate":"包裹分类","purchase_method":"采购方式","location_code":"库位代码","prime_group":"Prime组类","pre_sale":"DE预售","uk_pre_sale":"UK预售","amazon_sale_only":"只在Amazon销售","share_stock_country":"共享库存国家","uk_warehouse":"英仓标志","pack_material":"产品材质","product_link":"产品链接","product_ve":"产品VE","purchase_ve":"采购VE","product_storage_condition":"产品存储条件","china_hs_code":"中国HS Code","europe_hs_code":"欧洲HS Code","size1":"第一长边","size2":"第二长边","size3":"第三长边","new_product":"是否新品","first_stock_time":"第一次入库时间","sale_ok":"Can be Sold","purchase_ok":"Can be Purchased","on_sale":"On Sale","is_purchase_product":"Is Purchase Product","is_set":"Is Variant Set","is_pack":"Is Product Pack","is_to_switch":"Is W=Z","is_fba":"FBA Product","active":"Active","is_seasonal_product":"季节性产品","peek_season_month":"旺季月份","length":"长(cm)","width":"宽(cm)","height":"高(cm)","is_edit_group":"是否维护组SKU","edit_group_sku":"关联维护组SKU","actions":{"part1_name":"基础信息","part2_name":"Freifield","part3_name":"产品额外属性","confirm_cancel":"确定要取消编辑吗?","ok":"确定","cancel":"取消"},"columns":{"prod_status":"产品状态","prod_status_sale":"正常在售","prod_status_stop":"淘汰停售","prod_status_waiting":"待观察","prod_status_sz_prod":"深圳产品","prod_status_uk_sale":"UK正常在售","prod_status_tort_stop":"侵权停售"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "acb1":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"ae_commission_rate":"ae_commission_rate","after_refund_tax":"after_refund_tax","at_ae_lowest_price":"at_ae_lowest_price","at_mfn_shipment_fee":"at_mfn_shipment_fee","au_mfn_shipment_fee":"au_mfn_shipment_fee","be_ae_lowest_price":"be_ae_lowest_price","be_mfn_shipment_fee":"be_mfn_shipment_fee","cn_category":"cn_category","cn_sub_category":"cn_sub_category","compute_state":"compute_state","custom_fee":"custom_fee","custom_tax":"custom_tax","de_ae_lowest_price":"de_ae_lowest_price","de_b2c_lowest_price":"de_b2c_lowest_price","de_fba_fee":"de_fba_fee","de_fba_lowest_price":"de_fba_lowest_price","de_lowest_profit":"de_lowest_profit","de_mfn_lowest_price":"de_mfn_lowest_price","de_mfn_shipment_fee":"de_mfn_shipment_fee","de_prime_discount_price":"de_prime_discount_price","de_prime_fee":"de_prime_fee","de_prime_normal_price":"de_prime_normal_price","discount_end":"discount_end","discount_percent":"discount_percent","discount_start":"discount_start","dollar_to_cn":"dollar_to_cn","ero_to_cn":"ero_to_cn","es_ae_lowest_price":"es_ae_lowest_price","es_b2c_lowest_price":"es_b2c_lowest_price","es_fba_fee":"es_fba_fee","es_fba_lowest_price":"es_fba_lowest_price","es_float_price":"es_float_price","es_mfn_lowest_price":"es_mfn_lowest_price","es_mfn_shipment_fee":"es_mfn_shipment_fee","float_platform":"float_platform","float_price":"float_price","fr_ae_lowest_price":"fr_ae_lowest_price","fr_b2c_lowest_price":"fr_b2c_lowest_price","fr_cd_fbc_fee":"fr_cd_fbc_fee","fr_cd_fbc_price":"fr_cd_fbc_price","fr_cd_mfn_price":"fr_cd_mfn_price","fr_fba_fee":"fr_fba_fee","fr_fba_lowest_price":"fr_fba_lowest_price","fr_float_price":"fr_float_price","fr_mfn_lowest_price":"fr_mfn_lowest_price","fr_mfn_shipment_fee":"fr_mfn_shipment_fee","gb_ae_lowest_price":"gb_ae_lowest_price","gb_b2c_lowest_price":"gb_b2c_lowest_price","gb_fba_fee":"gb_fba_fee","gb_fba_lowest_price":"gb_fba_lowest_price","gb_mfn_lowest_price":"gb_mfn_lowest_price","gb_mfn_shipment_fee":"gb_mfn_shipment_fee","gb_own_ae_lowest_price":"gb_own_ae_lowest_price","gb_own_fba_fee":"gb_own_fba_fee","gb_own_fba_lowest_price":"gb_own_fba_lowest_price","gb_own_lowest_price":"gb_own_lowest_price","girth":"girth","header_fee":"header_fee","id":"id","it_ae_lowest_price":"it_ae_lowest_price","it_b2c_lowest_price":"it_b2c_lowest_price","it_fba_fee":"it_fba_fee","it_fba_lowest_price":"it_fba_lowest_price","it_float_price":"it_float_price","it_mfn_lowest_price":"it_mfn_lowest_price","it_mfn_shipment_fee":"it_mfn_shipment_fee","latest_compute_time":"latest_compute_time","lu_ae_lowest_price":"lu_ae_lowest_price","lu_mfn_shipment_fee":"lu_mfn_shipment_fee","money_type":"money_type","nl_ae_lowest_price":"nl_ae_lowest_price","nl_b2c_lowest_price":"nl_b2c_lowest_price","nl_fba_fee":"nl_fba_fee","nl_fba_lowest_price":"nl_fba_lowest_price","nl_float_price":"nl_float_price","nl_mfn_lowest_price":"nl_mfn_lowest_price","nl_mfn_shipment_fee":"nl_mfn_shipment_fee","operator":"operator","other_fee":"other_fee","pack_num":"pack_num","pl_ae_lowest_price":"pl_ae_lowest_price","pl_fba_fee":"pl_fba_fee","pl_fba_lowest_price":"pl_fba_lowest_price","pl_float_price":"pl_float_price","pl_mfn_lowest_price":"pl_mfn_lowest_price","pl_mfn_shipment_fee":"pl_mfn_shipment_fee","refund_tax":"refund_tax","se_fba_fee":"se_fba_fee","se_fba_lowest_price":"se_fba_lowest_price","size1":"size1","size2":"size2","size3":"size3","sku":"sku","uk_float_price":"uk_float_price","volume":"volume","purchase_price":"purchase_price","cost_price":"cost_price","change_reason":"Change Reason","warehouse":"Waerhouse","weight":"Weight","memo":"Memo"},"action":{"edit":"Edit","cancel":"Cancel","more":"More","action":"Action","add":"Add","export":"Export","save":"Save","pre_check":"Pre Check","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","please_choose":"Please Choose","sku":"SKU","check_type":"Check Type","memo":"Memo","check_date":"Check Date","approve_state":"Approve State","actions":"Action","view":"View","page_name":"ProdPriceCheckHistory"},"zh-cn":{"desc":"","columns":{"ae_commission_rate":"ae_commission_rate","after_refund_tax":"退后税","at_mfn_shipment_fee":"AT-MFN运费","au_mfn_shipment_fee":"AU-MFN运费","be_mfn_shipment_fee":"BE-MFN运费","cn_category":"中文分类","cn_sub_category":"中文子类","compute_state":"compute_state","custom_fee":"custom_fee","custom_tax":"关税税率","de_fba_fee":"DE-FBA费用","de_lowest_profit":"DE-MFN最低毛利率","de_mfn_shipment_fee":"DE-MFN运费","de_prime_discount_price":"de_prime_discount_price","discount_end":"折扣结束时间","discount_percent":"折扣百分比","discount_start":"折扣开始时间","dollar_to_cn":"美金对人民币汇率","ero_to_cn":"欧元对人民币汇率","es_fba_fee":"ES-FBA费用","es_float_price":"ES站点浮动值","es_mfn_shipment_fee":"ES-MFN运费","float_platform":"平台","float_price":"float_price","fr_cd_fbc_fee":"fr_cd_fbc_fee","fr_cd_fbc_price":"FR-CD-FBC最低定价","fr_cd_mfn_price":"FR-CD-MFN最低定价","fr_fba_fee":"FR-FBA费用","fr_float_price":"FR站点浮动值","fr_mfn_shipment_fee":"FR-MFN运费","gb_fba_fee":"GB-FBA费用","gb_mfn_shipment_fee":"GB-MFN运费","gb_own_fba_fee":"英国仓发FBA费用","girth":"周长","header_fee":"头程","id":"id","it_fba_fee":"IT-FBA费用","it_float_price":"IT站点浮动值","it_mfn_shipment_fee":"IT-MFN运费","latest_compute_time":"latest_compute_time","lu_mfn_shipment_fee":"LU-MFN运费","money_type":"币种","nl_fba_fee":"NL-FBA费用","nl_float_price":"NL站点浮动值","nl_mfn_shipment_fee":"NL-MFN运费","operator":"运营","other_fee":"杂费","pack_num":"pack_num","pl_fba_fee":"PL-FBA费用","pl_float_price":"PL站点浮动值","pl_mfn_shipment_fee":"PL-MFN运费","refund_tax":"出口退税率","se_fba_fee":"SE-FBA费用","size1":"包装尺寸1","size2":"包装尺寸2","size3":"包装尺寸3","sku":"sku","uk_float_price":"uk_float_price","volume":"体积","at_ae_lowest_price":"AT-速卖通最低定价","be_ae_lowest_price":"BE-速卖通最低定价","de_ae_lowest_price":"DE-速卖通最低定价","de_b2c_lowest_price":"DE-B2C最低定价","de_fba_lowest_price":"DE-FBA最低定价","de_mfn_lowest_price":"DE-MFN最低定价","de_prime_fee":"DE-Prime折扣定价","de_prime_normal_price":"DE-Prime正常定价","es_ae_lowest_price":"ES-速卖通最低定价","es_b2c_lowest_price":"ES-B2C最低定价","es_fba_lowest_price":"ES-FBA最低定价","es_mfn_lowest_price":"ES-MFN最低定价","fr_ae_lowest_price":"FR-速卖通最低定价","fr_b2c_lowest_price":"FR-B2C最低定价","fr_fba_lowest_price":"FR-FBA最低定价","fr_mfn_lowest_price":"FR-最低定价","gb_ae_lowest_price":"GB-速卖通最低定价","gb_b2c_lowest_price":"GB-B2C最低定价","gb_own_ae_lowest_price":"GB英仓速卖通最低定价","gb_own_fba_lowest_price":"英国仓发FBA最低定价","gb_own_lowest_price":"GB-英仓最低定价","it_ae_lowest_price":"IT-速卖通最低定价","it_b2c_lowest_price":"IT-B2C最低定价","it_fba_lowest_price":"IT-FBA最低定价","it_mfn_lowest_price":"IT-MFN最低定价","lu_ae_lowest_price":"LU-速卖通最低定价","nl_b2c_lowest_price":"NL-B2C最低定价","nl_fba_lowest_price":"NL-FBA最低定价","nl_mfn_lowest_price":"NL-MFN最低定价","pl_fba_lowest_price":"PL-FBA最低定价","pl_mfn_lowest_price":"PL-MFN最低定价","se_fba_lowest_price":"SE-FBA最低定价","purchase_price":"采购价","cost_price":"成本价","change_reason":"浮动价格变动原因","warehouse":"仓库","weight":"重量","memo":"核价备注"},"action":{"edit":"编辑","cancel":"取消","more":"更多操作","action":"Action","add":"新增","export":"导出","save":"保存","pre_check":"预调价","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","please_choose":"请选择","sku":"产品SKU","check_type":"核价类型","memo":"备注","check_date":"核价时间","approve_state":"审核状况","actions":"操作","view":"查看","page_name":"历史核价"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "ae00":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("22fd");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_purchase_predict_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "af45":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_history_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d1c3");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_history_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_history_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_history_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b265":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f073");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "b4f7":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "b6d7":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"log":"Log","type":"Type","operater":"Operater","date":"Date","product_sku":"Product Sku","qty_available":"Qty Onhand","product_qty":"Product Qty","in_out_warehouse_type":"In Out Warehouse Type","location_dest_name":"Location Dest Name","location_from_name":"Location From  Name","state":"State","qty_done":"Qty Done","picking_name":"Picking Name","operate_user":"Operate User","merge_time":"Merge Time","done_time":"Done Time","note":"Note","warehouse":"Warehouse","all":"All"},"zh-cn":{"log":"日志","type":"类型","operater":"操作人","date":"日期","product_sku":"Product Sku","qty_available":"产品在手数量","product_qty":"产品数量","in_out_warehouse_type":"出入库类型","location_dest_name":"目标库位","location_from_name":"来源库位","state":"状态","qty_done":"完成数量","picking_name":"拣货单","operate_user":"操作人员","merge_time":"合并时间","done_time":"完成时间","note":"备注","warehouse":"仓库","all":"全部"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "bc57":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "c492":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-create.vue?vue&type=template&id=37a80690&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px","min-height":"40px","display":"inline-block"}},[_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"type":"primary","size":"small"},on:{"click":function($event){return _vm.onSubmit()}}},[_vm._v(_vm._s(_vm.$t('action.save')))])],1),_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 8 },"wrapperCol":{ span: 15, offset: 1 }}},[_c('a-card',[_c('div',{staticStyle:{"margin-top":"10px","font-weight":"600","color":"#222"}},[_vm._v(" 基础信息 ")]),_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":"SKU","required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sku', { rules: _vm.rules.required }]),expression:"['sku', { rules: rules.required }]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":"product_tmpl_id"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_tmpl_id']),expression:"['product_tmpl_id']"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.operator')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['operator']),expression:"['operator']"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.z_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_category']),expression:"['cn_category']"}],staticStyle:{"width":"120px"},attrs:{"size":"small"},on:{"change":_vm.handleFatherCateChange}},_vm._l((_vm.fatherCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.z_sub_category')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['cn_sub_category']),expression:"['cn_sub_category']"}],staticStyle:{"width":"200px"},attrs:{"size":"small"}},_vm._l((_vm.sonCates),function(cate){return _c('a-select-option',{key:cate},[_vm._v(" "+_vm._s(cate)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.weight'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'weight',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'weight',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.size1'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'size1',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'size1',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.size2'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'size2',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'size2',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.size3'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'size3',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'size3',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.pack_num'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'pack_num',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'pack_num',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.girth'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'girth',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'girth',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.volume'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'volume',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'volume',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1)],1)],1),_c('a-card',{staticStyle:{"margin-top":"5px"}},[_c('div',{staticStyle:{"margin-top":"10px","font-weight":"600","color":"#222"}},[_vm._v(" 采购信息 ")]),_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.purchase_price'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'purchase_price',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'purchase_price',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.money_type'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'money_type',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'money_type',\n                                { rules: rules.required }\n                            ]"}],staticStyle:{"width":"120px"},attrs:{"size":"small"}},[_c('a-select-option',{key:"人民币",attrs:{"value":"人民币"}},[_vm._v(" 人民币 ")]),_c('a-select-option',{key:"欧元",attrs:{"value":"欧元"}},[_vm._v(" 欧元 ")]),_c('a-select-option',{key:"美金",attrs:{"value":"美金"}},[_vm._v(" 美金 ")])],1)],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.refund_tax'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'refund_tax',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'refund_tax',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.ero_to_cn'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'ero_to_cn',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'ero_to_cn',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.dollar_to_cn'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'dollar_to_cn',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'dollar_to_cn',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.custom_tax'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'custom_tax',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'custom_tax',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.cost_price'),"required":""}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'cost_price',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'cost_price',\n                                { rules: rules.required }\n                            ]"}],attrs:{"min":0,"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":8}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.memo'),"required":""}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'memo',
                                { rules: _vm.rules.required }
                            ]),expression:"[\n                                'memo',\n                                { rules: rules.required }\n                            ]"}],attrs:{"size":"small"}})],1)],1)],1)],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-price-check-create.vue?vue&type=template&id=37a80690&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/generate_code.service.ts
var generate_code_service = __webpack_require__("57db");

// EXTERNAL MODULE: ./src/shared/common/log-view.vue + 4 modules
var log_view = __webpack_require__("7986");

// EXTERNAL MODULE: ./src/services/report.service.ts
var report_service = __webpack_require__("914f");

// EXTERNAL MODULE: ./src/components/product/product-price-check-edit-detail.vue + 9 modules
var product_price_check_edit_detail = __webpack_require__("62b8");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-price-check-create.vue?vue&type=script&lang=ts&












var pageParamsModule = Object(lib["c" /* namespace */])('pageParamsModule');

var product_price_check_createvue_type_script_lang_ts_ProductPriceCheckCreate =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPriceCheckCreate, _super);

  function ProductPriceCheckCreate() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.order = [];
    _this.originData = [];
    _this.historyList = [];
    _this.editAble = false;
    _this.activeKey = 'base';
    _this.save_flag = 0;
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalCodeService = new generate_code_service["a" /* GeneralCodeService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.reportService = new report_service["a" /* ReportService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    _this.fatherCates = [];
    _this.sonCates = [];
    _this.cateDict = {};
    _this.selectedList = [];
    return _this;
  }

  ProductPriceCheckCreate.prototype.submit = function () {
    return true;
  };

  ProductPriceCheckCreate.prototype.cancel = function () {
    return;
  }; // public setFormValues(param) {
  //     this.form.setFieldsValue(param)
  // }


  ProductPriceCheckCreate.prototype.onInfoChange = function () {
    if (this.info) {
      this.editAble = false;
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckCreate.prototype.updateOrder = function (order) {
    var _this = this;

    this.originData = order;
    this.$nextTick(function () {
      _this.order = order[0];
      _this.save_flag = 0;
      _this.editAble = false;
    });
  };

  ProductPriceCheckCreate.prototype.created = function () {
    this.getCn_cate();
    this.form = this.$form.createForm(this);
  };

  ProductPriceCheckCreate.prototype.mounted = function () {
    if (this.info.length) {
      this.updateOrder(this.info);
    }
  };

  ProductPriceCheckCreate.prototype.getCn_cate = function () {
    var _this = this;

    this.reportService.query_category_dict(new http["RequestParams"]()).subscribe(function (data) {
      _this.cateDict = data[0];
      var cateData = data[0];

      for (var i in cateData) {
        _this.fatherCates.push(i);
      }
    }, function (error) {
      _this.$message.error(error.message);
    });
  };

  ProductPriceCheckCreate.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['save_flag'] = 0;
        values['id'] = _this.order.id;

        _this.saveInfo(values);
      }
    });
  };

  ProductPriceCheckCreate.prototype.saveInfo = function (param) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/save_product_price_check_info', common_service["a" /* CommonService */].getMenuCode('product_price_check'));
    this.publicService.modify(new http["RequestParams"](param, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');

      _this.form.resetFields();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductPriceCheckCreate.prototype.onExport = function () {//
  };

  ProductPriceCheckCreate.prototype.handleFatherCateChange = function (value) {
    this.sonCates = this.cateDict[value];
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckCreate.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckCreate.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckCreate.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([pageParamsModule.Mutation('addCommonPageInfo'), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPriceCheckCreate.prototype, "addCommonPageInfo", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPriceCheckCreate.prototype, "onInfoChange", null);

  ProductPriceCheckCreate = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      LogView: log_view["a" /* default */],
      ProductPriceCheckEditDetail: product_price_check_edit_detail["a" /* default */]
    }
  })], ProductPriceCheckCreate);
  return ProductPriceCheckCreate;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_price_check_createvue_type_script_lang_ts_ = (product_price_check_createvue_type_script_lang_ts_ProductPriceCheckCreate);
// CONCATENATED MODULE: ./src/components/product/product-price-check-create.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_price_check_createvue_type_script_lang_ts_ = (product_price_check_createvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-price-check-create.vue?vue&type=custom&index=0&blockType=i18n
var product_price_check_createvue_type_custom_index_0_blockType_i18n = __webpack_require__("12df");

// CONCATENATED MODULE: ./src/components/product/product-price-check-create.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_price_check_createvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_price_check_createvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_price_check_createvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_price_check_create = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "cbc9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_depart_info_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ccd0");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_depart_info_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_depart_info_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "ccd0":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "d027":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "d1c3":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"ae_commission_rate":"ae_commission_rate","after_refund_tax":"after_refund_tax","at_ae_lowest_price":"at_ae_lowest_price","at_mfn_shipment_fee":"at_mfn_shipment_fee","au_mfn_shipment_fee":"au_mfn_shipment_fee","be_ae_lowest_price":"be_ae_lowest_price","be_mfn_shipment_fee":"be_mfn_shipment_fee","cn_category":"cn_category","cn_sub_category":"cn_sub_category","compute_state":"compute_state","custom_fee":"custom_fee","custom_tax":"custom_tax","de_ae_lowest_price":"de_ae_lowest_price","de_b2c_lowest_price":"de_b2c_lowest_price","de_fba_fee":"de_fba_fee","de_fba_lowest_price":"de_fba_lowest_price","de_lowest_profit":"de_lowest_profit","de_mfn_lowest_price":"de_mfn_lowest_price","de_mfn_shipment_fee":"de_mfn_shipment_fee","de_prime_discount_price":"de_prime_discount_price","de_prime_fee":"de_prime_fee","de_prime_normal_price":"de_prime_normal_price","discount_end":"discount_end","discount_percent":"discount_percent","discount_start":"discount_start","dollar_to_cn":"dollar_to_cn","ero_to_cn":"ero_to_cn","es_ae_lowest_price":"es_ae_lowest_price","es_b2c_lowest_price":"es_b2c_lowest_price","es_fba_fee":"es_fba_fee","es_fba_lowest_price":"es_fba_lowest_price","es_float_price":"es_float_price","es_mfn_lowest_price":"es_mfn_lowest_price","es_mfn_shipment_fee":"es_mfn_shipment_fee","float_platform":"float_platform","float_price":"float_price","fr_ae_lowest_price":"fr_ae_lowest_price","fr_b2c_lowest_price":"fr_b2c_lowest_price","fr_cd_fbc_fee":"fr_cd_fbc_fee","fr_cd_fbc_price":"fr_cd_fbc_price","fr_cd_mfn_price":"fr_cd_mfn_price","fr_fba_fee":"fr_fba_fee","fr_fba_lowest_price":"fr_fba_lowest_price","fr_float_price":"fr_float_price","fr_mfn_lowest_price":"fr_mfn_lowest_price","fr_mfn_shipment_fee":"fr_mfn_shipment_fee","gb_ae_lowest_price":"gb_ae_lowest_price","gb_b2c_lowest_price":"gb_b2c_lowest_price","gb_fba_fee":"gb_fba_fee","gb_fba_lowest_price":"gb_fba_lowest_price","gb_mfn_lowest_price":"gb_mfn_lowest_price","gb_mfn_shipment_fee":"gb_mfn_shipment_fee","gb_own_ae_lowest_price":"gb_own_ae_lowest_price","gb_own_fba_fee":"gb_own_fba_fee","gb_own_fba_lowest_price":"gb_own_fba_lowest_price","gb_own_lowest_price":"gb_own_lowest_price","girth":"girth","header_fee":"header_fee","id":"id","it_ae_lowest_price":"it_ae_lowest_price","it_b2c_lowest_price":"it_b2c_lowest_price","it_fba_fee":"it_fba_fee","it_fba_lowest_price":"it_fba_lowest_price","it_float_price":"it_float_price","it_mfn_lowest_price":"it_mfn_lowest_price","it_mfn_shipment_fee":"it_mfn_shipment_fee","latest_compute_time":"latest_compute_time","lu_ae_lowest_price":"lu_ae_lowest_price","lu_mfn_shipment_fee":"lu_mfn_shipment_fee","money_type":"money_type","nl_ae_lowest_price":"nl_ae_lowest_price","nl_b2c_lowest_price":"nl_b2c_lowest_price","nl_fba_fee":"nl_fba_fee","nl_fba_lowest_price":"nl_fba_lowest_price","nl_float_price":"nl_float_price","nl_mfn_lowest_price":"nl_mfn_lowest_price","nl_mfn_shipment_fee":"nl_mfn_shipment_fee","operator":"operator","other_fee":"other_fee","pack_num":"pack_num","pl_ae_lowest_price":"pl_ae_lowest_price","pl_fba_fee":"pl_fba_fee","pl_fba_lowest_price":"pl_fba_lowest_price","pl_float_price":"pl_float_price","pl_mfn_lowest_price":"pl_mfn_lowest_price","pl_mfn_shipment_fee":"pl_mfn_shipment_fee","refund_tax":"refund_tax","se_fba_fee":"se_fba_fee","se_fba_lowest_price":"se_fba_lowest_price","size1":"size1","size2":"size2","size3":"size3","sku":"sku","uk_float_price":"uk_float_price","volume":"volume"},"action":{"edit":"Edit","cancel":"Cancel","more":"More","action":"Action","add":"Add","export":"Export","save":"Save","pre_check":"Pre Check","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","please_choose":"Please Choose","sku":"SKU","check_type":"Check Type","memo":"Memo","check_date":"Check Date","approve_state":"Approve State","actions":"Action","view":"View"},"zh-cn":{"desc":"","columns":{"ae_commission_rate":"ae_commission_rate","after_refund_tax":"退后税","at_mfn_shipment_fee":"AT-MFN运费","au_mfn_shipment_fee":"AU-MFN运费","be_mfn_shipment_fee":"BE-MFN运费","cn_category":"中文分类","cn_sub_category":"中文子类","compute_state":"compute_state","custom_fee":"custom_fee","custom_tax":"custom_tax","de_fba_fee":"DE-FBA费用","de_lowest_profit":"DE-MFN最低毛利率","de_mfn_shipment_fee":"DE-MFN运费","de_prime_discount_price":"de_prime_discount_price","discount_end":"折扣结束时间","discount_percent":"折扣百分比","discount_start":"折扣开始时间","dollar_to_cn":"美金对人民币汇率","ero_to_cn":"欧元对人民币汇率","es_fba_fee":"ES-FBA费用","es_float_price":"ES站点浮动值","es_mfn_shipment_fee":"ES-MFN运费","float_platform":"平台","float_price":"float_price","fr_cd_fbc_fee":"fr_cd_fbc_fee","fr_cd_fbc_price":"FR-CD-FBC最低定价","fr_cd_mfn_price":"FR-CD-MFN最低定价","fr_fba_fee":"FR-FBA费用","fr_float_price":"FR站点浮动值","fr_mfn_shipment_fee":"FR-MFN运费","gb_fba_fee":"GB-FBA费用","gb_mfn_shipment_fee":"GB-MFN运费","gb_own_fba_fee":"英国仓发FBA费用","girth":"周长","header_fee":"头程","id":"id","it_fba_fee":"IT-FBA费用","it_float_price":"IT站点浮动值","it_mfn_shipment_fee":"IT-MFN运费","latest_compute_time":"latest_compute_time","lu_mfn_shipment_fee":"LU-MFN运费","money_type":"币种","nl_fba_fee":"NL-FBA费用","nl_float_price":"NL站点浮动值","nl_mfn_shipment_fee":"NL-MFN运费","operator":"运营","other_fee":"杂费","pack_num":"pack_num","pl_fba_fee":"PL-FBA费用","pl_float_price":"PL站点浮动值","pl_mfn_shipment_fee":"PL-MFN运费","refund_tax":"refund_tax","se_fba_fee":"SE-FBA费用","size1":"包装尺寸1","size2":"包装尺寸2","size3":"包装尺寸3","sku":"sku","uk_float_price":"uk_float_price","volume":"体积","at_ae_lowest_price":"AT-速卖通最低定价","be_ae_lowest_price":"BE-速卖通最低定价","de_ae_lowest_price":"DE-速卖通最低定价","de_b2c_lowest_price":"DE-B2C最低定价","de_fba_lowest_price":"DE-FBA最低定价","de_mfn_lowest_price":"DE-MFN最低定价","de_prime_fee":"DE-Prime折扣定价","de_prime_normal_price":"DE-Prime正常定价","es_ae_lowest_price":"ES-速卖通最低定价","es_b2c_lowest_price":"ES-B2C最低定价","es_fba_lowest_price":"ES-FBA最低定价","es_mfn_lowest_price":"ES-MFN最低定价","fr_ae_lowest_price":"FR-速卖通最低定价","fr_b2c_lowest_price":"FR-B2C最低定价","fr_fba_lowest_price":"FR-FBA最低定价","fr_mfn_lowest_price":"FR-最低定价","gb_ae_lowest_price":"GB-速卖通最低定价","gb_b2c_lowest_price":"GB-B2C最低定价","gb_own_ae_lowest_price":"GB英仓速卖通最低定价","gb_own_fba_lowest_price":"英国仓发FBA最低定价","gb_own_lowest_price":"GB-英仓最低定价","it_ae_lowest_price":"IT-速卖通最低定价","it_b2c_lowest_price":"IT-B2C最低定价","it_fba_lowest_price":"IT-FBA最低定价","it_mfn_lowest_price":"IT-MFN最低定价","lu_ae_lowest_price":"LU-速卖通最低定价","nl_b2c_lowest_price":"NL-B2C最低定价","nl_fba_lowest_price":"NL-FBA最低定价","nl_mfn_lowest_price":"NL-MFN最低定价","pl_fba_lowest_price":"PL-FBA最低定价","pl_mfn_lowest_price":"PL-MFN最低定价","se_fba_lowest_price":"SE-FBA最低定价"},"action":{"edit":"编辑","cancel":"取消","more":"更多操作","action":"Action","add":"新增","export":"导出","save":"保存","pre_check":"预调价","deal_update_for_check":"处理更新核价(update)","deal_new":"处理新加核价(new)","deal_allnew":"处理新加数据获取核价(allnew)","flag_to_update":"标注为update","flag_to_new":"标注为new","flag_to_allnew":"标注为allnew","recheck_for_ship":"物流费用变动后一键重新核价","recheck_for_sku":"插入相同通用货号基础产品核价","recheck_for_update":"一键更新相同通用货号核价数据"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","please_choose":"请选择","sku":"产品SKU","check_type":"核价类型","memo":"备注","check_date":"核价时间","approve_state":"审核状况","actions":"操作","view":"查看"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "dab1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-detail.vue?vue&type=template&id=c9260a4a&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-detail"},[_c('a-tabs',{attrs:{"defaultActiveKey":"base","v-model":_vm.activeKey},on:{"change":function (e) { return _vm.onPanelChange(e); }}},[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('base')}},[_c('ProductBaseDetail',{attrs:{"info":_vm.data,"id":_vm.id,"systemUsers":_vm.systemUsers}})],1),_c('a-tab-pane',{key:"instock",attrs:{"tab":_vm.$t('instock')}},[_c('InstockInfo',{attrs:{"id":_vm.id}})],1),_c('a-tab-pane',{key:"shipment",attrs:{"tab":_vm.$t('shipment')}},[_c('ShipmentInfo',{attrs:{"id":_vm.id}})],1),_c('a-tab-pane',{key:"record",attrs:{"tab":_vm.$t('record')}},[_c('ProductInoutRecord',{attrs:{"id":_vm.id}})],1),_c('a-tab-pane',{key:"depart",attrs:{"tab":_vm.$t('depart')}},[_c('ProductDepartInfo',{attrs:{"id":_vm.id,"editAble":true,"departmentList":_vm.departmentList,"systemUsers":_vm.systemUsers}})],1),_c('a-tab-pane',{key:"log",attrs:{"tab":_vm.$t('log')}},[_c('ProductLogDetail',{attrs:{"id":_vm.id}})],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-detail.vue?vue&type=template&id=c9260a4a&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-base-detail.vue?vue&type=template&id=bf0b538e&
var product_base_detailvue_type_template_id_bf0b538e_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-data"},[_c('div',{staticStyle:{"padding":"0 20px 10px 0px"}},[(!_vm.editable)?_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.editBtn}},[_vm._v(_vm._s(_vm.$t('edit'))+" ")]):_c('a-popconfirm',{attrs:{"title":_vm.$t('actions.confirm_cancel'),"okText":_vm.$t('actions.ok'),"cancelText":_vm.$t('actions.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.editBtn()}}},[_c('a-button',{attrs:{"type":"primary"}},[_vm._v(_vm._s(_vm.$t('cancel_edit')))])],1),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"},on:{"click":_vm.saveBtn}},[_vm._v(_vm._s(_vm.$t('save'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"},on:{"click":_vm.changeCategory}},[_vm._v(_vm._s(_vm.$t('change_category'))+" ")])],1),_c('p',{staticStyle:{"color":"#fff","font-weight":"600","font-size":"18px","margin":"0","border-bottom":"3px solid #ccc"}},[_c('span',{staticClass:"side_label"},[_vm._v(" "+_vm._s(_vm.$t('actions.part1_name'))+" ")])]),_c('div',{staticClass:"pic-box"},[_c('div',{staticClass:"pic"},[_c('img',{staticStyle:{"width":"100%"},attrs:{"src":_vm.data.product_link,"alt":""}})]),_c('div',{staticClass:"prod-name"},[_c('p',[(_vm.data.product_url && _vm.data.product_url.length > 10)?_c('span',[_c('a',{attrs:{"title":"Download the Product Manual(产品说明书)"},on:{"click":function($event){_vm.view_old_manual_pdf(
                                _vm.data.product_url.replace(
                                    /Introduction@@/g,
                                    ''
                                )
                            )}}},[_vm._v(_vm._s(_vm.data.default_code)+" ")])]):_c('span',[_vm._v(_vm._s(_vm.data.default_code))])])]),_c('div',{staticClass:"ck-box"},[_c('ul',[_c('li',[_c('a-checkbox',{attrs:{"disabled":!_vm.editable,"checked":_vm.data.is_purchase_product},on:{"change":function (e) { return _vm.handleChange(
                                    e.target.checked,
                                    'is_purchase_product'
                                ); }}}),_vm._v(" "+_vm._s(_vm.$t('is_purchase_product'))+" ")],1),_c('li',[_c('a-checkbox',{attrs:{"disabled":!_vm.editable,"checked":_vm.data.is_set},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'is_set'); }}}),_vm._v(" "+_vm._s(_vm.$t('is_set'))+" ")],1),_c('li',[_c('a-checkbox',{attrs:{"disabled":!_vm.editable,"checked":_vm.data.is_pack},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'is_pack'); }}}),_vm._v(" "+_vm._s(_vm.$t('is_pack'))+" ")],1),_c('li',[_c('a-checkbox',{attrs:{"id":"is_edit_group","disabled":!_vm.editable,"checked":_vm.data.is_edit_group},on:{"change":function (e) { return _vm.handleChange(
                                    e.target.checked,
                                    'is_edit_group'
                                ); }}}),_vm._v(" "+_vm._s(_vm.$t('is_edit_group'))+" ")],1)])]),_c('div',{staticClass:"ck-box"},[_c('ul',[_c('li',[_c('a-checkbox',{attrs:{"disabled":!_vm.editable,"checked":_vm.data.is_to_switch},on:{"change":function (e) { return _vm.handleChange(
                                    e.target.checked,
                                    'is_to_switch'
                                ); }}}),_vm._v(" "+_vm._s(_vm.$t('is_to_switch'))+" ")],1),_c('li',[_c('a-checkbox',{attrs:{"disabled":!_vm.editable,"checked":_vm.data.is_fba},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'is_fba'); }}}),_vm._v(" "+_vm._s(_vm.$t('is_fba'))+" ")],1),_c('li',[_c('a-checkbox',{attrs:{"disabled":!_vm.editable,"checked":_vm.data.active},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'active'); }}}),_vm._v(" "+_vm._s(_vm.$t('active'))+" ")],1),_c('li',[_c('a-checkbox',{attrs:{"disabled":"","checked":!!_vm.data.new_product}}),_vm._v(" "+_vm._s(_vm.$t('new_product'))+" ")],1)])]),_vm._m(0)]),_c('table',{staticClass:"xgtb"},[_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('type')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['type']),expression:"['type']"}],style:({ width: '200px' }),attrs:{"value":_vm.data.type,"size":"small","placeholder":"Select Type"},on:{"change":function (e) { return _vm.handleChange(e, 'type'); }}},_vm._l((_vm.$dict.ProductType),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(_vm.data.type,'ProductType')))+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('name')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.name,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'name'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.name)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('default_code')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.default_code,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'default_code'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.default_code)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('product_number')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.product_number,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'product_number'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.product_number)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('common_sku')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.common_sku,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'common_sku'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.common_sku)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('edit_group_sku')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.edit_group_sku,"disabled":!_vm.edit_group_sku_able,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'edit_group_sku'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.edit_group_sku)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('product_color')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.product_color,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'product_color'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.product_color)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('pack_material')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.pack_material,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'pack_material'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.pack_material)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('weight')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input-number',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.weight,"size":"small","min":0},on:{"change":function (e) { return _vm.handleChange(e, 'weight'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.weight)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('weight1')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input-number',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.weight1,"size":"small","min":0},on:{"change":function (e) { return _vm.handleChange(e, 'weight1'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.weight1)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('basic_size')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.basic_size,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'basic_size'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.basic_size)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('max_size')))]),_c('td',{staticClass:"content"},[(_vm.editable)?[_c('a-input-number',{staticStyle:{"width":"25%","margin-right":"1%"},attrs:{"size":"small","placeholder":this.$t('length')},model:{value:(_vm.data.package_length),callback:function ($$v) {_vm.$set(_vm.data, "package_length", $$v)},expression:"data.package_length"}}),_c('a-input-number',{staticStyle:{"width":"25%","margin-right":"1%"},attrs:{"size":"small","placeholder":this.$t('width')},model:{value:(_vm.data.package_width),callback:function ($$v) {_vm.$set(_vm.data, "package_width", $$v)},expression:"data.package_width"}}),_c('a-input-number',{staticStyle:{"width":"25%"},attrs:{"size":"small","placeholder":this.$t('height')},model:{value:(_vm.data.package_height),callback:function ($$v) {_vm.$set(_vm.data, "package_height", $$v)},expression:"data.package_height"}})]:_c('span',[_vm._v(" "+_vm._s(_vm.data.max_size)+" ")])],2)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('carton_size')))]),_c('td',{staticClass:"content"},[(_vm.editable)?[_c('a-input-number',{staticStyle:{"width":"25%","margin-right":"1%"},attrs:{"size":"small","placeholder":this.$t('length')},model:{value:(_vm.data.carton_length),callback:function ($$v) {_vm.$set(_vm.data, "carton_length", $$v)},expression:"data.carton_length"}}),_c('a-input-number',{staticStyle:{"width":"25%","margin-right":"1%"},attrs:{"size":"small","placeholder":this.$t('width')},model:{value:(_vm.data.carton_width),callback:function ($$v) {_vm.$set(_vm.data, "carton_width", $$v)},expression:"data.carton_width"}}),_c('a-input-number',{staticStyle:{"width":"25%"},attrs:{"size":"small","placeholder":this.$t('height')},model:{value:(_vm.data.carton_height),callback:function ($$v) {_vm.$set(_vm.data, "carton_height", $$v)},expression:"data.carton_height"}})]:_c('span',[_vm._v(" "+_vm._s(_vm.data.carton_size)+" ")])],2)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('package_size_container')))]),_c('td',{staticClass:"content"},[(_vm.editable)?[_c('a-input-number',{staticStyle:{"width":"25%","margin-right":"1%"},attrs:{"size":"small","placeholder":this.$t('length')},model:{value:(_vm.data.size1),callback:function ($$v) {_vm.$set(_vm.data, "size1", $$v)},expression:"data.size1"}}),_c('a-input-number',{staticStyle:{"width":"25%","margin-right":"1%"},attrs:{"size":"small","placeholder":this.$t('width')},model:{value:(_vm.data.size2),callback:function ($$v) {_vm.$set(_vm.data, "size2", $$v)},expression:"data.size2"}}),_c('a-input-number',{staticStyle:{"width":"25%"},attrs:{"size":"small","placeholder":this.$t('height')},model:{value:(_vm.data.size3),callback:function ($$v) {_vm.$set(_vm.data, "size3", $$v)},expression:"data.size3"}})]:_c('span',[_vm._v(" "+_vm._s(_vm.data.package_size_container)+" ")])],2)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('min_pack')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input-number',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.min_pack,"size":"small","min":0},on:{"change":function (e) { return _vm.handleChange(e, 'min_pack'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.min_pack)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('pack_cate')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.pack_cate,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'pack_cate'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.pack_cate)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('location_code')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.location_code,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'location_code'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.location_code)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('is_seasonal_product')))]),_c('td',{staticClass:"content"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"disabled":!_vm.editable,"checked":!!_vm.data.season_prod,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'season_prod'); }}})],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('peek_season_month')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['hot_sale_month']),expression:"['hot_sale_month']"}],style:({ width: '200px' }),attrs:{"mode":"multiple","default-value":_vm.data.hot_sale_month,"size":"small","placeholder":"Please Select"},on:{"change":function (e) { return _vm.handleChange(e, 'hot_sale_month'); }}},_vm._l((12),function(item){return _c('a-select-option',{key:item},[_vm._v(_vm._s(item)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm.data.hot_sale_month ? _vm.data.hot_sale_month.join(',') : '')+" ")])],1)])]),_c('table',{staticClass:"xgtb",staticStyle:{"border-left":"1px solid #ccc"}},[_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('category')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.category,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'category'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.category)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('z_category')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.z_category,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'z_category'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.z_category)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('sub_category')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.sub_category,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'sub_category'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.sub_category)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('z_sub_category')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.z_sub_category,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'z_sub_category'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.z_sub_category)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(" "+_vm._s(_vm.$t('department'))+" "),_c('span',{staticStyle:{"color":"#f00"}},[_vm._v("*")])]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['dept_id']),expression:"['dept_id']"}],style:({ width: '90%' }),attrs:{"value":_vm.data.dept_id,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e, 'dept_id'); }}},_vm._l((_vm.topDepartmentList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.dept_name}},[_vm._v(" "+_vm._s(i.dept_name)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(this.getDepartName(_vm.data.dept_id))+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('operator')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.operator,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'operator'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.operator)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('purchase_method')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.purchase_method,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'purchase_method'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.purchase_method)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('prime_group')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.prime_group,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'prime_group'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.prime_group)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('pre_sale')))]),_c('td',{staticClass:"content"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"disabled":!_vm.editable,"checked":!!_vm.data.pre_sale,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'pre_sale'); }}})],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('uk_pre_sale')))]),_c('td',{staticClass:"content"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"disabled":!_vm.editable,"checked":!!_vm.data.uk_pre_sale,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'uk_pre_sale'); }}})],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('amazon_sale_only')))]),_c('td',{staticClass:"content"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"disabled":!_vm.editable,"checked":!!_vm.data.amazon_sale_only,"size":"small"},on:{"change":function (e) { return _vm.handleChange(
                                e.target.checked,
                                'amazon_sale_only'
                            ); }}})],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('share_stock_country')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.share_stock_country,"size":"small"},on:{"change":function (e) { return _vm.handleChange(
                                e.target.value,
                                'share_stock_country'
                            ); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.share_stock_country)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('uk_warehouse')))]),_c('td',{staticClass:"content"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"disabled":!_vm.editable,"checked":!!_vm.data.uk_warehouse,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'uk_warehouse'); }}})],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('product_link')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.product_link,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'product_link'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.product_link)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('product_ve'))+"1")]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input-number',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.product_ve,"size":"small","min":0},on:{"change":function (e) { return _vm.handleChange(e, 'product_ve'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.product_ve)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('purchase_ve')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input-number',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.purchase_ve,"size":"small","min":0},on:{"change":function (e) { return _vm.handleChange(e, 'purchase_ve'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.purchase_ve)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('product_storage_condition')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.product_storage_condition,"size":"small"},on:{"change":function (e) { return _vm.handleChange(
                                e.target.value,
                                'product_storage_condition'
                            ); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.product_storage_condition)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('stock_calculated_time')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"show-time":"","value":_vm.data.stock_calculated_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'stock_calculated_time'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.stock_calculated_time)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('first_stock_time')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"show-time":"","value":_vm.data.first_stock_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'first_stock_time'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.first_stock_time)+" ")])],1)])]),_c('p',{staticStyle:{"color":"#fff","font-weight":"600","font-size":"18px","clear":"both","margin":"0","border-bottom":"3px solid #ccc"}},[_c('span',{staticClass:"side_label"},[_vm._v(" "+_vm._s(_vm.$t('actions.part2_name'))+" ")])]),_c('table',{staticClass:"xgtb-full"},[_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_1')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_1,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_1'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_1)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_2')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_2,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_2'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_2)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_3')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_3,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_3'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_3)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_4')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_4,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_4'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_4)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_5')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_5,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_5'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_5)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_6')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_6,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_6'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_6)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_7')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_7,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_7'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_7)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_8')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_8,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_8'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_8)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_9')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_9,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_9'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_9)+" ")])],1)]),_c('tr',[_c('td',{staticClass:"title"},[_vm._v(_vm._s(_vm.$t('frei_field_10')))]),_c('td',{staticClass:"content"},[(_vm.editable)?_c('a-textarea',{staticStyle:{"width":"95%","margin":"3px 0"},attrs:{"auto-size":"","value":_vm.data.frei_field_10,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'frei_field_10'); }}}):_c('span',[_vm._v(" "+_vm._s(_vm.data.frei_field_10)+" ")])],1)])]),_c('p',{staticStyle:{"color":"#fff","font-weight":"600","font-size":"18px","clear":"both","margin":"0","border-bottom":"3px solid #ccc"}},[_c('span',{staticClass:"side_label"},[_vm._v(" "+_vm._s(_vm.$t('actions.part3_name'))+" ")])]),_c('div',{staticStyle:{"padding":"0 20px 10px 0px","margin-top":"10px"}},[(!_vm.editable2)?_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.editBtn2}},[_vm._v(_vm._s(_vm.$t('edit'))+" ")]):_c('a-popconfirm',{attrs:{"title":_vm.$t('actions.confirm_cancel'),"okText":_vm.$t('actions.ok'),"cancelText":_vm.$t('actions.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.editBtn2()}}},[_c('a-button',{attrs:{"type":"primary"}},[_vm._v(_vm._s(_vm.$t('cancel_edit')))])],1),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"},on:{"click":_vm.addExtraInfo}},[_vm._v(_vm._s(_vm.$t('add'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},attrs:{"type":"primary"},on:{"click":_vm.saveExtraInfo}},[_vm._v(_vm._s(_vm.$t('save'))+" ")])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.extraInfoList,"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"product_attr",attrs:{"title":_vm.$t('product_attr'),"align":"left","width":"40%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.editable2)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":row.product_attr,"size":"small"},on:{"change":function (e) { return _vm.handleExtraChange(
                                e.target.value,
                                'product_attr',
                                row.index
                            ); }}}):_c('span',[_vm._v(" "+_vm._s(row.product_attr)+" ")])]}}])}),_c('a-table-column',{key:"product_value",attrs:{"title":_vm.$t('product_value'),"align":"left","width":"50%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.editable2)?_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":row.product_value,"size":"small"},on:{"change":function (e) { return _vm.handleExtraChange(
                                e.target.value,
                                'product_value',
                                row.index
                            ); }}}):_c('span',[_vm._v(" "+_vm._s(row.product_value)+" ")])]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('operate'),"align":"center","width":"10%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.onDelete(row)}}},[_vm._v(_vm._s(_vm.$t('delete')))])]}}])})],1)],1)}
var product_base_detailvue_type_template_id_bf0b538e_staticRenderFns = [function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"ck-box"},[_c('ul')])}]


// CONCATENATED MODULE: ./src/components/product/product-base-detail.vue?vue&type=template&id=bf0b538e&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__("a9e3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/components/product/select-product-category.vue + 4 modules
var select_product_category = __webpack_require__("54ad");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-base-detail.vue?vue&type=script&lang=ts&















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_base_detailvue_type_script_lang_ts_ProductBasedata =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductBasedata, _super);

  function ProductBasedata() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.topDepartmentList = [];
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.productService = new product_service["a" /* ProductService */]();
    _this.data = {};
    _this.extraInfoList = [];
    _this.editable = false;
    _this.editable2 = false;
    _this.pre_sale = false;
    _this.originData = [];
    _this.extraInfoListOrigin = [];
    _this.edit_group_sku_able = true;
    _this.pageService = new page_service["a" /* PageService */]();
    return _this;
  }

  ProductBasedata.prototype.created = function () {
    this.getDepartmentList();
  };

  ProductBasedata.prototype.mounted = function () {
    // this.info['is_edit_group'] = true
    this.data = Object.assign({}, this.info);
    this.originData = Object.assign({}, this.info);

    if (this.data.id) {
      this.getExtraInfo(this.data.id);
    }

    if (this.data.is_edit_group) {
      this.edit_group_sku_able = false;
      this.data['edit_group_sku'] = this.data.default_code;
    }

    this.topDepartmentList = this.departmentList.filter(function (x) {
      return x.dept_type == 30;
    });
  };

  ProductBasedata.prototype.onInfoChange = function () {
    // this.info['is_edit_group'] = true
    this.data = Object.assign({}, this.info);
    this.originData = Object.assign({}, this.info);

    if (this.data.id) {
      this.getExtraInfo(this.data.id);
    }

    if (this.data.is_edit_group) {
      this.edit_group_sku_able = false;
      this.data['edit_group_sku'] = this.data.default_code;
    }
  };

  ProductBasedata.prototype.editBtn = function () {
    this.editable = !this.editable;

    if (!this.editable) {
      this.data = Object.assign({}, this.info);
    }
  };

  ProductBasedata.prototype.editBtn2 = function () {
    this.editable2 = !this.editable2;

    if (!this.editable2) {
      this.extraInfoList = this.extraInfoListOrigin.map(function (x) {
        return x;
      });
    }
  };

  ProductBasedata.prototype.handleChange = function (value, key) {
    var that = this;

    if (key === 'is_edit_group') {
      if (value == false) {
        this.$confirm({
          title: '警告',
          content: '该维护组SKU关联的其它SKU将失去与该SKU的关联关系。此操作不可恢复。确认取消？',
          onOk: function onOk() {
            that.data[key] = false;
            that.edit_group_sku_able = true;
            that.data['edit_group_sku'] = '';
          },
          onCancel: function onCancel() {
            var dom = window.document.getElementById('is_edit_group');
            dom.checked = true;
            return;
          }
        });
      } else {
        this.data[key] = value;
        this.data['edit_group_sku'] = this.data.default_code;
        this.edit_group_sku_able = false;
      }
    } else {
      this.data[key] = value;
    }
  };

  ProductBasedata.prototype.handleExtraChange = function (value, key, index) {
    var item = this.extraInfoList.find(function (x) {
      return x.index === index;
    });

    if (item) {
      item[key] = value;
    }
  };

  ProductBasedata.prototype.compareData = function (data1, data2) {
    var ret = 0;

    for (var i in data1) {
      if ((data1[i] || data2[i]) && data1[i] !== data2[i]) {
        ret = 1;
        break;
      }
    }

    return ret;
  };

  ProductBasedata.prototype.calcStyle = function (state) {
    if (state === 'ok') {
      return 'green';
    } else if (state === 'error') {
      return 'red';
    } else {
      return 'blue';
    }
  };

  ProductBasedata.prototype.saveBtn = function () {
    var _this = this;

    this.data['save_flag'] = 1;

    if (!this.data.dept_id) {
      this.$message.error('department is required');
      return;
    }

    if (this.data.season_prod && !this.data.hot_sale_month.length) {
      this.$message.error('旺季月份(peek_season_month) is required');
      return;
    }

    this.productService.save(new http["RequestParams"](this.data, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.handleUnit();

      _this.originData = Object.assign({}, _this.data);
      _this.editable = false;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductBasedata.prototype.handleUnit = function () {
    this.data.max_size = "" + (this.data.package_length ? this.data.package_length : '') + (this.data.package_width ? 'x' + this.data.package_width : '') + (this.data.package_height ? 'x' + this.data.package_height : '');
    this.data.carton_size = "" + (this.data.carton_length ? this.data.carton_length : '') + (this.data.carton_width ? 'x' + this.data.carton_width : '') + (this.data.carton_height ? 'x' + this.data.carton_height : '');
    this.data.package_size_container = "" + (this.data.size1 ? this.data.size1 : '') + (this.data.size2 ? 'x' + this.data.size2 : '') + (this.data.size3 ? 'x' + this.data.size3 : '');
  };

  ProductBasedata.prototype.cancelBtn = function () {
    this.data = Object.assign({}, this.info);
  };

  ProductBasedata.prototype.addExtraInfo = function () {
    this.extraInfoList.push({
      save_flag: 0,
      index: uuid_default.a.generate(),
      product_attr: '',
      product_value: ''
    });
    this.editable2 = true;
  };

  ProductBasedata.prototype.getExtraInfo = function (id) {
    var _this = this;

    this.productService.query_product_extra_value(new http["RequestParams"]({
      product_tmpl_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.extraInfoList = _this.extraInfoListOrigin = data.map(function (x) {
        x['index'] = uuid_default.a.generate();
        x['save_flag'] = 1;
        return x;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductBasedata.prototype.saveExtraInfo = function () {
    var _this = this;

    var params = []; // params = this.extraInfoList.map(x => {
    //     delete x.index
    //     x['product_template_id'] = parseInt(this.id)
    //     return x
    // })

    for (var _i = 0, _a = this.extraInfoList; _i < _a.length; _i++) {
      var i = _a[_i];
      params.push({
        id: i.id,
        product_attr: i.product_attr,
        product_template_id: parseInt(this.id),
        product_value: i.product_value,
        save_flag: i.save_flag
      });
    }

    this.productService.save_product_extra_value(new http["RequestParams"]({
      extra_list: params
    }, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.editable2 = false;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductBasedata.prototype.onDelete = function (row) {
    var _this = this;

    if (!row.id) {
      this.extraInfoList = this.extraInfoList.filter(function (x) {
        return x.index !== row.index;
      });
      this.editable2 = false;
      return;
    }

    this.productService.delete_extra_value(new http["RequestParams"]({
      id: row.id
    }, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this.$t('tips.delete_success');

      _this.$message.success(msg);

      _this.extraInfoList = _this.extraInfoList.filter(function (x) {
        return x.index !== row.index;
      });
      _this.editable2 = false;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductBasedata.prototype.view_old_manual_pdf = function (product_url) {
    if (product_url == '') {
      this.$message.info('说明书链接不存在.');
      return;
    }

    window.open(app_config["a" /* default */].server + '/product/get_product_manual_pdf?product_url=' + product_url);
  };

  ProductBasedata.prototype.getDepartName = function (dept_id) {
    var ret = dept_id;
    var item = this.departmentList.find(function (x) {
      return x.id == dept_id;
    });

    if (item) {
      ret = item.dept_name;
    }

    return ret;
  };

  ProductBasedata.prototype.changeCategory = function () {
    var _this = this;

    this.$modal.open(select_product_category["a" /* default */], {
      idList: [this.id]
    }, {
      title: this.$t('change_category')
    }).subscribe(function (data) {
      _this.$message.success('update success');

      _this.refrushCategoryInfo();
    });
  };

  ProductBasedata.prototype.refrushCategoryInfo = function () {
    var _this = this;

    this.productService.query_product_basic_info(new http["RequestParams"]({
      product_tmpl_id: parseInt(this.id)
    }, {
      page: this.pageService,
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.data.cn_main_category = data[0].cn_main_category;
      _this.data.de_main_category = data[0].de_main_category;
      _this.data.category = data[0].category;
      _this.data.category_id = data[0].category_id;
      _this.data.z_category = data[0].z_category;
      _this.data.z_sub_category = data[0].z_sub_category;
      _this.data.sub_category = data[0].sub_category;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 0,
    type: Number
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "saveDetail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: false
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "pageShow", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductBasedata.prototype, "getDepartmentList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductBasedata.prototype, "onInfoChange", null);

  ProductBasedata = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductBasedata);
  return ProductBasedata;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_base_detailvue_type_script_lang_ts_ = (product_base_detailvue_type_script_lang_ts_ProductBasedata);
// CONCATENATED MODULE: ./src/components/product/product-base-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_base_detailvue_type_script_lang_ts_ = (product_base_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/product-base-detail.vue?vue&type=style&index=0&lang=css&
var product_base_detailvue_type_style_index_0_lang_css_ = __webpack_require__("f010");

// EXTERNAL MODULE: ./src/components/product/product-base-detail.vue?vue&type=style&index=1&lang=css&
var product_base_detailvue_type_style_index_1_lang_css_ = __webpack_require__("0e53");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/product/product-base-detail.vue?vue&type=custom&index=0&blockType=i18n
var product_base_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("9475");

// CONCATENATED MODULE: ./src/components/product/product-base-detail.vue







/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  product_product_base_detailvue_type_script_lang_ts_,
  product_base_detailvue_type_template_id_bf0b538e_render,
  product_base_detailvue_type_template_id_bf0b538e_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_base_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_base_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_base_detail = (component.exports);
// EXTERNAL MODULE: ./src/components/product/instock-info.vue + 4 modules
var instock_info = __webpack_require__("2017");

// EXTERNAL MODULE: ./src/components/product/shipment-info.vue + 4 modules
var shipment_info = __webpack_require__("9a5b");

// EXTERNAL MODULE: ./src/components/product/product-depart-info.vue + 4 modules
var product_depart_info = __webpack_require__("70aa");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-inout-record.vue?vue&type=template&id=fba0021c&
var product_inout_recordvue_type_template_id_fba0021c_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-product-detail"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"data":_vm.data,"rowKey":"index","page":_vm.pageService,"scroll":{ y: 600 },"showExportBtn":false,"bordered":""},on:{"on-page-change":_vm.getRecordInfo,"change":_vm.onTableChange}},[_c('a-table-column',{key:"product_sku",attrs:{"title":_vm.$t('product_sku'),"data-index":"product_sku","align":"left","width":"8%"}}),_c('a-table-column',{key:"qty_available",attrs:{"title":_vm.$t('qty_available'),"data-index":"qty_available","align":"center","width":"6%"}}),_c('a-table-column',{key:"product_qty",attrs:{"title":_vm.$t('product_qty'),"align":"center","width":"6%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.product_qty)+" ")]}}])}),_c('a-table-column',{key:"in_out_warehouse_type",attrs:{"title":_vm.$t('in_out_warehouse_type'),"data-index":"in_out_warehouse_type","align":"center","width":"6%"}}),_c('a-table-column',{key:"location_dest_name",attrs:{"title":_vm.$t('location_dest_name'),"data-index":"location_dest_name","filters":_vm.wsFilter,"filterDropdown":function (ref) {
                                var setSelectedKeys = ref.setSelectedKeys;
                                var selectedKeys = ref.selectedKeys;
                                var confirm = ref.confirm;
                                var clearFilters = ref.clearFilters;

                                return _vm.getFilterDom(confirm);
},"filterMultiple":false,"align":"center","width":"8%"},on:{"filter":function (value, record) { return _vm.onFilter(value, record); }}}),_c('a-table-column',{key:"location_from_name",attrs:{"title":_vm.$t('location_from_name'),"data-index":"location_from_name","align":"center","width":"8%"}}),_c('a-table-column',{key:"state",attrs:{"title":_vm.$t('state'),"data-index":"state","align":"center","width":"6%"}}),_c('a-table-column',{key:"qty_done",attrs:{"title":_vm.$t('qty_done'),"data-index":"qty_done","align":"center","width":"6%"}}),_c('a-table-column',{key:"picking_name",attrs:{"title":_vm.$t('picking_name'),"data-index":"picking_name","align":"center","width":"8%"}}),_c('a-table-column',{key:"operate_user",attrs:{"title":_vm.$t('operate_user'),"data-index":"operate_user","align":"center","width":"8%"}}),_c('a-table-column',{key:"merge_time",attrs:{"title":_vm.$t('merge_time'),"align":"center","width":"6%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.merge_time))+" ")]}}])}),_c('a-table-column',{key:"done_time",attrs:{"title":_vm.$t('done_time'),"align":"center","sorter":true,"width":"6%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.done_time))+" ")]}}])}),_c('a-table-column',{key:"note",attrs:{"title":_vm.$t('note'),"data-index":"note","align":"center","width":"6%"}})],1)],1)}
var product_inout_recordvue_type_template_id_fba0021c_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-inout-record.vue?vue&type=template&id=fba0021c&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./src/components/common/filter-dropdown-dom.vue + 2 modules
var filter_dropdown_dom = __webpack_require__("164e");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-inout-record.vue?vue&type=script&lang=ts&











var product_inout_recordvue_type_script_lang_ts_ProductInoutRecord =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductInoutRecord, _super);

  function ProductInoutRecord() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.productService = new product_service["a" /* ProductService */]();
    _this.pageService = new page_service["a" /* PageService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.wareHouse = '';
    _this.data = [];
    _this.wsFilter = [];
    _this.filterValue = '';
    _this.orderBy = 'done_time desc';
    return _this;
  }

  ProductInoutRecord.prototype.mounted = function () {
    this.getRecordInfo();
    this.wsFilter = [{
      text: this.$t('all'),
      value: ''
    }, {
      text: 'DE',
      value: 'de'
    }, {
      text: 'UK',
      value: 'uk'
    }, {
      text: 'RENEW',
      value: 'c_de_renew'
    }];
  };

  ProductInoutRecord.prototype.getRecordInfo = function () {
    var _this = this;

    var values = {
      product_tmpl_id: parseInt(this.id)
    };

    if (this.wareHouse) {
      values['warehouse'] = this.wareHouse;
    }

    var params = common_service["a" /* CommonService */].createQueryCondition(values, {
      product_tmpl_id: '=',
      warehouse: '='
    });

    if (this.orderBy) {
      params['order_by'] = this.orderBy;
    }

    this.productService.query_product_stock_operation(new http["RequestParams"](params, {
      page: this.pageService,
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductInoutRecord.prototype.sortByTime = function (a, b) {
    var aTimeString = a ? a.replace(/-/g, '/') : 0;
    var bTimeString = b ? b.replace(/-/g, '/') : 0;
    var aTime = new Date(aTimeString).getTime();
    var bTime = new Date(bTimeString).getTime();
    return aTime - bTime;
  };

  ProductInoutRecord.prototype.onWarehouseChange = function (e) {
    this.wareHouse = e;
    this.getRecordInfo();
  };

  ProductInoutRecord.prototype.onFilter = function (confirm, value) {
    confirm();
    this.wareHouse = value;
    this.getRecordInfo();
  };

  ProductInoutRecord.prototype.getFilterDom = function (confirm) {
    var _this = this;

    return this.$createElement('FilterDropdownDom', {
      props: {
        data: this.wsFilter
      },
      on: {
        filter: function filter(value) {
          return _this.onFilter(confirm, value);
        },
        clear: function clear() {
          return _this.onFilter(confirm, '');
        }
      },
      attrs: {
        class: 'x-filter'
      }
    });
  };

  ProductInoutRecord.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getRecordInfo();
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductInoutRecord.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductInoutRecord.prototype, "systemUsers", void 0);

  ProductInoutRecord = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      FilterDropdownDom: filter_dropdown_dom["a" /* default */]
    }
  })], ProductInoutRecord);
  return ProductInoutRecord;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_inout_recordvue_type_script_lang_ts_ = (product_inout_recordvue_type_script_lang_ts_ProductInoutRecord);
// CONCATENATED MODULE: ./src/components/product/product-inout-record.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_inout_recordvue_type_script_lang_ts_ = (product_inout_recordvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/product-inout-record.vue?vue&type=custom&index=0&blockType=i18n
var product_inout_recordvue_type_custom_index_0_blockType_i18n = __webpack_require__("56f0");

// CONCATENATED MODULE: ./src/components/product/product-inout-record.vue





/* normalize component */

var product_inout_record_component = Object(componentNormalizer["a" /* default */])(
  product_product_inout_recordvue_type_script_lang_ts_,
  product_inout_recordvue_type_template_id_fba0021c_render,
  product_inout_recordvue_type_template_id_fba0021c_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_inout_recordvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_inout_recordvue_type_custom_index_0_blockType_i18n["default"])(product_inout_record_component)

/* harmony default export */ var product_inout_record = (product_inout_record_component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"423d475a-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-log-detail.vue?vue&type=template&id=f9e8fa84&
var product_log_detailvue_type_template_id_f9e8fa84_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-product-detail"},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"data":_vm.data,"rowKey":"index","page":_vm.pageService,"showExportBtn":false,"scroll":{ y: 600 },"bordered":""},on:{"change":_vm.onTableChange,"on-page-change":_vm.getLogInfo}},[_c('a-table-column',{key:"log_content",attrs:{"title":_vm.$t('log'),"data-index":"log_content","align":"left","width":"40%"}}),_c('a-table-column',{key:"log_type",attrs:{"title":_vm.$t('type'),"data-index":"log_type","align":"center","width":"15%","filters":_vm.logTypeFilter},on:{"Filter":_vm.onTypeFilter}}),_c('a-table-column',{key:"who_log",attrs:{"title":_vm.$t('operater'),"align":"center","width":"15%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.who_log,_vm.systemUsers))+" ")]}}])}),_c('a-table-column',{key:"log_date",attrs:{"title":_vm.$t('date'),"align":"center","sorter":true},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.log_date)))]}}])})],1)],1)}
var product_log_detailvue_type_template_id_f9e8fa84_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/product/product-log-detail.vue?vue&type=template&id=f9e8fa84&

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/components/data-table.vue + 4 modules
var data_table = __webpack_require__("8975");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-log-detail.vue?vue&type=script&lang=ts&














var product_log_detailvue_type_script_lang_ts_datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_log_detailvue_type_script_lang_ts_ProductLogDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductLogDetail, _super);

  function ProductLogDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.pageService = new page_service["a" /* PageService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.orderBy = 'log_date desc';

    _this.compare = function (prop) {
      return function (obj1, obj2) {
        var val1 = obj1[prop];
        var val2 = obj2[prop];

        if (val1 > val2) {
          return -1;
        } else if (val1 < val2) {
          return 1;
        } else {
          return 0;
        }
      };
    };

    return _this;
  }

  Object.defineProperty(ProductLogDetail.prototype, "logTypeFilter", {
    get: function get() {
      var types = [];

      for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
        var item = _a[_i];

        if (types.indexOf(item.log_type) == -1) {
          types.push(item.log_type);
        }
      }

      var value = [];
      types.forEach(function (item) {
        value.push({
          text: item,
          value: item
        });
      });
      return value;
    },
    enumerable: true,
    configurable: true
  });

  ProductLogDetail.prototype.onTypeFilter = function (value, record) {
    return record.log_type.indexOf(value) === 0;
  };

  ProductLogDetail.prototype.created = function () {
    this.getSystemuser();
    this.getLogInfo();
  };

  ProductLogDetail.prototype.getLogInfo = function () {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_all_product_log', common_service["a" /* CommonService */].getMenuCode('product-manage'));
    this.publicService.queryPagination(new http["RequestParams"]({
      query_condition: [{
        query_name: 'product_id',
        operate: '=',
        value: this.id
      }],
      order_by: this.orderBy
    }, {
      loading: this.loadingService,
      page: this.pageService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.data = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ProductLogDetail.prototype.sortByTime = function (a, b) {
    var aTimeString = a ? a.replace(/-/g, '/') : 0;
    var bTimeString = b ? b.replace(/-/g, '/') : 0;
    var aTime = new Date(aTimeString).getTime();
    var bTime = new Date(bTimeString).getTime();
    return aTime - bTime;
  };

  ProductLogDetail.prototype.onTableChange = function (pagination, filters, sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getLogInfo();
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductLogDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([product_log_detailvue_type_script_lang_ts_datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductLogDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([product_log_detailvue_type_script_lang_ts_datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductLogDetail.prototype, "getSystemuser", void 0);

  ProductLogDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      DataTable: data_table["a" /* default */]
    }
  })], ProductLogDetail);
  return ProductLogDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_log_detailvue_type_script_lang_ts_ = (product_log_detailvue_type_script_lang_ts_ProductLogDetail);
// CONCATENATED MODULE: ./src/components/product/product-log-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_log_detailvue_type_script_lang_ts_ = (product_log_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/product-log-detail.vue?vue&type=custom&index=0&blockType=i18n
var product_log_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("eb0d1");

// CONCATENATED MODULE: ./src/components/product/product-log-detail.vue





/* normalize component */

var product_log_detail_component = Object(componentNormalizer["a" /* default */])(
  product_product_log_detailvue_type_script_lang_ts_,
  product_log_detailvue_type_template_id_f9e8fa84_render,
  product_log_detailvue_type_template_id_f9e8fa84_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_log_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_log_detailvue_type_custom_index_0_blockType_i18n["default"])(product_log_detail_component)

/* harmony default export */ var product_log_detail = (product_log_detail_component.exports);
// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/product/product-detail.vue?vue&type=script&lang=ts&











var product_detailvue_type_script_lang_ts_datasModule = Object(lib["c" /* namespace */])('datasModule');

var product_detailvue_type_script_lang_ts_ProductDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductDetail, _super);

  function ProductDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.object_name = 'product_changed_log';
    _this.record_code = '1';
    _this.activeKey = 'base';
    _this.data = {};
    _this.orderID = '';
    _this.saveDetail = 0;
    _this.order_info = [];
    _this.saveShipment = 0;
    _this.invoice = [];
    _this.editable = false;
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  ProductDetail.prototype.onDetailChange = function () {
    // if (!this.data.id || (this.data.id && this.detail.id != this.data.id)) {
    if (this.detail.id) {
      this.data = Object.assign({}, this.detail);
      this.handleUnit();
      this.orderID = this.data.order_id;
    }
  };

  ProductDetail.prototype.handleUnit = function () {
    this.data.max_size = "" + (this.data.package_length ? this.data.package_length : '') + (this.data.package_width ? 'x' + this.data.package_width : '') + (this.data.package_height ? 'x' + this.data.package_height : '');
    this.data.carton_size = "" + (this.data.carton_length ? this.data.carton_length : '') + (this.data.carton_width ? 'x' + this.data.carton_width : '') + (this.data.carton_height ? 'x' + this.data.carton_height : '');
    this.data.package_size_container = "" + (this.data.size1 ? this.data.size1 : '') + (this.data.size2 ? 'x' + this.data.size2 : '') + (this.data.size3 ? 'x' + this.data.size3 : '');
  };

  ProductDetail.prototype.created = function () {
    this.getDepartmentList();
  };

  ProductDetail.prototype.mounted = function () {
    this.data = Object.assign({}, this.detail);
  };

  ProductDetail.prototype.onPanelChange = function (e) {
    this.activeKey = e;

    if (!this.id) {
      return;
    }
  };

  ProductDetail.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  ProductDetail.prototype.editBtn = function () {
    this.editable = !this.editable;
  };

  ProductDetail.prototype.handleChange = function (value, key) {
    this.data[key] = value;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDetail.prototype, "detail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([product_detailvue_type_script_lang_ts_datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDetail.prototype, "departmentList", void 0);

  tslib_es6["c" /* __decorate */]([product_detailvue_type_script_lang_ts_datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ProductDetail.prototype, "getDepartmentList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('detail'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductDetail.prototype, "onDetailChange", null);

  ProductDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductBaseDetail: product_base_detail,
      InstockInfo: instock_info["a" /* default */],
      ShipmentInfo: shipment_info["a" /* default */],
      ProductInoutRecord: product_inout_record,
      ProductLogDetail: product_log_detail,
      ProductDepartInfo: product_depart_info["a" /* default */]
    }
  })], ProductDetail);
  return ProductDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_detailvue_type_script_lang_ts_ = (product_detailvue_type_script_lang_ts_ProductDetail);
// CONCATENATED MODULE: ./src/components/product/product-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var product_product_detailvue_type_script_lang_ts_ = (product_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/product/product-detail.vue?vue&type=style&index=0&lang=css&
var product_detailvue_type_style_index_0_lang_css_ = __webpack_require__("4562");

// EXTERNAL MODULE: ./src/components/product/product-detail.vue?vue&type=custom&index=0&blockType=i18n
var product_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("19bd");

// CONCATENATED MODULE: ./src/components/product/product-detail.vue






/* normalize component */

var product_detail_component = Object(componentNormalizer["a" /* default */])(
  product_product_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_detailvue_type_custom_index_0_blockType_i18n["default"])(product_detail_component)

/* harmony default export */ var product_detail = __webpack_exports__["a"] = (product_detail_component.exports);

/***/ }),

/***/ "eb0d1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("4bff");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "eef0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3745");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_edit_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "f010":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("bc57");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_base_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "f073":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "f127":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"sub_category":"Sub Category","sub_category_attr":"Attributes","value":"Value"},"action":{"create":"Create","edit":"Edit","delete":"Delete","ok":"Ok","cancel":"Cancel","commit":"Commit"}},"zh-cn":{"desc":"","columns":{"sub_category":"子类","sub_category_attr":"属性","value":"值"},"action":{"create":"新建","edit":"编辑查询条件","delete":"删除","ok":"确定","cancel":"取消","commit":"提交"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "f3f3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_discount_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("78cd");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_discount_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_discount_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_price_check_discount_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "f430":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"","columns":{"warehouse_id":"Warehouse","req_type":"Req Type","sales_expected_give_date":"Sales Expected Date","date_expected":"Date Expected","product_qty":"Prod QTY","coefficient":"Coefficient","min_qty":"Min Order"},"action":{"ok":"Ok","cancel":"Cancel","commit":"Commit"},"rules":{}},"zh-cn":{"desc":"","columns":{"warehouse_id":"仓库","req_type":"开发类型","sales_expected_give_date":"期望交期","date_expected":"期望入库","product_qty":"预计采购数量","coefficient":"比例","min_qty":"起订量"},"action":{"ok":"确定","cancel":"取消","commit":"提交"},"rules":{"date_range_error":"开始日期不能大于结束日期"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "fbeb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("7567");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_purchase_predict_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ })

}]);