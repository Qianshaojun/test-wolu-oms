(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~51f20000"],{

/***/ "005d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("cbae");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "04d5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-detail.vue?vue&type=template&id=1d77aae2&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-detail",style:({ height: _vm.divHeight })},[(_vm.pageShow)?_c('a-card',{staticClass:"btn-area"},[[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.reserve}},[_vm._v(" "+_vm._s(_vm.$t('action.reserved'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.validateAddress}},[_vm._v(_vm._s(_vm.$t('action.validate_address'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.createShipment}},[_vm._v(" "+_vm._s(_vm.$t('action.auto_create'))+" ")]),_c('a-button',{staticStyle:{"display":"none"},attrs:{"type":"primary"},on:{"click":_vm.donePickingGetLabel}},[_vm._v(_vm._s(_vm.$t('action.done_picking_get_label'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.fake_shipments}},[_vm._v(_vm._s(_vm.$t('action.fake_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.upload_shipment}},[_vm._v(_vm._s(_vm.$t('action.upload_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.upload_fake_shipment}},[_vm._v(_vm._s(_vm.$t('action.upload_fake_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.createReturn}},[_vm._v(_vm._s(_vm.$t('action.createReturn'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.deliveryMore}},[_vm._v(_vm._s(_vm.$t('action.deliveryMore'))+" ")]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.data['is_resend']),expression:"data['is_resend']"}],attrs:{"type":"primary"},on:{"click":_vm.productPart}},[_vm._v(_vm._s(_vm.$t('action.ProductPart'))+" ")]),_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"type":"primary"}},[_vm._v(" "+_vm._s(_vm.$t('action.create_dhl'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"}},[_vm._v(" "+_vm._s(_vm.$t('action.create_dpd'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"}},[_vm._v(" "+_vm._s(_vm.$t('action.create_gls'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":_vm.modifyAddress}},[_vm._v(_vm._s(_vm.$t('action.modify_address'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":_vm.batchSendEmail}},[_vm._v(_vm._s(_vm.$t('action.batch_send_email'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"8px"}},[_vm._v("Action "),_c('a-icon',{attrs:{"type":"down"}})],1)],1),_c('a-dropdown',[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":_vm.forceAvailability}},[_vm._v(_vm._s(_vm.$t('action.force_available'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelPicking}},[_vm._v(_vm._s(_vm.$t('action.cancelPicking'))+" ")]),_c('a-menu-item',{on:{"click":_vm.setAsDraft}},[_vm._v(_vm._s(_vm.$t('action.setAsDraft'))+" ")]),_c('a-menu-item',{on:{"click":_vm.setPresale}},[_vm._v(_vm._s(_vm.$t('action.setPresale'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelPresale}},[_vm._v(_vm._s(_vm.$t('action.cancelPresale'))+" ")]),_c('a-menu-item',{on:{"click":_vm.markSoldOut}},[_vm._v(_vm._s(_vm.$t('action.markSoldOut'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelSoldOut}},[_vm._v(_vm._s(_vm.$t('action.cancelSoldOut'))+" ")]),_c('a-menu-item',{on:{"click":_vm.checkShipments}},[_vm._v(_vm._s(_vm.$t('action.checkShipmentCount'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelCheckShipments}},[_vm._v(_vm._s(_vm.$t('action.cancelShipmentCount'))+" ")]),_c('a-menu-item',{on:{"click":_vm.serviceProcess}},[_vm._v(_vm._s(_vm.$t('action.serviceProcess'))+" ")]),_c('a-menu-item',{on:{"click":_vm.returnProcess}},[_vm._v(_vm._s(_vm.$t('action.returnProcess'))+" ")]),_c('a-menu-item',{on:{"click":_vm.customer_service_stop_plz}},[_vm._v(_vm._s(_vm.$t('action.customer_service_stop_plz'))+" ")]),_c('a-popconfirm',{attrs:{"title":_vm.$t('action.confirm_operate_refund_order'),"okText":_vm.$t('action.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":_vm.cancel_stock_picking_for_order_refund}},[_c('a-menu-item',{staticStyle:{"text-indent":"10px"}},[_vm._v(_vm._s(_vm.$t( 'action.cancel_stock_picking_for_order_refund' ))+" ")])],1)],1),_c('a-button',{staticStyle:{"margin-left":"8px"}},[_vm._v("更多按钮 "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]],2):_vm._e(),_c('a-tabs',{attrs:{"defaultActiveKey":"base","v-model":_vm.activeKey},on:{"change":function (e) { return _vm.onPanelChange(e); }}},[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('base')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('PickingBaseDetail',{attrs:{"info":_vm.data,"id":_vm.id,"countryList":_vm.countryList,"systemUsers":_vm.systemUsers}})],1)]),_c('a-tab-pane',{key:"operation",attrs:{"tab":_vm.$t('operation')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('OperationDetail',{attrs:{"info":_vm.operations,"id":_vm.id}})],1)]),_c('a-tab-pane',{key:"demand",attrs:{"tab":_vm.$t('initial_demand')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('DemandDetail',{attrs:{"info":_vm.demands,"id":_vm.id}})],1)]),_c('a-tab-pane',{key:"shipment",attrs:{"tab":_vm.$t('shipment')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('ShipmentDetail',{attrs:{"info":_vm.shipments,"id":_vm.id,"systemUsers":_vm.systemUsers,"shipTypeList":_vm.shipTypeList}})],1)]),_c('a-tab-pane',{key:"return",attrs:{"tab":_vm.$t('return_info')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('ReturnDetail',{attrs:{"info":_vm.returns,"picking_id":_vm.id,"orderID":_vm.orderID,"systemUsers":_vm.systemUsers}})],1)]),_c('a-tab-pane',{key:"order_detail",attrs:{"tab":_vm.$t('order_detail')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('OrderBaseDetail',{attrs:{"info":_vm.order_info,"height":_vm.divHeight}})],1)]),_c('a-tab-pane',{key:"invoices",attrs:{"tab":_vm.$t('invoices')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('OrderInvoiceDetail',{attrs:{"info":_vm.invoice,"height":_vm.divHeight,"systemUsers":_vm.systemUsers,"companyList":_vm.companyList}})],1)]),_c('a-tab-pane',{key:"logs",attrs:{"tab":_vm.$t('logs')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('PickingLogDetail',{attrs:{"info":_vm.logs,"id":_vm.id,"systemUsers":_vm.systemUsers}})],1)])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/picking-detail.vue?vue&type=template&id=1d77aae2&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/components/picking/picking-base-detail.vue + 4 modules
var picking_base_detail = __webpack_require__("11ef");

// EXTERNAL MODULE: ./src/components/picking/operation-detail.vue + 4 modules
var operation_detail = __webpack_require__("228e");

// EXTERNAL MODULE: ./src/components/picking/demand-detail.vue + 4 modules
var demand_detail = __webpack_require__("bc03");

// EXTERNAL MODULE: ./src/components/picking/shipment-detail.vue + 4 modules
var shipment_detail = __webpack_require__("055d");

// EXTERNAL MODULE: ./src/components/picking/return-detail.vue + 4 modules
var return_detail = __webpack_require__("d31d");

// EXTERNAL MODULE: ./src/components/picking/picking-log-detail.vue + 4 modules
var picking_log_detail = __webpack_require__("53e6");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./src/components/picking/batch-send-email.vue + 4 modules
var batch_send_email = __webpack_require__("7f15");

// EXTERNAL MODULE: ./src/components/picking/create-return.vue + 4 modules
var create_return = __webpack_require__("7053");

// EXTERNAL MODULE: ./src/services/shipment.service.ts
var shipment_service = __webpack_require__("1af5");

// EXTERNAL MODULE: ./src/components/picking/delivery-more.vue + 4 modules
var delivery_more = __webpack_require__("2b19");

// EXTERNAL MODULE: ./src/components/picking/product-part.vue + 4 modules
var product_part = __webpack_require__("1eb8");

// EXTERNAL MODULE: ./src/services/taxes.service.ts
var taxes_service = __webpack_require__("3723");

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/components/orders/order-base-detail.vue + 4 modules
var order_base_detail = __webpack_require__("443e");

// EXTERNAL MODULE: ./src/services/general_code.service.ts
var general_code_service = __webpack_require__("5083");

// EXTERNAL MODULE: ./src/components/orders/order-invoice-detail.vue + 4 modules
var order_invoice_detail = __webpack_require__("9100");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-detail.vue?vue&type=script&lang=ts&




























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var picking_detailvue_type_script_lang_ts_PickingDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PickingDetail, _super);

  function PickingDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.activeKey = 'base';
    _this.data = {};
    _this.orderID = '';
    _this.taxList = [];
    _this.taxesService = new taxes_service["a" /* TaxesService */]();
    _this.invoice = [];
    _this.operations = [];
    _this.demands = [];
    _this.shipments = [];
    _this.returns = [];
    _this.logs = [];
    _this.editable = false;
    _this.pre_sale = false;
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.shipmentService = new shipment_service["a" /* ShipmentService */]();
    _this.generalCodeService = new general_code_service["a" /* GeneralCodeService */]();
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.order_info = [];
    return _this;
  }

  PickingDetail.prototype.onDetailChange = function () {
    // if (!this.data.id || (this.data.id && this.detail.id != this.data.id)) {
    if (this.detail.id) {
      this.data = Object.assign({}, this.detail);
      this.orderID = this.data.order_id;
      this.getTaxList();
      this.reset();
    }
  };

  PickingDetail.prototype.getTaxList = function () {
    var _this = this;

    if (this.data.seller_code) {
      this.taxesService.queryAll(new http["RequestParams"]({
        seller_code: this.data.seller_code
      })).subscribe(function (data) {
        _this.taxList = data;
      });
    } else {
      this.taxList = [];
    }
  };

  PickingDetail.prototype.onCntChange = function () {
    this.data = [];
    this.operations = [];
    this.demands = [];
    this.shipments = [];
    this.returns = [];
    this.logs = [];
    this.order_info = [];
    this.invoice = [];
  };

  PickingDetail.prototype.reset = function () {
    this.operations = [];
    this.demands = [];
    this.shipments = [];
    this.returns = [];
    this.logs = [];
    this.order_info = [];
    this.invoice = [];

    if (this.activeKey == 'operation') {
      this.getOperations();
    } else if (this.activeKey == 'base') {
      this.updatePickingInfo();
    } else if (this.activeKey == 'demand') {
      this.getDemands();
    } else if (this.activeKey == 'shipment') {
      this.getShipments();
    } else if (this.activeKey == 'return') {
      this.getReturns();
    } else if (this.activeKey == 'logs') {
      this.getLogs();
    } else if (this.activeKey == 'order_detail') {
      this.getOrderDetail();
    } else if (this.activeKey == 'invoices') {
      this.getInvoiceList();
    }
  };

  PickingDetail.prototype.created = function () {
    this.getShipType();
  };

  PickingDetail.prototype.mounted = function () {
    this.data = Object.assign({}, this.detail);
    this.orderID = this.data.order_id;
  };

  PickingDetail.prototype.onPanelChange = function (e) {
    this.activeKey = e;

    if (!this.id) {
      return;
    }

    if (e == 'operation') {
      this.getOperations();
    } else if (e == 'demand') {
      this.getDemands();
    } else if (e == 'shipment') {
      this.getShipments();
    } else if (e == 'return') {
      this.getReturns();
    } else if (e == 'logs') {
      this.getLogs();
    } else if (e == 'order_detail') {
      this.getOrderDetail();
    } else if (e == 'invoices') {
      this.getInvoiceList();
    }
  };

  PickingDetail.prototype.getInvoiceList = function () {
    var _this = this;

    this.orderService.getInvoiceList(new http["RequestParams"]({
      order_name: this.data.origin
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.invoice = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.getOperations = function () {
    var _this = this;

    this.pickingService.queryStockOperation(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.operations = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.getOrderDetail = function () {
    var _this = this;

    this.orderService.getDetail(new http["RequestParams"]({
      order_id: this.orderID
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.order_info = data.order_lines.map(function (x) {
        var tax = _this.taxList.find(function (t) {
          return t.id === x.account_tax_id;
        });

        if (tax) {
          x['tax_name'] = tax.name;
          x.account_tax_id = tax.amount;
        } else {
          x['tax_name'] = x.account_tax_id;
          x.account_tax_id = 0;
        }

        return x;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.getDemands = function () {
    var _this = this;

    this.pickingService.queryStockMove(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.demands = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.getShipments = function () {
    var _this = this;

    this.pickingService.queryShipment(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.shipments = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.getReturns = function () {
    var _this = this;

    this.pickingService.queryReturnInfo(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.returns = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.getLogs = function () {
    var _this = this;

    this.pickingService.queryPickingLog(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.logs = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PickingDetail.prototype.editBtn = function () {
    this.editable = !this.editable;
  };

  PickingDetail.prototype.handleChange = function (value, key) {
    this.data[key] = value;
  };

  PickingDetail.prototype.saveBtn = function () {
    var _this = this;

    this.data['save_flag'] = 1;
    this.pickingService.save(new http["RequestParams"](this.data, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);
    }, function (err) {
      _this.$message.error(err.message);
    }); // this.editable = false
  };

  PickingDetail.prototype.cancelBtn = function () {
    this.data = Object.assign({}, this.detail); // this.editable = false
  };

  PickingDetail.prototype.createShipment = function () {
    var _this = this;

    this.pickingService.createShipmentsLines(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.reserve = function () {
    var _this = this;

    this.pickingService.reserve(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.modifyAddress = function () {
    router["a" /* default */].push({
      name: 'modify-address',
      params: {
        pickingList: JSON.stringify([this.id])
      }
    });
  };

  PickingDetail.prototype.validateAddress = function () {
    var _this = this;

    this.pickingService.validateAddress(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.batchSendEmail = function () {
    var _this = this;

    this.$modal.open(batch_send_email["a" /* default */], {
      stock: [this.id]
    }, {
      title: this.$t('action.batch_send_email'),
      width: '1000px'
    }).subscribe(function (data) {
      var msg = _this.$t('save_success');

      _this.$message.success(msg);
    });
  };

  PickingDetail.prototype.cancelPicking = function () {
    var _this = this;

    this.pickingService.cancelPicking(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.createReturn = function () {
    var _this = this;

    this.$modal.open(create_return["a" /* default */], {
      picking_id: parseInt(this.id)
    }, {
      title: this.$t('Create Return Shipment'),
      width: '80%'
    }).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);
    });
  };

  PickingDetail.prototype.donePickingGetLabel = function () {
    var _this = this;

    this.shipmentService.donePickingGetLabel(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.setAsDraft = function () {
    var _this = this;

    this.pickingService.setAsDraft(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.setPresale = function () {
    var _this = this;

    this.pickingService.setPresale(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.cancelPresale = function () {
    var _this = this;

    this.pickingService.cancelPresale(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.markSoldOut = function () {
    var _this = this;

    this.pickingService.markSoldOut(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.cancelSoldOut = function () {
    var _this = this;

    this.pickingService.cancelSoldOut(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.checkShipments = function () {
    var _this = this;

    this.pickingService.checkShipments(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.cancelCheckShipments = function () {
    var _this = this;

    this.pickingService.cancelCheckShipments(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.serviceProcess = function () {
    var _this = this;

    this.pickingService.serviceProcess(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.returnProcess = function () {
    var _this = this;

    this.pickingService.returnProcess(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.deliveryMore = function () {
    var _this = this;

    this.$modal.open(delivery_more["a" /* default */], {
      picking_id: parseInt(this.id)
    }, {
      title: this.$t('action.deliveryMore'),
      width: '800px'
    }).subscribe(function (data) {
      var msg = _this.$t('save_success');

      _this.$message.success(msg);

      _this.reset();

      _this.$router.push({
        name: 'picking-detail',
        path: "/picking/picking-detail/" + data.new_picking_id,
        params: {
          id: data.new_picking_id,
          name: data.new_picking_name
        }
      });
    });
  };

  PickingDetail.prototype.productPart = function () {
    var _this = this;

    this.$modal.open(product_part["a" /* default */], {
      picking_id: parseInt(this.id)
    }, {
      title: this.$t('action.ProductPart'),
      width: '800px'
    }).subscribe(function (data) {
      var msg = _this.$t('save_success');

      _this.$message.success(msg);

      _this.reset();
    });
  };

  PickingDetail.prototype.customer_service_stop_plz = function () {
    var _this = this;

    this.pickingService.customer_service_stop_plz(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.cancel_stock_picking_for_order_refund = function () {
    var _this = this;

    this.pickingService.cancel_stock_picking_for_order_refund(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.fake_shipments = function () {
    var _this = this;

    this.pickingService.fake_shipments(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.upload_shipment = function () {
    var _this = this;

    this.pickingService.upload_shipment(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.upload_fake_shipment = function () {
    var _this = this;

    this.pickingService.upload_fake_shipment(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this.$t('success');

      _this.$message.success(msg);

      _this.reset();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.updatePickingInfo = function () {
    var _this = this;

    this.pickingService.queryDetail(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      data[0]['id'] = parseInt(_this.id);
      _this.data = data[0];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingDetail.prototype.forceAvailability = function () {
    var _this = this;

    this.pickingService.force_available(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$message.success('操作成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "detail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: true
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "pageShow", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 'auto'
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "divHeight", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 0
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "cnt", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "shipTypeList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "getShipType", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetail.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('detail'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingDetail.prototype, "onDetailChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('cnt'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingDetail.prototype, "onCntChange", null);

  PickingDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      PickingBaseDetail: picking_base_detail["a" /* default */],
      OperationDetail: operation_detail["a" /* default */],
      DemandDetail: demand_detail["a" /* default */],
      ShipmentDetail: shipment_detail["a" /* default */],
      ReturnDetail: return_detail["a" /* default */],
      PickingLogDetail: picking_log_detail["a" /* default */],
      OrderBaseDetail: order_base_detail["a" /* default */],
      OrderInvoiceDetail: order_invoice_detail["a" /* default */]
    }
  })], PickingDetail);
  return PickingDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var picking_detailvue_type_script_lang_ts_ = (picking_detailvue_type_script_lang_ts_PickingDetail);
// CONCATENATED MODULE: ./src/components/picking/picking-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_picking_detailvue_type_script_lang_ts_ = (picking_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/picking-detail.vue?vue&type=style&index=0&lang=css&
var picking_detailvue_type_style_index_0_lang_css_ = __webpack_require__("ba21");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/picking-detail.vue?vue&type=custom&index=0&blockType=i18n
var picking_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("12c5");

// CONCATENATED MODULE: ./src/components/picking/picking-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_picking_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof picking_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(picking_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var picking_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "055d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/shipment-detail.vue?vue&type=template&id=796a7f5e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px"}},[_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.saveBtn}},[_vm._v(_vm._s(_vm.$t('actions.save')))]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.cancelBtn}},[_vm._v(_vm._s(_vm.$t('actions.cancel')))])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"index","scroll":{ x: 1500 },"customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"bordered":""}},[_c('a-table-column',{key:"shipment_num",attrs:{"title":_vm.$t('shipment_order'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.shipment_num)+" "),_c('a',{on:{"click":function($event){return _vm.toTrackShip(row)}}},[_c('a-icon',{staticStyle:{"font-size":"18px","margin-left":"5px"},attrs:{"type":"search"}})],1)]}}])}),_c('a-table-column',{key:"ship_url",attrs:{"title":_vm.$t('pdf'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{directives:[{name:"show",rawName:"v-show",value:(row.shipment_num),expression:"row.shipment_num"}],on:{"click":function($event){return _vm.downloadPdf(row)}}},[_vm._v("预览")])]}}])}),_c('a-table-column',{key:"smtype",attrs:{"title":_vm.$t('shipment_order_type'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            !row.shipment_num
                    )?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['smtype']),expression:"['smtype']"}],style:({ width: '100%' }),attrs:{"value":row.smtype,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'smtype', e); }}},_vm._l((_vm.shipTypeList),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.smtype,_vm.shipTypeList))+" ")])]}}])}),_c('a-table-column',{key:"user_id",attrs:{"title":_vm.$t('create_user'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.user_id,_vm.systemUsers))+" ")]}}])}),_c('a-table-column',{key:"display_product",attrs:{"title":_vm.$t('sent_product'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(
                        _vm.currentRow == row.index &&
                            _vm.editable &&
                            !row.shipment_num
                    )?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['display_product']),expression:"['display_product']"}],style:({ width: '100%' }),attrs:{"value":row.display_product,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'display_product', e); }}}):_c('span',[_vm._v(_vm._s(row.display_product))])]}}])}),_c('a-table-column',{key:"location_product",attrs:{"title":_vm.$t('location_sort'),"data-index":"location_product","ellipsis":true,"align":"center"}}),_c('a-table-column',{key:"prime_item_id",attrs:{"title":_vm.$t('prime_item_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['prime_item_id']),expression:"['prime_item_id']"}],style:({ width: '100%' }),attrs:{"value":row.prime_item_id,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'prime_item_id', e); }}}):_c('span',[_vm._v(_vm._s(row.prime_item_id))])]}}])}),_c('a-table-column',{key:"ship_date",attrs:{"title":_vm.$t('ceate_time'),"data-index":"ship_date","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(ship_date){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(ship_date))+" ")]}}])}),_c('a-table-column',{key:"merge_time",attrs:{"title":_vm.$t('merge_time'),"data-index":"merge_time","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(merge_time){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(merge_time))+" ")]}}])}),_c('a-table-column',{key:"latest_status",attrs:{"title":_vm.$t('latest_status'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['latest_status']),expression:"['latest_status']"}],style:({ width: '100%' }),attrs:{"value":row.latest_status,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'latest_status', e); }}}):_c('span',[_vm._v(" "+_vm._s(row.latest_status)+" ")])]}}])}),_c('a-table-column',{key:"need_process",attrs:{"title":_vm.$t('need_process'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['need_process']),expression:"['need_process']"}],style:({ width: '100%' }),attrs:{"value":row.need_process,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'need_process', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.needProcess),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.need_process,_vm.needProcess))+" ")])]}}])}),_c('a-table-column',{key:"need_process_time",attrs:{"title":_vm.$t('need_process_time'),"data-index":"need_process_time","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(need_process_time){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(need_process_time))+" ")]}}])}),_c('a-table-column',{key:"processed_time_logi",attrs:{"title":_vm.$t('processed_time_logi'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-date-picker',{attrs:{"value":row.processed_time_logi,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.onRowChange(row, 'processed_time_logi', e); }}}):_c('span',[_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.processed_time_logi))+" ")])]}}])}),_c('a-table-column',{key:"processed_time_cs",attrs:{"title":_vm.$t('processed_time_CS'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-date-picker',{attrs:{"value":row.processed_time_cs,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.onRowChange(row, 'processed_time_cs', e); }}}):_c('span',[_vm._v(" "+_vm._s(_vm._f("datetolocal")(row.processed_time_cs))+" ")])]}}])}),_c('a-table-column',{key:"process_type",attrs:{"title":_vm.$t('process_type'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['process_type']),expression:"['process_type']"}],style:({ width: '100%' }),attrs:{"value":row.process_type,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'process_type', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.processType),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.process_type,_vm.processType))+" ")])]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center","width":"100px"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-popconfirm',{attrs:{"title":_vm.$t('actions.delete_shipment_number'),"okText":_vm.$t('actions.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDelPickNumber(row)}}},[_c('a',[_c('a-icon',{attrs:{"type":"close"}})],1)]),_c('a-popconfirm',{attrs:{"title":_vm.$t('actions.delete_shipment'),"okText":_vm.$t('actions.ok'),"cancelText":_vm.$t('action.cancel'),"placement":"left"},on:{"confirm":function($event){return _vm.onDel(row)}}},[_c('a',{staticStyle:{"margin-left":"10px"}},[_c('a-icon',{attrs:{"type":"delete"}})],1)]),_c('a',{staticStyle:{"margin-left":"10px"},attrs:{"title":_vm.$t('actions.send_rt')},on:{"click":function($event){return _vm.sendRT(row)}}},[_c('a-icon',{attrs:{"type":"mail"}})],1)]}}])}),_c('a-table-column',{key:"sceenshot_operate",attrs:{"title":_vm.$t('actions.sceenshot_operate'),"align":"center","width":"80px"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{staticStyle:{"margin-left":"10px"},attrs:{"title":_vm.$t('actions.upload')},on:{"click":function($event){return _vm.onUpload(row)}}},[_c('a-icon',{attrs:{"type":"upload"}})],1),_c('a',{staticStyle:{"margin-left":"10px"},attrs:{"title":_vm.$t('actions.revert')},on:{"click":function($event){return _vm.revertPdf(row)}}},[_c('a-icon',{attrs:{"type":"redo"}})],1)]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/shipment-detail.vue?vue&type=template&id=796a7f5e&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__("a9e3");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/components/common/text-edit-cell.vue + 4 modules
var text_edit_cell = __webpack_require__("746c");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/components/common/send-email.vue + 3 modules
var send_email = __webpack_require__("b390");

// EXTERNAL MODULE: ./src/services/shipment.service.ts
var shipment_service = __webpack_require__("1af5");

// EXTERNAL MODULE: ./src/services/general_code.service.ts
var general_code_service = __webpack_require__("5083");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/shared/common/upload-file.vue + 3 modules
var upload_file = __webpack_require__("b912");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/shipment-detail.vue?vue&type=script&lang=ts&





















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var shipment_detailvue_type_script_lang_ts_ShipmentDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ShipmentDetail, _super);

  function ShipmentDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.selectedRowKeys = [];
    _this.processType = [{
      name: 'STOP',
      code: 'stop'
    }, {
      name: '40%',
      code: '40'
    }, {
      name: '60%',
      code: '60'
    }, {
      name: '80%',
      code: '80'
    }];
    _this.needProcess = [{
      name: 'Stop 20%',
      code: 'stop20'
    }, {
      name: 'Stop 40%',
      code: 'stop40'
    }, {
      name: 'Stop 60%',
      code: 'stop60'
    }, {
      name: 'Stop 80%',
      code: 'stop80'
    }, {
      name: 'WrongAA3',
      code: 'wrongaa3'
    }, {
      name: 'WrongAA4',
      code: 'wrongaa4'
    }, {
      name: 'WrongAA5',
      code: 'wrongaa5'
    }, {
      name: 'NE-Nicht erhalten 签收证明错误/没收到货',
      code: 'NE'
    }];
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.shipmentService = new shipment_service["a" /* ShipmentService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalCodeService = new general_code_service["a" /* GeneralCodeService */]();
    return _this;
  }

  ShipmentDetail.prototype.created = function () {};

  ShipmentDetail.prototype.mounted = function () {
    if (this.info.length) {
      this.data = this.info.map(function (x) {
        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        x.need_process = x.need_process ? x.need_process : '';
        x.process_type = x.process_type ? x.process_type : '';
        return x;
      });
    }
  };

  ShipmentDetail.prototype.onInfoChange = function () {
    if (this.info.length) {
      this.data = this.info.map(function (x) {
        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        x.need_process = x.need_process ? x.need_process : '';
        x.process_type = x.process_type ? x.process_type : '';
        return x;
      });
    } else {
      this.data = [];
    }
  };

  ShipmentDetail.prototype.onSaveShipmentChange = function () {
    if (this.saveShipment > 0) {
      this.saveBtn(false);
    }
  };

  ShipmentDetail.prototype.downloadPdf = function (row) {
    if (row.ship_url.indexOf('http') !== -1) {
      window.open(row.ship_url);
    } else {
      window.open(app_config["a" /* default */].server + '/shipment/get_shipment_pdf?attachment_id=' + row.attachment_id);
    }
  };

  ShipmentDetail.prototype.onDelPickNumber = function (row) {
    row.shipment_num = '';
    this.deleteShipment(row);
  };

  ShipmentDetail.prototype.onDel = function (row) {
    this.deleteShipmentNew(row);
  };

  ShipmentDetail.prototype.deleteShipment = function (row) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.shipmentService.deleteShipmentOrder(new http["RequestParams"]({
      shipment_id: parseInt(row.id)
    }, loading)).subscribe(function () {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      var msg = _this.$t('tips.delete_success');

      _this.$message.success(msg);
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  ShipmentDetail.prototype.deleteShipmentNew = function (row) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.deleteDhlShiDpment(new http["RequestParams"]({
      shipment_id: parseInt(row.id)
    }, loading)).subscribe(function () {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      var msg = _this.$t('tips.delete_success');

      _this.$message.success(msg);

      if (['dpd', 'ship_order', 'gls', 'return_order', 'bri', 'prime'].indexOf(row.smtype) != -1) {
        _this.data = _this.data.filter(function (x) {
          return x.id !== row.id;
        });
      } else {
        _this.getShipments();
      }
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  ShipmentDetail.prototype.sendRT = function (row) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.shipmentService.getSendData(new http["RequestParams"]({
      shipment_id: row.id
    }, loading)).subscribe(function (data) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$modal.open(send_email["a" /* default */], {
        model: 'shipmentManage',
        recordID: data[0].id,
        data: {
          orderId: data[0].order_id,
          templateId: data[0].template_id,
          attachmentList: [data[0].attachment_id],
          filename: row.shipment_num + '.pdf'
        },
        changeSpinning: _this.changeSpinning
      }, {
        title: _this.$t('actions.send_rt'),
        width: '1000px'
      }).subscribe(function (data) {});
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShipmentDetail.prototype.toTrackShip = function (row) {
    if (row.shipment_num) {
      var v = row.shipment_num;
      var ship_type = row.smtype; // var gls_track_id = row_data['gls_track_id'].value;

      if (v.length <= 1) {
        this.$message.error('undefined order name');
      } // var url = "http://nolp.dhl.de/nextt-online-public/set_identcodes.do?lang=de&idc=" + v;


      var url = 'https://www.dhl.de/de/privatkunden/pakete-empfangen/verfolgen.html?piececode=' + v;

      if (ship_type == 'dpd' || ship_type == 'prime') {
        url = 'https://tracking.dpd.de/status/en_US/parcel/' + v;
      }

      if (ship_type == 'gls') {
        url = 'https://gls-group.eu/app/service/closed/page/DE/de/witt004#/edit/' + v;
      }

      if (ship_type == 'HERM_48' || ship_type == 'HERM_48_LL') {
        url = 'https://new.myhermes.co.uk/track.html#/parcel/' + v + '/details';
      }

      if (ship_type == 'GB_DHL_PAR') {
        url = 'https://track.dhlparcel.co.uk/?con=' + v + '&nav=1';
      }

      if (ship_type == 'RM_TR48') {
        url = 'https://www.royalmail.com/track-your-item#/tracking-results/' + v;
      }

      if (ship_type == 'GB_DX') {
        url = 'https://my.dxdelivery.com?t=' + v + '&p=' + (row.postcode ? row.postcode : ''); //加邮编
      }

      if (ship_type == 'XDPUK') {
        url = 'https://www.xdp.co.uk/track.php?c=' + v + '&code=' + (row.postcode ? row.postcode : ''); //加邮编
      }

      if (ship_type == 'GB_DPD_C1') {
        url = 'https://t.17track.net/en#nums=' + v + '&fc=100010';
      }

      if (ship_type == 'TUFFNELLS_P1') {
        url = 'https://www.tuffnells.co.uk/track-and-trace/' + v;
      }

      if (['YDL_MP48S', 'YDL_LP48S', 'YDL_XL'].includes(ship_type)) {
        url = 'https://www.yodel.co.uk/track?error=5&parcel_id=' + v + '&postcode=' + (row.postcode ? row.postcode : ''); //加邮编
      }

      if (ship_type == 'return_order2' || ship_type == 'return_order') {
        if (v.length == '56760141212'.length && v.indexOf('5') == 0) {
          url = 'https://www.gls-pakete.de/sendungsverfolgung?trackingNumber=' + v;
        } else if (v.length == '01425063371295'.length && v.indexOf('0') == 0) {
          url = 'https://tracking.dpd.de/status/en_US/parcel/' + v;
        }
      }

      window.open(url);
    }
  };

  ShipmentDetail.prototype.saveBtn = function (showMessage) {
    var _this = this;

    if (showMessage === void 0) {
      showMessage = true;
    }

    var list = [];

    for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
      var i = _a[_i];
      list.push({
        save_flag: 1,
        id: i.id,
        smtype: i.smtype,
        display_product: i.display_product,
        prime_item_id: i.prime_item_id,
        latest_status: i.latest_status,
        need_process: i.need_process,
        processed_time_logi: i.processed_time_logi,
        processed_time_cs: i.processed_time_cs,
        process_type: i.process_type
      });
    }

    var loading = {};

    if (showMessage) {
      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }
    }

    this.pickingService.saveShipmentInfo(new http["RequestParams"]({
      picking_id: parseInt(this.id),
      shipment_list: list
    }, loading)).subscribe(function () {
      if (showMessage) {
        var msg = _this.$t('tips.save_success');

        _this.$message.success(msg);

        if (_this.changeSpinning) {
          _this.changeSpinning(false);
        }
      }
    }, function (err) {
      if (showMessage) {
        if (_this.changeSpinning) {
          _this.changeSpinning(false);
        }

        _this.$message.error(err.message);
      }
    });
  };

  ShipmentDetail.prototype.cancelBtn = function () {
    this.currentRow = -1;
    this.getShipments();
  };

  ShipmentDetail.prototype.getShipments = function () {
    var _this = this;

    this.pickingService.queryShipment(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    })).subscribe(function (data) {
      _this.data = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: uuid_default.a.generate()
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShipmentDetail.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]') {
      row[column] = value.target.value;
    } else {
      row[column] = value;
    }
  };

  ShipmentDetail.prototype.onUpload = function (row) {
    var _this = this;

    this.$modal.open(upload_file["a" /* default */], {
      urlPath: '/system_api/upload?inner_action=/shipment/upload_shipment_pic&menu_code=' + common_service["a" /* CommonService */].getMenuCode('picking-manage'),
      info: row.id
    }, {
      title: 'Upload Files',
      width: '800px'
    }).subscribe(function (data) {
      _this.$message.success('上传成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShipmentDetail.prototype.revertPdf = function (row) {
    var _this = this;

    this.innerAction.setActionAPI('/shipment/revert_shipment_pic', common_service["a" /* CommonService */].getMenuCode('picking-manage'));
    this.publicService.modify(new http["RequestParams"]({
      id: row.id
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功');
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentDetail.prototype, "shipTypeList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 0,
    type: Number
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentDetail.prototype, "saveShipment", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ShipmentDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('saveShipment'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ShipmentDetail.prototype, "onSaveShipmentChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentDetail.prototype, "changeSpinning", void 0);

  ShipmentDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      TextEditCell: text_edit_cell["a" /* default */],
      SendEmail: send_email["a" /* default */],
      UploadFile: upload_file["a" /* default */]
    }
  })], ShipmentDetail);
  return ShipmentDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var shipment_detailvue_type_script_lang_ts_ = (shipment_detailvue_type_script_lang_ts_ShipmentDetail);
// CONCATENATED MODULE: ./src/components/picking/shipment-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_shipment_detailvue_type_script_lang_ts_ = (shipment_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/shipment-detail.vue?vue&type=custom&index=0&blockType=i18n
var shipment_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("7bff");

// CONCATENATED MODULE: ./src/components/picking/shipment-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_shipment_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof shipment_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(shipment_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var shipment_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "0a7b":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"log":"Log","type":"Type","operater":"Operater","date":"Date"},"zh-cn":{"log":"日志","type":"类型","operater":"操作人","date":"日期"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "0b09":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/shipment-list-content.vue?vue&type=template&id=93232628&
var render = function () {
var this$1 = this;
var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('data-form',{ref:"dataForm",attrs:{"extends":_vm.extendItems,"column":2,"showSearch":_vm.showSearch},on:{"submit":_vm.getShipmentList},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.picking_name')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['picking_name']),expression:"['picking_name']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.shipment_num')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['shipment_num']),expression:"['shipment_num']"}],style:({ width: '351px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.pre_sale')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pick_pre_sale', { initialValue: '' }]),expression:"['pick_pre_sale', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.merge_time')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['merge_time']),expression:"['merge_time']"}],attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm","size":"small"}})],1)]},proxy:true}])}),_c('a-card',{staticClass:"margin-y autoFlex",staticStyle:{"margin":"0 !important"}},[_c('data-table',{staticStyle:{"table-layout":"fixed"},attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"rowKey":"id","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
            },"scroll":{ y: 499 }},on:{"on-page-change":_vm.getShipmentList,"onClick":function (record) {
                    this$1.selectedRowKeys = [record]
                }}},[_c('a-table-column',{key:"shipment_num",attrs:{"title":_vm.$t('shipment_order'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.shipment_num)+" "),_c('a',{on:{"click":function($event){return _vm.toTrackShip(row)}}},[_c('a-icon',{staticStyle:{"font-size":"18px","margin-left":"5px"},attrs:{"type":"search"}})],1)]}}])}),_c('a-table-column',{key:"ship_url",attrs:{"title":_vm.$t('pdf'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{directives:[{name:"show",rawName:"v-show",value:(row.shipment_num),expression:"row.shipment_num"}],on:{"click":function($event){return _vm.downloadPdf(row)}}},[_vm._v("预览")])]}}])}),_c('a-table-column',{key:"smtype",attrs:{"title":_vm.$t('shipment_order_type'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.smtype,_vm.shipTypeList))+" ")])]}}])}),_c('a-table-column',{key:"user_id",attrs:{"title":_vm.$t('create_user'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.user_id,_vm.systemUsers))+" ")]}}])}),_c('a-table-column',{key:"display_product",attrs:{"title":_vm.$t('sent_product'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.display_product))])]}}])}),_c('a-table-column',{key:"location_product",attrs:{"title":_vm.$t('location_sort'),"data-index":"location_product","align":"center"}}),_c('a-table-column',{key:"prime_item_id",attrs:{"title":_vm.$t('prime_item_id'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.prime_item_id))])]}}])}),_c('a-table-column',{key:"ship_date",attrs:{"title":_vm.$t('ceate_time'),"data-index":"ship_date","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(ship_date){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(ship_date))+" ")]}}])}),_c('a-table-column',{key:"merge_time",attrs:{"title":_vm.$t('merge_time'),"data-index":"merge_time","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(merge_time){return [_vm._v(" "+_vm._s(_vm._f("datetolocal")(merge_time))+" ")]}}])}),_c('a-table-column',{key:"picking_name",attrs:{"title":_vm.$t('picking_name'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(" "+_vm._s(row.picking_name)+" ")])]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{staticStyle:{"margin-left":"10px"},attrs:{"title":_vm.$t('actions.send_rt')},on:{"click":function($event){return _vm.sendRT(row)}}},[_c('a-icon',{attrs:{"type":"mail"}})],1)]}}])})],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/shipment-list-content.vue?vue&type=template&id=93232628&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/decorators/index.ts + 1 modules
var decorators = __webpack_require__("16e0");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/services/shipment.service.ts
var shipment_service = __webpack_require__("1af5");

// EXTERNAL MODULE: ./src/services/general_code.service.ts
var general_code_service = __webpack_require__("5083");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/components/common/send-email.vue + 3 modules
var send_email = __webpack_require__("b390");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/shipment-list-content.vue?vue&type=script&lang=ts&


















var userModule = Object(lib["c" /* namespace */])('userModule');
var datasModule = Object(lib["c" /* namespace */])('datasModule');

var shipment_list_contentvue_type_script_lang_ts_ShipmentListContent =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ShipmentListContent, _super);

  function ShipmentListContent() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.showSearch = true;
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.shipmentService = new shipment_service["a" /* ShipmentService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalCodeService = new general_code_service["a" /* GeneralCodeService */](); // 分页服务

    _this.pageService = new page_service["a" /* PageService */](); // 表格数据源

    _this.data = []; // 表格选择项

    _this.selectedRowKeys = [];
    _this.stateList = '';
    _this.caseTypeList = '';
    _this.processType = [{
      name: 'STOP',
      code: 'stop'
    }, {
      name: '40%',
      code: '40'
    }, {
      name: '60%',
      code: '60'
    }, {
      name: '80%',
      code: '80'
    }];
    _this.needProcess = [{
      name: 'Stop 20%',
      code: 'stop20'
    }, {
      name: 'Stop 40%',
      code: 'stop40'
    }, {
      name: 'Stop 60%',
      code: 'stop60'
    }, {
      name: 'Stop 80%',
      code: 'stop80'
    }, {
      name: 'WrongAA3',
      code: 'wrongaa3'
    }, {
      name: 'WrongAA4',
      code: 'wrongaa4'
    }, {
      name: 'WrongAA5',
      code: 'wrongaa5'
    }, {
      name: 'NE-Nicht erhalten 签收证明错误/没收到货',
      code: 'NE'
    }];
    return _this;
  }

  ShipmentListContent.prototype.showhideSearch = function (flag) {
    this.showSearch = flag;
  };

  Object.defineProperty(ShipmentListContent.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });
  Object.defineProperty(ShipmentListContent.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });
  /**
   * 获取订单数据
   */

  ShipmentListContent.prototype.getShipmentList = function () {
    var _this = this;

    this.dataForm.validateFields().then(function (values) {
      var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
        picking_name: 'in_or_like',
        shipment_num: 'in_or_like',
        smtype: '='
      }, form_config["a" /* formConfig */].condition));
      var nowConditions = [];

      for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
        var item = _a[_i];

        if (item.value.constructor == Array && item.operate !== 'in') {
          if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
            var startDate = {};

            for (var key in item.value[0]) {
              startDate[key] = item.value[0][key];
            }

            var vle = new Date(startDate.utc()); // if (item.query_name === 'latest_ship_date_new') {
            //     vle = new Date(
            //         startDate.format('YYYY-MM-DD HH:mm:ss')
            //     )
            // }

            nowConditions.push({
              query_name: item.query_name,
              operate: '>=',
              value: vle
            });
          }

          if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
            var endDate = {};

            for (var key in item.value[1]) {
              endDate[key] = item.value[1][key];
            }

            var vle = new Date(endDate.utc()); // if (item.query_name === 'latest_ship_date_new') {
            //     vle = new Date(
            //         endDate.format('YYYY-MM-DD HH:mm:ss')
            //     )
            // }

            nowConditions.push({
              query_name: item.query_name,
              operate: '<=',
              value: vle
            });
          }
        } else {
          nowConditions.push(item);
        }
      }

      params.query_condition = nowConditions;

      _this.shipmentService.getShipmentList(new http["RequestParams"](params, {
        page: _this.pageService,
        loading: _this.loadingService
      })).subscribe(function (data) {
        _this.data = data;
        _this.selectedRowKeys = [];
      }, function (err) {
        _this.$message.error(err.message);
      });
    });
  };

  ShipmentListContent.prototype.onStatusChange = function (e) {};

  ShipmentListContent.prototype.downloadPdf = function (row) {
    if (row.ship_url.indexOf('http') !== -1) {
      window.open(row.ship_url);
    } else {
      window.open(app_config["a" /* default */].server + '/shipment/get_shipment_pdf?attachment_id=' + row.attachment_id);
    }
  };

  ShipmentListContent.prototype.deleteShipment = function (row) {
    var _this = this;

    this.shipmentService.deleteShipmentOrder(new http["RequestParams"]({
      shipment_id: parseInt(row.id)
    }, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this.$t('tips.delete_success');

      _this.$message.success(msg);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShipmentListContent.prototype.deleteShipmentNew = function (row) {
    var _this = this;

    this.pickingService.deleteDhlShiDpment(new http["RequestParams"]({
      shipment_id: parseInt(row.id)
    }, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this.$t('tips.delete_success');

      _this.$message.success(msg);

      _this.data = _this.data.filter(function (x) {
        return x.id !== row.id;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShipmentListContent.prototype.sendRT = function (row) {
    var _this = this;

    this.shipmentService.getSendData(new http["RequestParams"]({
      shipment_id: row.id
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.$modal.open(send_email["a" /* default */], {
        model: 'shipmentManage',
        recordID: data[0].id,
        data: {
          orderId: data[0].order_id,
          templateId: data[0].template_id,
          attachmentList: [data[0].attachment_id],
          filename: row.shipment_num + '.pdf'
        }
      }, {
        title: _this.$t('actions.send_rt'),
        width: '1000px'
      }).subscribe(function (data) {});
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShipmentListContent.prototype.toTrackShip = function (row) {
    if (row.shipment_num) {
      var v = row.shipment_num;
      var ship_type = row.smtype; // var gls_track_id = row_data['gls_track_id'].value;

      if (v.length <= 1) {
        this.$message.error('undefined order name');
      } // var url = "http://nolp.dhl.de/nextt-online-public/set_identcodes.do?lang=de&idc=" + v;


      var url = 'https://www.dhl.de/de/privatkunden/pakete-empfangen/verfolgen.html?piececode=' + v;

      if (ship_type == 'dpd' || ship_type == 'prime') {
        url = 'https://tracking.dpd.de/status/en_US/parcel/' + v;
      }

      if (ship_type == 'gls') {
        url = 'https://gls-group.eu/app/service/closed/page/DE/de/witt004#/edit/' + v;
      }

      if (ship_type == 'HERM_48') {
        url = 'https://new.myhermes.co.uk/track.html#/parcel/' + v + '/details';
      }

      if (ship_type == 'GB_DHL_PAR') {
        url = 'https://track.dhlparcel.co.uk/?con=' + v + '&nav=1';
      }

      if (ship_type == 'RM_TR48') {
        url = 'https://www.royalmail.com/track-your-item#/tracking-results/' + v;
      }

      if (ship_type == 'return_order2' || ship_type == 'return_order') {
        if (v.length == '56760141212'.length && v.indexOf('5') == 0) {
          url = 'https://www.gls-pakete.de/sendungsverfolgung?trackingNumber=' + v;
        } else if (v.length == '01425063371295'.length && v.indexOf('0') == 0) {
          url = 'https://tracking.dpd.de/status/en_US/parcel/' + v;
        }
      }

      window.open(url);
    }
  };

  var _a;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], ShipmentListContent.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentListContent.prototype, "page_flag", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentListContent.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([userModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentListContent.prototype, "username", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentListContent.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentListContent.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentListContent.prototype, "shipTypeList", void 0);

  ShipmentListContent = tslib_es6["c" /* __decorate */]([Object(decorators["a" /* Page */])({
    layout: 'workspace',
    name: 'shipment-list'
  }), Object(vue_property_decorator["a" /* Component */])({
    components: {
      SendEmail: send_email["a" /* default */]
    }
  })], ShipmentListContent);
  return ShipmentListContent;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var shipment_list_contentvue_type_script_lang_ts_ = (shipment_list_contentvue_type_script_lang_ts_ShipmentListContent);
// CONCATENATED MODULE: ./src/components/picking/shipment-list-content.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_shipment_list_contentvue_type_script_lang_ts_ = (shipment_list_contentvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/shipment-list-content.vue?vue&type=custom&index=0&blockType=i18n
var shipment_list_contentvue_type_custom_index_0_blockType_i18n = __webpack_require__("a558");

// CONCATENATED MODULE: ./src/components/picking/shipment-list-content.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_shipment_list_contentvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof shipment_list_contentvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(shipment_list_contentvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var shipment_list_content = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "11ef":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-base-detail.vue?vue&type=template&id=21aaf5ef&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-data"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px"}},[_c('a-button',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.saveBtn()}}},[_vm._v(_vm._s(_vm.$t('save'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.cancelBtn}},[_vm._v(_vm._s(_vm.$t('cancel'))+" ")]),_c('div',{staticStyle:{"float":"right"}},[_c('div',{staticClass:"progress-bar",staticStyle:{"float":"left"}},_vm._l((_vm.$dict.PickingStatus),function(item){return _c('li',{key:item.value,class:{ active: _vm.data.state == item.value },attrs:{"value":item.value}},[_c('span',[_vm._v(_vm._s(_vm.$t(item.label)))])])}),0)])],1),_c('table',{staticClass:"xgtb2"},[_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('partner')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.partner_id)+" ")]),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('scheduled_date')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm._f("datetolocal")(_vm.data.min_date))+" ")])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('partner_name')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.data.partner_name && _vm.data.partner_name.length > 35
                            ? 'color:red'
                            : 'color:#666'),attrs:{"value":_vm.data.partner_name,"size":"small","title":_vm.messageTips(_vm.data.partner_name)},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'partner_name'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('source_document')))]),_c('td',{staticClass:"sencond-td"},[_c('a',{on:{"click":function($event){return _vm.toPageOrder(_vm.data.origin)}}},[_vm._v(" "+_vm._s(_vm.data.origin)+" ")])])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('company')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.data.name2 && _vm.data.name2.length > 35
                            ? 'color:red'
                            : 'color:#666'),attrs:{"value":_vm.data.name2,"size":"small","title":_vm.messageTips(_vm.data.name2)},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'name2'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('ebay_buyer_id')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(_vm._s(_vm.data.ebay_buyer_id))])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('street')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.data.street && _vm.data.street.length > 35
                            ? 'color:red'
                            : 'color:#666'),attrs:{"value":_vm.data.street,"size":"small","title":_vm.messageTips(_vm.data.street)},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'street'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('payment_date')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm._f("datetolocal")(_vm.data.payment_date))+" ")])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('nr')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.nr_1,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'nr_1'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('weight')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.weight1,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'weight1'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('street2')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},style:(_vm.data.street2 && _vm.data.street2.length > 35
                            ? 'color:red'
                            : 'color:#666'),attrs:{"value":_vm.data.street2,"size":"small","title":_vm.messageTips(_vm.data.street2)},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'street2'); }}})],1),_c('td',{staticClass:"first-td",staticStyle:{"font-weight":"bold","color":"red","vertical-align":"top"}},[_vm._v(" "+_vm._s(_vm.$t('shipment_content'))+" ")]),_c('td',{staticClass:"sencond-td"},[_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.shipment_content,"size":"small","rows":"2","cols":"40"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'shipment_content'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('zip')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.zip,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'zip'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('validate_state')))]),_c('td',{staticClass:"sencond-td"},[_c('span',{style:({ color: _vm.calcStyle(_vm.data.validate_s) })},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(_vm.data.validate_s,'PickingValidateState'))))])])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('city')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.city,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'city'); }}})],1),_c('td',{staticClass:"first-td",staticStyle:{"vertical-align":"top"}},[_vm._v(" "+_vm._s(_vm.$t('validate_error_text'))+" ")]),_c('td',{staticClass:"sencond-td"},[_c('a-textarea',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.validate_err,"size":"small","rows":"2","cols":"40"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'validate_err'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('country')))]),_c('td',{staticClass:"sencond-td"},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['country_id']),expression:"['country_id']"}],style:({ width: '200px' }),attrs:{"showSearch":"","value":_vm.data.country_id,"size":"small","filterOption":_vm.filterSelectOption,"placeholder":"Select Country"},on:{"change":function (e) { return _vm.handleChange(e, 'country_id'); }}},_vm._l((_vm.countryList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name)+" ")])}),1),_c('a-button',{staticStyle:{"float":"right","margin-right":"10%"},attrs:{"type":"danger"},on:{"click":_vm.googleMap}},[_vm._v("Google Map ")])],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('pre_sale')))]),_c('td',{staticClass:"sencond-td"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"checked":!!_vm.data.pick_pre_sale,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'pick_pre_sale'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('email')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.email,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'email'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('send_gift')))]),_c('td',{staticClass:"sencond-td"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"checked":!!_vm.data.send_gift,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'send_gift'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('phone')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.phone,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'phone'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('send_warehouse')))]),_c('td',{staticClass:"sencond-td"},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['send_warehouse']),expression:"['send_warehouse']"}],style:({ width: '200px' }),attrs:{"value":_vm.data.send_warehouse,"size":"small","placeholder":"Select Warehouse"},on:{"change":function (e) { return _vm.handleChange(e, 'send_warehouse'); }}},_vm._l((_vm.$dict.WarehouseList),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])}),1)],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('shipment_number')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.shipment_number)+" ")]),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('updated_in_platform')))]),_c('td',{staticClass:"sencond-td"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"checked":!!_vm.data.updated_in_platform,"size":"small"},on:{"change":function (e) { return _vm.handleChange(
                                e.target.checked,
                                'updated_in_platform'
                            ); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('fake_shipment')))]),_c('td',{staticClass:"sencond-td"},[_c('a-input',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.fake_shipment,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'fake_shipment'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('confirm_return_time')))]),_c('td',{staticClass:"sencond-td"},[_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.confirm_return_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'confirm_return_time'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('check_shipments')))]),_c('td',{staticClass:"sencond-td"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"checked":!!_vm.data.check_number,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'check_number'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('resend')))]),_c('td',{staticClass:"sencond-td"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"checked":!!_vm.data.is_resend,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'is_resend'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('sold_out')))]),_c('td',{staticClass:"sencond-td"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"checked":!!_vm.data.is_sold_out,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.checked, 'is_sold_out'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('return_process_time')))]),_c('td',{staticClass:"sencond-td"},[_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.return_process_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'return_process_time'); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('sold_out_time')))]),_c('td',{staticClass:"sencond-td"},[_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.sold_out_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'sold_out_time'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('assign_to_user')))]),_c('td',{staticClass:"sencond-td"},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['assign_to_user']),expression:"['assign_to_user']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Select User"},on:{"change":function (e) { return _vm.handleChange(e, 'assign_to_user'); }}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name)+" ")])}),1)],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('container_time')))]),_c('td',{staticClass:"sencond-td"},[_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.container_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'container_time'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('remote_district')))]),_c('td',{staticClass:"sencond-td"},[_c('a-checkbox',{staticStyle:{"width":"3%","margin":"3px 0"},attrs:{"checked":!!_vm.data.remote_district,"size":"small"},on:{"change":function (e) { return _vm.handleChange(
                                e.target.checked,
                                'remote_district'
                            ); }}})],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('user_continue')))]),_c('td',{staticClass:"sencond-td"},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['continue_user']),expression:"['continue_user']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"Select User"},on:{"change":function (e) { return _vm.handleChange(e, 'continue_user'); }}},_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])}),1)],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('ebay_type')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.stock_ebay3)+" ")])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('service_process')))]),_c('td',{staticClass:"sencond-td"},[_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.cs_process_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'cs_process_time'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('amazon_type')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.stock_amazon3)+" ")])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('stock_process')))]),_c('td',{staticClass:"sencond-td"},[_c('a-date-picker',{staticStyle:{"width":"90%","margin":"3px 0"},attrs:{"value":_vm.data.stock_process_time,"size":"small","format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.handleChange(e, 'stock_process_time'); }}})],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('instance')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.swichInstanceName(_vm.data.instance_code))+" ")])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('latest_ship_date')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.latest_ship_date_new)+" ")]),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('latest_delivery_date_new')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.latest_delivery_date_new)+" ")])]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('ship_method')))]),_c('td',{staticClass:"sencond-td"},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_method']),expression:"['ship_method']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"PLZ Select"},on:{"change":function (e) { return _vm.handleChange(e, 'ship_method'); }}},_vm._l((_vm.shipMethodList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])}),1)],1),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('need_resend_memo')))]),_c('td',{staticClass:"sencond-td"},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['need_resend']),expression:"['need_resend']"}],style:({ width: '200px' }),attrs:{"size":"small","placeholder":"PLZ Select"},on:{"change":function (e) { return _vm.handleChange(e, 'need_resend'); }}},_vm._l((_vm.resendMemoList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])}),1)],1)]),_c('tr',[_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('fee')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.shipment_fee)+" ")]),_c('td',{staticClass:"first-td"},[_vm._v(_vm._s(_vm.$t('total')))]),_c('td',{staticClass:"sencond-td"},[_vm._v(" "+_vm._s(_vm.data.amount_total ? _vm.data.amount_total.toFixed(2) : '')+" ")])]),_c('tr',[_c('td',{staticClass:"first-td",staticStyle:{"vertical-align":"top"}},[_vm._v(" "+_vm._s(_vm.$t('memo'))+" ")]),_c('td',{staticClass:"sencond-td",attrs:{"colspan":"3"}},[_c('a-textarea',{staticStyle:{"width":"96%","margin":"8px 0","height":"160px"},attrs:{"value":_vm.data.memo,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e.target.value, 'memo'); }}})],1)])])])}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/picking-base-detail.vue?vue&type=template&id=21aaf5ef&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__("fb6a");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.number.constructor.js
var es_number_constructor = __webpack_require__("a9e3");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/services/general.service.ts
var general_service = __webpack_require__("2219");

// EXTERNAL MODULE: ./src/services/general_code.service.ts
var general_code_service = __webpack_require__("5083");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./src/services/seller-instance.service.ts
var seller_instance_service = __webpack_require__("5c97");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-base-detail.vue?vue&type=script&lang=ts&

















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var picking_base_detailvue_type_script_lang_ts_PickingBasedata =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PickingBasedata, _super);

  function PickingBasedata() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalService = new general_service["a" /* GeneralService */]();
    _this.generalCodeService = new general_code_service["a" /* GeneralCodeService */]();
    _this.sellerInstanceService = new seller_instance_service["a" /* SellerInstanceService */]();
    _this.data = {};
    _this.editable = false;
    _this.pre_sale = false;
    _this.resendMemoList = [];
    _this.shipMethodList = [];
    _this.instanceCodeList = [];
    _this.originData = [];
    return _this;
  }

  PickingBasedata.prototype.created = function () {
    this.getResendMemoList();
    this.getShipMethodList();
  };

  PickingBasedata.prototype.mounted = function () {
    this.data = Object.assign({}, this.info);
    this.originData = Object.assign({}, this.info);

    if (this.data.seller_code) {
      this.getInstanceCodeList(this.data.seller_code);
    }
  };

  PickingBasedata.prototype.onInfoChange = function () {
    this.data = Object.assign({}, this.info);
    this.originData = Object.assign({}, this.info);

    if (this.data.seller_code) {
      this.getInstanceCodeList(this.data.seller_code);
    }
  };

  PickingBasedata.prototype.onSaveDetailChange = function () {
    if (this.saveDetail > 0) {
      this.validateAddress();
    }
  };

  PickingBasedata.prototype.validateAddress = function () {
    var _this = this;

    var params = [];
    params.push({
      id: this.data.id,
      partner_name: this.data.partner_name,
      name2: this.data.name2,
      street: this.data.street,
      nr_1: this.data.nr_1,
      street2: this.data.street2,
      zip: this.data.zip,
      city: this.data.city,
      country_id: this.data.country_id,
      email: this.data.email,
      phone: this.data.phone
    });
    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.validateAddress(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)],
      picking_address_list: params
    }, loading)).subscribe(function (data) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$emit('validateAds');

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      if (_this.pageShow) {
        _this.setPickingSaveStatus(_this.pickingNeedSave.replace('p-' + _this.data.id, ''));
      }
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$emit('validateAds');

      _this.$message.error(err.message);
    });
  };

  PickingBasedata.prototype.editBtn = function () {
    this.editable = !this.editable;
  };

  PickingBasedata.prototype.handleChange = function (value, key) {
    this.data[key] = value;

    if (this.pageShow) {
      if (this.compareData(this.originData, this.data)) {
        if (this.pickingNeedSave.indexOf('p-' + this.data.id) < 0) {
          this.setPickingSaveStatus(this.pickingNeedSave + 'p-' + this.data.id);
        }
      } else {
        this.setPickingSaveStatus(this.pickingNeedSave.replace('p-' + this.data.id, ''));
      }
    }
  };

  PickingBasedata.prototype.compareData = function (data1, data2) {
    var ret = 0;

    for (var i in data1) {
      if ((data1[i] || data2[i]) && data1[i] !== data2[i]) {
        ret = 1;
        break;
      }
    }

    return ret;
  };

  PickingBasedata.prototype.getInstanceCodeList = function (key) {
    var _this = this;

    this.sellerInstanceService.queryInstanceBySellerCode(new http["RequestParams"]({
      seller_code: key
    })).subscribe(function (data) {
      _this.instanceCodeList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingBasedata.prototype.swichInstanceName = function (value) {
    var ret = value;
    var item = this.instanceCodeList.find(function (x) {
      return x.code == value;
    });

    if (item) {
      ret = item.name;
    }

    return ret;
  };

  PickingBasedata.prototype.messageTips = function (value) {
    if (value && value.length > 35) {
      value = value.slice(0, 35) + '@kss' + value.slice(35);
    }

    return value;
  };

  PickingBasedata.prototype.calcStyle = function (state) {
    if (state === 'ok') {
      return 'green';
    } else if (state === 'error') {
      return 'red';
    } else {
      return 'blue';
    }
  };

  PickingBasedata.prototype.saveBtn = function () {
    var _this = this;

    this.data['save_flag'] = 1;
    delete this.data.amount_total;
    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.save(new http["RequestParams"](this.data, loading)).subscribe(function () {
      _this.reset_save_data(_this.data.id);

      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    }); // this.editable = false
  };

  PickingBasedata.prototype.cancelBtn = function () {
    this.data = Object.assign({}, this.info); // this.editable = false

    this.updatePickingInfo();

    if (this.pageShow) {
      this.setPickingSaveStatus(this.pickingNeedSave.replace('p-' + this.data.id, ''));
    }
  };

  PickingBasedata.prototype.createShipment = function (picking_id) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    if (this.pickingNeedSave.indexOf('p-' + picking_id) >= 0) {
      this.data['save_flag'] = 1;
      delete this.data.amount_total;
      this.pickingService.save(new http["RequestParams"](this.data, loading)).subscribe(function () {
        _this.reset_save_data(picking_id);

        _this.createShipmentsLines(picking_id, loading);
      }, function (err) {
        if (_this.changeSpinning) {
          _this.changeSpinning(false);
        }

        _this.$message.error(err.message);
      });
    } else {
      this.createShipmentsLines(picking_id, loading);
    }
  };

  PickingBasedata.prototype.reset_save_data = function (picking_id) {
    this.originData = Object.assign({}, this.data);

    if (this.pageShow) {
      this.setPickingSaveStatus(this.pickingNeedSave.replace('p-' + this.data.id, ''));
    }
  };

  PickingBasedata.prototype.createShipmentsLines = function (picking_id, loading) {
    var _this = this;

    this.pickingService.createShipmentsLines(new http["RequestParams"]({
      picking_id_list: [picking_id]
    }, loading)).subscribe(function () {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  PickingBasedata.prototype.updatePickingInfo = function () {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.queryDetail(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, loading)).subscribe(function (data) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      data[0]['id'] = parseInt(_this.id);
      _this.originData = data[0];
      _this.data = Object.assign({}, data[0]);
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  PickingBasedata.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PickingBasedata.prototype.getResendMemoList = function () {
    var _this = this;

    this.generalService.queryResendMemo(new http["RequestParams"]({})).subscribe(function (data) {
      _this.resendMemoList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingBasedata.prototype.getShipMethodList = function () {
    var _this = this;

    this.generalCodeService.queryShipType(new http["RequestParams"]({})).subscribe(function (data) {
      _this.shipMethodList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  PickingBasedata.prototype.googleMap = function () {
    var _this = this;

    var url = 'http://maps.google.com/maps?oi=map&q=';

    if (this.data.street) {
      url += this.data.street.replace(' ', '+');
    }

    if (this.data.nr_1) {
      url += this.data.nr_1.replace(' ', '+');
    }

    if (this.data.zip) {
      url += '+' + this.data.zip.replace(' ', '+');
    }

    if (this.data.city) {
      url += '+' + this.data.city.replace(' ', '+');
    }

    if (this.data.country_id) {
      var country = this.countryList.find(function (x) {
        return x.id === _this.data.country_id;
      });

      if (country) {
        url += '+' + country.replace(' ', '+');
      }
    }

    window.open(url);
  };

  PickingBasedata.prototype.toPageOrder = function (origin) {
    //判断如果是邮件页面，在新页面打开订单管理页面
    if (this.changeSpinning) {
      var url = this.$router.resolve({
        name: 'order-manage',
        query: {
          origin: origin
        }
      });
      window.open(url.href, '_blank');
    } else {
      router["a" /* default */].push({
        name: 'order-manage',
        params: {
          origin: origin
        }
      });
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 0,
    type: Number
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "saveDetail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: false
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "pageShow", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "pickingNeedSave", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Mutation, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingBasedata.prototype, "setPickingSaveStatus", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingBasedata.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('saveDetail'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingBasedata.prototype, "onSaveDetailChange", null);

  PickingBasedata = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PickingBasedata);
  return PickingBasedata;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var picking_base_detailvue_type_script_lang_ts_ = (picking_base_detailvue_type_script_lang_ts_PickingBasedata);
// CONCATENATED MODULE: ./src/components/picking/picking-base-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_picking_base_detailvue_type_script_lang_ts_ = (picking_base_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/picking-base-detail.vue?vue&type=style&index=0&lang=css&
var picking_base_detailvue_type_style_index_0_lang_css_ = __webpack_require__("005d");

// EXTERNAL MODULE: ./src/components/picking/picking-base-detail.vue?vue&type=style&index=1&lang=css&
var picking_base_detailvue_type_style_index_1_lang_css_ = __webpack_require__("4612");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/picking-base-detail.vue?vue&type=custom&index=0&blockType=i18n
var picking_base_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("1999");

// CONCATENATED MODULE: ./src/components/picking/picking-base-detail.vue







/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_picking_base_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof picking_base_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(picking_base_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var picking_base_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "12c5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("197d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "196d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/shipment-type-edit.vue?vue&type=template&id=2c1cd7e6&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 6 },"wrapperCol":{ span: 16, offset: 2 }}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.ship_type'),"required":""}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                    'ship_type',
                    {
                        rules: _vm.rules.required
                    }
                ]),expression:"[\n                    'ship_type',\n                    {\n                        rules: rules.required\n                    }\n                ]"}],attrs:{"showSearch":"","size":"small"}},_vm._l((_vm.shipTypeList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1),_c('a-form-item',{attrs:{"label":_vm.$t('columns.rel_name'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                    "rel_name",
                    {
                        rules: _vm.rules.required
                    }
                ]),expression:"[\n                    `rel_name`,\n                    {\n                        rules: rules.required\n                    }\n                ]"}],attrs:{"size":"small"}})],1),_c('a-form-item',{attrs:{"label":_vm.$t('columns.tms_ship_code'),"required":""}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                    'tms_ship_code',
                    {
                        rules: _vm.rules.required
                    }
                ]),expression:"[\n                    'tms_ship_code',\n                    {\n                        rules: rules.required\n                    }\n                ]"}],staticStyle:{"width":"120px"},attrs:{"size":"small"}})],1),_c('a-form-item',{attrs:{"label":_vm.$t('columns.seller_code_list')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['seller_code_list']),expression:"['seller_code_list']"}],attrs:{"showSearch":"","mode":"multiple","size":"small","filterOption":_vm.filterSelectOption}},_vm._l((_vm.sellerList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1),_c('a-form-item',{attrs:{"label":_vm.$t('columns.warehouse_name_list')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(["warehouse_name_list"]),expression:"[`warehouse_name_list`]"}],attrs:{"size":"small"}})],1),_c('a-form-item',{attrs:{"label":_vm.$t('columns.country_code_list')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['country_code_list']),expression:"['country_code_list']"}],attrs:{"showSearch":"","mode":"multiple","filterOption":_vm.filterSelectOption,"size":"small"}},_vm._l((_vm.countryList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" ["+_vm._s(item.code)+"]"+_vm._s(item.name)+" ")])}),1)],1),_c('a-form-item',{attrs:{"label":_vm.$t('columns.package_size')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['package_size']),expression:"['package_size']"}],attrs:{"size":"small"}},_vm._l((_vm.$dict.PackageSize),function(item){return _c('a-select-option',{key:item.value,attrs:{"value":item.value}},[_vm._v(" "+_vm._s(_vm.$t(item.label))+" ")])}),1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v("取消")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v("提交")])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/shipment-type-edit.vue?vue&type=template&id=2c1cd7e6&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/services/shipment.service.ts
var shipment_service = __webpack_require__("1af5");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/shipment-type-edit.vue?vue&type=script&lang=ts&






var shipment_type_editvue_type_script_lang_ts_ShipmentTypeEdit =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ShipmentTypeEdit, _super);

  function ShipmentTypeEdit() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.shipmentService = new shipment_service["a" /* ShipmentService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.seller_list = [];
    _this.country_code_list = [];
    _this.rel_code = '';
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  ShipmentTypeEdit.prototype.submit = function () {
    return true;
  };

  ShipmentTypeEdit.prototype.cancel = function () {
    return;
  };

  ShipmentTypeEdit.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  ShipmentTypeEdit.prototype.mounted = function () {
    if (this.row) {
      this.rel_code = this.row.rel_code;
      this.setFormValues();
    }
  };

  ShipmentTypeEdit.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.row);
  };

  ShipmentTypeEdit.prototype.saveShipType = function (data) {
    var _this = this;

    this.shipmentService.saveShipType(new http["RequestParams"](data, {
      loading: this.loadingService
    })).subscribe(function () {
      _this.submit();
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ShipmentTypeEdit.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        values['save_flag'] = _this.saveFlag;
        values['rel_code'] = _this.rel_code;

        if (values['country_code_list']) {
          values['country_code_list'] = values['country_code_list'].length ? values['country_code_list'] : null;
        } else {
          values['country_code_list'] = null;
        }

        _this.saveShipType(values);
      }
    });
  };

  ShipmentTypeEdit.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ShipmentTypeEdit.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ShipmentTypeEdit.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentTypeEdit.prototype, "saveFlag", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentTypeEdit.prototype, "shipTypeList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentTypeEdit.prototype, "row", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentTypeEdit.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ShipmentTypeEdit.prototype, "sellerList", void 0);

  ShipmentTypeEdit = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ShipmentTypeEdit);
  return ShipmentTypeEdit;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var shipment_type_editvue_type_script_lang_ts_ = (shipment_type_editvue_type_script_lang_ts_ShipmentTypeEdit);
// CONCATENATED MODULE: ./src/components/picking/shipment-type-edit.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_shipment_type_editvue_type_script_lang_ts_ = (shipment_type_editvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/shipment-type-edit.vue?vue&type=custom&index=0&blockType=i18n
var shipment_type_editvue_type_custom_index_0_blockType_i18n = __webpack_require__("4207");

// CONCATENATED MODULE: ./src/components/picking/shipment-type-edit.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_shipment_type_editvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof shipment_type_editvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(shipment_type_editvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var shipment_type_edit = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "197d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"invoices":"invoices","order_detail":"Order Detail","base":"Picking Info","operation":"Operations","initial_demand":"Initial Demand","shipment":"Shipments","return_info":"Customer Problem","logs":"Logs","action":{"create":"Create","batch-create":"EXCEL Import","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","auto_create":"Auto Create","create_dhl":"Create DHL","create_dpd":"Create DPD","create_gls":"Create GLS","sold_out":"Sold Out","validate_address":"Validate Address","modify_address":"Modify Address","batch_send_email":"Batch Send Email","fake_shipment":"Fake Shipment","upload_shipment":"Upload Shipment","upload_fake_shipment":"Upload Fake Shipment","createReturn":"Create Return","done_picking_get_label":"Shipping Label","deliveryMore":"Delivery More","ProductPart":"Product Part","cancelPicking":"Cancel","setAsDraft":"Set Draft","setPresale":"Set Presale","cancelPresale":"Cancel Presale","markSoldOut":"Mark SoldOut","cancelSoldOut":"Cancel SoldOut","checkShipmentCount":"Check Shipments","cancelShipmentCount":"Cancel Check Shipments","serviceProcess":"Service Process","returnProcess":"Return Process","customer_service_stop_plz":"Wrong Address","cancel_stock_picking_for_order_refund":"Cancel Order For Refund","reserved":"Reserved","force_available":"Force Availability","confirm_operate_refund_order":"Are you sure to cancel order for refund?"}},"zh-cn":{"invoices":"发票","order_detail":"订单明细","base":"拣货单详情","operation":"操作","initial_demand":"包裹明细","shipment":"面单","return_info":"客户问题","logs":"操作日志","action":{"create":"新建","batch-create":"EXCEL导入","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","auto_create":"创建运单","create_dhl":"创建DHL","create_dpd":"创建DPD","create_gls":"创建GLS","sold_out":"卖超","validate_address":"验证地址","modify_address":"批量验证","batch_send_email":"批量发邮件","fake_shipment":"假单号","upload_shipment":"上传单号","upload_fake_shipment":"上传假单号","createReturn":"创建回程单","done_picking_get_label":"生成运单号","deliveryMore":"创建补发","ProductPart":"补发零部件","cancelPicking":"取消","setAsDraft":"设为草稿","setPresale":"设为预售","cancelPresale":"取消预售","markSoldOut":"卖超","cancelSoldOut":"取消卖超","checkShipmentCount":"Check Shipments","cancelShipmentCount":"Cancel Check Shipments","serviceProcess":"Service Process","returnProcess":"Return Process","customer_service_stop_plz":"Wrong Address","cancel_stock_picking_for_order_refund":"Cancel Order For Refund","reserved":"预留","force_available":"强制预留","confirm_operate_refund_order":"确定要取消订单[直接退款]吗?"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "1999":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("f3ce");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "1c4d":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "1eb8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/product-part.vue?vue&type=template&id=57ab5302&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('ProductPartForm',{ref:"partForm",attrs:{"picking_id":_vm.picking_id},on:{"partChange":_vm.onPartFormChange,"shipTypeChange":_vm.onShipmentTypeChange}}),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/product-part.vue?vue&type=template&id=57ab5302&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/components/picking/product-part-form.vue + 4 modules
var product_part_form = __webpack_require__("43c1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/product-part.vue?vue&type=script&lang=ts&











var product_partvue_type_script_lang_ts_ProductPart =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPart, _super);

  function ProductPart() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.shipment_type = '';
    _this.product_part = '';
    _this.data = [];
    _this.listData = [];
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  ProductPart.prototype.submit = function () {
    return;
  };

  ProductPart.prototype.cancel = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }

    return;
  };

  Object.defineProperty(ProductPart.prototype, "loading", {
    get: function get() {
      var loading = {};

      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }

      return loading;
    },
    enumerable: true,
    configurable: true
  });

  ProductPart.prototype.closeLoading = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }
  };

  ProductPart.prototype.onChangeDefaultCode = function () {
    var _this = this;

    this.pickingService.query_product_part(new http["RequestParams"]({
      default_code: this.product_part
    }, this.loading)).subscribe(function (data) {
      data.map(function (x) {
        return x['quantity'] = 1;
      });
      _this.data = data;

      _this.closeLoading();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error('err');
    });
  };

  ProductPart.prototype.onSubmit = function () {
    var value = [];

    if (this.shipment_type == '') {
      var err_msg = this.$t('shipment_type');
      this.$message.error(err_msg);
      return;
    } // if (this.listData.length < 1) {
    //     let err_msg: any = this.$t('product_Part')
    //     this.$message.error(err_msg)
    //     return
    // }


    value['picking_id'] = this.picking_id;
    value['shipment_type'] = this.shipment_type;
    value['part_list'] = [];
    var partForm = this.$refs.partForm; //判断用户填写是否完整

    if (partForm.tempPartList.length) {
      for (var _i = 0, _a = partForm.tempPartList; _i < _a.length; _i++) {
        var i = _a[_i];

        for (var _b = 0, _c = partForm.tempPartList; _b < _c.length; _b++) {
          var i_1 = _c[_b];

          if (i_1.part_code == '' && i_1.default_code != '' || i_1.part_code != '' && i_1.default_code == '') {
            this.$message.error('请先完善配件信息');
            return;
          }

          if (i_1.part_code != '' && i_1.default_code != '') {
            if (i_1.part_code.length + i_1.default_code.length > 32) {
              var msg = this.$t('max_length_32');
              this.$message.error('[' + i_1.default_code + ']' + msg);
              return;
            }
          }
        }
      }
    }

    if (this.listData.length) {
      value['part_list'] = this.listData.map(function (x) {
        return {
          default_code: x.default_code,
          quantity: x.quantity,
          add_part: false
        };
      });

      if (partForm.tempPartList.length) {
        for (var i in partForm.tempPartList) {
          if (partForm.tempPartList[i].part_code != '' && partForm.tempPartList[i].default_code != '') {
            value['part_list'].push(partForm.tempPartList[i]);
          }
        }
      }
    } else {
      if (partForm.tempPartList.length) {
        value['part_list'] = partForm.tempPartList.filter(function (x) {
          return x.part_code != '' && x.default_code != '';
        });
      } else {
        this.$message.error('请选择配件或创建临时配件');
        return;
      }
    }

    if (value['part_list'].length == 0) {
      this.$message.error('请选择配件或创建临时配件');
      return;
    }

    if (partForm.showShipmentContent) {
      if (!partForm.shipmentContent) {
        this.$message.error('请输入shipment content');
        return;
      } else {
        value['shipment_content'] = partForm.shipmentContent;
      }
    }

    value['shipment_type'] = this.shipment_type;
    this.ConfirmProductParts(value);
  };

  ProductPart.prototype.ConfirmProductParts = function (value) {
    var _this = this;

    this.pickingService.confirmProductParts(new http["RequestParams"](value, this.loading)).subscribe(function () {
      _this.submit();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error(err.message);
    });
  };

  ProductPart.prototype.onPartFormChange = function (data) {
    this.listData = data;
  };

  ProductPart.prototype.onShipmentTypeChange = function (data) {
    this.shipment_type = data;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPart.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPart.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPart.prototype, "picking_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPart.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('product_part'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPart.prototype, "onChangeDefaultCode", null);

  ProductPart = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductPartForm: product_part_form["a" /* default */]
    }
  })], ProductPart);
  return ProductPart;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_partvue_type_script_lang_ts_ = (product_partvue_type_script_lang_ts_ProductPart);
// CONCATENATED MODULE: ./src/components/picking/product-part.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_product_partvue_type_script_lang_ts_ = (product_partvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/product-part.vue?vue&type=style&index=0&lang=css&
var product_partvue_type_style_index_0_lang_css_ = __webpack_require__("e36e");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/product-part.vue?vue&type=custom&index=0&blockType=i18n
var product_partvue_type_custom_index_0_blockType_i18n = __webpack_require__("f48d");

// CONCATENATED MODULE: ./src/components/picking/product-part.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_product_partvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_partvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_partvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_part = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "228e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/operation-detail.vue?vue&type=template&id=353302cb&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"sku","bordered":""}},[_c('a-table-column',{key:"package_id",attrs:{"title":_vm.$t('source_package'),"data-index":"package_id","align":"center"}}),_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('product'),"align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',{attrs:{"title":row.name}},[_vm._v(_vm._s(row.name ? row.name.length > 20 ? row.name.substr(0, 17) + '...' : row.name : ''))])]}}])}),_c('a-table-column',{key:"ordered_qty",attrs:{"title":_vm.$t('ordered_qty'),"align":"center","data-index":"ordered_qty"}}),_c('a-table-column',{key:"unit_measure",attrs:{"title":_vm.$t('unit_measure'),"data-index":"unit_measure","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(unit_measure){return [_c('span',{attrs:{"_id":unit_measure}},[_vm._v("Unit")])]}}])}),_c('a-table-column',{key:"owner_id",attrs:{"title":_vm.$t('owner'),"data-index":"owner_id","align":"center"}}),_c('a-table-column',{key:"todo",attrs:{"title":_vm.$t('todo'),"data-index":"todo","align":"center"}}),_c('a-table-column',{key:"location_id",attrs:{"title":_vm.$t('source_location'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.location_id,_vm.locationList))+" ")]}}])}),_c('a-table-column',{key:"location_dest_id",attrs:{"title":_vm.$t('destination_location'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.location_dest_id,_vm.locationList))+" ")]}}])}),_c('a-table-column',{key:"result_package_id",attrs:{"title":_vm.$t('destination_package'),"data-index":"result_package_id","align":"center"}})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/operation-detail.vue?vue&type=template&id=353302cb&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/location.service.ts
var location_service = __webpack_require__("e73b");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/operation-detail.vue?vue&type=script&lang=ts&






var operation_detailvue_type_script_lang_ts_OperationDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](OperationDetail, _super);

  function OperationDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = [];
    _this.locationList = [];
    _this.locationService = new location_service["a" /* LocationService */]();
    return _this;
  }

  OperationDetail.prototype.created = function () {
    this.getLocationList();
  };

  OperationDetail.prototype.mounted = function () {
    if (this.info.length) {
      this.data = this.info.map(function (x) {
        x['save_flag'] = 1;
        return x;
      });
    }
  };

  OperationDetail.prototype.onInfoChange = function () {
    if (this.info.length) {
      this.data = this.info.map(function (x) {
        x['save_flag'] = 1;
        return x;
      });
    } else {
      this.data = [];
    }
  };

  OperationDetail.prototype.getLocationList = function () {
    var _this = this;

    this.locationService.getLocationList(new http["RequestParams"]()).subscribe(function (data) {
      _this.locationList = data;
    }, function (err) {
      _this.$message.error('获取库位列表失败');
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], OperationDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], OperationDetail.prototype, "onInfoChange", null);

  OperationDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], OperationDetail);
  return OperationDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var operation_detailvue_type_script_lang_ts_ = (operation_detailvue_type_script_lang_ts_OperationDetail);
// CONCATENATED MODULE: ./src/components/picking/operation-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_operation_detailvue_type_script_lang_ts_ = (operation_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/operation-detail.vue?vue&type=custom&index=0&blockType=i18n
var operation_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("6a9a");

// CONCATENATED MODULE: ./src/components/picking/operation-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_operation_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof operation_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(operation_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var operation_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "2516":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_multi_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ec78");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_multi_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_multi_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_multi_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "27a2":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"no":"No","desc":"this is a Order Page1","columns":{"status":"Status","reference":"Reference","product_name":"Product Name","instance":"Instance","partner":"Partner","scheduled_date":"Scheduled Date","order_id":"Order ID","state":"State","payment_date":"Payment Date","latest_ship_date":"Latest Ship Date","validate_state":"Validate State","shipment_count":"Shipment Count","shipment_num":"Shipment Num.","shipment_time":"Shipment Time","ebay_type":"Ebay Type","amazon_type":"Amazon Type","order_memo":"Memo","operate":"Operate","Create Return Shipment":"Create Return Shipment","seller_code":"Seller","instance_code":"Instance","ebay_buyer_id":"Buyer ID","amount_total":"Amount","customer":"Customer","zip":"Zip","street":"Street"},"forms":{"prime":"Prime","picking_type":"Picking Type","ebay_plus":"Ebay Plus","picking_id":"PickingID","print_state":"Print State","order_id":"orderID","sold_out":"Sold Out","shipment_num":"Shipment Num","sku":"SKU","validate_state":"Validate State","order_from":"Order From","ship_type":"Ship Type","partner":"Partner","latest_ship_date":"Latest Ship Date","create_date":"Create Date","pre_sale":"Pre Sale","payment_date":"Payment Date","is_resend":"Is Resend","ebay_buyer_id":"Buyer ID","assign_to_user":"Assign User","quick_search":"Quick Search","operator_like":"Fuzzy Search","operator_equal":"Match Search"},"action":{"create":"Create","batch-create":"EXCEL Import","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","auto_create":"Auto Create","create_dhl":"Create DHL","create_dpd":"Create DPD","create_gls":"Create GLS","sold_out":"Sold Out","validate_address":"Validate Address","modify_address":"Modify Address","batch_send_email":"Batch Send Email","fake_shipment":"Fake Shipment","upload_shipment":"Upload Shipment","upload_fake_shipment":"Upload Fake Shipment","createReturn":"Create Return","done_picking_get_label":"Shipping Label","deliveryMore":"Delivery More","ProductPart":"Product Part","cancelPicking":"Cancel","setAsDraft":"Set Draft","setPresale":"Set Presale","cancelPresale":"Cancel Presale","markSoldOut":"Mark SoldOut","cancelSoldOut":"Cancel SoldOut","checkShipmentCount":"Check Shipments","cancelShipmentCount":"Cancel Check Shipments","serviceProcess":"Service Process","returnProcess":"Return Process","customer_service_stop_plz":"Wrong Address","cancel_stock_picking_for_order_refund":"Cancel Order For Refund","today":"Today","yestoday":"Yestoday","3day":"3 Day","3days":"3 Days","refund":"Refund","createCp":"Create Cp","create_brief":"Create Brief","assign_to_user":"Assign To User","force_available":"Force Availability","force_verify_address":"Force Verify Address","deletePicking":"Delete Picking","modify_memo":"Modify Memo","reserved":"Reserved","more_btn":"More Buttons","confirm_operate_refund_order":"Are you sure to cancel order for refund?","confirm_operate_wrong_address":"Are you sure to cancel order because wrong address?","viewAmazonInvoicePDF":"view AMA PDF","cancelOrder":"Cancel Order","make_done":"Make Done For Available","create_gift":"Create Gift"},"rules":{"date_range_error":"start date can\u0027t later start date"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","yes":"Yes","success":"success"},"zh-cn":{"no":"否","desc":"这是订单页面1","columns":{"status":"状态","reference":"参数","product_name":"产品名称","instance":"实例","partner":"客户","scheduled_date":"约定日期","order_id":"订单号","state":"状态","payment_date":"支付日期","latest_ship_date":"发货时间","validate_state":"有效状态","shipment_count":"面单数量","shipment_num":"物流单号","shipment_time":"物流时间","ebay_type":"Ebay类型","amazon_type":"亚马逊类型","order_memo":"Memo","operate":"操作","Create Return Shipment":"创建回程单","seller_code":"店铺","instance_code":"实例","ebay_buyer_id":"买家ID","amount_total":"金额","customer":"客户","zip":"邮编","street":"街道"},"forms":{"prime":"Prime","picking_type":"拣货类型","ebay_plus":"Ebay +","picking_id":"拣货单号","print_state":"打印状态","order_id":"订单号","sold_out":"卖超","shipment_num":"物流单号","sku":"SKU","validate_state":"有效状态","order_from":"订单来源","ship_type":"物流类型","partner":"客户","latest_ship_date":"发货时间","create_date":"创建时间","pre_sale":"预售单","payment_date":"支付时间","is_resend":"补发单","ebay_buyer_id":"买家ID","assign_to_user":"任务人","quick_search":"快速查找","operator_like":"模糊查找","operator_equal":"精确查找"},"action":{"create":"新建","batch-create":"EXCEL导入","edit":"编辑","delete":"删除","ok":"确定","cancel":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","auto_create":"创建运单","create_dhl":"创建DHL","create_dpd":"创建DPD","create_gls":"创建GLS","sold_out":"卖超","validate_address":"验证地址","modify_address":"批量验证","batch_send_email":"批量发邮件","fake_shipment":"假单号","upload_shipment":"上传单号","upload_fake_shipment":"上传假单号","createReturn":"创建回程单","done_picking_get_label":"生成运单号","deliveryMore":"创建补发","ProductPart":"补发零部件","make_done":"Make Done For Available","cancelPicking":"取消","setAsDraft":"设为草稿","setPresale":"设为预售","cancelPresale":"取消预售","markSoldOut":"卖超","cancelSoldOut":"取消卖超","checkShipmentCount":"Check Shipments","cancelShipmentCount":"Cancel Check Shipments","serviceProcess":"Service Process","returnProcess":"Return Process","customer_service_stop_plz":"Wrong Address","cancel_stock_picking_for_order_refund":"Cancel Order For Refund","today":"今天","yestoday":"昨天","3day":"前天","3days":"近3天","refund":"退款","createCp":"创建CP","create_brief":"创建Brief","assign_to_user":"Assign To User","force_available":"强制预留","force_verify_address":"强制验证地址","deletePicking":"删除","modify_memo":"编辑Memo","reserved":"预留","more_btn":"更多按钮","confirm_operate_refund_order":"确定要批量取消订单[直接退款]吗?","confirm_operate_wrong_address":"确定要批量取消订单[错误地址]吗?","viewAmazonInvoicePDF":"查看AMA账单","cancelOrder":"取消订单","create_gift":"创建Gift"},"rules":{"date_range_error":"开始日期不能大于结束日期"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","yes":"是","success":"成功"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "2b19":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/delivery-more.vue?vue&type=template&id=2b83741e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":3}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.deliveryType')))])]),_c('a-col',{attrs:{"span":21}},[_c('a-select',{staticStyle:{"width":"60%"},attrs:{"placeholder":_vm.$t('plzSelect'),"size":"small"},on:{"change":function (e) { return _vm.onTypeChange(e); }},model:{value:(_vm.delivery_type),callback:function ($$v) {_vm.delivery_type=$$v},expression:"delivery_type"}},[_c('a-select-option',{key:"Part",attrs:{"value":"part"}},[_vm._v("Part ")]),_c('a-select-option',{key:"Compelete Product",attrs:{"value":"one"}},[_vm._v("Compelete Product ")])],1)],1)],1),(_vm.showParts)?_c('div',[_c('p',{staticStyle:{"font-weight":"600","color":"#222","margin-top":"10px"}},[_vm._v("parts:")]),_c('a-table',{attrs:{"dataSource":_vm.productListShow,"pagination":false,"rowKey":"product","rowSelection":{
                selectedRowKeys: _vm.selectedRowKeys,
                onChange: function (keys) { return _vm.onSelectedChange(keys); }
            },"scroll":{ y: 240 }}},[_c('a-table-column',{key:"product",attrs:{"title":_vm.$t('columns.product_name'),"width":"40%","align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',[_vm._v(_vm._s(row.product))])]}}],null,false,615940457)}),_c('a-table-column',{key:"type",attrs:{"title":_vm.$t('columns.product_type'),"width":"40%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.type == 1)?_c('span',[_vm._v(_vm._s(_vm.$t('columns.base')))]):(row.type == 2)?_c('span',{staticStyle:{"color":"red"}},[_vm._v(_vm._s(_vm.$t('columns.similar')))]):_c('span',{staticStyle:{"color":"blue"}},[_vm._v(_vm._s(_vm.$t('columns.other')))])]}}],null,false,478442882)}),_c('a-table-column',{key:"qty",attrs:{"title":_vm.$t('columns.qty'),"width":"30%","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-input-number',{style:({ width: '80px' }),attrs:{"value":row.qty,"min":1},on:{"change":function (e) { return _vm.onQuantityChange(row.product, e); }}})]}}],null,false,2433836041)})],1),_c('p',[_c('span',{staticStyle:{"font-weight":"600","color":"#222","margin-right":"10px"}},[_vm._v("shipment content:")]),_c('a-checkbox',{on:{"change":function (e) { return _vm.onCheckStatusChange(e); }}})],1),(_vm.showShipmentContent)?_c('p',[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(['shipment_content']),expression:"['shipment_content']"}],attrs:{"rows":"3","cols":"40"},on:{"input":function (e) { return _vm.onShipmentContentChange(e); }}})],1):_vm._e()],1):_vm._e(),(_vm.showPartForm)?_c('div',{staticStyle:{"margin-top":"20px"}},[_c('ProductPartForm',{ref:"partForm",attrs:{"picking_id":_vm.picking_id,"order_id":_vm.order_id,"changeSpinning":_vm.changeSpinning},on:{"partChange":_vm.onPartFormChange,"shipTypeChange":_vm.onShipmentTypeChange}})],1):_vm._e(),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit'))+" ")])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/delivery-more.vue?vue&type=template&id=2b83741e&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__("a15b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.split.js
var es_string_split = __webpack_require__("1276");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.sort.js
var es_array_sort = __webpack_require__("4e82");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/components/picking/product-part-form.vue + 4 modules
var product_part_form = __webpack_require__("43c1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/delivery-more.vue?vue&type=script&lang=ts&


















var delivery_morevue_type_script_lang_ts_DeliveryMore =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](DeliveryMore, _super);

  function DeliveryMore() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.delivery_type = '';
    _this.tipCount = 0;
    _this.shipment_type = '';
    _this.partList = [];
    _this.showShipmentContent = false;
    _this.showParts = false;
    _this.showPartForm = false;
    _this.shipmentContent = '';
    _this.productList = [];
    _this.productListShow = [];
    _this.selectedRowKeys = [];
    _this.productListSub1 = [];
    _this.productListSub2 = [];
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    return _this;
  }

  DeliveryMore.prototype.submit = function (data) {
    return data;
  };

  DeliveryMore.prototype.cancel = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }

    return;
  };

  DeliveryMore.prototype.created = function () {
    this.delivery_type = undefined;
  };

  DeliveryMore.prototype.onSubmit = function () {
    var value = [];

    if (this.delivery_type == '') {
      var err_msg = this.$t('err_msg');
      this.$message.error(err_msg);
      return;
    }

    if (this.order_id) {
      value['number'] = this.order_id;
      value['number_type'] = 'order';
    } else {
      value['number'] = this.picking_id;
      value['number_type'] = 'picking';
    }

    value['delivery_type'] = this.delivery_type;

    if (this.selectedRowKeys.length == 0 && this.delivery_type == 'one' && this.productListShow.length > 0) {
      this.showConfirm(value);
    } else {
      if (this.delivery_type == 'part') {
        var partForm = this.$refs.partForm;

        if (partForm.showShipmentContent) {
          if (!partForm.shipmentContent) {
            this.$message.error('请输入shipment content');
            return;
          } else {
            value['shipment_content'] = partForm.shipmentContent;
          }
        }

        value['shipment_type'] = this.shipment_type; //判断用户填写是否完整

        if (partForm.tempPartList.length) {
          for (var _i = 0, _a = partForm.tempPartList; _i < _a.length; _i++) {
            var i = _a[_i];

            if (i.part_code == '' && i.default_code != '' || i.part_code != '' && i.default_code == '') {
              this.$message.error('请先完善配件信息');
              return;
            }
          }
        }

        value['part_list'] = [];

        if (this.partList.length) {
          value['part_list'] = this.partList.map(function (x) {
            return {
              default_code: x.default_code,
              quantity: x.quantity,
              add_part: false
            };
          });

          if (partForm.tempPartList.length) {
            for (var i in partForm.tempPartList) {
              if (partForm.tempPartList[i].part_code != '' && partForm.tempPartList[i].default_code != '') {
                value['part_list'].push(partForm.tempPartList[i]);
              }
            }
          }
        } else {
          if (partForm.tempPartList.length) {
            value['part_list'] = partForm.tempPartList.filter(function (x) {
              return x.part_code != '' && x.default_code != '';
            });
          } else {
            this.$message.error('请选择配件或创建临时配件');
            return;
          }
        }

        if (value['part_list'].length == 0) {
          this.$message.error('请选择配件或创建临时配件');
          return;
        }
      }

      this.deliverMore(value);
    }
  };

  DeliveryMore.prototype.showConfirm = function (value) {
    var _that = this;

    this.$confirm({
      title: this.$t('tip'),
      content: this.$t('tip_content'),
      onOk: function onOk() {
        _that.deliverMore(value);
      },
      onCancel: function onCancel() {}
    });
  };

  DeliveryMore.prototype.deliverMore = function (value) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    if (this.showShipmentContent) {
      if (this.shipmentContent) {
        value['shipment_content'] = this.shipmentContent;
      } else {
        this.$message.error('please input shipment content');
        return;
      }
    }

    if (this.selectedRowKeys.length) {
      var product_list = [];
      product_list = this.productListShow.filter(function (x) {
        return _this.selectedRowKeys.includes(x.product);
      });
      var products = product_list.map(function (x) {
        return x.qty + '×' + x.product;
      }).join('\n');

      if (this.showShipmentContent) {
        value['shipment_content'] = products + '\n' + this.shipmentContent;
      }

      value['product_list'] = product_list.map(function (x) {
        return {
          product_id: x.product_id,
          qty: x.qty
        };
      });
    }

    this.orderService.deliverMore(new http["RequestParams"](value, loading)).subscribe(function (data) {
      _this.submit(data);
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  DeliveryMore.prototype.onTypeChange = function (e) {
    var _this = this;

    this.shipmentContent = '';
    this.showShipmentContent = false;
    this.showParts = false;
    this.showPartForm = false;
    this.selectedRowKeys = [];

    if (e == 'one') {
      var object_id = this.order_id;
      var object_type = 'order';

      if (this.picking_id) {
        object_id = this.picking_id;
        object_type = 'picking';
      }

      var loading = {};

      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }

      this.pickingService.query_stock_move_base_product(new http["RequestParams"]({
        object_id: object_id,
        object_type: object_type
      }, loading)).subscribe(function (data) {
        _this.productList = data.product_list.map(function (x) {
          return {
            product: x.default_code,
            product_id: x.product_id,
            qty: 1
          };
        });
        _this.productListSub1 = [];
        _this.productListSub2 = [];
        _this.productListShow = [];

        for (var _i = 0, _a = _this.productList; _i < _a.length; _i++) {
          var i = _a[_i];
          var contain = 0;

          for (var _b = 0, _c = data.default_code_list; _b < _c.length; _b++) {
            var j = _c[_b];
            var baseStr = j.default_code;
            var baseArr = j.default_code.split('-');

            if (baseArr.length > 1 && !isNaN(baseArr[baseArr.length - 1])) {
              baseArr.pop();
              baseStr = baseArr.join('-');
            }

            if (i.product.includes(baseStr)) {
              if (i.product == j.default_code) {
                i['type'] = 1;
                i['qty'] = j.prod_qty ? j.prod_qty : 1;
              } else {
                i['type'] = 2;
              }

              _this.productListSub1.push(i);

              contain = 1;
              break;
            }
          }

          if (contain == 0) {
            i['type'] = 0;

            _this.productListSub2.push(i);
          }
        }

        _this.productListSub1.sort(function (a, b) {
          return a.type > b.type ? 1 : -1;
        });

        _this.productListShow = _this.productListSub1.map(function (x) {
          return x;
        });

        for (var _d = 0, _e = _this.productListSub2; _d < _e.length; _d++) {
          var p = _e[_d];

          _this.productListShow.push(p);
        }

        _this.showParts = true;

        for (var _f = 0, _g = _this.productListShow; _f < _g.length; _f++) {
          var x = _g[_f];

          if (x.type == 1) {
            _this.selectedRowKeys.push(x.product);
          }
        }

        if (_this.changeSpinning) {
          _this.changeSpinning(false);
        }
      }, function (err) {
        if (_this.changeSpinning) {
          _this.changeSpinning(false);
        }

        _this.$message.error(err.message);
      });
    } else {
      this.showPartForm = true;
    }
  };

  DeliveryMore.prototype.onCheckStatusChange = function (e) {
    if (e.target.checked) {
      this.showShipmentContent = true;
    } else {
      this.showShipmentContent = false;
      this.shipmentContent = '';
    }
  };

  DeliveryMore.prototype.onShipmentContentChange = function (e) {
    this.shipmentContent = e.target.value;
  };

  DeliveryMore.prototype.onQuantityChange = function (key, e) {
    var item = this.productList.find(function (x) {
      return x.product === key;
    });

    if (item) {
      item.qty = e;
    }
  };

  DeliveryMore.prototype.onSelectedChange = function (keys) {
    this.selectedRowKeys = keys;
  };

  DeliveryMore.prototype.onPartFormChange = function (data) {
    this.partList = data;
  };

  DeliveryMore.prototype.onShipmentTypeChange = function (data) {
    this.shipment_type = data;
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], DeliveryMore.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], DeliveryMore.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DeliveryMore.prototype, "picking_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DeliveryMore.prototype, "order_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DeliveryMore.prototype, "changeSpinning", void 0);

  DeliveryMore = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      ProductPartForm: product_part_form["a" /* default */]
    }
  })], DeliveryMore);
  return DeliveryMore;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var delivery_morevue_type_script_lang_ts_ = (delivery_morevue_type_script_lang_ts_DeliveryMore);
// CONCATENATED MODULE: ./src/components/picking/delivery-more.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_delivery_morevue_type_script_lang_ts_ = (delivery_morevue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/delivery-more.vue?vue&type=style&index=0&lang=css&
var delivery_morevue_type_style_index_0_lang_css_ = __webpack_require__("f93a");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/delivery-more.vue?vue&type=custom&index=0&blockType=i18n
var delivery_morevue_type_custom_index_0_blockType_i18n = __webpack_require__("b21f");

// CONCATENATED MODULE: ./src/components/picking/delivery-more.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_delivery_morevue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof delivery_morevue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(delivery_morevue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var delivery_more = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "3026":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"product":"Product","quantity":"Quantity","ship":"Ship","state":"State","product_info":"Product Info","w_warehouse_reason":"WareHouse Reason(rt)","w_return_reason":"Grund Ruckgabe","customer_reason":"Customer Reason","product_problem":"Customer Problem(cs)","logistic_reason":"Logistic Reason","warehouse_reason":"Warehouse Reason(cs)","solution_type":"Solution Type","stock_processed":"Stock Processed","create_time":"Create Time","create_user":"Create User","is_return_user":"Is Return User","sale_tag":"Product Problem","null":"None","ship_num":"Shipment Number","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Discard"}},"zh-cn":{"product":"产品","quantity":"数量","ship":"物流","state":"产品状态","product_info":"产品信息","w_warehouse_reason":"仓库原因(rt)","w_return_reason":"退货原因","customer_reason":"客户原因","product_problem":"客户原因(cs)","logistic_reason":"物流原因","warehouse_reason":"仓库原因(cs)","solution_type":"解决方案类型","stock_processed":"库存处理","create_time":"创建时间","create_user":"创建者","is_return_user":"Is Return User","sale_tag":"产品问题","null":"无","ship_num":"运单号","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"丢弃"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "30f4":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"dynamic_price_calc":"Dynamic Price Calc","open":"Open","close":"Close","latest_calc_time":"Latest Calc Time","start_end_time":"Start and End Time","ratio_set":"Ratio Setting","calculation":"Calculate"},"err_msg":"The sum Ratio mast be 100","save":"Save"},"zh-cn":{"columns":{"dynamic_price_calc":"动态价格计算","open":"开启","close":"关闭","latest_calc_time":"最新计算时间","start_end_time":"起止时间","ratio_set":"物流比例设置","calculation":"计算"},"err_msg":"总比例数必须等于100","save":"保存"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "4207":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_type_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b011");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_type_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_type_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_type_edit_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "43c1":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/product-part-form.vue?vue&type=template&id=4559167e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail",staticStyle:{"max-height":"600px","overflow-x":"hidden","overflow-y":"auto"}},[_c('a-card',{staticClass:"margin-y",staticStyle:{"margin":"0 !important"}},[_c('a-row',{staticStyle:{"margin-bottom":"8px"},attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":2}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.product_sku')))])]),_c('a-col',{attrs:{"span":8}},[_c('a-select',{staticStyle:{"width":"100%"},attrs:{"size":"small","placeholder":_vm.$t('plzSelect')},model:{value:(_vm.product_part),callback:function ($$v) {_vm.product_part=$$v},expression:"product_part"}},_vm._l((_vm.product_list),function(item){return _c('a-select-option',{key:item.id,attrs:{"value":item.id}},[_vm._v(_vm._s(item.name)+" ")])}),1)],1),_c('a-col',{attrs:{"span":3,"offset":2}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.shipment_type')))])]),_c('a-col',{attrs:{"span":9}},[_c('a-select',{staticStyle:{"width":"100%"},attrs:{"size":"small","placeholder":_vm.$t('plzSelect')},on:{"change":function (e) { return _vm.onShipmentTypeChange(e); }},model:{value:(_vm.shipment_type),callback:function ($$v) {_vm.shipment_type=$$v},expression:"shipment_type"}},[_c('a-select-option',{key:"dpd",attrs:{"value":"dpd"}},[_vm._v("DPD ")]),_c('a-select-option',{key:"ship_order",attrs:{"value":"dhl"}},[_vm._v("DHL ")]),_c('a-select-option',{key:"bri",attrs:{"value":"bri"}},[_vm._v("Brief ")]),_c('a-select-option',{key:"gls",attrs:{"value":"gls"}},[_vm._v("GLS ")]),_c('a-select-option',{key:"RM_TR48",attrs:{"value":"RM_TR48"}},[_vm._v("UK_RoyalMail ")]),_c('a-select-option',{key:"HERM_48",attrs:{"value":"HERM_48"}},[_vm._v("UK_Hermes ")])],1)],1)],1),_c('div',{directives:[{name:"show",rawName:"v-show",value:(_vm.listData.length > 0),expression:"listData.length > 0"}]},[_c('br'),_c('a-list',{attrs:{"grid":{
                    gutter: 16,
                    xs: 1,
                    sm: 2,
                    md: 4,
                    lg: 4,
                    xl: 6,
                    xxl: 3
                },"data-source":_vm.listData},scopedSlots:_vm._u([{key:"renderItem",fn:function(item, index){return _c('a-list-item',{},[_c('span',[_vm._v(_vm._s(item.default_code))]),_c('a-input-number',{staticStyle:{"margin":"0 3px"},attrs:{"decimalSeparator":",","min":1,"value":item.quantity,"size":"small"},on:{"change":function (e) { return _vm.handleListChange(e, index); }}}),_c('a-icon',{attrs:{"type":"delete"},on:{"click":function($event){return _vm.deleteList(index)}}})],1)}}])})],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"name","bordered":"","scroll":{ y: 300 }}},[_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('forms.default_code'),"align":"left","data-index":"default_code"}}),_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('forms.product_name'),"data-index":"name","align":"left"}}),_c('a-table-column',{key:"manual_id",attrs:{"title":_vm.$t('forms.manual_url'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.product_url)?_c('span',{attrs:{"title":"老版说明书"}},[_c('a',{attrs:{"href":row.product_url,"target":"_blank"}},[_vm._v(_vm._s(_vm.product_name))])]):_c('span',[_c('a',[_vm._v(_vm._s(_vm.product_name))])])]}}])}),_c('a-table-column',{key:"quantity",attrs:{"title":_vm.$t('forms.quantity'),"data-index":"quantity","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(quantity, row){return [_c('a-input-number',{attrs:{"decimalSeparator":",","value":quantity,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e, row, 'quantity'); }}})]}}])}),_c('a-table-column',{key:"delete",attrs:{"title":_vm.$t('forms.Add'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-icon',{attrs:{"type":"file-add"},on:{"click":function($event){return _vm.onAdd(row)}}})]}}])})],1)],1),_c('div',[_c('p',{staticStyle:{"margin":"10px 0 0 0"}},[_vm._v(_vm._s(_vm.$t('create_tmpl_part_no'))+"：")]),_c('ul',_vm._l((_vm.tempPartList),function(item){return _c('li',{key:item.id,staticStyle:{"margin":"10px 0"}},[_c('a-input-number',{attrs:{"value":item.quantity,"min":1},on:{"change":function (e) { return _vm.handleShipmentChange(e, item, 'quantity'); }}}),_vm._v(" × "),_c('a-input',{staticStyle:{"width":"270px"},attrs:{"value":item.part_code,"placeholder":_vm.$t('part_no_name')},on:{"change":function (e) { return _vm.handleShipmentChange(e, item, 'part_code'); }}}),_vm._v(" / "),_c('a-auto-complete',{staticStyle:{"width":"270px"},attrs:{"dataSource":_vm.prodList,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"defaultValue":item.default_code,"value":item.default_code,"placeholder":_vm.$t('resend_prod_sku')},on:{"change":function (e) { return _vm.handleShipmentChange(e, item, 'default_code'); },"search":function (e) { return _vm.onSearch(e); }}},[_c('template',{slot:"dataSource"},[_vm._l((_vm.prodList),function(opt){return _c('a-select-option',{key:opt.id,attrs:{"value":opt.id}},[_vm._v(_vm._s(opt.name)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(item)}}},[_vm._v(" Search More ")])])],2)],2),_c('a-icon',{staticStyle:{"margin-left":"5px"},attrs:{"type":"minus-circle"},on:{"click":function($event){return _vm.deleteShipmentContent(item.id)}}})],1)}),0),_c('a-button',{staticStyle:{"width":"660px","margin-left":"40px"},attrs:{"type":"dashed"},on:{"click":_vm.addShipmentContent}},[_c('a-icon',{attrs:{"type":"plus"}}),_vm._v(" "+_vm._s(_vm.$t('add_tmpl_part_no'))+" ")],1)],1),_c('div',[_c('p',{staticStyle:{"margin":"10px 0 0 0"}},[_c('a-checkbox',{on:{"change":function (e) { return _vm.onPartCheckStatusChange(e); }}}),_c('span',{staticStyle:{"font-weight":"600","color":"#222","margin":"10px"}},[_vm._v("shipment content:")])],1),(_vm.showShipmentContent)?_c('div',{staticStyle:{"margin-bottom":"20px"}},[_c('a-textarea',{staticStyle:{"width":"760px"},attrs:{"row":"4","col":"40","placeholder":"备注，如@仓库3333"},on:{"input":function (e) { return _vm.onShipmentContentChange(e); }}})],1):_vm._e()])],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/product-part-form.vue?vue&type=template&id=4559167e&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__("a434");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.includes.js
var es_array_includes = __webpack_require__("caad");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.includes.js
var es_string_includes = __webpack_require__("2532");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.slice.js
var es_array_slice = __webpack_require__("fb6a");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/product-part-form.vue?vue&type=script&lang=ts&





















var product_part_formvue_type_script_lang_ts_ProductPartForm =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ProductPartForm, _super);

  function ProductPartForm() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.product_list = [];
    _this.shipment_type = '';
    _this.product_part = '';
    _this.product_name = '';
    _this.prodList = [];
    _this.showShipmentContent = false;
    _this.tempPartList = [];
    _this.shipmentContent = '';
    _this.data = [];
    _this.listData = [];
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  Object.defineProperty(ProductPartForm.prototype, "loading", {
    get: function get() {
      var loading = {};

      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }

      return loading;
    },
    enumerable: true,
    configurable: true
  });

  ProductPartForm.prototype.closeLoading = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }
  };

  ProductPartForm.prototype.onChangeDefaultCode = function () {
    var _this = this;

    var obj = this.product_list.find(function (x) {
      return x.id == _this.product_part;
    });
    if (!obj) return;
    this.product_name = obj.name;
    this.pickingService.query_product_part(new http["RequestParams"]({
      default_code: obj.default_code
    }, this.loading)).subscribe(function (data) {
      data.map(function (x) {
        return x['quantity'] = 1;
      });
      _this.data = data;

      _this.closeLoading();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error('err');
    });
  };

  ProductPartForm.prototype.onListDataChange = function () {
    this.$emit('partChange', this.listData);
  };

  ProductPartForm.prototype.created = function () {
    this.product_part = undefined;
    this.shipment_type = undefined;
    this.getProductList();
  };

  ProductPartForm.prototype.mounted = function () {
    this.tempPartList.push({
      id: uuid_default.a.generate(),
      quantity: 1,
      part_code: '',
      default_code: '',
      add_part: true
    });
  };

  ProductPartForm.prototype.onAdd = function (row) {
    if (this.listData.filter(function (x) {
      return x.default_code == row.default_code;
    }).length > 0) {
      var err_msg = this.$t('add_repeatedly');
      this.$message.error(err_msg);
      return;
    }

    this.listData.push(row);
  };

  ProductPartForm.prototype.handleListChange = function (value, index) {
    this.listData[index].quantity = value;
    this.$emit('partChange', this.listData);
  };

  ProductPartForm.prototype.handleChange = function (e, row, column) {
    row[column] = e;
  };

  ProductPartForm.prototype.deleteList = function (index) {
    this.listData.splice(index, 1);
  };

  ProductPartForm.prototype.getProductList = function () {
    var _this = this;

    var params = {};

    if (this.picking_id) {
      params['number'] = this.picking_id;
      params['number_type'] = 'picking';
    } else if (this.order_id) {
      params['number'] = this.order_id;
      params['number_type'] = 'order';
    } else {
      return;
    }

    this.pickingService.queryStockMoveForResend(new http["RequestParams"](params, this.loading)).subscribe(function (data) {
      var arr = [];
      data.map(function (x) {
        if (x.default_code.indexOf('TMPL-EZT') == -1) {
          arr.push(x);
        }
      });

      if (arr.length) {
        arr.forEach(function (v) {
          v.id = uuid_default.a.generate();

          if (!v.name) {
            v.name = v.default_code;
          }
        });
        _this.product_list = arr;
        _this.prodList = arr;
      }

      _this.closeLoading();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error(err.message);
    });
  }; // private onSubmit() {
  //     const value: any = []
  //     if (this.shipment_type == '') {
  //         let err_msg: any = this.$t('shipment_type')
  //         this.$message.error(err_msg)
  //         return
  //     }
  //     if (this.listData.length < 1) {
  //         let err_msg: any = this.$t('product_Part')
  //         this.$message.error(err_msg)
  //         return
  //     }
  //
  //     value['picking_id'] = this.picking_id
  //     value['shipment_type'] = this.shipment_type
  //     value['part_list'] = this.listData
  //     this.ConfirmProductParts(value)
  // }
  //
  // private ConfirmProductParts(value) {
  //     this.pickingService
  //         .confirmProductParts(new RequestParams(value, this.loading))
  //         .subscribe(
  //             () => {},
  //             err => {
  //                 this.closeLoading()
  //                 this.$message.error(err.message)
  //             }
  //         )
  // }


  ProductPartForm.prototype.onPartCheckStatusChange = function (e) {
    if (e.target.checked) {
      this.showShipmentContent = true;
    } else {
      this.showShipmentContent = false;
    }
  };

  ProductPartForm.prototype.handleShipmentChange = function (e, row, column) {
    if (Object.prototype.toString.call(e) === '[object InputEvent]' || Object.prototype.toString.call(e) === '[object Event]' || Object.prototype.toString.call(e) === '[object Object]') {
      row[column] = e.target.value;
    } else {
      row[column] = e;
    }

    var _row = JSON.parse(JSON.stringify(row));

    var obj = this.prodList.find(function (v) {
      return v.id == row.default_code;
    });
    if (!obj) return;

    if (column == 'default_code') {
      var default_code = obj.name;
      row.default_code = obj.default_code;
      var part_code = row['part_code'];

      if (!part_code) {
        part_code = '';
      }

      var total_length = part_code.length + default_code;

      if (total_length > 32) {
        var msg = this.$t('max_length_32');
        this.$message.error('[' + default_code + ']' + msg);
      }
    }

    if (column == 'part_code') {
      if (row[column].includes('-')) {
        this.$message.error('部件部位号不能包含"-"');
      }

      var default_code = obj.name;

      if (!default_code) {
        default_code = '';
      }

      var part_code = row['part_code'];

      if (!part_code) {
        part_code = '';
      }

      var total_length = default_code.length + part_code.length;

      if (total_length > 32) {
        var msg = this.$t('max_length_32');
        this.$message.error('[' + default_code + ']' + msg);
      }
    }
  };

  ProductPartForm.prototype.getPlaceholderCount = function (strSource) {
    //统计字符串中包含{}或{xxXX}的个数
    var thisCount = 0;
    strSource.replace(/-/g, function (m, i) {
      //m为找到的{xx}元素、i为索引
      thisCount++;
    });
    return thisCount;
  };

  ProductPartForm.prototype.addShipmentContent = function () {
    this.tempPartList.push({
      id: uuid_default.a.generate(),
      quantity: 1,
      part_code: '',
      default_code: '',
      add_part: true
    });
  };

  ProductPartForm.prototype.deleteShipmentContent = function (id) {
    this.tempPartList = this.tempPartList.filter(function (x) {
      return x.id != id;
    });
  };

  ProductPartForm.prototype.searchMore = function (row) {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {}, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      var item = _that.tempPartList.find(function (x) {
        return x.id == row.id;
      });

      item.default_code = data.default_code;
      var partCode = '';

      if (_this.getPlaceholderCount(data.default_code) >= 2) {
        partCode = data.default_code.slice(data.default_code.lastIndexOf('-') + 1);
      }

      item.part_code = partCode;
    });
  };

  ProductPartForm.prototype.onShipmentTypeChange = function (e) {
    this.$emit('shipTypeChange', this.shipment_type);
  };

  ProductPartForm.prototype.onShipmentContentChange = function (e) {
    this.shipmentContent = e.target.value;
  };

  ProductPartForm.prototype.onSearch = function (e) {
    this.prodList = this.product_list.filter(function (x) {
      return x.name.toLowerCase().includes(e.toLowerCase());
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPartForm.prototype, "picking_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPartForm.prototype, "order_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ProductPartForm.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('product_part'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPartForm.prototype, "onChangeDefaultCode", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('listData'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ProductPartForm.prototype, "onListDataChange", null);

  ProductPartForm = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ProductPartForm);
  return ProductPartForm;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var product_part_formvue_type_script_lang_ts_ = (product_part_formvue_type_script_lang_ts_ProductPartForm);
// CONCATENATED MODULE: ./src/components/picking/product-part-form.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_product_part_formvue_type_script_lang_ts_ = (product_part_formvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/product-part-form.vue?vue&type=style&index=0&lang=css&
var product_part_formvue_type_style_index_0_lang_css_ = __webpack_require__("582d");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/product-part-form.vue?vue&type=custom&index=0&blockType=i18n
var product_part_formvue_type_custom_index_0_blockType_i18n = __webpack_require__("e12a");

// CONCATENATED MODULE: ./src/components/picking/product-part-form.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_product_part_formvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof product_part_formvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(product_part_formvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var product_part_form = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "4612":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("87f7");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_base_detail_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "50f8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/edit-de-ship-ratio.vue?vue&type=template&id=584d3955&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-tabs',{attrs:{"defaultActiveKey":"de","type":"card"}},[(_vm.data.find(function (x) { return x.instance == 'DE'; }))?_c('a-tab-pane',{key:"de",attrs:{"tab":"DE"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'DE'; }),"type":"de"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'FR'; }))?_c('a-tab-pane',{key:"fr",attrs:{"tab":"FR"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'FR'; }),"type":"fr"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'ES'; }))?_c('a-tab-pane',{key:"es",attrs:{"tab":"ES"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'ES'; }),"type":"es"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'IT'; }))?_c('a-tab-pane',{key:"it",attrs:{"tab":"IT"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'IT'; }),"type":"it"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'NL'; }))?_c('a-tab-pane',{key:"nl",attrs:{"tab":"NL"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'NL'; }),"type":"nl"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'SE'; }))?_c('a-tab-pane',{key:"se",attrs:{"tab":"SE"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'SE'; }),"type":"se"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'PL'; }))?_c('a-tab-pane',{key:"pl",attrs:{"tab":"PL"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'PL'; }),"type":"pl"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'AT'; }))?_c('a-tab-pane',{key:"at",attrs:{"tab":"AT"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'AT'; }),"type":"at"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'BE'; }))?_c('a-tab-pane',{key:"be",attrs:{"tab":"BE"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'BE'; }),"type":"be"},on:{"changeData":_vm.updateData}})],1):_vm._e(),(_vm.data.find(function (x) { return x.instance == 'LU'; }))?_c('a-tab-pane',{key:"lu",attrs:{"tab":"LU"}},[_c('SetShipRatio',{attrs:{"info":_vm.data.find(function (x) { return x.instance == 'LU'; }),"type":"lu"},on:{"changeData":_vm.updateData}})],1):_vm._e()],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.submit}},[_vm._v(_vm._s(_vm.$t('close')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/edit-de-ship-ratio.vue?vue&type=template&id=584d3955&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/set-ship-ratio.vue?vue&type=template&id=9fe36974&
var set_ship_ratiovue_type_template_id_9fe36974_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-card',{staticStyle:{"margin":"0","padding":"20px 10px 30px 10px","border":"none"}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":4}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.dynamic_price_calc'))+"：")])]),_c('a-col',{attrs:{"span":5}},[_c('a-radio-group',{attrs:{"value":_vm.defaultPriceCalcType,"button-style":"solid","size":"small"},on:{"change":function (e) { return _vm.onPriceCalcChange(e); }}},[_c('a-radio-button',{attrs:{"value":"open"}},[_vm._v(" "+_vm._s(_vm.$t('columns.open'))+" ")]),_c('a-radio-button',{attrs:{"value":"close"}},[_vm._v(" "+_vm._s(_vm.$t('columns.close'))+" ")])],1)],1),_c('a-col',{attrs:{"span":14,"offset":1}},[(_vm.defaultPriceCalcType == 'open')?_c('a-row',{attrs:{"gutter":4}},[_c('a-col',{attrs:{"span":10}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.latest_calc_time'))+"：")])]),_c('a-col',{attrs:{"span":10}},[_c('span',[_vm._v(_vm._s(_vm._f("datetolocal")(_vm.data.write_date)))])]),_c('a-col',{attrs:{"span":3}},[_c('a-button',{attrs:{"type":"primary","size":"small"},on:{"click":_vm.calculation}},[_vm._v(_vm._s(_vm.$t('columns.calculation')))])],1)],1):_c('a-row',{attrs:{"gutter":4}},[_c('a-col',{attrs:{"span":6}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.start_end_time'))+"：")])]),_c('a-col',{attrs:{"span":16}},[_c('a-range-picker',{attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm:ss","size":"small"},on:{"change":function (e) { return _vm.onStartEndTimeChange(e); }},model:{value:(_vm.startEndTime),callback:function ($$v) {_vm.startEndTime=$$v},expression:"startEndTime"}})],1)],1)],1)],1),(_vm.defaultPriceCalcType == 'close')?_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form}},[_c('a-row',{staticStyle:{"margin-top":"30px"},attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":3}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.ratio_set')}})],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"DPD:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'dpd_percent',
                                {
                                    initialValue: _vm.info.dpd_percent
                                        ? _vm.info.dpd_percent
                                        : 0
                                }
                            ]),expression:"[\n                                'dpd_percent',\n                                {\n                                    initialValue: info.dpd_percent\n                                        ? info.dpd_percent\n                                        : 0\n                                }\n                            ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"DHL:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'dhl_percent',
                                {
                                    initialValue: _vm.info.dhl_percent
                                        ? _vm.info.dhl_percent
                                        : 0
                                }
                            ]),expression:"[\n                                'dhl_percent',\n                                {\n                                    initialValue: info.dhl_percent\n                                        ? info.dhl_percent\n                                        : 0\n                                }\n                            ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"GLS:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                'gls_percent',
                                {
                                    initialValue: _vm.info.gls_percent
                                        ? _vm.info.gls_percent
                                        : 0
                                }
                            ]),expression:"[\n                                'gls_percent',\n                                {\n                                    initialValue: info.gls_percent\n                                        ? info.gls_percent\n                                        : 0\n                                }\n                            ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1)],1)],1):_vm._e(),(_vm.defaultPriceCalcType == 'close')?_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{attrs:{"type":"primary","size":"small"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('save')))])],1):_vm._e()],1)],1)}
var set_ship_ratiovue_type_template_id_9fe36974_staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/set-ship-ratio.vue?vue&type=template&id=9fe36974&

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/set-ship-ratio.vue?vue&type=script&lang=ts&










var datasModule = Object(lib["c" /* namespace */])('datasModule');

var set_ship_ratiovue_type_script_lang_ts_SetShipRatio =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](SetShipRatio, _super);

  function SetShipRatio() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = {};
    _this.assign_to_user = '';
    _this.defaultPriceCalcType = 'open';
    _this.startEndTime = [];
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    return _this;
  }

  SetShipRatio.prototype.submit = function (data) {
    return data;
  };

  SetShipRatio.prototype.cancel = function () {
    return;
  };

  SetShipRatio.prototype.onInfoChange = function () {
    this.data = Object.assign({}, this.info);
    this.defaultPriceCalcType = this.info.is_dynamic_calculation ? 'open' : 'close';
    this.setFormValues();
  };

  SetShipRatio.prototype.mounted = function () {
    if (this.info) {
      this.data = Object.assign({}, this.info);
      this.defaultPriceCalcType = this.info.is_dynamic_calculation ? 'open' : 'close';
      this.setFormValues();
    }
  };

  SetShipRatio.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  SetShipRatio.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.data);
  };

  SetShipRatio.prototype.handleChange = function (value) {//console.log(value)
  };

  SetShipRatio.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      var sum = 0;

      for (var i in values) {
        if (values[i] > 0) {
          sum += parseInt(values[i]);
        }
      }

      if (_this.defaultPriceCalcType == 'close') {
        if (sum !== 100) {
          var err_msg = _this.$t('err_msg');

          _this.$message.error(err_msg);

          return;
        }

        if (_this.startEndTime.length == 0) {
          _this.$message.error('请输入起止时间');

          return;
        } else {
          var start = new Date(_this.startEndTime[0].format('YYYY-MM-DD HH:mm:ss'));
          var end = new Date(_this.startEndTime[1].format('YYYY-MM-DD HH:mm:ss'));
          var now = new Date();

          if (end < now) {
            _this.$message.error('开始和结束时间不能小于当前时间');

            return;
          }

          if (start < now) {
            start = now;
          }

          values['start_date'] = moment_default()(start).format('YYYY-MM-DD HH:mm:ss');
          values['end_date'] = moment_default()(end).format('YYYY-MM-DD HH:mm:ss');
        }
      }

      for (var i in values) {
        values[i] = values[i] ? values[i] : 0;
      }

      values['instance'] = _this.type.toUpperCase();
      values['warehouse'] = 'de';
      values['is_dynamic_calculation'] = _this.defaultPriceCalcType == 'open' ? true : false;

      if (_this.data.id) {
        values['id'] = _this.data.id;
      }

      values['product_id'] = _this.data.product_template_logistic_id;

      _this.submitData(values);
    });
  };

  SetShipRatio.prototype.onPriceCalcChange = function (e) {
    this.defaultPriceCalcType = e.target.value;
  };

  SetShipRatio.prototype.onStartEndTimeChange = function (e) {
    this.startEndTime = e;
  };

  SetShipRatio.prototype.submitData = function (params) {
    var _this = this;

    this.innerAction.setActionAPI('theoretical_final_freight/modify_freight', common_service["a" /* CommonService */].getMenuCode('final-shipping-de'));
    this.publicService.modify(new http["RequestParams"]({
      modify_data: [params]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');

      params['id'] = data.message;
      _this.data.id = data.message;

      _this.$emit('changeData', params);
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  SetShipRatio.prototype.calculation = function () {
    var params = {
      is_dynamic_calculation: true,
      product_id: this.data.product_template_logistic_id,
      instance: this.type.toUpperCase(),
      warehouse: 'de'
    };

    if (this.data.id) {
      params['id'] = this.data.id;
    }

    this.submitData(params);
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], SetShipRatio.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], SetShipRatio.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], SetShipRatio.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], SetShipRatio.prototype, "type", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], SetShipRatio.prototype, "onInfoChange", null);

  SetShipRatio = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], SetShipRatio);
  return SetShipRatio;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var set_ship_ratiovue_type_script_lang_ts_ = (set_ship_ratiovue_type_script_lang_ts_SetShipRatio);
// CONCATENATED MODULE: ./src/components/picking/set-ship-ratio.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_set_ship_ratiovue_type_script_lang_ts_ = (set_ship_ratiovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/set-ship-ratio.vue?vue&type=custom&index=0&blockType=i18n
var set_ship_ratiovue_type_custom_index_0_blockType_i18n = __webpack_require__("783d");

// CONCATENATED MODULE: ./src/components/picking/set-ship-ratio.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_set_ship_ratiovue_type_script_lang_ts_,
  set_ship_ratiovue_type_template_id_9fe36974_render,
  set_ship_ratiovue_type_template_id_9fe36974_staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof set_ship_ratiovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(set_ship_ratiovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var set_ship_ratio = (component.exports);
// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/edit-de-ship-ratio.vue?vue&type=script&lang=ts&









var edit_de_ship_ratiovue_type_script_lang_ts_datasModule = Object(lib["c" /* namespace */])('datasModule');

var edit_de_ship_ratiovue_type_script_lang_ts_EditDeShipRatio =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](EditDeShipRatio, _super);

  function EditDeShipRatio() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = [];
    _this.assign_to_user = '';
    _this.defaultPriceCalcType = 'open';
    _this.startEndTime = [];
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  EditDeShipRatio.prototype.submit = function () {
    return this.data;
  };

  EditDeShipRatio.prototype.cancel = function (params) {
    return params;
  };

  EditDeShipRatio.prototype.onInfoChange = function () {
    this.data = this.info.map(function (x) {
      return x;
    });
  };

  EditDeShipRatio.prototype.mounted = function () {
    if (this.info) {
      this.data = this.info.map(function (x) {
        return x;
      });
    }
  };

  EditDeShipRatio.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  EditDeShipRatio.prototype.updateData = function (params) {
    var item = this.data.find(function (x) {
      return x.instance == params.instance;
    });

    if (item) {
      item['id'] = params['id'];

      for (var i in params) {
        if (item[i] !== undefined) {
          item[i] = params[i];
        }
      }
    }
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditDeShipRatio.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditDeShipRatio.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], EditDeShipRatio.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditDeShipRatio.prototype, "onInfoChange", null);

  EditDeShipRatio = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      SetShipRatio: set_ship_ratio
    }
  })], EditDeShipRatio);
  return EditDeShipRatio;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var edit_de_ship_ratiovue_type_script_lang_ts_ = (edit_de_ship_ratiovue_type_script_lang_ts_EditDeShipRatio);
// CONCATENATED MODULE: ./src/components/picking/edit-de-ship-ratio.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_edit_de_ship_ratiovue_type_script_lang_ts_ = (edit_de_ship_ratiovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/edit-de-ship-ratio.vue?vue&type=custom&index=0&blockType=i18n
var edit_de_ship_ratiovue_type_custom_index_0_blockType_i18n = __webpack_require__("6d66");

// CONCATENATED MODULE: ./src/components/picking/edit-de-ship-ratio.vue





/* normalize component */

var edit_de_ship_ratio_component = Object(componentNormalizer["a" /* default */])(
  picking_edit_de_ship_ratiovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof edit_de_ship_ratiovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(edit_de_ship_ratiovue_type_custom_index_0_blockType_i18n["default"])(edit_de_ship_ratio_component)

/* harmony default export */ var edit_de_ship_ratio = __webpack_exports__["a"] = (edit_de_ship_ratio_component.exports);

/***/ }),

/***/ "53e6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-log-detail.vue?vue&type=template&id=5087ce3a&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-product-detail"},[_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"index","bordered":""}},[_c('a-table-column',{key:"log_content",attrs:{"title":_vm.$t('log'),"data-index":"log_content","align":"left","width":"40%"}}),_c('a-table-column',{key:"log_type",attrs:{"title":_vm.$t('type'),"data-index":"log_type","align":"center","width":"15%"}}),_c('a-table-column',{key:"who_log",attrs:{"title":_vm.$t('operater'),"align":"center","width":"15%"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("dict2")(row.who_log,_vm.systemUsers))+" ")]}}])}),_c('a-table-column',{key:"log_date",attrs:{"title":_vm.$t('date'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(_vm._s(_vm._f("datetolocal")(row.log_date)))]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/picking-log-detail.vue?vue&type=template&id=5087ce3a&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.sort.js
var es_array_sort = __webpack_require__("4e82");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-log-detail.vue?vue&type=script&lang=ts&





var picking_log_detailvue_type_script_lang_ts_PickingLogDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PickingLogDetail, _super);

  function PickingLogDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = [];

    _this.compare = function (prop) {
      return function (obj1, obj2) {
        var val1 = obj1[prop];
        var val2 = obj2[prop];

        if (val1 > val2) {
          return -1;
        } else if (val1 < val2) {
          return 1;
        } else {
          return 0;
        }
      };
    };

    return _this;
  }

  PickingLogDetail.prototype.mounted = function () {
    this.data = this.info.map(function (x, i) {
      x['index'] = i + 1;
      return x;
    }).sort(this.compare('log_date'));
  };

  PickingLogDetail.prototype.onInfoChange = function () {
    this.data = this.info.map(function (x, i) {
      x['index'] = i + 1;
      return x;
    }).sort(this.compare('log_date'));
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingLogDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingLogDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingLogDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingLogDetail.prototype, "onInfoChange", null);

  PickingLogDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], PickingLogDetail);
  return PickingLogDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var picking_log_detailvue_type_script_lang_ts_ = (picking_log_detailvue_type_script_lang_ts_PickingLogDetail);
// CONCATENATED MODULE: ./src/components/picking/picking-log-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_picking_log_detailvue_type_script_lang_ts_ = (picking_log_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/picking-log-detail.vue?vue&type=custom&index=0&blockType=i18n
var picking_log_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("7873");

// CONCATENATED MODULE: ./src/components/picking/picking-log-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_picking_log_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof picking_log_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(picking_log_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var picking_log_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "582d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_form_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("86a2");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_form_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_form_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "5a53":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "5c1f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-modify-memo.vue?vue&type=template&id=6ff39ce6&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component"},[_c('a-form',{staticClass:"data-form",attrs:{"form":_vm.form}},[_c('a-form-item',{attrs:{"required":""}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                    "memo",
                    {
                        initialValue: _vm.memo
                    },
                    {
                        rules: _vm.rules.required
                    }
                ]),expression:"[\n                    `memo`,\n                    {\n                        initialValue: memo\n                    },\n                    {\n                        rules: rules.required\n                    }\n                ]"}],attrs:{"placeholder":"Memo","rows":4}})],1)],1),_c('div',{staticClass:"flex-row",staticStyle:{"margin-top":"-15px","margin-bottom":"15px"}},[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.save')))]),_c('a-button',{staticClass:"margin-right",staticStyle:{"margin-left":"5px"},on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))])],1),_c('div',{staticClass:"page-container",staticStyle:{"width":"100%","height":"340px","overflow-y":"auto"}},[_c('a-tabs',[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('customer_problem')}},[_c('ReturnDetail',{attrs:{"info":_vm.returns,"picking_id":_vm.id,"orderID":_vm.orderID,"systemUsers":_vm.systemUsers}})],1)],1)],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/picking-modify-memo.vue?vue&type=template&id=6ff39ce6&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/components/picking/return-detail.vue + 4 modules
var return_detail = __webpack_require__("d31d");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-modify-memo.vue?vue&type=script&lang=ts&








var picking_modify_memovue_type_script_lang_ts_PickingModifyMemo =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PickingModifyMemo, _super);

  function PickingModifyMemo() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.returns = [];
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.rules = {
      required: [{
        required: true,
        message: '必填项'
      }]
    };
    return _this;
  }

  PickingModifyMemo.prototype.submit = function (value) {
    return value;
  };

  PickingModifyMemo.prototype.cancel = function () {
    return;
  };

  PickingModifyMemo.prototype.created = function () {
    this.form = this.$form.createForm(this);
    this.getReturns();
  };

  PickingModifyMemo.prototype.mounted = function () {};

  PickingModifyMemo.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields().then(function (values) {
      _this.submit(values.memo);
    });
  };

  PickingModifyMemo.prototype.getReturns = function () {
    var _this = this;

    this.pickingService.queryReturnInfo(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this.returns = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingModifyMemo.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingModifyMemo.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingModifyMemo.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingModifyMemo.prototype, "memo", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingModifyMemo.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingModifyMemo.prototype, "orderID", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: ''
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingModifyMemo.prototype, "open_from", void 0);

  PickingModifyMemo = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      ReturnDetail: return_detail["a" /* default */]
    }
  })], PickingModifyMemo);
  return PickingModifyMemo;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var picking_modify_memovue_type_script_lang_ts_ = (picking_modify_memovue_type_script_lang_ts_PickingModifyMemo);
// CONCATENATED MODULE: ./src/components/picking/picking-modify-memo.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_picking_modify_memovue_type_script_lang_ts_ = (picking_modify_memovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/picking-modify-memo.vue?vue&type=custom&index=0&blockType=i18n
var picking_modify_memovue_type_custom_index_0_blockType_i18n = __webpack_require__("ba98");

// CONCATENATED MODULE: ./src/components/picking/picking-modify-memo.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_picking_modify_memovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof picking_modify_memovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(picking_modify_memovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var picking_modify_memo = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "5ead":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d7f3");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_style_index_1_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "6076":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"plzSelect":"Please Select","columns":{"deliveryType":"Delivery Type","product_name":"Product Name","product_type":"Product Type","base":"Same","similar":"Similar","other":"Other","qty":"Quantity"},"err_msg":"Please Select Delivery Type","tip":"Tip","tip_content":"Are you sure not to choose any products?"},"zh-cn":{"plzSelect":"请选择","columns":{"deliveryType":"补发类型","product_name":"产品名称","product_type":"产品类型","base":"同款","similar":"相似","other":"其它","qty":"数量"},"err_msg":"请选择补发类型","tip":"提示","tip_content":"确定不勾选任何补发产品吗？"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "6a9a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_operation_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("d6a6");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_operation_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_operation_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_operation_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "6cf4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_multi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("5a53");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_multi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_multi_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "6d66":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_de_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("df30");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_de_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_de_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_de_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7053":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/create-return.vue?vue&type=template&id=794a22f2&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 4 },"wrapperCol":{ span: 16, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.selected_ship_type'),"required":""}},[_c('a-checkbox',{attrs:{"defaultChecked":_vm.is_check},model:{value:(_vm.is_check),callback:function ($$v) {_vm.is_check=$$v},expression:"is_check"}})],1)],1),_c('a-col',{attrs:{"span":10}},[_c('a-form-item',{directives:[{name:"show",rawName:"v-show",value:(_vm.is_check),expression:"is_check"}],attrs:{"label":_vm.$t('columns.ship_type'),"required":""}},[_c('a-select',{staticStyle:{"width":"100%"},attrs:{"placeholder":"Please select","size":"small"},model:{value:(_vm.ship_type),callback:function ($$v) {_vm.ship_type=$$v},expression:"ship_type"}},[_c('a-select-option',{key:"dpd",attrs:{"value":"dpd"}},[_vm._v(" DPD ")]),_c('a-select-option',{key:"gls",attrs:{"value":"gls"}},[_vm._v(" GLS ")]),_c('a-select-option',{key:"ship_order",attrs:{"value":"ship_order"}},[_vm._v(" DHL ")])],1)],1)],1)],1)],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.demands,"pagination":false,"rowKey":"name","bordered":""}},[_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('forms.name'),"data-index":"name","align":"left"}}),_c('a-table-column',{key:"product_qty",attrs:{"title":_vm.$t('forms.product_qty'),"data-index":"product_qty","align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(product_qty, row){return [_c('a-input-number',{attrs:{"decimalSeparator":",","value":product_qty,"size":"small"},on:{"change":function (e) { return _vm.handleChange(e, row, 'product_qty'); }}})]}}])}),_c('a-table-column',{key:"delete",attrs:{"title":_vm.$t('columns.Delete'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-icon',{staticStyle:{"color":"red"},attrs:{"type":"delete"},on:{"click":function($event){return _vm.onDelete(row)}}})]}}])})],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.ok'))+" ")])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/create-return.vue?vue&type=template&id=794a22f2&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find-index.js
var es_array_find_index = __webpack_require__("c740");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.splice.js
var es_array_splice = __webpack_require__("a434");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/create-return.vue?vue&type=script&lang=ts&









var create_returnvue_type_script_lang_ts_CreateReturn =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](CreateReturn, _super);

  function CreateReturn() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.ship_type = 'dpd';
    _this.is_check = false;
    _this.form = {};
    _this.demands = [];
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  CreateReturn.prototype.submit = function () {
    return;
  };

  CreateReturn.prototype.cancel = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }

    return;
  };

  CreateReturn.prototype.created = function () {
    this.getDemands();
  };

  CreateReturn.prototype.getDemands = function () {
    var _this = this;

    this.pickingService.queryStockMoveForReturn(new http["RequestParams"]({
      picking_id: this.picking_id
    })).subscribe(function (data) {
      _this.demands = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  CreateReturn.prototype.handleChange = function (e, row, column) {
    row[column] = e;
  };

  CreateReturn.prototype.onSubmit = function () {
    var values = [];
    values['picking_id'] = this.picking_id;
    values['selected_ship_type'] = this.is_check;
    values['ship_type'] = this.ship_type;
    var move_lines = [];

    for (var _i = 0, _a = this.demands; _i < _a.length; _i++) {
      var i = _a[_i];

      if (!i['product_qty']) {
        this.$message.error('return qty is not correct.');
        return;
      }

      move_lines.push({
        product_tmpl_id: i['product_tmpl_id'],
        qty: i['product_qty']
      });
    }

    values['move_lines'] = move_lines;
    this.saveData(values);
  };

  CreateReturn.prototype.saveData = function (values) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.returnShipment(new http["RequestParams"](values, loading)).subscribe(function (data) {
      _this.submit();
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  CreateReturn.prototype.onDelete = function (row) {
    var index = this.demands.findIndex(function (x) {
      return x.name === row.name;
    });
    this.demands.splice(index, 1);
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], CreateReturn.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], CreateReturn.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], CreateReturn.prototype, "picking_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], CreateReturn.prototype, "changeSpinning", void 0);

  CreateReturn = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], CreateReturn);
  return CreateReturn;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var create_returnvue_type_script_lang_ts_ = (create_returnvue_type_script_lang_ts_CreateReturn);
// CONCATENATED MODULE: ./src/components/picking/create-return.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_create_returnvue_type_script_lang_ts_ = (create_returnvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/create-return.vue?vue&type=custom&index=0&blockType=i18n
var create_returnvue_type_custom_index_0_blockType_i18n = __webpack_require__("b899");

// CONCATENATED MODULE: ./src/components/picking/create-return.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_create_returnvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof create_returnvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(create_returnvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var create_return = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "73f3":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"shipment_order":"Shipment Order","search_shipment":"Search Shipment","shipment_order_type":"Shipment Order Type","create_user":"Create User","sent_product":"Sent Product","location_sort":"Location Sort","prime_item_id":"Prime Item ID","ceate_time":"Ceate Time","merge_time":"Merge Time","latest_status":"Latest Status","need_process":"Need Process","need_process_time":"Need Process Time","processed_time_logi":"Processed Time Logi","processed_time_CS":"Processed Time CS","process_type":"Process Type","pdf":"PDF","null":"None","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Discard","delete_shipment_number":"Confirm delete Shipment Number?","delete_shipment":"Confirm delete shipment line?","send_rt":"Send RT","ok":"OK","upload":"Upload","revert":"Revert","sceenshot_operate":"Sceenshot Operate"}},"zh-cn":{"shipment_order":"物流单号","search_shipment":"搜索","shipment_order_type":"物流单类型","create_user":"创建用户","sent_product":"已寄出产品","location_sort":"库位顺序","prime_item_id":"Prime ID","ceate_time":"创建时间","merge_time":"合单时间","latest_status":"现在状态","need_process":"需要处理","need_process_time":"需要处理时间","processed_time_logi":"处理时间逻辑","processed_time_CS":"处理时间CS","process_type":"处理类型","pdf":"PDF","null":"无","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"丢弃","delete_shipment_number":"确认删除运单的物流单号?","delete_shipment":"确认删除运单行数据?","send_rt":"发送RT","ok":"确认","upload":"上传","revert":"还原","sceenshot_operate":"截图操作"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "743e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("832d");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_edit_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "783d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_set_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("30f4");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_set_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_set_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_set_ship_ratio_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7873":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("0a7b");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_log_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7bff":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("73f3");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "7f15":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/batch-send-email.vue?vue&type=template&id=4974687e&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form,"labelCol":{ span: 3 },"wrapperCol":{ span: 20, offset: 1 }}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.order_memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "add_order_memo",
                            { rules: _vm.rules.required }
                        ]),expression:"[\n                            `add_order_memo`,\n                            { rules: rules.required }\n                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.cancel_order')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["order_cancel"]),expression:"[`order_cancel`]"}],attrs:{"size":"small"},model:{value:(_vm.is_cancel_order),callback:function ($$v) {_vm.is_cancel_order=$$v},expression:"is_cancel_order"}})],1)],1),(_vm.is_cancel_order)?_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.cancel_memo')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            "cancel_memo",
                            { rules: _vm.rules.required }
                        ]),expression:"[\n                            `cancel_memo`,\n                            { rules: rules.required }\n                        ]"}],attrs:{"size":"small"}})],1)],1):_vm._e(),_c('a-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.is_cancel_order),expression:"is_cancel_order"}],attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.customer_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["customer_reason"]),expression:"[`customer_reason`]"}],attrs:{"size":"small"}},_vm._l((_vm.customerReasonList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.is_cancel_order),expression:"is_cancel_order"}],attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.product_problem')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["sale_tag"]),expression:"[`sale_tag`]"}],attrs:{"size":"small","showSearch":""}},_vm._l((_vm.productReasonList),function(item){return _c('a-select-option',{key:item,attrs:{"value":item}},[_vm._v(" "+_vm._s(item)+" ")])}),1)],1)],1),_c('a-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.is_cancel_order),expression:"is_cancel_order"}],attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.logistic_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["logistic_reason"]),expression:"[`logistic_reason`]"}],attrs:{"size":"small"}},_vm._l((_vm.logisticReasonList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.is_cancel_order),expression:"is_cancel_order"}],attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.warehouse_reason')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(["warehouse_reason"]),expression:"[`warehouse_reason`]"}],attrs:{"size":"small"}},_vm._l((_vm.warehouseReasonList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(" "+_vm._s(item.name)+" ")])}),1)],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":_vm.$t('forms.send_email')}},[_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(["need_send_email"]),expression:"[`need_send_email`]"}],attrs:{"size":"small"},model:{value:(_vm.is_need_send_email),callback:function ($$v) {_vm.is_need_send_email=$$v},expression:"is_need_send_email"}})],1)],1),_c('a-col',{directives:[{name:"show",rawName:"v-show",value:(_vm.is_need_send_email),expression:"is_need_send_email"}],attrs:{"span":23}},[_c('a-tabs',{attrs:{"default-active-key":"en"}},[_c('a-tab-pane',{key:"en",attrs:{"tab":"EN Email"}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Title"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "en_title",
                                            { initialValue: _vm.en_title }
                                        ]),expression:"[\n                                            `en_title`,\n                                            { initialValue: en_title }\n                                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Body"}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["en_body"]),expression:"[`en_body`]"}],attrs:{"size":"small","rows":"6"}})],1)],1)],1)],1),_c('a-tab-pane',{key:"de",attrs:{"tab":"DE Email","force-render":""}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Title"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "de_title",
                                            { initialValue: _vm.de_title }
                                        ]),expression:"[\n                                            `de_title`,\n                                            { initialValue: de_title }\n                                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Body"}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["de_body"]),expression:"[`de_body`]"}],attrs:{"size":"small","rows":"6"}})],1)],1)],1)],1),_c('a-tab-pane',{key:"fr",attrs:{"tab":"FR Email","force-render":""}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Title"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "fr_title",
                                            { initialValue: _vm.fr_title }
                                        ]),expression:"[\n                                            `fr_title`,\n                                            { initialValue: fr_title }\n                                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Body"}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["fr_body"]),expression:"[`fr_body`]"}],attrs:{"size":"small","rows":"6"}})],1)],1)],1)],1),_c('a-tab-pane',{key:"it",attrs:{"tab":"IT Email","force-render":""}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Title"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "it_title",
                                            { initialValue: _vm.it_title }
                                        ]),expression:"[\n                                            `it_title`,\n                                            { initialValue: it_title }\n                                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Body"}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["it_body"]),expression:"[`it_body`]"}],attrs:{"size":"small","rows":"6"}})],1)],1)],1)],1),_c('a-tab-pane',{key:"es",attrs:{"tab":"ES Email","force-render":""}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Title"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "es_title",
                                            { initialValue: _vm.es_title }
                                        ]),expression:"[\n                                            `es_title`,\n                                            { initialValue: es_title }\n                                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Body"}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["es_body"]),expression:"[`es_body`]"}],attrs:{"size":"small","rows":"6"}})],1)],1)],1)],1),_c('a-tab-pane',{key:"nl",attrs:{"tab":"NL Email","force-render":""}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Title"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "nl_title",
                                            { initialValue: _vm.nl_title }
                                        ]),expression:"[\n                                            `nl_title`,\n                                            { initialValue: nl_title }\n                                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Body"}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["nl_body"]),expression:"[`nl_body`]"}],attrs:{"size":"small","rows":"6"}})],1)],1)],1)],1),_c('a-tab-pane',{key:"se",attrs:{"tab":"SE Email","force-render":""}},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Title"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                                            "se_title",
                                            { initialValue: _vm.se_title }
                                        ]),expression:"[\n                                            `se_title`,\n                                            { initialValue: se_title }\n                                        ]"}],attrs:{"size":"small"}})],1)],1),_c('a-col',{attrs:{"span":23}},[_c('a-form-item',{attrs:{"label":"Body"}},[_c('a-textarea',{directives:[{name:"decorator",rawName:"v-decorator",value:(["se_body"]),expression:"[`se_body`]"}],attrs:{"size":"small","rows":"6"}})],1)],1)],1)],1)],1)],1)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.send')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/batch-send-email.vue?vue&type=template&id=4974687e&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.search.js
var es_string_search = __webpack_require__("841c");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/custom_problem.service.ts
var custom_problem_service = __webpack_require__("6a1c");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/batch-send-email.vue?vue&type=script&lang=ts&













var batch_send_emailvue_type_script_lang_ts_BatchSendEmail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](BatchSendEmail, _super);

  function BatchSendEmail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.customProblemService = new custom_problem_service["a" /* CustomProblemService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.customerReasonList = [];
    _this.productReasonList = [];
    _this.logisticReasonList = [];
    _this.warehouseReasonList = [];
    _this.is_cancel_order = false;
    _this.is_need_send_email = true;
    _this.en_title = 'delivery delay';
    _this.de_title = 'Versandverspätung';
    _this.fr_title = "L'expédition retardée";
    _this.it_title = 'Ritardo nella spedizione';
    _this.es_title = 'retraso en la entrega';
    _this.nl_title = 'bezorgingsvertraging';
    _this.se_title = 'leverans fördröjning';
    _this.rules = {
      required: [{
        required: true,
        message: 'required'
      }]
    };
    _this.defaultValue = {
      number_type: 'picking',
      add_order_memo: '',
      cancel_memo: '',
      order_cancel: false,
      need_send_email: true,
      sale_tag: '',
      logistic_reason: '',
      customer_reason: '',
      warehouse_reason: '',
      // en_title: '',
      en_body: '',
      // it_title: '',
      it_body: '',
      // de_title: '',
      de_body: '',
      // fr_title: '',
      fr_body: '',
      // es_title: '',
      es_body: '',
      // nl_title: '',
      nl_body: '',
      se_body: ''
    };
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    return _this;
  }

  BatchSendEmail.prototype.submit = function () {
    return true;
  };

  BatchSendEmail.prototype.cancel = function () {
    return;
  };

  BatchSendEmail.prototype.mounted = function () {
    if (this.stock) {
      this.setFormValues();
    }
  };

  BatchSendEmail.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.defaultValue);
  };

  BatchSendEmail.prototype.created = function () {
    this.form = this.$form.createForm(this);
    this.getCpReason();
    this.getProductReason(['']);
  };

  BatchSendEmail.prototype.getCpReason = function () {
    var _this = this;

    this.customProblemService.queryCpReasonEnum(new http["RequestParams"]()).subscribe(function (data) {
      _this.warehouseReasonList = data[0]['warehouse_reason'];
      _this.customerReasonList = data[0]['customer_reason']; // this.productReasonList = data[0]['product_reason']

      _this.logisticReasonList = data[0]['logistic_reason'];
    });
  };

  BatchSendEmail.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      if (!err) {
        var data = {};
        data['number_list'] = _this.stock;
        data['cancel_info'] = {
          number_type: 'picking',
          add_order_memo: values['add_order_memo'],
          cancel_memo: values['cancel_memo'],
          order_cancel: values['order_cancel'],
          need_send_email: values['need_send_email'],
          sale_tag: values['sale_tag'],
          logistic_reason: values['logistic_reason'],
          customer_reason: values['customer_reason'],
          warehouse_reason: values['warehouse_reason']
        };

        if (!values['order_cancel']) {
          delete data['cancel_info'].cancel_memo;
        } else {
          if (values['sale_tag'].length < 1 && values['logistic_reason'].length < 1 && values['customer_reason'].length < 1 && values['warehouse_reason'].length < 1) {
            var cancel_order_err = _this.$t('cancel_order_err');

            _this.$message.error(cancel_order_err);

            return false;
          }
        }

        if (values['need_send_email']) {
          var count = 0;

          var err_msg = _this.$t('email_msg');

          for (var i in values) {
            if (i.search('_title') > 0) {
              count += 1;

              if (Object(esm_typeof["a" /* default */])(values[i]) == undefined || values[i].length < 1) {
                _this.$message.error(err_msg);

                return false;
              }
            }
          }

          if (count < 6) {
            _this.$message.error(err_msg);

            return false;
          }

          data['email_list'] = [{
            language: 'en',
            body: values['en_body'],
            title: values['en_title']
          }, {
            language: 'fr',
            body: values['fr_body'],
            title: values['fr_title']
          }, {
            language: 'de',
            body: values['de_body'],
            title: values['de_title']
          }, {
            language: 'it',
            body: values['it_body'],
            title: values['it_title']
          }, {
            language: 'es',
            body: values['es_body'],
            title: values['es_title']
          }, {
            language: 'nl',
            body: values['nl_body'],
            title: values['nl_title']
          }, {
            language: 'se',
            body: values['se_body'],
            title: values['se_title']
          }];
        }

        _this.sendEmail(data);
      }
    });
  };

  BatchSendEmail.prototype.sendEmail = function (data) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.SendEmail(new http["RequestParams"](data, loading)).subscribe(function () {
      _this.submit();
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  BatchSendEmail.prototype.getProductReason = function (sku) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_product_reason_enum', common_service["a" /* CommonService */].getMenuCode('common-menu'));
    this.publicService.query(new http["RequestParams"]({
      sku_list: sku
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.productReasonList = data[''];
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], BatchSendEmail.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], BatchSendEmail.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], BatchSendEmail.prototype, "stock", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], BatchSendEmail.prototype, "saveFlag", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], BatchSendEmail.prototype, "changeSpinning", void 0);

  BatchSendEmail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], BatchSendEmail);
  return BatchSendEmail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var batch_send_emailvue_type_script_lang_ts_ = (batch_send_emailvue_type_script_lang_ts_BatchSendEmail);
// CONCATENATED MODULE: ./src/components/picking/batch-send-email.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_batch_send_emailvue_type_script_lang_ts_ = (batch_send_emailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/batch-send-email.vue?vue&type=custom&index=0&blockType=i18n
var batch_send_emailvue_type_custom_index_0_blockType_i18n = __webpack_require__("a2d2");

// CONCATENATED MODULE: ./src/components/picking/batch-send-email.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_batch_send_emailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof batch_send_emailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(batch_send_emailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var batch_send_email = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "7f2c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_demand_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("e70c");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_demand_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_demand_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_demand_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "832d":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"dynamic_price_calc":"Dynamic Price Calc","open":"Open","close":"Close","latest_calc_time":"Latest Calc Time","start_end_time":"Start and End Time","ratio_set":"Ratio Setting","calculation":"Calculate"},"err_msg":"The sum Ratio mast be 100","save":"Save","return":"Return"},"zh-cn":{"columns":{"dynamic_price_calc":"动态价格计算","open":"开启","close":"关闭","latest_calc_time":"最新计算时间","start_end_time":"起止时间","ratio_set":"物流比例设置","calculation":"计算"},"err_msg":"总比例数必须等于100","save":"保存","return":"返回"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "84c9":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"Assign to User":"Assign to User"},"err_msg":"Please Select User"},"zh-cn":{"columns":{"Assign to User":"Assign to User"},"err_msg":"请选择用户"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "865e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/assign_user.vue?vue&type=template&id=8bfd31f2&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":4}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.Assign to User')))])]),_c('a-col',{attrs:{"span":20}},[_c('a-select',{style:({ width: '70%' }),attrs:{"showSearch":"","size":"small","placeholder":"Select User","filterOption":_vm.filterSelectOption},model:{value:(_vm.assign_to_user),callback:function ($$v) {_vm.assign_to_user=$$v},expression:"assign_to_user"}},[_c('a-select-option',{key:"null",attrs:{"value":""}},[_vm._v("null")]),_vm._l((_vm.systemUsers),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(item.name))])})],2)],1)],1),_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{staticClass:"margin-right",on:{"click":_vm.cancel}},[_vm._v(_vm._s(_vm.$t('action.cancel')))]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('action.submit')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/assign_user.vue?vue&type=template&id=8bfd31f2&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/assign_user.vue?vue&type=script&lang=ts&






var datasModule = Object(lib["c" /* namespace */])('datasModule');

var assign_uservue_type_script_lang_ts_AssignUser =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](AssignUser, _super);

  function AssignUser() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.assign_to_user = '';
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    return _this;
  }

  AssignUser.prototype.submit = function (data) {
    return data;
  };

  AssignUser.prototype.cancel = function () {
    return;
  };

  AssignUser.prototype.created = function () {};

  AssignUser.prototype.handleChange = function (value) {//console.log(value)
  };

  AssignUser.prototype.onSubmit = function () {
    var value = [];

    if (this.assign_to_user == '') {
      this.assign_to_user = null; // let err_msg: any = this.$t('err_msg')
      // this.$message.error(err_msg)
      // return
    }

    value['picking_id_list'] = this.picking_id_list;
    value['assign_to_user'] = this.assign_to_user;
    this.assignToUser(value);
  };

  AssignUser.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  AssignUser.prototype.assignToUser = function (value) {
    var _this = this;

    var loading = {};

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.assign_to_user(new http["RequestParams"](value, loading)).subscribe(function (data) {
      _this.submit(data);
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AssignUser.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], AssignUser.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AssignUser.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AssignUser.prototype, "picking_id_list", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], AssignUser.prototype, "changeSpinning", void 0);

  AssignUser = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], AssignUser);
  return AssignUser;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var assign_uservue_type_script_lang_ts_ = (assign_uservue_type_script_lang_ts_AssignUser);
// CONCATENATED MODULE: ./src/components/picking/assign_user.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_assign_uservue_type_script_lang_ts_ = (assign_uservue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/assign_user.vue?vue&type=custom&index=0&blockType=i18n
var assign_uservue_type_custom_index_0_blockType_i18n = __webpack_require__("e16f");

// CONCATENATED MODULE: ./src/components/picking/assign_user.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_assign_uservue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof assign_uservue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(assign_uservue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var assign_user = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "86a2":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "87f7":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "8d8f":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"plzSelect":"Please Select","columns":{"shipment_type":"Shipment Type","product_sku":"product Sku"},"forms":{"default_code":"Default Code","quantity":"Quantity","Add":"Add","manual_url":"New Manual","product_name":"Product Name"},"shipment_type":"Please Select Shipment Type","add_repeatedly":"Please DONT Add repeatedly","product_Part":"At Least Select One Product Part","max_length_32":"Up to 32 characters","create_tmpl_part_no":"TMPL Ersatzteile hinzufügen","add_tmpl_part_no":"TMPL Ersatzteile hinzufügen","part_no_name":"TMPL Ersatzteile","resend_prod_sku":"SKU"},"zh-cn":{"plzSelect":"请选择","columns":{"shipment_type":"包裹类型","product_sku":"产品"},"forms":{"default_code":"sku","quantity":"数量","Add":"添加","manual_url":"说明书查看","product_name":"产品名称"},"shipment_type":"请选择包裹类型","add_repeatedly":"请勿重复添加","product_Part":"至少添加一条产品部件数据","max_length_32":"SKU(含配件号)长度不能超过32个字符","create_tmpl_part_no":"创建临时配件号","add_tmpl_part_no":"添加临时配件号","part_no_name":"配件部位号","resend_prod_sku":"补发产品货号"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "9626":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"forms":{"order_memo":"Memo","cancel_order":"Cancel Order","cancel_memo":"Cancel Memo","customer_reason":"Customer Reason","product_problem":"Product Problem","logistic_reason":"Logistic Reason","warehouse_reason":"Warehouse Reason","send_email":"Send Email"},"action":{"send":"Send Email","cancel":"Cancel"},"email_msg":"Please write all emails","cancel_order_err":"Please Select at least one Reason"},"zh-cn":{"forms":{"order_memo":"Memo","cancel_order":"取消订单","cancel_memo":"取消备注","customer_reason":"客户原因","product_problem":"产品原因","logistic_reason":"物流原因","warehouse_reason":"仓库原因","send_email":"发送邮件"},"action":{"send":"发送","cancel":"取消"},"email_msg":"请将所有邮件都填写完整","cancel_order_err":"请至少选择一条原因"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "977d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/edit-ship-ratio.vue?vue&type=template&id=43f539dc&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('a-row',{attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":4}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.dynamic_price_calc'))+"：")])]),_c('a-col',{attrs:{"span":5}},[_c('a-radio-group',{attrs:{"value":_vm.defaultPriceCalcType,"button-style":"solid","size":"small"},on:{"change":function (e) { return _vm.onPriceCalcChange(e); }}},[_c('a-radio-button',{attrs:{"value":"open"}},[_vm._v(" "+_vm._s(_vm.$t('columns.open'))+" ")]),_c('a-radio-button',{attrs:{"value":"close"}},[_vm._v(" "+_vm._s(_vm.$t('columns.close'))+" ")])],1)],1),_c('a-col',{attrs:{"span":14,"offset":1}},[(_vm.defaultPriceCalcType == 'open')?_c('a-row',{attrs:{"gutter":4}},[_c('a-col',{attrs:{"span":10}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.latest_calc_time'))+"：")])]),_c('a-col',{attrs:{"span":10}},[_c('span',[_vm._v(_vm._s(_vm._f("datetolocal")(_vm.data.write_date)))])]),_c('a-col',{attrs:{"span":3}},[_c('a-button',{attrs:{"type":"primary","size":"small"},on:{"click":_vm.calculation}},[_vm._v(_vm._s(_vm.$t('columns.calculation')))])],1)],1):_c('a-row',{attrs:{"gutter":4}},[_c('a-col',{attrs:{"span":6}},[_c('span',[_vm._v(_vm._s(_vm.$t('columns.start_end_time'))+"：")])]),_c('a-col',{attrs:{"span":16}},[_c('a-range-picker',{attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm:ss","size":"small"},on:{"change":function (e) { return _vm.onStartEndTimeChange(e); }},model:{value:(_vm.startEndTime),callback:function ($$v) {_vm.startEndTime=$$v},expression:"startEndTime"}})],1)],1)],1)],1),(_vm.defaultPriceCalcType == 'close')?_c('a-form',{staticClass:"data-form",attrs:{"layout":"inline","form":_vm.form}},[_c('a-row',{staticStyle:{"margin-top":"30px"},attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":3}},[_c('a-form-item',{attrs:{"label":_vm.$t('columns.ratio_set')}})],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"Hermes:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'hermes_percent',
                            {
                                initialValue: _vm.data.hermes_percent
                                    ? _vm.data.hermes_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'hermes_percent',\n                            {\n                                initialValue: data.hermes_percent\n                                    ? data.hermes_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"Yodel:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'yodel_percent',
                            {
                                initialValue: _vm.data.yodel_percent
                                    ? _vm.data.yodel_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'yodel_percent',\n                            {\n                                initialValue: data.yodel_percent\n                                    ? data.yodel_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"DHL:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'dhl_percent',
                            {
                                initialValue: _vm.data.dhl_percent
                                    ? _vm.data.dhl_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'dhl_percent',\n                            {\n                                initialValue: data.dhl_percent\n                                    ? data.dhl_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"RoyalMail:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'royalmail_percent',
                            {
                                initialValue: _vm.data.royalmail_percent
                                    ? _vm.data.royalmail_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'royalmail_percent',\n                            {\n                                initialValue: data.royalmail_percent\n                                    ? data.royalmail_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1)],1),_c('a-row',{staticStyle:{"margin-top":"30px","margin-bottom":"20px"},attrs:{"gutter":24}},[_c('a-col',{attrs:{"span":5,"offset":3}},[_c('a-form-item',{attrs:{"label":"DPD:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'dpd_percent',
                            {
                                initialValue: _vm.data.dpd_percent
                                    ? _vm.data.dpd_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'dpd_percent',\n                            {\n                                initialValue: data.dpd_percent\n                                    ? data.dpd_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"DX:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'dx_percent',
                            {
                                initialValue: _vm.data.dx_percent
                                    ? _vm.data.dx_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'dx_percent',\n                            {\n                                initialValue: data.dx_percent\n                                    ? data.dx_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"XDP:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'xdp_percent',
                            {
                                initialValue: _vm.data.xdp_percent
                                    ? _vm.data.xdp_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'xdp_percent',\n                            {\n                                initialValue: data.xdp_percent\n                                    ? data.xdp_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1),_c('a-col',{attrs:{"span":5}},[_c('a-form-item',{attrs:{"label":"Tuffnulls:"}},[_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                            'tuffnells_percent',
                            {
                                initialValue: _vm.data.tuffnells_percent
                                    ? _vm.data.tuffnulls_percent
                                    : 0
                            }
                        ]),expression:"[\n                            'tuffnells_percent',\n                            {\n                                initialValue: data.tuffnells_percent\n                                    ? data.tuffnulls_percent\n                                    : 0\n                            }\n                        ]"}],attrs:{"size":"small","min":0,"max":100}}),_vm._v("% ")],1)],1)],1)],1):_vm._e(),(_vm.defaultPriceCalcType == 'close')?_c('div',{staticClass:"flex-row justify-content-end margin-top"},[_c('a-button',{attrs:{"type":"primary","size":"small"},on:{"click":_vm.onSubmit}},[_vm._v(_vm._s(_vm.$t('save')))])],1):_vm._e(),_c('div',{staticClass:"flex-row justify-content-end margin-top",staticStyle:{"margin-top":"35px !important"}},[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.submit}},[_vm._v(_vm._s(_vm.$t('return')))])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/edit-ship-ratio.vue?vue&type=template&id=43f539dc&

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/edit-ship-ratio.vue?vue&type=script&lang=ts&










var datasModule = Object(lib["c" /* namespace */])('datasModule');

var edit_ship_ratiovue_type_script_lang_ts_EditShipRatio =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](EditShipRatio, _super);

  function EditShipRatio() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.data = {};
    _this.assign_to_user = '';
    _this.defaultPriceCalcType = 'open';
    _this.startEndTime = [];
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    return _this;
  }

  EditShipRatio.prototype.submit = function () {
    return [this.data];
  };

  EditShipRatio.prototype.cancel = function () {
    return;
  };

  EditShipRatio.prototype.onInfoChange = function () {
    this.data = Object.assign({}, this.info[0]);
    this.defaultPriceCalcType = this.data.is_dynamic_calculation ? 'open' : 'close';
    this.setFormValues();
  };

  EditShipRatio.prototype.mounted = function () {
    if (this.info) {
      this.data = Object.assign({}, this.info[0]);
      this.defaultPriceCalcType = this.data.is_dynamic_calculation ? 'open' : 'close';
      this.setFormValues();
    }
  };

  EditShipRatio.prototype.created = function () {
    this.form = this.$form.createForm(this);
  };

  EditShipRatio.prototype.setFormValues = function () {
    this.form.setFieldsValue(this.data);
  };

  EditShipRatio.prototype.handleChange = function (value) {//console.log(value)
  };

  EditShipRatio.prototype.onSubmit = function () {
    var _this = this;

    this.form.validateFields({}, function (err, values) {
      var sum = 0;

      for (var i in values) {
        if (values[i] > 0) {
          sum += parseInt(values[i]);
        }
      }

      if (_this.defaultPriceCalcType == 'close') {
        if (sum !== 100) {
          var err_msg = _this.$t('err_msg');

          _this.$message.error(err_msg);

          return;
        }

        if (_this.startEndTime.length == 0) {
          _this.$message.error('请输入起止时间');

          return;
        } else {
          var start = new Date(_this.startEndTime[0].format('YYYY-MM-DD HH:mm:ss'));
          var end = new Date(_this.startEndTime[1].format('YYYY-MM-DD HH:mm:ss'));
          var now = new Date();

          if (end < now) {
            _this.$message.error('开始和结束时间不能小于当前时间');

            return;
          }

          if (start < now) {
            start = now;
          }

          values['start_date'] = moment_default()(start).format('YYYY-MM-DD HH:mm:ss');
          values['end_date'] = moment_default()(end).format('YYYY-MM-DD HH:mm:ss');
        }
      }

      for (var i in values) {
        values[i] = values[i] ? values[i] : 0;
      }

      values['instance'] = 'GB';
      values['warehouse'] = 'uk';
      values['is_dynamic_calculation'] = _this.defaultPriceCalcType == 'open' ? true : false;

      if (_this.data.id) {
        values['id'] = _this.data.id;
      }

      values['product_id'] = _this.data.product_template_logistic_id;

      _this.submitData(values);
    });
  };

  EditShipRatio.prototype.onPriceCalcChange = function (e) {
    this.defaultPriceCalcType = e.target.value;
  };

  EditShipRatio.prototype.onStartEndTimeChange = function (e) {
    this.startEndTime = e;
  };

  EditShipRatio.prototype.submitData = function (params) {
    var _this = this;

    this.innerAction.setActionAPI('theoretical_final_freight/modify_freight', common_service["a" /* CommonService */].getMenuCode('final-shipping-uk'));
    this.publicService.modify(new http["RequestParams"]({
      modify_data: [params]
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      _this.$message.success('修改成功!');

      _this.data['id'] = data.message;

      for (var i in params) {
        if (_this.data[i] !== undefined) {
          _this.data[i] = params[i];
        }
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  EditShipRatio.prototype.calculation = function () {
    var params = {
      is_dynamic_calculation: true,
      product_id: this.data.product_template_logistic_id,
      instance: 'GB',
      warehouse: 'uk'
    };

    if (this.data.id) {
      params['id'] = this.data.id;
    }

    this.submitData(params);
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.submit'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditShipRatio.prototype, "submit", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["b" /* Emit */])('modal.cancel'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditShipRatio.prototype, "cancel", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], EditShipRatio.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], EditShipRatio.prototype, "onInfoChange", null);

  EditShipRatio = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], EditShipRatio);
  return EditShipRatio;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var edit_ship_ratiovue_type_script_lang_ts_ = (edit_ship_ratiovue_type_script_lang_ts_EditShipRatio);
// CONCATENATED MODULE: ./src/components/picking/edit-ship-ratio.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_edit_ship_ratiovue_type_script_lang_ts_ = (edit_ship_ratiovue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/edit-ship-ratio.vue?vue&type=custom&index=0&blockType=i18n
var edit_ship_ratiovue_type_custom_index_0_blockType_i18n = __webpack_require__("743e");

// CONCATENATED MODULE: ./src/components/picking/edit-ship-ratio.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_edit_ship_ratiovue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof edit_ship_ratiovue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(edit_ship_ratiovue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var edit_ship_ratio = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "a2d2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_batch_send_email_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("9626");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_batch_send_email_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_batch_send_email_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_batch_send_email_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "a444":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"shipment_type":"Shipment Type","product_sku":"product Sku"},"forms":{"default_code":"Default Code","quantity":"Quantity","Add":"Add"},"shipment_type":"Please Select Shipment Type","add_repeatedly":"Please DONT Add repeatedly","product_Part":"At Least Select One Product Part","max_length_32":"Up to 32 characters"},"zh-cn":{"columns":{"shipment_type":"包裹类型","product_sku":"产品"},"forms":{"default_code":"sku","quantity":"数量","Add":"添加"},"shipment_type":"请选择包裹类型","add_repeatedly":"请勿重复添加","product_Part":"至少添加一条产品部件数据","max_length_32":"SKU(含配件号)长度不能超过32个字符"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "a467":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("ee0e");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "a558":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_list_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("dddf");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_list_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_list_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_shipment_list_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "a5c3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_return_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3026");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_return_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_return_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_return_detail_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b011":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"desc":"this is a Order Page1","columns":{"rel_name":"rel_name","ship_type":"ship_type","seller_code_list":"seller_code_list","seller_name_list":"seller_name_list","country_code_list":"country_code_list","warehouse_id_list":"warehouse_id_list","warehouse_name_list":"warehouse_name_list","package_size":"package_size","tms_ship_code":"tms_ship_code"},"action":{"cancel":"Cancel","save":"Save"},"delete":"Are you sure delete?","fuzzy_search":"Fuzzy Search","save_success":"Save Success","delete_success":"Delete Success","yes":"Yes","no":"No"},"zh-cn":{"desc":"","columns":{"rel_name":"关系名","ship_type":"物流编码","seller_code_list":"店铺列表","country_code_list":"国家列表","warehouse_name_list":"仓库列表","package_size":"包裹尺寸","tms_ship_code":"tms物流编码"},"action":{"cancel":"取消","save":"保存"},"delete":"是否确认删除?","fuzzy_search":"模糊搜索","save_success":"操作成功","delete_success":"删除成功","yes":"是","no":"否"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "b21f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_delivery_more_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("6076");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_delivery_more_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_delivery_more_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_delivery_more_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "b7d6":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "b899":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c0f3");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_create_return_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "ba21":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("b7d6");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "ba98":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("e370");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_modify_memo_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "bc03":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/demand-detail.vue?vue&type=template&id=4dc23626&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-base-detail"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px"}},[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.addBtn}},[_vm._v(_vm._s(_vm.$t('actions.add')))]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.saveBtn}},[_vm._v(_vm._s(_vm.$t('actions.save')))]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.cancelBtn}},[_vm._v(_vm._s(_vm.$t('actions.cancel')))])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"rowKey":"index","customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"bordered":""}},[_c('a-table-column',{key:"name",attrs:{"title":_vm.$t('product'),"align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-auto-complete',{staticStyle:{"width":"100%"},attrs:{"dataSource":_vm.skuSource,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"defaultValue":row.name,"size":"small","placeholder":"input for search"},on:{"search":_vm.onSkuSearch,"change":function (e) { return _vm.onRowChange(row, 'name', e); }}},[_c('template',{slot:"dataSource"},[_vm._l((_vm.skuSource),function(opt){return _c('a-select-option',{key:opt,attrs:{"value":opt,"title":opt}},[_vm._v(" "+_vm._s(opt)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(row)}}},[_vm._v(" Search More ")])])],2)],2):_c('span',{attrs:{"title":row.name}},[_vm._v(_vm._s(row.name ? row.name.length > 20 ? row.name.substr(0, 17) + '...' : row.name : ''))])]}}])}),_c('a-table-column',{key:"default_code",attrs:{"title":_vm.$t('default_code')},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.product_url && row.product_url.length > 10)?_c('a',{attrs:{"title":"old version of the Product Manual(老版说明书)","href":row.product_url,"target":"_blank"}},[_vm._v(_vm._s(row.default_code))]):_c('span',[_vm._v(" "+_vm._s(row.default_code)+" ")]),(row.manual_id)?_c('span',{attrs:{"title":"new version of the Product Manual(新版说明书)"}},[_c('a',{attrs:{"href":row.manual_url,"target":"_blank"}},[_c('a-icon',{staticStyle:{"margin-left":"10px","color":"blue"},attrs:{"type":"file-text"}})],1)]):_vm._e()]}}])}),_c('a-table-column',{key:"product_uom_qty",attrs:{"title":_vm.$t('quantity'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_uom_qty']),expression:"['product_uom_qty']"}],style:({ width: '100%' }),attrs:{"decimalSeparator":",","value":row.product_uom_qty,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_uom_qty', e); }}}):_c('span',[_vm._v(_vm._s(row.product_uom_qty))])]}}])}),_c('a-table-column',{key:"product_uom",attrs:{"title":_vm.$t('unit_measure'),"data-index":"product_uom","align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(product_uom){return [_c('span',{attrs:{"_id":product_uom}},[_vm._v("Unit")])]}}])}),_c('a-table-column',{key:"stock_de_available_qty",attrs:{"title":_vm.$t('stock_de_available_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.stock_de_available_qty)+" ")]}}])}),_c('a-table-column',{key:"stock_uk_available_qty",attrs:{"title":_vm.$t('stock_uk_available_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.stock_uk_available_qty)+" ")]}}])}),_c('a-table-column',{key:"mv_ship_type",attrs:{"title":_vm.$t('ship_type'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['mv_ship_type']),expression:"['mv_ship_type']"}],style:({ width: '100%' }),attrs:{"value":row.mv_ship_type,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'mv_ship_type', e); }}},_vm._l((_vm.mvShipTypeList),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])}),1):_c('span',[_vm._v(" "+_vm._s(_vm._f("dict2")(row.mv_ship_type,_vm.mvShipTypeList))+" ")])]}}])}),_c('a-table-column',{key:"pre_sale",attrs:{"title":_vm.$t('pre_sale'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pre_sale']),expression:"['pre_sale']"}],attrs:{"disabled":true,"checked":row.pre_sale}})]}}])}),_c('a-table-column',{key:"min_pack",attrs:{"title":_vm.$t('max_pack_qty'),"align":"right"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.min_pack)+" ")]}}])}),_c('a-table-column',{key:"pack_cate",attrs:{"title":_vm.$t('packet_category'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.pack_cate)+" ")]}}])}),_c('a-table-column',{key:"date_count",attrs:{"title":_vm.$t('date_count'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(row.date_count)+" ")]}}])}),_c('a-table-column',{key:"state",attrs:{"title":_vm.$t('status'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_vm._v(" "+_vm._s(_vm._f("translate")(_vm._f("dict")(row.state,'PickingStatus')))+" ")]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.onDel(row)}}},[_vm._v(" "+_vm._s(_vm.$t('actions.delete'))+" ")])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/demand-detail.vue?vue&type=template&id=4dc23626&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/general_code.service.ts
var general_code_service = __webpack_require__("5083");

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/store/index.ts + 9 modules
var store = __webpack_require__("0613");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/demand-detail.vue?vue&type=script&lang=ts&


















var datasModule = Object(lib["c" /* namespace */])('datasModule');

var demand_detailvue_type_script_lang_ts_DemandDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](DemandDetail, _super);

  function DemandDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = []; // private shipmentList: any[] = []

    _this.deleteList = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.generalCodeService = new general_code_service["a" /* GeneralCodeService */]();
    _this.mvShipTypeList = [];
    _this.sd = store["a" /* default */];
    return _this;
  }

  DemandDetail.prototype.mounted = function () {
    this.mvShipTypeList = this.sd.state.datasModule.mvShipTypeList;

    if (this.info.length) {
      this.data = this.info.map(function (x) {
        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        return x;
      });
    }
  };

  DemandDetail.prototype.onInfoChange = function () {
    this.deleteList = [];

    if (this.info.length) {
      this.data = this.info.map(function (x) {
        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        return x;
      });
    } else {
      this.data = [];
    }
  };

  DemandDetail.prototype.addBtn = function () {
    this.data.push({
      save_flag: 0,
      index: uuid_default.a.generate(),
      date_count: '',
      default_code: '',
      min_pack: 0,
      mv_ship_type: '',
      name: '',
      pack_cate: '',
      pre_sale: false,
      product_uom: 1,
      product_uom_qty: 0,
      state: 'draft',
      stock_available_quantity: 0
    });
    this.currentRow = this.data.length;
  };

  DemandDetail.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      row[column] = value.target.value;
    } else {
      row[column] = value;
    }

    if (column === 'name') {
      var productItem = this.skuQueryResult.find(function (x) {
        return '[' + x.default_code + ']' + x.name == value;
      });

      if (productItem) {
        row.default_code = productItem.default_code;
        row.name = productItem.name;
        row.product_id = productItem.product_id;
        row.available_qty = productItem.stock_available_quantity > 0 ? productItem.stock_available_quantity : 0;
      }
    }
  };

  DemandDetail.prototype.saveBtn = function () {
    var _this = this;

    var list = [];

    for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
      var i = _a[_i];
      delete i.index;
      delete i.default_code;
      delete i.min_pack;
      delete i.pack_cate;
      delete i.stock_available_quantity;
      delete i.pre_sale;
      delete i.available_qty;
      delete i.product_url;
      delete i.stock_de_available_qty;
      delete i.stock_uk_available_qty;
      delete i.manual_id;
      delete i.manual_url;
      list.push(i);
    }

    if (this.deleteList.length) {
      for (var _b = 0, _c = this.deleteList; _b < _c.length; _b++) {
        var j = _c[_b];
        delete i.index;
        delete i.default_code;
        delete i.min_pack;
        delete i.pack_cate;
        delete i.stock_available_quantity;
        delete i.pre_sale;
        delete i.available_qty;
        delete i.product_url;
        delete i.stock_de_available_qty;
        delete i.stock_uk_available_qty;
        delete i.manual_id;
        delete i.manual_url;
        list.push(j);
      }
    }

    var loading = '';

    if (this.changeSpinning) {
      this.changeSpinning(true);
    } else {
      loading = {
        loading: this.loadingService
      };
    }

    this.pickingService.saveMove(new http["RequestParams"]({
      picking_id: parseInt(this.id),
      move_list: list
    }, loading)).subscribe(function () {
      _this.deleteList = [];

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }
    }, function (err) {
      if (_this.changeSpinning) {
        _this.changeSpinning(false);
      }

      _this.$message.error(err.message);
    });
  };

  DemandDetail.prototype.cancelBtn = function () {
    this.currentRow = -1;
    this.getDemands();
  };

  DemandDetail.prototype.getDemands = function () {
    var _this = this;

    this.pickingService.queryStockMove(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    })).subscribe(function (data) {
      _this.data = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: uuid_default.a.generate(),
          save_flag: 1
        });
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  DemandDetail.prototype.onDel = function (row) {
    this.currentRow = -1;
    var item = this.data.find(function (x) {
      return x.index === row.index;
    });

    if (item) {
      if (item.save_flag == 1) {
        item['save_flag'] = 2;
        this.deleteList.push(item);
      } else {
        item['save_flag'] = 2;
      }
    }

    this.data = this.data.filter(function (x) {
      return !x.save_flag || x.save_flag < 2;
    });
  };

  DemandDetail.prototype.onSkuSearch = function (key) {
    var _this = this;

    var params = common_service["a" /* CommonService */].createQueryCondition({
      default_code: key
    }, tslib_es6["a" /* __assign */]({
      default_code: 'like'
    }, form_config["a" /* formConfig */].condition));
    params['page_index'] = 1;
    params['page_size'] = 10;
    this.productService.queryAsyncProductInfo(new http["RequestParams"](params)).subscribe(function (data) {
      _this.skuSource = data.map(function (x) {
        return '[' + x.default_code + ']' + x.name;
      });
      _this.skuQueryResult = data;
    });
  };

  DemandDetail.prototype.onSkuChange = function (key, row) {
    if (key && key.length > 1) {
      var productItem = this.skuQueryResult.find(function (x) {
        return x.default_code === key;
      }); // this.product = productItem ? productItem : []
    }
  };

  DemandDetail.prototype.searchMore = function (row) {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {}, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      //sku不能重复
      var item = _this.data.find(function (x) {
        return x.index === row.index;
      });

      item['name'] = '[' + data.default_code + ']' + data.name;
      item['product_id'] = data.product_id;
      item['default_code'] = data.default_code;
      _this.currentRow = -1;

      var _t;

      setTimeout(function () {
        _that.currentRow = row.index;
      }, 100);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DemandDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DemandDetail.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], DemandDetail.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], DemandDetail.prototype, "onInfoChange", null);

  DemandDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], DemandDetail);
  return DemandDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var demand_detailvue_type_script_lang_ts_ = (demand_detailvue_type_script_lang_ts_DemandDetail);
// CONCATENATED MODULE: ./src/components/picking/demand-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_demand_detailvue_type_script_lang_ts_ = (demand_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/demand-detail.vue?vue&type=custom&index=0&blockType=i18n
var demand_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("7f2c");

// CONCATENATED MODULE: ./src/components/picking/demand-detail.vue





/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_demand_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof demand_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(demand_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var demand_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "c0f3":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"selected_ship_type":"Select Ship Type","ship_type":"Ship Type","product_qty":"QTY","Delete":"Delete"},"forms":{"name":"sku","product_qty":"QTY","picking_type":"拣货类型"},"action":{"ok":"Commit"}},"zh-cn":{"columns":{"selected_ship_type":"手动选择","ship_type":"物流方式","product_qty":"数量","Delete":"删除"},"forms":{"name":"sku","product_qty":"数量","picking_type":"拣货类型"},"action":{"ok":"提交"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "c3c6":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "c990":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "cbae":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "cd6b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("27a2");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_picking_manage_content_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "d177":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-manage-content.vue?vue&type=template&id=62db3c2c&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component edit-customer"},[_c('data-form',{ref:"dataForm",attrs:{"extends":_vm.extendItems,"column":2,"lCol":{ span: 7 },"wCol":{ span: 16, offset: 1 },"showSearch":_vm.showSearch},on:{"submit":_vm.getOrderList,"heightChange":_vm.onHeightChange},scopedSlots:_vm._u([{key:"default",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.picking_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name', { initialValue: _vm.defaultName }]),expression:"['name', { initialValue: defaultName }]"}],style:({ width: '300px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.order_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['origin']),expression:"['origin']"}],style:({ width: '300px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.quick_search')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_code',
                        { initialValue: 30 }
                    ]),expression:"[\n                        'fuzzy_search_code',\n                        { initialValue: 30 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('forms.picking_id'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('forms.order_id'))+" ")]),_c('a-select-option',{attrs:{"value":30}},[_vm._v(" Email ")]),_c('a-select-option',{attrs:{"value":40}},[_vm._v(" "+_vm._s(_vm.$t('forms.sku'))+" ")]),_c('a-select-option',{attrs:{"value":50}},[_vm._v(" "+_vm._s(_vm.$t('forms.shipment_num'))+" ")]),_c('a-select-option',{attrs:{"value":60}},[_vm._v(" "+_vm._s(_vm.$t('forms.ebay_buyer_id'))+" ")]),_c('a-select-option',{attrs:{"value":70}},[_vm._v(" "+_vm._s(_vm.$t('columns.customer'))+" ")]),_c('a-select-option',{attrs:{"value":80}},[_vm._v(" "+_vm._s(_vm.$t('columns.zip'))+" ")]),_c('a-select-option',{attrs:{"value":90}},[_vm._v(" "+_vm._s(_vm.$t('columns.street'))+" ")])],1),_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['fuzzy_search_value']),expression:"['fuzzy_search_value']"}],style:({ width: '195px', margin: '0 5px' }),attrs:{"placeholder":_vm.$t('plzInput'),"size":"small"}}),_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'fuzzy_search_operator',
                        { initialValue: 20 }
                    ]),expression:"[\n                        'fuzzy_search_operator',\n                        { initialValue: 20 }\n                    ]"}],style:({ width: '100px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":10}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_like'))+" ")]),_c('a-select-option',{attrs:{"value":20}},[_vm._v(" "+_vm._s(_vm.$t('forms.operator_equal'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.sku')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['default_code']),expression:"['default_code']"}],style:({ width: '300px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.validate_state')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['validate_s', { initialValue: '' }]),expression:"['validate_s', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PickingValidateState),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.payment_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['payment_date']),expression:"['payment_date']"}],style:({ width: '300px' }),attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm","size":"small"}}),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fillToday}},[_vm._v(_vm._s(_vm.$t('action.today'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fillYestoday}},[_vm._v(_vm._s(_vm.$t('action.yestoday'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fill3day}},[_vm._v(_vm._s(_vm.$t('action.3day'))+" ")]),_c('a-button',{staticStyle:{"margin-left":"5px"},attrs:{"size":"small","type":"primary"},on:{"click":_vm.fill3days}},[_vm._v(_vm._s(_vm.$t('action.3days'))+" ")])],1)]},proxy:true},{key:"collapse",fn:function(){return [_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.status')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['state', { initialValue: '' }]),expression:"['state', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.PickingStatus),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":"Email"}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['email']),expression:"['email']"}],style:({ width: '200px' }),attrs:{"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.seller_code')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['seller_code', { initialValue: '' }]),expression:"['seller_code', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","mode":"multiple","size":"small","placeholder":"Please Select","filter-option":_vm.filterOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sellerCodeList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('columns.instance_code')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['instance_code', { initialValue: '' }]),expression:"['instance_code', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","placeholder":"Please Select","mode":"multiple","filter-option":_vm.filterOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.sellerInstanceList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.prime')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['amazon_type_sale', { initialValue: '' }]),expression:"['amazon_type_sale', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.pre_sale')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['pick_pre_sale', { initialValue: '' }]),expression:"['pick_pre_sale', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.is_resend')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['is_resend', { initialValue: '' }]),expression:"['is_resend', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.ebay_plus')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ebay_plus_type', { initialValue: '' }]),expression:"['ebay_plus_type', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.sold_out')}},[_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:([
                        'is_sold_out',
                        { initialValue: _vm.defaultSaleOut }
                    ]),expression:"[\n                        'is_sold_out',\n                        { initialValue: defaultSaleOut }\n                    ]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onSaleOutChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_c('a-radio-button',{attrs:{"value":true}},[_vm._v(" "+_vm._s(_vm.$t('yes'))+" ")]),_c('a-radio-button',{attrs:{"value":false}},[_vm._v(" "+_vm._s(_vm.$t('no'))+" ")])],1),(_vm.defaultSaleOut)?_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sold_out_time']),expression:"['sold_out_time']"}],staticStyle:{"margin-left":"5px"},attrs:{"format":"YYYY-MM-DD HH:mm:ss","size":"small"}}):_vm._e()],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.shipment_num')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['shipment_num']),expression:"['shipment_num']"}],style:({ width: '200px' }),attrs:{"placeholder":_vm.$t('split_query_condition'),"size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.order_from')}},[(_vm.page_flag == 'aliexpress')?_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['platform', { initialValue: 60 }]),expression:"['platform', { initialValue: 60 }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"}},[_c('a-radio-button',{attrs:{"value":60}},[_vm._v(" Aliexpress ")])],1):_c('a-radio-group',{directives:[{name:"decorator",rawName:"v-decorator",value:(['platform', { initialValue: '' }]),expression:"['platform', { initialValue: '' }]"}],style:({ height: '20px' }),attrs:{"size":"small","buttonStyle":"solid"},on:{"change":function (e) { return _vm.onStatusChange(e); }}},[_c('a-radio-button',{attrs:{"value":""}},[_vm._v(" "+_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.$dict.SellerPlatform),function(item){return _c('a-radio-button',{key:item.value,attrs:{"value":item.value}},[_vm._v(_vm._s(_vm.$t(item.label))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.ship_type')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['mv_ship_type', { initialValue: '' }]),expression:"['mv_ship_type', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"size":"small"}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.shipmentList),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])})],2)],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.latest_ship_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['latest_ship_date_new']),expression:"['latest_ship_date_new']"}],attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.create_date')}},[_c('a-range-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['create_date']),expression:"['create_date']"}],attrs:{"show-time":"","format":"YYYY-MM-DD HH:mm:ss","size":"small"}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.ebay_buyer_id')}},[_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ebay_buyer_id']),expression:"['ebay_buyer_id']"}],style:({ width: '300px' }),attrs:{"size":"small","placeholder":_vm.$t('split_query_condition')}})],1),_c('a-form-item',{staticStyle:{"height":"35px","margin":"0"},attrs:{"label":_vm.$t('forms.assign_to_user')}},[_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['assign_to_user', { initialValue: '' }]),expression:"['assign_to_user', { initialValue: '' }]"}],style:({ width: '200px' }),attrs:{"showSearch":"","size":"small","filter-option":_vm.filterOption}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('dict.all'))+" ")]),_vm._l((_vm.customerServiceUser),function(item){return _c('a-select-option',{key:item.code,attrs:{"value":item.code}},[_vm._v(_vm._s(_vm.$t(item.name))+" ")])})],2)],1)]},proxy:true},{key:"action",fn:function(){return [_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.reserve}},[_vm._v(" "+_vm._s(_vm.$t('action.reserved'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.validateAddress}},[_vm._v(_vm._s(_vm.$t('action.validate_address'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.createShipment}},[_vm._v(" "+_vm._s(_vm.$t('action.auto_create'))+" ")]),_c('a-button',{staticStyle:{"display":"none"},attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.donePickingGetLabel}},[_vm._v(_vm._s(_vm.$t('action.done_picking_get_label'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.modifyAddress}},[_vm._v(_vm._s(_vm.$t('action.modify_address'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.fake_shipments}},[_vm._v(_vm._s(_vm.$t('action.fake_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.upload_shipment}},[_vm._v(_vm._s(_vm.$t('action.upload_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.upload_fake_shipment}},[_vm._v(_vm._s(_vm.$t('action.upload_fake_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.createReturn}},[_vm._v(_vm._s(_vm.$t('action.createReturn'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.deliveryMore}},[_vm._v(_vm._s(_vm.$t('action.deliveryMore'))+" ")]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(
                    _vm.data.length > 0 &&
                        _vm.selectedRowKeys.length &&
                        _vm.data.find(function (x) { return x['id'] == _vm.selectedRowKeys[0]; }) &&
                        _vm.data.find(function (x) { return x['id'] == _vm.selectedRowKeys[0]; })[
                            'is_resend'
                        ]
                ),expression:"\n                    data.length > 0 &&\n                        selectedRowKeys.length &&\n                        data.find(x => x['id'] == selectedRowKeys[0]) &&\n                        data.find(x => x['id'] == selectedRowKeys[0])[\n                            'is_resend'\n                        ]\n                "}],attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.productPart}},[_vm._v(_vm._s(_vm.$t('action.ProductPart'))+" ")]),_c('a-button',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.multiCreateInvoice}},[_vm._v(" "+_vm._s(_vm.$t('action.create_invovice'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.createShipmentByType('dhl')}}},[_vm._v(" "+_vm._s(_vm.$t('action.create_dhl'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.createShipmentByType('dpd')}}},[_vm._v(" "+_vm._s(_vm.$t('action.create_dpd'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.createShipmentByType('gls')}}},[_vm._v(" "+_vm._s(_vm.$t('action.create_gls'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.createShipmentByType('brief')}}},[_vm._v(_vm._s(_vm.$t('action.create_brief'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":function($event){return _vm.createGift()}}},[_vm._v(_vm._s(_vm.$t('action.create_gift'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.batchSendEmail}},[_vm._v(_vm._s(_vm.$t('action.batch_send_email'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary","disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.assignToUser}},[_vm._v(_vm._s(_vm.$t('action.assign_to_user'))+" ")]),_c('a-menu-item',{attrs:{"disabled":_vm.selectedRowKeys.length == 0},on:{"click":_vm.viewAmazonInvoicePDF}},[_vm._v(_vm._s(_vm.$t('action.viewAmazonInvoicePDF'))+" ")]),_c('a-menu-item',{directives:[{name:"auth",rawName:"v-auth",value:('make_done'),expression:"'make_done'"}],attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.makeDone}},[_vm._v(_vm._s(_vm.$t('action.make_done'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v("Action "),_c('a-icon',{attrs:{"type":"down"}})],1)],1),_c('a-dropdown',{ref:"dropdown",attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.deletePicking}},[_vm._v(_vm._s(_vm.$t('action.deletePicking'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.cancelPicking}},[_vm._v(_vm._s(_vm.$t('action.cancelPicking'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.setAsDraft}},[_vm._v(_vm._s(_vm.$t('action.setAsDraft'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.setPresale}},[_vm._v(_vm._s(_vm.$t('action.setPresale'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.cancelPresale}},[_vm._v(_vm._s(_vm.$t('action.cancelPresale'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.markSoldOut}},[_vm._v(_vm._s(_vm.$t('action.markSoldOut'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.cancelSoldOut}},[_vm._v(_vm._s(_vm.$t('action.cancelSoldOut'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.checkShipments}},[_vm._v(_vm._s(_vm.$t('action.checkShipmentCount'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.cancelCheckShipments}},[_vm._v(_vm._s(_vm.$t('action.cancelShipmentCount'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.forceAvailability}},[_vm._v(_vm._s(_vm.$t('action.force_available'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.OnRefund}},[_vm._v(_vm._s(_vm.$t('action.refund'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.createCPofAllProduct}},[_vm._v(_vm._s(_vm.$t('action.createCp'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.serviceProcess}},[_vm._v(_vm._s(_vm.$t('action.serviceProcess'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.returnProcess}},[_vm._v(_vm._s(_vm.$t('action.returnProcess'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.showStopConfirm}},[_vm._v(_vm._s(_vm.$t('action.customer_service_stop_plz'))+" ")]),_c('a-menu-item',{attrs:{"disabled":!_vm.selectedRowKeys.length},on:{"click":_vm.showRefundConfirm}},[_vm._v(_vm._s(_vm.$t( 'action.cancel_stock_picking_for_order_refund' ))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"2px"}},[_vm._v(_vm._s(_vm.$t('action.more_btn'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]},proxy:true}])}),_c('DragArea',{attrs:{"formShow":_vm.isDataFormShow},on:{"traggle":_vm.onDragChange},scopedSlots:_vm._u([{key:"up",fn:function(){return [(!_vm.groupbyList.length)?_c('div',[_c('AutoColumnTable',{attrs:{"stripe":true,"data":_vm.data,"page":_vm.pageService,"queryNameAuth":_vm.allNameAuth,"rowKey":"id","columns":_vm.columnList,"rowSelection":{
                        selectedRowKeys: _vm.selectedRowKeys,
                        onChange: function (keys) { return (_vm.selectedRowKeys = keys); }
                    },"scroll":{ x: 1800, y: _vm.formDivHeight },"queryUrl":_vm.queryUrl,"menu_code":_vm.dataForm.menu_code,"queryCondition":_vm.queryConsition,"selectedRowCnt":_vm.selectedRowKeys.length},on:{"on-page-change":_vm.getOrderList,"onClick":function (record) {
                            _vm.selectedRowKeys = [record]
                            _vm.onTrClick(record)
                        },"tbchange":_vm.onTableChange},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"lock",fn:function(text, row){return _c('span',{},[(
                                row.state == 'done' &&
                                    row.updated_in_platform
                            )?_c('a-icon',{staticStyle:{"margin-right":"10px"},attrs:{"type":"lock"}}):_vm._e()],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"color_render",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(" "+_vm._s(text != null ? text : '')+" ")])]}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(_vm._s(row.name ? row.name : ''))]),_c('a-icon',{staticStyle:{"margin-left":"10px","color":"blue"},attrs:{"type":"file-text"},on:{"click":function($event){return _vm.showDetailPage(row)}}})]}},{key:"product_name",fn:function(textr, row){return [_c('span',{class:_vm.calcStyle(row),attrs:{"title":row.product_name}},[_vm._v(" "+_vm._s(row.product_name ? row.product_name.substr(0, 15) + (row.product_name.length > 15 ? '...' : '') : '')+" ")])]}},{key:"instance_code",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(" "+_vm._s(row.instance_code ? _vm.sellerInstanceDict[row.instance_code] : '')+" ")])]}},{key:"origin",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.toPageOrder(row.origin)}}},[_vm._v(_vm._s(row.origin ? row.origin : ''))])]}},{key:"memo",fn:function(text, row){return [_c('a',{staticStyle:{"color":"blue"},attrs:{"title":row.memo},on:{"click":function($event){return _vm.onEditMemo(row)}}},[_vm._v(" "+_vm._s(row.memo ? row.memo.substr(0, 10) : _vm.$t('no'))+" ")])]}},{key:"state",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.state ? row.state : '','PickingStatus'))))])]}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}}],null,false,3142001616)})],1):_c('GroupbyTable',{ref:"groupbyTable",attrs:{"groupByColumn":_vm.groupbyList,"oColumns":_vm.columnList,"queryNameAuth":_vm.allNameAuth,"urlStr":_vm.queryUrl,"scrollX":1800,"scrollY":_vm.formDivHeight},on:{"selectChange":_vm.onSelectChange,"rowClick":_vm.onTrClick},scopedSlots:_vm._u([{key:"check_render",fn:function(text){return _c('span',{},[_c('a-checkbox',{attrs:{"disabled":"","checked":text}})],1)}},{key:"show_message_tips",fn:function(text){return _c('span',{attrs:{"title":text}},[_vm._v(" "+_vm._s(text ? text.length > 20 ? text.substr(0, 17) + '...' : text : '')+" ")])}},{key:"color_render",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(" "+_vm._s(text != null ? text : '')+" ")])]}},{key:"lock",fn:function(text, row){return _c('span',{},[(row.state == 'done')?_c('a-icon',{staticStyle:{"margin-right":"10px"},attrs:{"type":"lock"}}):_vm._e()],1)}},{key:"date_render",fn:function(text){return _c('span',{},[_vm._v(_vm._s(_vm._f("datetolocal")(text))+" ")])}},{key:"name",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(_vm._s(row.name ? row.name : ''))]),_c('a-icon',{staticStyle:{"margin-left":"10px","color":"blue"},attrs:{"type":"file-text"},on:{"click":function($event){return _vm.showDetailPage(row)}}})]}},{key:"product_name",fn:function(textr, row){return [_c('span',{class:_vm.calcStyle(row),attrs:{"title":row.product_name}},[_vm._v(" "+_vm._s(row.product_name ? row.product_name.substr(0, 15) + (row.product_name.length > 15 ? '...' : '') : '')+" ")])]}},{key:"instance_code",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(" "+_vm._s(row.instance_code ? _vm.sellerInstanceDict[row.instance_code] : '')+" ")])]}},{key:"origin",fn:function(text, row){return [_c('a',{on:{"click":function($event){return _vm.toPageOrder(row.origin)}}},[_vm._v(_vm._s(row.origin ? row.origin : ''))])]}},{key:"memo",fn:function(text, row){return [_c('a',{staticStyle:{"color":"blue"},attrs:{"title":row.memo},on:{"click":function($event){return _vm.onEditMemo(row)}}},[_vm._v(" "+_vm._s(row.memo ? row.memo.substr(0, 10) : _vm.$t('no'))+" ")])]}},{key:"state",fn:function(text, row){return [_c('span',{class:_vm.calcStyle(row)},[_vm._v(_vm._s(_vm._f("translate")(_vm._f("dict")(row.state ? row.state : '','PickingStatus'))))])]}},{key:"user_render",fn:function(text){return [(!text)?_c('span'):_c('span',[_vm._v(_vm._s(_vm._f("dict2")(text,_vm.systemUsers)))])]}}])})]},proxy:true},{key:"down",fn:function(){return [_c('PickingDetail',{attrs:{"detail":_vm.detailInfo,"id":_vm.picking_id,"pageShow":false,"cnt":_vm.changeCnt,"countryList":_vm.countryList,"systemUsers":_vm.systemUsers,"divHeight":_vm.detailDivHeight}})]},proxy:true}])})],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/picking-manage-content.vue?vue&type=template&id=62db3c2c&

// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/typeof.js
var esm_typeof = __webpack_require__("53ca");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/web.dom-collections.for-each.js
var web_dom_collections_for_each = __webpack_require__("159b");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__("00b4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.join.js
var es_array_join = __webpack_require__("a15b");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/services/shipment.service.ts
var shipment_service = __webpack_require__("1af5");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/page.service.ts
var page_service = __webpack_require__("70f3");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/shared/components/data-form.vue + 2 modules
var data_form = __webpack_require__("f878");

// EXTERNAL MODULE: ./src/components/picking/picking-detail.vue + 4 modules
var picking_detail = __webpack_require__("04d5");

// EXTERNAL MODULE: ./src/components/picking/create-return.vue + 4 modules
var create_return = __webpack_require__("7053");

// EXTERNAL MODULE: ./src/shared/components/page-container.vue + 14 modules
var page_container = __webpack_require__("4d09");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/services/seller-instance.service.ts
var seller_instance_service = __webpack_require__("5c97");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./src/components/picking/batch-send-email.vue + 4 modules
var batch_send_email = __webpack_require__("7f15");

// EXTERNAL MODULE: ./src/components/picking/delivery-more.vue + 4 modules
var delivery_more = __webpack_require__("2b19");

// EXTERNAL MODULE: ./src/components/picking/product-part.vue + 4 modules
var product_part = __webpack_require__("1eb8");

// EXTERNAL MODULE: ./src/components/picking/assign_user.vue + 4 modules
var assign_user = __webpack_require__("865e");

// EXTERNAL MODULE: ./src/shared/components/drag-area.vue + 4 modules
var drag_area = __webpack_require__("4ad2");

// EXTERNAL MODULE: ./src/components/common/refund-form.vue + 4 modules
var refund_form = __webpack_require__("28e6");

// EXTERNAL MODULE: ./src/services/general_code.service.ts
var general_code_service = __webpack_require__("5083");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./src/services/cs-email.service.ts
var cs_email_service = __webpack_require__("00a1");

// EXTERNAL MODULE: ./src/services/account.service.ts
var account_service = __webpack_require__("82e7");

// EXTERNAL MODULE: ./src/services/user.service.ts
var user_service = __webpack_require__("2138");

// EXTERNAL MODULE: ./src/config/app.config.ts
var app_config = __webpack_require__("c249");

// EXTERNAL MODULE: ./src/components/picking/picking-modify-memo.vue + 4 modules
var picking_modify_memo = __webpack_require__("5c1f");

// EXTERNAL MODULE: ./src/components/common/groupby-table.vue + 7 modules
var groupby_table = __webpack_require__("c572");

// EXTERNAL MODULE: ./src/shared/components/auto-column-table.vue + 2 modules
var auto_column_table = __webpack_require__("39e1");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// EXTERNAL MODULE: ./src/components/orders/cancel-order-form.vue + 4 modules
var cancel_order_form = __webpack_require__("a03e");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--16-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--16-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-manage-content.vue?vue&type=script&lang=tsx&













































var userModule = Object(lib["c" /* namespace */])('userModule');
var datasModule = Object(lib["c" /* namespace */])('datasModule');

var picking_manage_contentvue_type_script_lang_tsx_PickingManageContent =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PickingManageContent, _super);

  function PickingManageContent() {
    var _this_1 = _super !== null && _super.apply(this, arguments) || this;

    _this_1.showSearch = true; // Loading服务

    _this_1.pickingService = new picking_service["a" /* PickingService */]();
    _this_1.shipmentService = new shipment_service["a" /* ShipmentService */]();
    _this_1.emailService = new cs_email_service["a" /* EmailService */]();
    _this_1.accountService = new account_service["a" /* AccountService */]();
    _this_1.userService = new user_service["a" /* UserService */](); // Loading服务

    _this_1.loadingService = new loading_service["a" /* LoadingService */](); // 分页服务

    _this_1.pageService = new page_service["a" /* PageService */]();
    _this_1.sellerInstanceService = new seller_instance_service["a" /* SellerInstanceService */]();
    _this_1.generalCodeService = new general_code_service["a" /* GeneralCodeService */](); // 表格数据源

    _this_1.data = [];
    _this_1.showBtn = false;
    _this_1.sellerInstanceList = [];
    _this_1.sellerInstanceDict = {}; // 表格选择项

    _this_1.selectedRowKeys = [];
    _this_1.sellerCodeList = [];
    _this_1.shipmentList = [];
    _this_1.customerServiceUser = [];
    _this_1.publicService = new public_service["a" /* PublicService */]();
    _this_1.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this_1.defaultSaleOut = ''; // 详情项

    _this_1.detailInfo = null;
    _this_1.picking_id = 0;
    _this_1.changeCnt = 0;
    _this_1.defaultName = '';
    _this_1.isDataFormShow = true;
    _this_1.formDivHeight = 400;
    _this_1.detailDivHeight = 300;
    _this_1.orderBy = 'payment_date desc';
    _this_1.groupbyList = [];
    _this_1.allNameAuth = [];
    _this_1.columnList = [];
    _this_1.queryUrl = '/stock_picking/query_all';
    _this_1.queryConsition = [];
    _this_1.moment = moment_default.a;
    _this_1.initialDate = [];
    return _this_1; // private getQrCondition() {
    //     this.getQueryCondition()
    //         .then(condition => {
    //             return condition
    //         })
    //         .catch(err => {
    //             return ''
    //         })
    // }
  }

  PickingManageContent.prototype.showhideSearch = function (flag) {
    this.showSearch = flag;
  };

  Object.defineProperty(PickingManageContent.prototype, "extendItems", {
    // 开启后页面的查询条件会出现‘更多’
    get: function get() {
      return form_config["a" /* formConfig */].defaults();
    },
    enumerable: true,
    configurable: true
  });
  Object.defineProperty(PickingManageContent.prototype, "rules", {
    get: function get() {
      return {};
    },
    enumerable: true,
    configurable: true
  });

  PickingManageContent.prototype.created = function () {
    this.getMvShipType();
    this.getcountry();
    this.getcurrency();
    this.getSystemuser();
    this.getSellerInstanceList();
    this.getSellerCodeList();
    this.getShipmentList();
    this.getCustomerServiceUserList();

    var _that = this;

    document.onkeydown = function (e) {
      var event = e || window.event || arguments.callee.caller.arguments[0];

      if (event.ctrlKey && event.keyCode == 81) {
        _that.getOrderList();
      }
    };
  };

  PickingManageContent.prototype.mounted = function () {
    this.groupbyList = this.dataForm.checkedGroupbyList;
    this.columnList = this.dataForm.tableColumns;
    this.allNameAuth = this.dataForm.queryNameAuth;

    if (this.$route.params.name2) {
      this.defaultName = this.$route.params.name2;
      var values = this.dataForm.getValues();
      values['name'] = this.defaultName;
      this.dataForm.setValues(values);
      this.getOrderList();
    }
  };

  PickingManageContent.prototype.showStopConfirm = function () {
    var _this = this;

    this.$confirm({
      title: this.$t('action.confirm_operate_wrong_address'),
      onOk: function onOk() {
        _this.customer_service_stop_plz();
      },
      onCancel: function onCancel() {}
    });
  };

  PickingManageContent.prototype.showRefundConfirm = function () {
    var _this = this;

    this.$confirm({
      title: this.$t('action.confirm_operate_refund_order'),
      onOk: function onOk() {
        _this.cancel_stock_picking_for_order_refund();
      },
      onCancel: function onCancel() {}
    });
  };

  PickingManageContent.prototype.onRouteChange = function (newRoute, oldRoute) {
    if (this.$route.params.name2) {
      var values = this.dataForm.getValues();
      values['name'] = this.$route.params.name2;
      this.dataForm.setValues(values);

      if (this.data.length === 0) {
        this.getOrderList();
      }
    }
  };

  PickingManageContent.prototype.onCreate = function () {};

  PickingManageContent.prototype.onSaleOutChange = function (e) {
    this.defaultSaleOut = e.target.value;
  };

  PickingManageContent.prototype.getCustomerServiceUserList = function () {
    var _this_1 = this;

    this.userService.customerServiceUser(new http["RequestParams"]({})).subscribe(function (data) {
      _this_1.customerServiceUser = data;
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.getSellerCodeList = function () {
    var _this_1 = this;

    this.sellerInstanceService.query_seller_name(new http["RequestParams"]({})).subscribe(function (data) {
      _this_1.sellerCodeList = data;
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.getSellerInstanceList = function () {
    var _this_1 = this;

    this.sellerInstanceService.queryInstanceList(new http["RequestParams"]()).subscribe(function (data) {
      _this_1.sellerInstanceList = data;

      for (var _i = 0, data_1 = data; _i < data_1.length; _i++) {
        var i = data_1[_i];
        _this_1.sellerInstanceDict[i.code] = i.name;
      }
    });
  };

  PickingManageContent.prototype.getShipmentList = function () {
    var _this_1 = this;

    this.generalCodeService.queryShipType(new http["RequestParams"]()).subscribe(function (data) {
      _this_1.shipmentList = data;
    }, function (err) {
      _this_1.$message.error('获取物流方式失败');
    });
  };

  PickingManageContent.prototype.onHeightChange = function (key) {
    this.isDataFormShow = key;
  };

  PickingManageContent.prototype.onDragChange = function (param) {
    this.formDivHeight = param[0] - 110 > 0 ? param[0] - 110 : 0;
    this.detailDivHeight = param[1] - 97 > 0 ? param[1] - 97 : 0;
  };
  /**
   * 获取订单数据
   */


  PickingManageContent.prototype.getOrderList = function () {
    var _this_1 = this;

    var params = {};
    this.getQueryCondition().then(function (nowConditions) {
      _this_1.queryConsition = nowConditions;

      if (_this_1.groupbyList.length) {
        var groupbyTable = _this_1.$refs.groupbyTable;
        groupbyTable.getFirstTableData(nowConditions);
      } else {
        params.query_condition = nowConditions;

        if (_this_1.orderBy) {
          params['order_by'] = _this_1.orderBy;
        }

        _this_1.innerAction.setActionAPI(_this_1.queryUrl, common_service["a" /* CommonService */].getMenuCode('picking-manage'));

        _this_1.publicService.queryPagination(new http["RequestParams"](params, {
          page: _this_1.pageService,
          loading: _this_1.loadingService,
          innerAction: _this_1.innerAction
        })).subscribe(function (data) {
          _this_1.data = data;
          _this_1.selectedRowKeys = [];

          if (_this_1.data.length > 0) {
            _this_1.selectedRowKeys.push(_this_1.data[0].id);

            _this_1.onDetail(_this_1.data[0]);
          }

          _this_1.changeCnt += 1;
        }, function (err) {
          _this_1.$message.error(err.message);
        });
      }
    });
  };

  PickingManageContent.prototype.onEdit = function (row) {};

  PickingManageContent.prototype.modifyAddress = function () {
    var rks = this.selectedRowKeys;
    this.selectedRowKeys = [];
    router["a" /* default */].push({
      name: 'modify-address',
      params: {
        pickingList: JSON.stringify(rks)
      }
    });
  };

  PickingManageContent.prototype.validateAddress = function () {
    var _this_1 = this;

    this.pickingService.validateAddress(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.deliveryMore = function () {
    var _this_1 = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只限选择一条');
      return;
    }

    this.$modal.open(delivery_more["a" /* default */], {
      picking_id: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.deliveryMore'),
      width: '800px'
    }).subscribe(function (data) {
      var orderId = '';

      var order = _this_1.data.find(function (x) {
        return x.id === _this_1.selectedRowKeys[0];
      });

      if (order) {
        var formValue = _this_1.dataForm.getValues();

        formValue['origin'] = order.origin;

        _this_1.dataForm.setValues(formValue);
      }

      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();

      _this_1.$router.push({
        name: 'picking-detail',
        path: "/picking/picking-detail/" + data.new_picking_id,
        params: {
          id: data.new_picking_id,
          name: data.new_picking_name
        }
      });
    });
  };

  PickingManageContent.prototype.productPart = function () {
    var _this_1 = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只限选择一条');
      return;
    }

    this.$modal.open(product_part["a" /* default */], {
      picking_id: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.ProductPart'),
      width: '800px'
    }).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    });
  };

  PickingManageContent.prototype.batchSendEmail = function () {
    var _this_1 = this;

    this.$modal.open(batch_send_email["a" /* default */], {
      stock: this.selectedRowKeys
    }, {
      title: this.$t('action.batch_send_email'),
      width: '1000px'
    }).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    });
  };

  PickingManageContent.prototype.createShipmentByType = function (type) {
    var _this_1 = this;

    this.pickingService.create_shipment_lines_by_ship_type(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys,
      ship_type: type
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.createCPofAllProduct = function () {
    var _this_1 = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只限选择一条');
      return;
    }

    var row = this.data.find(function (x) {
      return x.id == _this_1.selectedRowKeys[0];
    });

    if (row) {
      router["a" /* default */].push({
        name: 'modify-custom-problem',
        params: {
          orderId: row.order_id
        }
      });
    }
  };

  PickingManageContent.prototype.makeDone = function () {
    var _this_1 = this;

    this.innerAction.setActionAPI('/stock_picking/make_picking_done_out', common_service["a" /* CommonService */].getMenuCode('picking-manage'));
    this.publicService.modify(new http["RequestParams"]({
      pick_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService,
      innerAction: this.innerAction
    })).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.showDetailPage = function (row) {
    this.$router.push({
      name: 'picking-detail',
      path: "/picking/picking-detail/" + row.id,
      params: {
        id: row.id,
        name: row.name
      }
    });
  };

  PickingManageContent.prototype.forceAvailability = function () {
    var _this_1 = this;

    var _loop_1 = function _loop_1(i) {
      var row = this_1.data.find(function (x) {
        return x.id == i;
      });

      if (!row || row.state !== 'confirmed') {
        this_1.$message.error('所选的picking的状态必须为等待可用');
        return {
          value: void 0
        };
      }
    };

    var this_1 = this;

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var i = _a[_i];

      var state_1 = _loop_1(i);

      if (Object(esm_typeof["a" /* default */])(state_1) === "object") return state_1.value;
    }

    this.pickingService.force_available(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this_1.$message.success('操作成功');
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.assignToUser = function () {
    var _this_1 = this;

    this.$modal.open(assign_user["a" /* default */], {
      picking_id_list: this.selectedRowKeys,
      systemUsers: this.systemUsers
    }, {
      title: 'Assign To User',
      width: '60%'
    }).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    });
  };

  PickingManageContent.prototype.onDetail = function (row) {
    var _this_1 = this;

    this.picking_id = row.id;
    this.pickingService.queryDetail(new http["RequestParams"]({
      picking_id: row.id
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      if (data.length) {
        data[0]['id'] = row.id;
        _this_1.detailInfo = data[0];
      } // this.$nextTick(() => this.pageContainer.scrollToBottom())

    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.onClose = function () {
    this.detailInfo = null;
  };

  PickingManageContent.prototype.onTrClick = function (record) {
    var info = this.data.find(function (x) {
      return x.id == record;
    });

    if (info) {
      this.onDetail(info);
    } else if (this.groupbyList.length) {
      this.onDetail({
        id: record
      });
    }
  };

  PickingManageContent.prototype.onStatusChange = function (e) {};

  PickingManageContent.prototype.calcStyle = function (row) {
    if (row.pick_pre_sale) {
      return 'blue-text';
    } else if (row.state == 'cancel') {
      return 'gray-text';
    } else {
      var today_end = this.get_endtime();
      var time_old = row.payment_date ? row.payment_date.substr(0, 10).replace(/-/g, '') + '235959' : '';

      if (today_end == time_old) {
        return 'red-text';
      } else {
        return 'default-text';
      }
    }
  };

  PickingManageContent.prototype.calcStyle2 = function (row) {
    if (row.validate_s === 'ok') {
      return 'green-text';
    } else if (row.validate_s === 'error') {
      return 'red-text';
    } else {
      return 'blue-text';
    }
  };

  PickingManageContent.prototype.get_endtime = function () {
    var time_end = new Date(new Date(new Date().toLocaleDateString()).getTime() + 24 * 60 * 60 * 1000 - 1);
    var time_format = this.format_date(time_end);
    return time_format;
  };

  PickingManageContent.prototype.modifyCP = function () {
    var _this_1 = this;

    var order_ids = [];
    this.selectedRowKeys.forEach(function (value) {
      order_ids.push(_this_1.data.filter(function (item) {
        return value === item.id;
      })[0].order_id);
    });
    router["a" /* default */].push({
      name: 'modify-custom-problem',
      params: {
        orderList: JSON.stringify(order_ids)
      }
    });
  };

  PickingManageContent.prototype.format_date = function (now) {
    var year = now.getFullYear(); //年

    var month = now.getMonth() + 1; //月

    var day = now.getDate(); //日

    var hh = now.getHours(); //时

    var mm = now.getMinutes(); //分

    var ss = now.getSeconds(); //秒

    var clock = year + '';

    if (month < 10) {
      clock += '0';
    }

    clock += month + '';

    if (day < 10) {
      clock += '0';
    }

    clock += day + '';

    if (hh < 10) {
      clock += '0';
    }

    clock += hh + '';

    if (mm < 10) {
      clock += '0';
    }

    clock += mm;

    if (ss < 10) {
      clock += '0';
    }

    clock += ss;
    return clock;
  };

  PickingManageContent.prototype.cancelPicking = function () {
    var _this_1 = this;

    this.pickingService.cancelPicking(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList(); // let orders: any = []
      // for(let i in this.selectedRowKeys) {
      //     let row = this.data.find(x=>x.id === i)
      //     if(row && row.origin !== undefined && (row.origin.includes('B2C-otto') || row.origin.includes('B2C-eugad') || row.origin.includes('B2C-eugad'))) {
      //         let ordernumber = ''
      //         orders.push(ordernumber)
      //     }
      // }
      // if(orders.length) {  //同步到shopware
      //     //
      // }

    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.setAsDraft = function () {
    var _this_1 = this;

    this.pickingService.setAsDraft(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.setPresale = function () {
    var _this_1 = this;

    this.pickingService.setPresale(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.createReturn = function () {
    var _this_1 = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只限选择一条');
      return;
    }

    this.$modal.open(create_return["a" /* default */], {
      picking_id: this.selectedRowKeys[0]
    }, {
      title: this.$t('columns.Create Return Shipment'),
      width: '50%'
    }).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    });
  };

  PickingManageContent.prototype.cancelPresale = function () {
    var _this_1 = this;

    this.pickingService.cancelPresale(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.markSoldOut = function () {
    var _this_1 = this;

    this.pickingService.markSoldOut(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.cancelSoldOut = function () {
    var _this_1 = this;

    this.pickingService.cancelSoldOut(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.checkShipments = function () {
    var _this_1 = this;

    this.pickingService.checkShipments(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.cancelCheckShipments = function () {
    var _this_1 = this;

    this.pickingService.cancelCheckShipments(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.serviceProcess = function () {
    var _this_1 = this;

    this.pickingService.serviceProcess(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.OnRefund = function () {
    var _this_1 = this;

    if (this.selectedRowKeys.length > 1) {
      this.$message.error('只限选择一条');
      return;
    }

    var row = this.data.find(function (x) {
      return x.id == _this_1.selectedRowKeys[0];
    });

    if (row) {
      this.$modal.open(refund_form["a" /* default */], {
        countryList: this.countryList,
        order_id: row.order_id
      }, {
        title: this.$t('action.refund'),
        width: '1000px'
      }).subscribe(function (data) {
        _this_1.changeCnt += 1;
      });
    }
  };

  PickingManageContent.prototype.returnProcess = function () {
    var _this_1 = this;

    this.pickingService.returnProcess(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.customer_service_stop_plz = function () {
    var _this_1 = this;

    this.pickingService.customer_service_stop_plz(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.cancel_stock_picking_for_order_refund = function () {
    var _this_1 = this;

    this.pickingService.cancel_stock_picking_for_order_refund(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.donePickingGetLabel = function () {
    var _this_1 = this;

    this.shipmentService.donePickingGetLabel(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.createShipment = function () {
    var _this_1 = this;

    this.pickingService.createShipmentsLines(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function () {
      var msg = _this_1.$t('tips.save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.reserve = function () {
    var _this_1 = this;

    this.pickingService.reserve(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('tips.save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.toPageOrder = function (origin) {
    router["a" /* default */].push({
      name: 'order-manage',
      params: {
        origin: origin
      }
    }); // this.$router.push({
    //     name: 'order-manage',
    //     path: `/orders/order-manage/${origin}`,
    //     params: {
    //         id: origin,
    //         name: '订单管理' + origin
    //     }
    // })
  };

  PickingManageContent.prototype.fake_shipments = function () {
    var _this_1 = this;

    this.pickingService.fake_shipments(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.upload_shipment = function () {
    var _this_1 = this;

    this.pickingService.upload_shipment(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.upload_fake_shipment = function () {
    var _this_1 = this;

    this.pickingService.upload_fake_shipment(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.forceVerifyAddress = function () {
    var _this_1 = this;

    this.pickingService.forceVerifyAddress(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.deletePicking = function () {
    var _this_1 = this;

    this.pickingService.deleteCancelPicking(new http["RequestParams"]({
      picking_id_list: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.onTableChange = function (sorter) {
    if (sorter.order) {
      var column = sorter.columnKey;
      var order = sorter.order.replace('end', '');
      this.orderBy = column + ' ' + order;
    } else {
      this.orderBy = '';
    }

    this.getOrderList();
  };

  PickingManageContent.prototype.fillToday = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(day), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime())), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['payment_date'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  PickingManageContent.prototype.fillYestoday = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(new Date(day.getTime() - 24 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 24 * 60 * 60 * 1000)), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['payment_date'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  PickingManageContent.prototype.fill3day = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(new Date(day.getTime() - 48 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 48 * 60 * 60 * 1000)), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['payment_date'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  PickingManageContent.prototype.fill3days = function () {
    var day = new Date();
    var endDate = moment_default()(this.formatDate(new Date(day.getTime() - 24 * 60 * 60 * 1000)), 'YYYY-MM-DD HH:mm');
    var startDate = moment_default()(this.formatDate(new Date(day.getTime() - 72 * 60 * 60 * 1000)), 'YYYY-MM-DD 00:00');
    var values = this.dataForm.getValues();
    this.initialDate = [startDate, endDate];
    values['payment_date'] = this.initialDate;
    this.dataForm.setValues(values);
  };

  PickingManageContent.prototype.formatDate = function (time) {
    // 空数据处理
    if (time === null || time === undefined || time === '') {
      return '';
    }

    var y = time.getFullYear();
    var m = time.getMonth() + 1;
    var d = time.getDate();
    var h = time.getHours();
    var mi = time.getMinutes();
    var s = time.getSeconds();
    m = m < 10 ? "0" + m : m;
    d = d < 10 ? "0" + d : d;
    h = h < 10 ? "0" + h : h;
    mi = mi < 10 ? "0" + mi : mi;
    s = s < 10 ? "0" + s : s;
    return y + "-" + m + "-" + d + " 23:59";
  };

  PickingManageContent.prototype.onEditMemo = function (record) {
    var _this_1 = this;

    this.$modal.open(picking_modify_memo["a" /* default */], {
      memo: record.memo,
      id: record.id,
      systemUsers: this.systemUsers,
      orderID: record.order_id
    }, {
      title: this.$t('action.modify_memo'),
      width: '1000px'
    }).subscribe(function (data) {
      _this_1.modifyMemo(record.order_id, data);
    });
  };

  PickingManageContent.prototype.modifyMemo = function (order_id, memo) {
    var _this_1 = this;

    this.emailService.modifyMemo(new http["RequestParams"]({
      order_id: order_id,
      memo: memo
    })).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.cancelOrder = function () {
    var _this_1 = this;

    this.$modal.open(cancel_order_form["a" /* default */], {
      order_id: this.selectedRowKeys[0]
    }, {
      title: this.$t('action.cancel_order'),
      width: '1000px'
    }).subscribe(function (data) {
      _this_1.$message.success('操作成功');

      _this_1.getOrderList();
    });
  };

  PickingManageContent.prototype.multiCreateInvoice = function () {
    var _this_1 = this;

    var order_ids = [];
    this.selectedRowKeys.forEach(function (value) {
      order_ids.push(_this_1.data.filter(function (item) {
        return value === item.id;
      })[0].order_id);
    });
    this.accountService.createInvoice(new http["RequestParams"]({
      order_id_list: order_ids
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      _this_1.getOrderList();
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  PickingManageContent.prototype.filterOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PickingManageContent.prototype.viewAmazonInvoicePDF = function () {
    var order_name_list = [];

    for (var _i = 0, _a = this.selectedRowKeys; _i < _a.length; _i++) {
      var selected_code = _a[_i];
      var row = this.data.find(function (x) {
        return x.id === selected_code;
      });
      var pattern = /^[0-9]{3}-[0-9]{7}-[0-9]{7}$/;

      if (!pattern.test(row.origin)) {
        this.$message.success('Only support Amazon Order to view invoice');
        return;
      }

      order_name_list.push(row.origin);
    }

    var urlParams = encodeURIComponent(JSON.stringify(order_name_list));
    var url = app_config["a" /* default */].server + '/account/download_order_invoice_pdf?order_name_list=' + urlParams;
    window.open(url, '_blank');
  };

  PickingManageContent.prototype.onSelectChange = function (rowkeys) {
    this.selectedRowKeys = rowkeys;
  };

  PickingManageContent.prototype.getQueryCondition = function () {
    var _this_1 = this;

    return new Promise(function (reslove, reject) {
      _this_1.dataForm.validateFields().then(function (values) {
        if (values['seller_code'] && values['seller_code'].length > 0) {
          values['seller_code'] = values['seller_code'].join(',');
        }

        if (values['instance_code'] && values['instance_code'].length > 0) {
          values['instance_code'] = values['instance_code'].join(',');
        }

        var name_operator = 'in_or_=';
        var origin_operator = 'in_or_=';
        var email_operator = '=';
        var default_code_operator = 'in_or_suffix_like';
        var shipment_num_operator = 'in_or_=';
        var ebay_buyer_id_operator = 'in_or_=';
        var customer_name_operator = 'like';
        var zip_operator = 'like';
        var street_operator = 'like';
        var fuzzy_search_operator = values['fuzzy_search_operator'];
        var operator = 'like';

        if (fuzzy_search_operator == 20) {
          operator = '=';
        }

        var fuzzy_search_value = values['fuzzy_search_value'];

        if (fuzzy_search_value) {
          var fuzzy_search_code = values['fuzzy_search_code'];
          var search_field_name = 'name';

          switch (fuzzy_search_code) {
            case 10:
              search_field_name = 'name';
              name_operator = operator;
              break;

            case 20:
              search_field_name = 'origin';
              origin_operator = operator;
              break;

            case 30:
              search_field_name = 'email';
              email_operator = operator;
              break;

            case 40:
              search_field_name = 'default_code';
              default_code_operator = operator;
              break;

            case 50:
              search_field_name = 'shipment_num';
              shipment_num_operator = operator;
              break;

            case 60:
              search_field_name = 'ebay_buyer_id';
              ebay_buyer_id_operator = operator;
              break;

            case 70:
              search_field_name = 'partner_name';
              customer_name_operator = operator;
              break;

            case 80:
              search_field_name = 'zip';
              zip_operator = operator;
              break;

            case 90:
              search_field_name = 'street';
              street_operator = operator;
              break;

            default:
              search_field_name = 'name';
              name_operator = operator;
          }

          values[search_field_name] = fuzzy_search_value;
        }

        if (_this_1.page_flag == 'aliexpress') {
          values['platform'] = 60;
        }

        delete values['fuzzy_search_value'];
        delete values['fuzzy_search_code'];
        delete values['fuzzy_search_operator'];
        var params = common_service["a" /* CommonService */].createQueryCondition(values, tslib_es6["a" /* __assign */]({
          picking_type_id: 'like',
          name: name_operator,
          origin: origin_operator,
          default_code: default_code_operator,
          ebay_buyer_id: ebay_buyer_id_operator,
          shipment_num: shipment_num_operator,
          shipment_time_str: 'null',
          email: email_operator,
          seller_code: 'in_or_=',
          instance_code: 'in_or_=',
          partner_name: customer_name_operator,
          zip: zip_operator,
          street: street_operator
        }, form_config["a" /* formConfig */].condition));
        var nowConditions = [];

        for (var _i = 0, _a = params.query_condition; _i < _a.length; _i++) {
          var item = _a[_i];

          if (item.value.constructor == Array && item.operate !== 'in') {
            if (item.value.length == 2 && item.value[0].constructor.name == 'Moment') {
              var startDate = {};

              for (var key in item.value[0]) {
                startDate[key] = item.value[0][key];
              }

              var vle = new Date(startDate.utc()); // if (item.query_name === 'latest_ship_date_new') {
              //     vle = new Date(
              //         startDate.format('YYYY-MM-DD HH:mm:ss')
              //     )
              // }

              nowConditions.push({
                query_name: item.query_name,
                operate: '>=',
                value: vle
              });
            }

            if (item.value.length == 2 && item.value[1].constructor.name == 'Moment') {
              var endDate = {};

              for (var key in item.value[1]) {
                endDate[key] = item.value[1][key];
              }

              var vle = new Date(endDate.utc()); // if (item.query_name === 'latest_ship_date_new') {
              //     vle = new Date(
              //         endDate.format('YYYY-MM-DD HH:mm:ss')
              //     )
              // }

              nowConditions.push({
                query_name: item.query_name,
                operate: '<=',
                value: vle
              });
            }
          } else {
            if (item.query_name === 'ebay_plus_type') {
              if (item.value) {
                item.value = 'eBayPlus';
              } else {
                item.value = 'eBayPlus';
                item.operate = '!=';
              }
            } else if (item.query_name === 'amazon_type_sale') {
              if (item.value) {
                item.value = 'prime';
              } else {
                item.value = 'prime';
                item.operate = '!=';
              }
            }

            nowConditions.push(item);
          }
        }

        reslove(nowConditions);
      }).catch(function (err) {
        _this_1.$message.error(JSON.stringify(err));
      });
    });
  };

  PickingManageContent.prototype.createGift = function () {
    var _this_1 = this;

    this.pickingService.create_dhl_dpd_gift(new http["RequestParams"]({
      picking_ids: this.selectedRowKeys
    }, {
      loading: this.loadingService
    })).subscribe(function (data) {
      _this_1.$message.success('创建成功!');
    }, function (err) {
      _this_1.$message.error(err.message);
    });
  };

  var _a, _b;

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_a = typeof data_form["a" /* default */] !== "undefined" && data_form["a" /* default */]) === "function" ? _a : Object)], PickingManageContent.prototype, "dataForm", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["d" /* Ref */])(), tslib_es6["f" /* __metadata */]("design:type", typeof (_b = typeof page_container["a" /* default */] !== "undefined" && page_container["a" /* default */]) === "function" ? _b : Object)], PickingManageContent.prototype, "pageContainer", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "page_flag", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "getcountry", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "currencyList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "getcurrency", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "getSystemuser", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "getMvShipType", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingManageContent.prototype, "mvShipTypeList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('$route'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", [Object, Object]), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingManageContent.prototype, "onRouteChange", null);

  PickingManageContent = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      CancelOrderForm: cancel_order_form["a" /* default */],
      PickingDetail: picking_detail["a" /* default */],
      BatchSendEmail: batch_send_email["a" /* default */],
      CreateReturn: create_return["a" /* default */],
      DeliveryMore: delivery_more["a" /* default */],
      ProductPart: product_part["a" /* default */],
      DragArea: drag_area["a" /* default */],
      RefundForm: refund_form["a" /* default */],
      AssignUser: assign_user["a" /* default */],
      GroupbyTable: groupby_table["a" /* default */],
      AutoColumnTable: auto_column_table["a" /* default */]
    }
  })], PickingManageContent);
  return PickingManageContent;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var picking_manage_contentvue_type_script_lang_tsx_ = (picking_manage_contentvue_type_script_lang_tsx_PickingManageContent);
// CONCATENATED MODULE: ./src/components/picking/picking-manage-content.vue?vue&type=script&lang=tsx&
 /* harmony default export */ var picking_picking_manage_contentvue_type_script_lang_tsx_ = (picking_manage_contentvue_type_script_lang_tsx_); 
// EXTERNAL MODULE: ./src/components/picking/picking-manage-content.vue?vue&type=style&index=0&lang=css&
var picking_manage_contentvue_type_style_index_0_lang_css_ = __webpack_require__("a467");

// EXTERNAL MODULE: ./src/components/picking/picking-manage-content.vue?vue&type=style&index=1&lang=css&
var picking_manage_contentvue_type_style_index_1_lang_css_ = __webpack_require__("5ead");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/picking-manage-content.vue?vue&type=custom&index=0&blockType=i18n
var picking_manage_contentvue_type_custom_index_0_blockType_i18n = __webpack_require__("cd6b");

// CONCATENATED MODULE: ./src/components/picking/picking-manage-content.vue







/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_picking_manage_contentvue_type_script_lang_tsx_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof picking_manage_contentvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(picking_manage_contentvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var picking_manage_content = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "d31d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/return-detail.vue?vue&type=template&id=7f7c27f4&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-customer-detail"},[_c('div',{staticStyle:{"padding":"0 20px 10px 20px"}},[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.addBtn}},[_vm._v(_vm._s(_vm.$t('actions.add')))]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.saveBtn}},[_vm._v(_vm._s(_vm.$t('actions.save')))]),_c('a-button',{staticStyle:{"margin-left":"10px"},on:{"click":_vm.cancelBtn}},[_vm._v(_vm._s(_vm.$t('actions.cancel')))])],1),_c('a-table',{staticStyle:{"table-layout":"fixed"},attrs:{"dataSource":_vm.data,"pagination":false,"scroll":{ y: 300, x: 1500 },"rowKey":"index","customRow":function (rowKey) { return ({
                on: {
                    // 单击每行
                    click: function () {
                        _vm.currentRow = rowKey.index
                    }
                }
            }); },"bordered":""}},[_c('a-table-column',{key:"name",staticClass:"tip-color",attrs:{"title":_vm.$t('product'),"align":"left"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['name']),expression:"['name']"}],style:({ width: '100%' }),attrs:{"value":row.name,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'name', e); }}},[_vm._l((_vm.productList),function(i){return _c('a-select-option',{key:i.id,attrs:{"value":i.id,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])}),_c('a-select-option',{key:"all",staticClass:"show-all",attrs:{"disabled":""}},[_c('a',{on:{"click":function($event){return _vm.searchMore(row)}}},[_vm._v(" Search More ")])])],2):_c('span',{class:_vm.calculateRowStyle(row),attrs:{"title":row.name}},[_vm._v(_vm._s(row.name ? row.name.substr(0, 20) + (row.name.length > 17 ? '...' : '') : ''))])]}}])}),_c('a-table-column',{key:"product_qty",attrs:{"title":_vm.$t('quantity'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input-number',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_qty']),expression:"['product_qty']"}],style:({ width: '100%' }),attrs:{"decimalSeparator":",","value":row.product_qty,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_qty', e); }}}):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.product_qty))])]}}])}),_c('a-table-column',{key:"ship_type",attrs:{"title":_vm.$t('ship'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_type']),expression:"['ship_type']"}],style:({ width: '100%' }),attrs:{"value":row.ship_type,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'ship_type', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.ship_type),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.ship_type,_vm.reasonList.ship_type)))])]}}])}),_c('a-table-column',{key:"ship_num",attrs:{"title":_vm.$t('ship_num'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-input',{directives:[{name:"decorator",rawName:"v-decorator",value:(['ship_num']),expression:"['ship_num']"}],style:({ width: '100%' }),attrs:{"decimalSeparator":",","value":row.ship_num,"min":0,"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'ship_num', e); }}}):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.ship_num))])]}}])}),_c('a-table-column',{key:"product_status",attrs:{"title":_vm.$t('state'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['product_status']),expression:"['product_status']"}],style:({ width: '100%' }),attrs:{"value":row.product_status,"dropdown-match-select-width":false,"dropdown-style":{ width: '200px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'product_status', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.product_status),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.product_status,_vm.reasonList.product_status)))])]}}])}),_c('a-table-column',{key:"info1",attrs:{"title":_vm.$t('product_info'),"data-index":"info1","align":"center"}}),_c('a-table-column',{key:"w_warehouse_reason",attrs:{"title":_vm.$t('w_warehouse_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['w_warehouse_reason']),expression:"['w_warehouse_reason']"}],style:({ width: '100%' }),attrs:{"value":row.w_warehouse_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'w_warehouse_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.w_warehouse_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.w_warehouse_reason,_vm.reasonList.w_warehouse_reason)))])]}}])}),_c('a-table-column',{key:"w_return_reason",attrs:{"title":_vm.$t('w_return_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['w_return_reason']),expression:"['w_return_reason']"}],style:({ width: '100%' }),attrs:{"value":row.w_return_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'w_return_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.w_return_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.w_return_reason,_vm.reasonList.w_return_reason)))])]}}])}),_c('a-table-column',{key:"customer_reason",attrs:{"title":_vm.$t('customer_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['customer_reason']),expression:"['customer_reason']"}],style:({ width: '100%' }),attrs:{"value":row.customer_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'customer_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.customer_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.customer_reason,_vm.reasonList.customer_reason)))])]}}])}),_c('a-table-column',{key:"sale_tag",attrs:{"title":_vm.$t('sale_tag'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['sale_tag']),expression:"['sale_tag']"}],style:({ width: '100%' }),attrs:{"value":row.sale_tag,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'sale_tag', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.productReason[row.default_code]),function(i){return _c('a-select-option',{key:i,attrs:{"value":i,"title":i}},[_vm._v(" "+_vm._s(i)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.sale_tag,_vm.productReason[row.default_code])))])]}}])}),_c('a-table-column',{key:"logistic_reason",attrs:{"title":_vm.$t('logistic_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['logistic_reason']),expression:"['logistic_reason']"}],style:({ width: '100%' }),attrs:{"value":row.logistic_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'logistic_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.logistic_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.logistic_reason,_vm.reasonList.logistic_reason)))])]}}])}),_c('a-table-column',{key:"warehouse_reason",attrs:{"title":_vm.$t('warehouse_reason'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['warehouse_reason']),expression:"['warehouse_reason']"}],style:({ width: '100%' }),attrs:{"value":row.warehouse_reason,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'warehouse_reason', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.warehouse_reason),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.warehouse_reason,_vm.reasonList.warehouse_reason)))])]}}])}),_c('a-table-column',{key:"solution_type",attrs:{"title":_vm.$t('solution_type'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-select',{directives:[{name:"decorator",rawName:"v-decorator",value:(['solution_type']),expression:"['solution_type']"}],style:({ width: '100%' }),attrs:{"mode":"multiple","value":row.solution_type,"dropdown-match-select-width":false,"dropdown-style":{ width: '300px' },"size":"small"},on:{"change":function (e) { return _vm.onRowChange(row, 'solution_type', e); }}},[_c('a-select-option',{attrs:{"value":""}},[_vm._v(_vm._s(_vm.$t('null'))+" ")]),_vm._l((_vm.reasonList.solution_type),function(i){return _c('a-select-option',{key:i.code,attrs:{"value":i.code,"title":i.name}},[_vm._v(" "+_vm._s(i.name)+" ")])})],2):_c('span',{class:_vm.calculateRowStyle(row)},_vm._l((row.solution_type),function(x){return _c('p',{key:x},[_vm._v(" "+_vm._s(_vm._f("dict2")((x ? x : ''),_vm.reasonList.solution_type))+" ")])}),0)]}}])}),_c('a-table-column',{key:"stock_processed",attrs:{"title":_vm.$t('stock_processed'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(_vm.currentRow == row.index && _vm.editable)?_c('a-date-picker',{directives:[{name:"decorator",rawName:"v-decorator",value:(['stock_processed']),expression:"['stock_processed']"}],attrs:{"value":row.stock_processed,"format":"YYYY-MM-DD HH:mm:ss"},on:{"change":function (e) { return _vm.onRowChange(row, 'stock_processed', e); }}}):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.stock_processed ? row.stock_processed.format('YY-MM-DD HH:mm') : ''))])]}}])}),_c('a-table-column',{key:"create_time",attrs:{"title":_vm.$t('create_time'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [(row.save_flag)?_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("datetolocal")(row.create_time.toString())))]):_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(row.create_time.format('YY-MM-DD HH:mm')))])]}}])}),_c('a-table-column',{key:"create_user",attrs:{"title":_vm.$t('create_user'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('span',{class:_vm.calculateRowStyle(row)},[_vm._v(_vm._s(_vm._f("dict2")(row.create_user,_vm.systemUsers)))])]}}])}),_c('a-table-column',{key:"is_return_user",attrs:{"title":_vm.$t('is_return_user'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a-checkbox',{directives:[{name:"decorator",rawName:"v-decorator",value:(['is_return_user']),expression:"['is_return_user']"}],attrs:{"disabled":_vm.currentRow !== row.index,"checked":row.is_return_user},on:{"change":function (e) { return _vm.onRowChange(
                                row,
                                'is_return_user',
                                e.target.checked
                            ); }}})]}}])}),_c('a-table-column',{key:"action",attrs:{"title":_vm.$t('actions.action'),"align":"center"},scopedSlots:_vm._u([{key:"default",fn:function(row){return [_c('a',{on:{"click":function($event){return _vm.onDel(row)}}},[_vm._v(" "+_vm._s(_vm.$t('actions.delete'))+" ")])]}}])})],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/return-detail.vue?vue&type=template&id=7f7c27f4&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.filter.js
var es_array_filter = __webpack_require__("4de4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.exec.js
var es_regexp_exec = __webpack_require__("ac1f");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.string.replace.js
var es_string_replace = __webpack_require__("5319");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.test.js
var es_regexp_test = __webpack_require__("00b4");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.constructor.js
var es_regexp_constructor = __webpack_require__("4d63");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.dot-all.js
var es_regexp_dot_all = __webpack_require__("c607");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.sticky.js
var es_regexp_sticky = __webpack_require__("2c3e");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.regexp.to-string.js
var es_regexp_to_string = __webpack_require__("25f0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.keys.js
var es_object_keys = __webpack_require__("b64b");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/services/product.service.ts
var product_service = __webpack_require__("1d1e");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/shared/utils/common.service.ts
var common_service = __webpack_require__("38a4");

// EXTERNAL MODULE: ./src/config/form.config.ts
var form_config = __webpack_require__("6829");

// EXTERNAL MODULE: ./src/components/product/search-product.vue + 4 modules
var search_product = __webpack_require__("abdd");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/custom_problem.service.ts
var custom_problem_service = __webpack_require__("6a1c");

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("c1df");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// EXTERNAL MODULE: ./node_modules/uuidjs/src/uuid.js
var uuid = __webpack_require__("1f82");
var uuid_default = /*#__PURE__*/__webpack_require__.n(uuid);

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/store/index.ts + 9 modules
var store = __webpack_require__("0613");

// EXTERNAL MODULE: ./src/services/public.service.ts
var public_service = __webpack_require__("7a22");

// EXTERNAL MODULE: ./src/bootstrap/services/inner.action.service.ts
var inner_action_service = __webpack_require__("60a2");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/return-detail.vue?vue&type=script&lang=ts&































var userModule = Object(lib["c" /* namespace */])('userModule');

var return_detailvue_type_script_lang_ts_ReturnDetail =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](ReturnDetail, _super);

  function ReturnDetail() {
    var _this = _super !== null && _super.apply(this, arguments) || this;

    _this.currentRow = '';
    _this.editable = true;
    _this.data = [];
    _this.skuSource = [];
    _this.skuQueryResult = [];
    _this.reasonList = [];
    _this.productList = [];
    _this.deleteList = [];
    _this.productService = new product_service["a" /* ProductService */]();
    _this.pickingService = new picking_service["a" /* PickingService */]();
    _this.customProblemService = new custom_problem_service["a" /* CustomProblemService */]();
    _this.loadingService = new loading_service["a" /* LoadingService */]();
    _this.orderService = new order_service["a" /* OrderService */]();
    _this.publicService = new public_service["a" /* PublicService */]();
    _this.innerAction = new inner_action_service["a" /* InnerActionService */]();
    _this.productReason = {};
    return _this;
  }

  ReturnDetail.prototype.created = function () {
    this.getSelectList();
    this.getProductList();
  };

  ReturnDetail.prototype.mounted = function () {
    var _this = this;

    this.moment = moment_default.a;

    if (this.info.length) {
      this.data = this.info.map(function (x) {
        if (x.stock_processed) {
          x.stock_processed = _this.moment(x.stock_processed, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.stock_processed = '';
        }

        if (x.create_time) {
          x.create_time = _this.moment(x.create_time, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.create_time = '';
        } // if (!(x.solution_type instanceof Array)) {
        //     x.solution_type = [x.solution_type]
        // }


        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        x.w_warehouse_reason = x.w_warehouse_reason ? x.w_warehouse_reason : '';
        x.w_return_reason = x.w_return_reason ? x.w_return_reason : '';
        x.customer_reason = x.customer_reason ? x.customer_reason : '';
        x.sale_tag = x.sale_tag ? x.sale_tag : '';
        x.logistic_reason = x.logistic_reason ? x.logistic_reason : '';
        x.warehouse_reason = x.warehouse_reason ? x.warehouse_reason : '';
        x.stock_processed = x.stock_processed ? x.stock_processed : '';
        x.ship_type = x.ship_type ? x.ship_type : '';
        x.product_status = x.product_status ? x.product_status : '';
        x.solution_type = x.solution_type ? x.solution_type : [];
        return x;
      });
      var skus = this.data.map(function (x) {
        return x.default_code;
      });
      this.getProductReason(skus);
    }
  };

  ReturnDetail.prototype.onInfoChange = function () {
    var _this = this;

    this.deleteList = [];

    if (this.info.length) {
      this.data = this.info.map(function (x) {
        if (x.stock_processed) {
          x.stock_processed = _this.moment(x.stock_processed, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.stock_processed = '';
        }

        if (x.create_time) {
          x.create_time = _this.moment(x.create_time, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.create_time = '';
        } // if (!(x.solution_type instanceof Array)) {
        //     x.solution_type = [x.solution_type]
        // }


        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        x.w_warehouse_reason = x.w_warehouse_reason ? x.w_warehouse_reason : '';
        x.w_return_reason = x.w_return_reason ? x.w_return_reason : '';
        x.customer_reason = x.customer_reason ? x.customer_reason : '';
        x.sale_tag = x.sale_tag ? x.sale_tag : '';
        x.logistic_reason = x.logistic_reason ? x.logistic_reason : '';
        x.warehouse_reason = x.warehouse_reason ? x.warehouse_reason : '';
        x.stock_processed = x.stock_processed ? x.stock_processed : '';
        x.ship_type = x.ship_type ? x.ship_type : '';
        x.product_status = x.product_status ? x.product_status : '';
        x.solution_type = x.solution_type ? x.solution_type : [];
        return x;
      });
      var skus = this.data.map(function (x) {
        return x.default_code;
      });
      this.getProductReason(skus);
    } else {
      this.data = [];
    }
  };

  ReturnDetail.prototype.onOrderIDChange = function () {
    if (this.orderID) {
      this.getProductList();
    } else {
      this.productList = [];
    }
  };

  ReturnDetail.prototype.getSelectList = function () {
    var _this = this;

    this.customProblemService.queryCpReasonEnum(new http["RequestParams"]({})).subscribe(function (data) {
      if (data.length) {
        _this.reasonList = data[0];
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReturnDetail.prototype.getProductList = function () {
    var _this = this;

    this.productList = [];
    this.customProblemService.queryCustomerProblemProduct(new http["RequestParams"]({
      order_id: this.orderID
    })).subscribe(function (data) {
      _this.productList = data;
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReturnDetail.prototype.addBtn = function () {
    this.data.push({
      save_flag: 0,
      index: uuid_default.a.generate(),
      create_time: moment_default()(new Date()),
      create_user: store["a" /* default */].state.userModule.id,
      customer_reason: '',
      default_code: '',
      info1: '',
      is_return_user: false,
      logistic_reason: '',
      name: '',
      note: '',
      product: 0,
      product_qty: 1,
      product_status: '',
      sale_tag: '',
      ship_type: '',
      stock_processed: '',
      w_return_reason: '',
      w_warehouse_reason: '',
      warehouse_reason: '',
      is_warehouse_in: false,
      solution_type: []
    });
    this.currentRow = this.data.length;
  };

  ReturnDetail.prototype.onRowChange = function (row, column, value) {
    if (Object.prototype.toString.call(value) === '[object InputEvent]' || Object.prototype.toString.call(value) === '[object Event]' || Object.prototype.toString.call(value) === '[object Object]') {
      if (value.target && value.target.value) {
        row[column] = value.target.value;
      } else {
        row[column] = value;
      }
    } else {
      row[column] = value;
    }

    if (column === 'name') {
      var item = this.productList.find(function (x) {
        return x.id === value;
      });

      if (item) {
        row.name = item.name;
        row.product = item.product_id;
        row.default_code = item.default_code;

        if (this.productReason[item.default_code] === undefined) {
          this.getProductReason([item.default_code]);
        }

        this.currentRow = -1;

        var _that_1 = this;

        setTimeout(function () {
          _that_1.currentRow = row.index;
        }, 1000);
      }
    }
  };

  Object.defineProperty(ReturnDetail.prototype, "loading", {
    get: function get() {
      var loading = {};

      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }

      return loading;
    },
    enumerable: true,
    configurable: true
  });

  ReturnDetail.prototype.closeLoading = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }
  };

  ReturnDetail.prototype.saveBtn = function () {
    var _this = this;

    var list = [];
    var beforeSaveData = JSON.parse(JSON.stringify(this.data));

    for (var _i = 0, _a = this.data; _i < _a.length; _i++) {
      var i = _a[_i];
      i.solution_type = i.solution_type.filter(function (x) {
        return x != null;
      });
      delete i.index;
      delete i.default_code;
      delete i.name;
      delete i.is_warehouse_in;

      if (i.save_flag) {
        delete i.create_time;
      }

      if (i.ship_type == '') {
        delete i.ship_type;
      }

      if (i.product_status == '') {
        delete i.product_status;
      }

      if (!i.stock_processed) {
        i.stock_processed = null;
      }

      list.push(i);
    }

    if (this.deleteList.length) {
      for (var _b = 0, _c = this.deleteList; _b < _c.length; _b++) {
        var j = _c[_b];
        j.solution_type = j.solution_type.filter(function (x) {
          return x != null;
        });

        if (j.product_status == '') {
          delete j.product_status;
        }

        list.push(j);
      }
    }

    this.pickingService.saveCustomerProblem(new http["RequestParams"]({
      picking_id: parseInt(this.picking_id),
      problem_list: list
    }, this.loading)).subscribe(function () {
      _this.deleteList = [];

      var msg = _this.$t('tips.save_success');

      _this.$message.success(msg);

      _this.getReturns();

      _this.closeLoading();
    }, function (err) {
      _this.closeLoading();

      _this.$message.error(err.message);

      _this.data = JSON.parse(JSON.stringify(beforeSaveData));
    });
  };

  ReturnDetail.prototype.getReturns = function () {
    var _this = this;

    this.pickingService.queryReturnInfo(new http["RequestParams"]({
      picking_id: parseInt(this.picking_id)
    })).subscribe(function (data) {
      _this.data = data.map(function (x) {
        if (x.stock_processed) {
          x.stock_processed = _this.moment(x.stock_processed, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.stock_processed = '';
        }

        if (x.create_time) {
          x.create_time = _this.moment(x.create_time, 'YYYY-MM-DD hh:mm:ss');
        } else {
          x.create_time = '';
        }

        if (!(x.solution_type instanceof Array)) {
          x.solution_type = [x.solution_type];
        }

        x['save_flag'] = 1;
        x['index'] = uuid_default.a.generate();
        return x;
      });
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  ReturnDetail.prototype.cancelBtn = function () {
    this.currentRow = -1;
    this.getReturns();
  };

  ReturnDetail.prototype.onDel = function (row) {
    this.currentRow = -1;
    var item = this.data.find(function (x) {
      return x.index === row.index;
    });

    if (item.save_flag == 1) {
      item['save_flag'] = 2;
      this.deleteList.push(item);
    }

    item['save_flag'] = 2;
    this.data = this.data.filter(function (x) {
      return !x.save_flag || x.save_flag < 2;
    });
  };

  ReturnDetail.prototype.onSkuSearch = function (key) {
    var _this = this;

    var params = common_service["a" /* CommonService */].createQueryCondition({
      product_number: key
    }, tslib_es6["a" /* __assign */]({
      product_number: 'like'
    }, form_config["a" /* formConfig */].condition));
    params['page_index'] = 1;
    params['page_size'] = 10;
    this.productService.queryProducForStockMove(new http["RequestParams"](params)).subscribe(function (data) {
      _this.skuSource = data.map(function (x) {
        return '[' + x.default_code + ']' + x.name;
      });
      _this.skuQueryResult = data;
    });
  };

  ReturnDetail.prototype.onSkuChange = function (key, row) {
    if (key && key.length > 1) {
      var productItem = this.skuQueryResult.find(function (x) {
        return '[' + x.default_code + ']' + x.name === key;
      });
      row.product = productItem ? productItem.id : '';
    }
  };

  ReturnDetail.prototype.searchMore = function (row) {
    var _this = this;

    var _that = this;

    this.$modal.open(search_product["a" /* default */], {
      changeSpinning: this.changeSpinning
    }, {
      title: '搜索产品',
      width: '60%'
    }).subscribe(function (data) {
      if (_this.productReason[data.default_code] === undefined) {
        _this.getProductReason([data.default_code]);
      } //sku不能重复


      var item = _this.data.find(function (x) {
        return x.index === row.index;
      });

      item['name'] = '[' + data.default_code + ']' + data.name;
      item['product'] = data.product_id;
      item['default_code'] = data.default_code;
      _this.currentRow = -1;

      var _t;

      setTimeout(function () {
        _that.currentRow = row.index;
      }, 1000);
    });
  };

  ReturnDetail.prototype.calculateRowStyle = function (row) {
    if (row.is_return_user) {
      return 'red-text';
    } else if (row.is_warehouse_in) {
      return 'green-text';
    } else {
      return 'default-text';
    }
  };

  ReturnDetail.prototype.datetolocal = function (date, fmt) {
    if (fmt === void 0) {
      fmt = 'yyyy-MM-dd hh:mm';
    } // 空数据处理


    if (date === null || date === undefined || date === '') {
      return '';
    } // 如果是时间戳则转化为时间


    if (typeof date === 'number') {
      date = new Date(date);
    }

    date = new Date(Date.parse(date.replace(/-/g, '/')));
    var utc = Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
    date = new Date(utc);
    var o = {
      'M+': date.getMonth() + 1,
      'd+': date.getDate(),
      'h+': date.getHours(),
      'm+': date.getMinutes(),
      's+': date.getSeconds(),
      'q+': Math.floor((date.getMonth() + 3) / 3),
      S: date.getMilliseconds() // 毫秒

    };

    if (/(y+)/.test(fmt)) {
      fmt = fmt.replace(RegExp.$1, date.getFullYear() + '');
    }

    for (var k in o) {
      // tslint:disable-next-line:max-line-length
      if (new RegExp('(' + k + ')').test(fmt)) {
        fmt = fmt.replace(RegExp.$1, RegExp.$1.length === 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
      }
    }

    return fmt;
  };

  ReturnDetail.prototype.getProductReason = function (sku) {
    var _this = this;

    this.innerAction.setActionAPI('product_management/query_product_reason_enum', common_service["a" /* CommonService */].getMenuCode('common-menu'));
    this.loading['innerAction'] = this.innerAction;
    this.publicService.query(new http["RequestParams"]({
      sku_list: sku
    }, this.loading)).subscribe(function (data) {
      if (!Object.keys(_this.productReason).length) {
        _this.productReason = data;
      } else {
        for (var i in data) {
          if (_this.productReason[i] === undefined) {
            _this.productReason[i] = data[i];
          }
        }
      }
    }, function (err) {
      _this.$message.error(err.message);
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReturnDetail.prototype, "info", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReturnDetail.prototype, "picking_id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReturnDetail.prototype, "orderID", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReturnDetail.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], ReturnDetail.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('info'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ReturnDetail.prototype, "onInfoChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('orderID'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], ReturnDetail.prototype, "onOrderIDChange", null);

  ReturnDetail = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {}
  })], ReturnDetail);
  return ReturnDetail;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var return_detailvue_type_script_lang_ts_ = (return_detailvue_type_script_lang_ts_ReturnDetail);
// CONCATENATED MODULE: ./src/components/picking/return-detail.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_return_detailvue_type_script_lang_ts_ = (return_detailvue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/return-detail.vue?vue&type=style&index=0&lang=css&
var return_detailvue_type_style_index_0_lang_css_ = __webpack_require__("d561");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/return-detail.vue?vue&type=custom&index=0&blockType=i18n
var return_detailvue_type_custom_index_0_blockType_i18n = __webpack_require__("a5c3");

// CONCATENATED MODULE: ./src/components/picking/return-detail.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_return_detailvue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof return_detailvue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(return_detailvue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var return_detail = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "d561":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_return_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("1c4d");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_return_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_return_detail_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "d6a6":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"source_package":"Source Package","product":"Product","unit_measure":"Unit of Measure","ordered_qty":"Ordered Qty","owner":"Owner","todo":"Todo","source_location":"Source Location","destination_location":"Destination Location","destination_package":"Destination Package"},"zh-cn":{"source_package":"源包裹","product":"产品","unit_measure":"计量单位","ordered_qty":"预留数量","owner":"拥有者","todo":"待做事项","source_location":"源库位","destination_location":"目标库位","destination_package":"包裹目的地"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "d7f3":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "dddf":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"picking_name":"Picking Name","shipment_num":"Shipment Num","pre_sale":"Pre Sale","merge_time":"Merge Time"},"shipment_order":"Shipment Order","search_shipment":"Search Shipment","shipment_order_type":"Shipment Order Type","create_user":"Create User","sent_product":"Sent Product","location_sort":"Location Sort","prime_item_id":"Prime Item ID","ceate_time":"Ceate Time","merge_time":"Merge Time","latest_status":"Latest Status","need_process":"Need Process","need_process_time":"Need Process Time","picking_name":"Picking Mame","processed_time_logi":"Processed Time Logi","processed_time_CS":"Processed Time CS","process_type":"Process Type","pdf":"PDF","null":"None","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Discard","delete_pick_number":"Delete Picking Number","send_rt":"Send RT"}},"zh-cn":{"columns":{"picking_name":"拣货单号","shipment_num":"物流单号","pre_sale":"预售","merge_time":"合单时间"},"shipment_order":"物流单号","search_shipment":"搜索","shipment_order_type":"物流单类型","create_user":"创建用户","sent_product":"已寄出产品","location_sort":"库位顺序","prime_item_id":"Prime ID","ceate_time":"创建时间","merge_time":"合单时间","latest_status":"现在状态","need_process":"需要处理","need_process_time":"需要处理时间","picking_name":"拣货单号","processed_time_logi":"处理时间逻辑","processed_time_CS":"处理时间CS","process_type":"处理类型","pdf":"PDF","null":"无","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"丢弃","delete_pick_number":"删除发货单号","send_rt":"发送RT"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "df30":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"columns":{"dynamic_price_calc":"Dynamic Price Calc","open":"Open","close":"Close","latest_calc_time":"Latest Calc Time","start_end_time":"Start and End Time","ratio_set":"Ratio Setting","calculation":"Calculate"},"err_msg":"The sum Ratio mast be 100","close":"Return"},"zh-cn":{"columns":{"dynamic_price_calc":"动态价格计算","open":"开启","close":"关闭","latest_calc_time":"最新计算时间","start_end_time":"起止时间","ratio_set":"物流比例设置","calculation":"计算"},"err_msg":"总比例数必须等于100","close":"返回"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "e12a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("8d8f");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_form_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "e16f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_user_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("84c9");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_user_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_user_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_assign_user_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "e36e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c3c6");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ }),

/***/ "e370":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"action":{"save":"Save","cancel":"Cancel"},"customer_problem":"Customer Problem"},"zh-cn":{"action":{"save":"保存","cancel":"取消"},"customer_problem":"客户问题"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "e70c":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"product":"Product","quantity":"Quantity","unit_measure":"Unit of Measure","available_qty":"Available Qty","ship_type":"Ship Type","pre_sale":"Pre Sale","max_pack_qty":"Max Pack Qty","packet_category":"Packet Category","date_count":"Date Count","status":"Status","default_code":"DefaultCode","stock_de_available_qty":"stock_de_available_qty","stock_uk_available_qty":"stock_uk_available_qty","actions":{"add":"Add","action":"Action","save":"Save","delete":"Delete","cancel":"Discard"}},"zh-cn":{"product":"产品","quantity":"数量","unit_measure":"计量单位","available_qty":"可用数量","ship_type":"物流类型","pre_sale":"预售","max_pack_qty":"最大包数","packet_category":"包种类","date_count":"日期统计","status":"状态","default_code":"货号","stock_de_available_qty":"DE可用数量","stock_uk_available_qty":"UK可用数量","actions":{"add":"新增","action":"操作","save":"保存","delete":"删除","cancel":"丢弃"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "e7d4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js?{"cacheDirectory":"node_modules/.cache/vue-loader","cacheIdentifier":"2d27c5f3-vue-loader-template"}!./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-detail-multi.vue?vue&type=template&id=4e6603e9&
var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('section',{staticClass:"component order-detail"},[(_vm.pageShow)?_c('a-card',{staticClass:"btn-area"},[[_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.reserve}},[_vm._v(" "+_vm._s(_vm.$t('action.reserved'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.validateAddress}},[_vm._v(_vm._s(_vm.$t('action.validate_address'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.createShipment}},[_vm._v(" "+_vm._s(_vm.$t('action.auto_create'))+" ")]),_c('a-button',{staticStyle:{"display":"none"},attrs:{"type":"primary"},on:{"click":_vm.donePickingGetLabel}},[_vm._v(_vm._s(_vm.$t('action.done_picking_get_label'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.fake_shipments}},[_vm._v(_vm._s(_vm.$t('action.fake_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.upload_shipment}},[_vm._v(_vm._s(_vm.$t('action.upload_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.upload_fake_shipment}},[_vm._v(_vm._s(_vm.$t('action.upload_fake_shipment'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.createReturn}},[_vm._v(_vm._s(_vm.$t('action.createReturn'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.deliveryMore}},[_vm._v(_vm._s(_vm.$t('action.deliveryMore'))+" ")]),_c('a-button',{directives:[{name:"show",rawName:"v-show",value:(_vm.data['is_resend']),expression:"data['is_resend']"}],attrs:{"type":"primary"},on:{"click":_vm.productPart}},[_vm._v(_vm._s(_vm.$t('action.ProductPart'))+" ")]),_c('a-button',{attrs:{"type":"primary"},on:{"click":_vm.multiCreateInvoice}},[_vm._v(" "+_vm._s(_vm.$t('action.create_invovice'))+" ")]),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.createShipmentByType('dhl')}}},[_vm._v(" "+_vm._s(_vm.$t('action.create_dhl'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.createShipmentByType('dpd')}}},[_vm._v(" "+_vm._s(_vm.$t('action.create_dpd'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.createShipmentByType('gls')}}},[_vm._v(" "+_vm._s(_vm.$t('action.create_gls'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.createShipmentByType('brief')}}},[_vm._v(_vm._s(_vm.$t('action.create_brief'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":function($event){return _vm.createGift()}}},[_vm._v(_vm._s(_vm.$t('action.create_gift'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":_vm.modifyAddress}},[_vm._v(_vm._s(_vm.$t('action.modify_address'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":_vm.forceVerifyAddress}},[_vm._v(_vm._s(_vm.$t('action.force_verify_address'))+" ")]),_c('a-menu-item',{attrs:{"type":"primary"},on:{"click":_vm.batchSendEmail}},[_vm._v(_vm._s(_vm.$t('action.batch_send_email'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"8px"}},[_vm._v("Action "),_c('a-icon',{attrs:{"type":"down"}})],1)],1),_c('a-dropdown',{attrs:{"trigger":['click']}},[_c('a-menu',{attrs:{"slot":"overlay"},slot:"overlay"},[_c('a-menu-item',{on:{"click":_vm.forceAvailability}},[_vm._v(_vm._s(_vm.$t('action.force_available'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelPicking}},[_vm._v(_vm._s(_vm.$t('action.cancelPicking'))+" ")]),_c('a-menu-item',{on:{"click":_vm.setAsDraft}},[_vm._v(_vm._s(_vm.$t('action.setAsDraft'))+" ")]),_c('a-menu-item',{on:{"click":_vm.setPresale}},[_vm._v(_vm._s(_vm.$t('action.setPresale'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelPresale}},[_vm._v(_vm._s(_vm.$t('action.cancelPresale'))+" ")]),_c('a-menu-item',{on:{"click":_vm.markSoldOut}},[_vm._v(_vm._s(_vm.$t('action.markSoldOut'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelSoldOut}},[_vm._v(_vm._s(_vm.$t('action.cancelSoldOut'))+" ")]),_c('a-menu-item',{on:{"click":_vm.checkShipments}},[_vm._v(_vm._s(_vm.$t('action.checkShipmentCount'))+" ")]),_c('a-menu-item',{on:{"click":_vm.cancelCheckShipments}},[_vm._v(_vm._s(_vm.$t('action.cancelShipmentCount'))+" ")]),_c('a-menu-item',{on:{"click":_vm.serviceProcess}},[_vm._v(_vm._s(_vm.$t('action.serviceProcess'))+" ")]),_c('a-menu-item',{on:{"click":_vm.returnProcess}},[_vm._v(_vm._s(_vm.$t('action.returnProcess'))+" ")]),_c('a-menu-item',{on:{"click":_vm.customer_service_stop_plz}},[_vm._v(_vm._s(_vm.$t('action.customer_service_stop_plz'))+" ")]),_c('a-menu-item',{on:{"click":_vm.pickingRefundConfirm}},[_vm._v(_vm._s(_vm.$t( 'action.cancel_stock_picking_for_order_refund' ))+" ")]),_c('a-menu-item',{on:{"click":_vm.OnRefund}},[_vm._v(_vm._s(_vm.$t('action.refund'))+" ")])],1),_c('a-button',{staticStyle:{"margin-left":"8px"}},[_vm._v(_vm._s(_vm.$t('action.more_btn'))+" "),_c('a-icon',{attrs:{"type":"down"}})],1)],1)]],2):_vm._e(),_c('a-tabs',{attrs:{"defaultActiveKey":"base","v-model":_vm.activeKey},on:{"change":function (e) { return _vm.onPanelChange(e); }}},[_c('a-tab-pane',{key:"base",attrs:{"tab":_vm.$t('base')}},[_c('div',[_c('PickingBaseDetail',{attrs:{"info":_vm.data,"id":_vm.id,"saveDetail":_vm.saveDetail,"countryList":_vm.countryList,"systemUsers":_vm.systemUsers,"pageShow":_vm.pageShow,"changeSpinning":_vm.changeSpinning},on:{"validateAds":_vm.refreshDetailPage}})],1)]),_c('a-tab-pane',{key:"pickingdetail",attrs:{"tab":_vm.$t('pickingdetail')}},[_c('div',[_c('a-card',[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 1. "+_vm._s(_vm.$t('title-1'))+" ")]),_c('DemandDetail',{attrs:{"info":_vm.demands,"id":_vm.id,"changeSpinning":_vm.changeSpinning}})],1),_c('a-card',{staticStyle:{"margin-top":"10px"}},[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 2. "+_vm._s(_vm.$t('title-2'))+" ")]),_c('OperationDetail',{attrs:{"info":_vm.operations,"id":_vm.id,"changeSpinning":_vm.changeSpinning}})],1),_c('a-card',{staticStyle:{"margin-top":"10px"}},[_c('h3',{staticStyle:{"margin-top":"10px","color":"#000","font-weight":"600"}},[_vm._v(" 3. "+_vm._s(_vm.$t('title-3'))+" ")]),_c('ShipmentDetail',{attrs:{"info":_vm.shipments,"id":_vm.id,"systemUsers":_vm.systemUsers,"shipTypeList":_vm.shipTypeList,"saveShipment":_vm.saveShipment,"changeSpinning":_vm.changeSpinning}})],1)],1)]),_c('a-tab-pane',{key:"return",attrs:{"tab":_vm.$t('return_info')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('ReturnDetail',{attrs:{"info":_vm.returns,"picking_id":_vm.id,"orderID":_vm.orderID,"systemUsers":_vm.systemUsers,"changeSpinning":_vm.changeSpinning}})],1)]),_c('a-tab-pane',{key:"order_detail",attrs:{"tab":_vm.$t('order_detail')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('OrderBaseDetail',{attrs:{"info":_vm.order_info,"height":500}})],1)]),_c('a-tab-pane',{key:"invoices",attrs:{"tab":_vm.$t('invoices')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('OrderInvoiceDetail',{attrs:{"info":_vm.invoice,"height":500,"systemUsers":_vm.systemUsers,"companyList":_vm.companyList,"changeSpinning":_vm.changeSpinning}})],1)]),_c('a-tab-pane',{key:"logs",attrs:{"tab":_vm.$t('logs')}},[_c('div',{style:(!_vm.pageShow
                        ? {
                              height: _vm.divHeight + 'px',
                              'overflow-y': 'scroll'
                          }
                        : '')},[_c('PickingLogDetail',{attrs:{"info":_vm.logs,"id":_vm.id,"systemUsers":_vm.systemUsers}})],1)])],1)],1)}
var staticRenderFns = []


// CONCATENATED MODULE: ./src/components/picking/picking-detail-multi.vue?vue&type=template&id=4e6603e9&

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.map.js
var es_array_map = __webpack_require__("d81d");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.array.find.js
var es_array_find = __webpack_require__("7db0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.object.to-string.js
var es_object_to_string = __webpack_require__("d3b7");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.function.name.js
var es_function_name = __webpack_require__("b0c0");

// EXTERNAL MODULE: ./node_modules/core-js/modules/es.json.stringify.js
var es_json_stringify = __webpack_require__("e9c4");

// EXTERNAL MODULE: ./node_modules/tslib/tslib.es6.js
var tslib_es6 = __webpack_require__("9ab4");

// EXTERNAL MODULE: ./node_modules/vue-property-decorator/lib/vue-property-decorator.js
var vue_property_decorator = __webpack_require__("60a3");

// EXTERNAL MODULE: ./src/components/picking/picking-base-detail.vue + 4 modules
var picking_base_detail = __webpack_require__("11ef");

// EXTERNAL MODULE: ./src/components/picking/operation-detail.vue + 4 modules
var operation_detail = __webpack_require__("228e");

// EXTERNAL MODULE: ./src/components/picking/demand-detail.vue + 4 modules
var demand_detail = __webpack_require__("bc03");

// EXTERNAL MODULE: ./src/components/picking/shipment-detail.vue + 4 modules
var shipment_detail = __webpack_require__("055d");

// EXTERNAL MODULE: ./src/components/picking/return-detail.vue + 4 modules
var return_detail = __webpack_require__("d31d");

// EXTERNAL MODULE: ./src/components/picking/picking-log-detail.vue + 4 modules
var picking_log_detail = __webpack_require__("53e6");

// EXTERNAL MODULE: ./src/core/http/index.ts
var http = __webpack_require__("c4d0");

// EXTERNAL MODULE: ./src/bootstrap/services/loading.service.ts
var loading_service = __webpack_require__("59f1");

// EXTERNAL MODULE: ./src/services/picking.service.ts
var picking_service = __webpack_require__("db1a");

// EXTERNAL MODULE: ./node_modules/vuex-class/lib/index.js + 1 modules
var lib = __webpack_require__("4bb5");

// EXTERNAL MODULE: ./src/router/index.ts
var router = __webpack_require__("afbc");

// EXTERNAL MODULE: ./src/components/picking/batch-send-email.vue + 4 modules
var batch_send_email = __webpack_require__("7f15");

// EXTERNAL MODULE: ./src/components/picking/create-return.vue + 4 modules
var create_return = __webpack_require__("7053");

// EXTERNAL MODULE: ./src/services/shipment.service.ts
var shipment_service = __webpack_require__("1af5");

// EXTERNAL MODULE: ./src/components/picking/delivery-more.vue + 4 modules
var delivery_more = __webpack_require__("2b19");

// EXTERNAL MODULE: ./src/components/picking/product-part.vue + 4 modules
var product_part = __webpack_require__("1eb8");

// EXTERNAL MODULE: ./src/services/account.service.ts
var account_service = __webpack_require__("82e7");

// EXTERNAL MODULE: ./src/components/common/refund-form.vue + 4 modules
var refund_form = __webpack_require__("28e6");

// EXTERNAL MODULE: ./src/services/order.service.ts
var order_service = __webpack_require__("d48f");

// EXTERNAL MODULE: ./src/services/taxes.service.ts
var taxes_service = __webpack_require__("3723");

// EXTERNAL MODULE: ./src/components/orders/order-base-detail.vue + 4 modules
var order_base_detail = __webpack_require__("443e");

// EXTERNAL MODULE: ./src/services/general_code.service.ts
var general_code_service = __webpack_require__("5083");

// EXTERNAL MODULE: ./src/components/orders/order-invoice-detail.vue + 4 modules
var order_invoice_detail = __webpack_require__("9100");

// CONCATENATED MODULE: ./node_modules/cache-loader/dist/cjs.js??ref--15-0!./node_modules/thread-loader/dist/cjs.js!./node_modules/babel-loader/lib!./node_modules/ts-loader??ref--15-3!./node_modules/cache-loader/dist/cjs.js??ref--1-0!./node_modules/vue-loader/lib??vue-loader-options!./src/components/picking/picking-detail-multi.vue?vue&type=script&lang=ts&






























var datasModule = Object(lib["c" /* namespace */])('datasModule');

var picking_detail_multivue_type_script_lang_ts_PickingDetailMulti =
/** @class */
function (_super) {
  tslib_es6["d" /* __extends */](PickingDetailMulti, _super);

  function PickingDetailMulti() {
    var _this_1 = _super !== null && _super.apply(this, arguments) || this;

    _this_1.activeKey = 'base';
    _this_1.data = {};
    _this_1.orderID = '';
    _this_1.saveDetail = 0;
    _this_1.order_info = [];
    _this_1.saveShipment = 0;
    _this_1.invoice = [];
    _this_1.taxList = [];
    _this_1.taxesService = new taxes_service["a" /* TaxesService */]();
    _this_1.orderService = new order_service["a" /* OrderService */]();
    _this_1.operations = [];
    _this_1.demands = [];
    _this_1.shipments = [];
    _this_1.returns = [];
    _this_1.logs = [];
    _this_1.editable = false;
    _this_1.pre_sale = false;
    _this_1.pickingService = new picking_service["a" /* PickingService */]();
    _this_1.loadingService = new loading_service["a" /* LoadingService */]();
    _this_1.shipmentService = new shipment_service["a" /* ShipmentService */]();
    _this_1.generalCodeService = new general_code_service["a" /* GeneralCodeService */]();
    _this_1.accountService = new account_service["a" /* AccountService */]();
    return _this_1;
  }

  PickingDetailMulti.prototype.onDetailChange = function () {
    // if (!this.data.id || (this.data.id && this.detail.id != this.data.id)) {
    if (this.detail.id) {
      this.data = Object.assign({}, this.detail);
      this.orderID = this.data.order_id;
      this.getTaxList();
      this.reset();
    }
  };

  PickingDetailMulti.prototype.onCntChange = function () {
    this.data = [];
    this.operations = [];
    this.demands = [];
    this.shipments = [];
    this.returns = [];
    this.logs = [];
    this.order_info = [];
    this.invoice = [];
  };

  PickingDetailMulti.prototype.getTaxList = function () {
    var _this_1 = this;

    if (this.data.seller_code) {
      this.taxesService.queryAll(new http["RequestParams"]({
        seller_code: this.data.seller_code
      })).subscribe(function (data) {
        _this_1.taxList = data;
      });
    } else {
      this.taxList = [];
    }
  };

  Object.defineProperty(PickingDetailMulti.prototype, "loading", {
    get: function get() {
      var loading = {};

      if (this.changeSpinning) {
        this.changeSpinning(true);
      } else {
        loading = {
          loading: this.loadingService
        };
      }

      return loading;
    },
    enumerable: true,
    configurable: true
  });

  PickingDetailMulti.prototype.closeLoading = function () {
    if (this.changeSpinning) {
      this.changeSpinning(false);
    }
  };

  PickingDetailMulti.prototype.reset = function () {
    this.operations = [];
    this.demands = [];
    this.shipments = [];
    this.returns = [];
    this.logs = [];
    this.order_info = [];
    this.invoice = [];

    if (this.activeKey == 'base') {
      this.updatePickingInfo();
    } else if (this.activeKey == 'pickingdetail') {
      this.getOperations();
      this.getDemands();
      this.getShipments();
    } else if (this.activeKey == 'return') {
      this.getReturns();
    } else if (this.activeKey == 'logs') {
      this.getLogs();
    } else if (this.activeKey == 'order_detail') {
      this.getOrderDetail();
    } else if (this.activeKey == 'invoices') {
      this.getInvoiceList();
    }
  };

  PickingDetailMulti.prototype.getOrderDetail = function () {
    var _this_1 = this;

    this.orderService.getDetail(new http["RequestParams"]({
      order_id: this.orderID
    }, this.loading)).subscribe(function (data) {
      _this_1.order_info = data.order_lines.map(function (x) {
        var tax = _this_1.taxList.find(function (t) {
          return t.id === x.account_tax_id;
        });

        if (tax) {
          x['tax_name'] = tax.name;
          x.account_tax_id = tax.amount;
        } else {
          x['tax_name'] = x.account_tax_id;
          x.account_tax_id = 0;
        }

        return x;
      });

      _this_1.closeLoading();
    }, function (err) {
      _this_1.closeLoading();

      _this_1.$message.error(err.message);
    });
  };

  PickingDetailMulti.prototype.created = function () {
    this.getShipType();
    this.getMvShipType();
  };

  PickingDetailMulti.prototype.mounted = function () {
    this.data = Object.assign({}, this.detail);
    this.orderID = this.data.order_id;
  };

  PickingDetailMulti.prototype.onPanelChange = function (e) {
    this.activeKey = e;

    if (!this.id) {
      return;
    }

    if (e == 'pickingdetail') {
      this.getOperations();
      this.getDemands();
      this.getShipments();
    } else if (e == 'return') {
      this.getReturns();
    } else if (e == 'logs') {
      this.getLogs();
    } else if (e == 'order_detail') {
      this.getOrderDetail();
    } else if (e == 'invoices') {
      this.getInvoiceList();
    }
  };

  PickingDetailMulti.prototype.getInvoiceList = function () {
    var _this_1 = this;

    this.orderService.getInvoiceList(new http["RequestParams"]({
      order_name: this.data.origin
    }, this.loading)).subscribe(function (data) {
      _this_1.invoice = data;

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.getOperations = function () {
    var _this_1 = this;

    this.pickingService.queryStockOperation(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, this.loading)).subscribe(function (data) {
      _this_1.operations = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.getDemands = function () {
    var _this_1 = this;

    this.pickingService.queryStockMove(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, this.loading)).subscribe(function (data) {
      _this_1.demands = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.getShipments = function () {
    var _this_1 = this;

    this.pickingService.queryShipment(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, this.loading)).subscribe(function (data) {
      _this_1.shipments = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.getReturns = function () {
    var _this_1 = this;

    this.pickingService.queryReturnInfo(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, this.loading)).subscribe(function (data) {
      _this_1.returns = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.getLogs = function () {
    var _this_1 = this;

    this.pickingService.queryPickingLog(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, this.loading)).subscribe(function (data) {
      _this_1.logs = data.map(function (x, i) {
        return tslib_es6["a" /* __assign */]({}, x, {
          index: i + 1
        });
      });

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.filterSelectOption = function (input, option) {
    return option.componentOptions.children[0].text.toLowerCase().indexOf(input.toLowerCase()) >= 0;
  };

  PickingDetailMulti.prototype.editBtn = function () {
    this.editable = !this.editable;
  };

  PickingDetailMulti.prototype.handleChange = function (value, key) {
    this.data[key] = value;
  };

  PickingDetailMulti.prototype.saveBtn = function () {
    var _this_1 = this;

    this.data['save_flag'] = 1;
    this.pickingService.save(new http["RequestParams"](this.data, this.loading)).subscribe(function () {
      var msg = _this_1.$t('tips.save_success');

      _this_1.$message.success(msg);

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    }); // this.editable = false
  };

  PickingDetailMulti.prototype.cancelBtn = function () {
    this.data = Object.assign({}, this.detail); // this.editable = false
  };

  PickingDetailMulti.prototype.createShipment = function () {
    var _this_1 = this;

    this.pickingService.createShipmentsLines(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function () {
      var msg = _this_1.$t('tips.save_success');

      _this_1.$message.success(msg); // this.reset()


      _this_1.reset();
    }, function (err) {
      _this_1.closeLoading();

      _this_1.$message.error(err.message);
    });
  };

  PickingDetailMulti.prototype.reserve = function () {
    var _this_1 = this;

    this.pickingService.reserve(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('tips.save_success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.modifyAddress = function () {
    router["a" /* default */].push({
      name: 'modify-address',
      params: {
        pickingList: JSON.stringify([this.id])
      }
    });
  };

  PickingDetailMulti.prototype.validateAddress = function () {
    this.saveDetail++;

    var _that = this; // setTimeout(function() {
    //     _that.reset()
    // }, 3000)

  };

  PickingDetailMulti.prototype.batchSendEmail = function () {
    var _this_1 = this;

    this.$modal.open(batch_send_email["a" /* default */], {
      stock: [this.id]
    }, {
      title: this.$t('action.batch_send_email'),
      width: '1000px'
    }).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);
    });
  };

  PickingDetailMulti.prototype.cancelPicking = function () {
    var _this_1 = this;

    this.pickingService.cancelPicking(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.createReturn = function () {
    var _this_1 = this;

    this.$modal.open(create_return["a" /* default */], {
      picking_id: parseInt(this.id),
      changeSpinning: this.changeSpinning
    }, {
      title: this.$t('Create Return Shipment'),
      width: '80%'
    }).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    });
  };

  PickingDetailMulti.prototype.donePickingGetLabel = function () {
    this.saveShipment++;

    var _that = this;

    setTimeout(function () {
      _that.shipmentService.donePickingGetLabel(new http["RequestParams"]({
        picking_id_list: [_that.id]
      }, _that.loading)).subscribe(function (data) {
        var msg = _that.$t('success');

        _that.$message.success(msg);

        _that.reset();
      }, function (err) {
        _that.$message.error(err.message);

        _that.closeLoading();
      });
    }, 1500);
  };

  PickingDetailMulti.prototype.setAsDraft = function () {
    var _this_1 = this;

    this.pickingService.setAsDraft(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.setPresale = function () {
    var _this_1 = this;

    this.pickingService.setPresale(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.cancelPresale = function () {
    var _this_1 = this;

    this.pickingService.cancelPresale(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.markSoldOut = function () {
    var _this_1 = this;

    this.pickingService.markSoldOut(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.cancelSoldOut = function () {
    var _this_1 = this;

    this.pickingService.cancelSoldOut(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.checkShipments = function () {
    var _this_1 = this;

    this.pickingService.checkShipments(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.cancelCheckShipments = function () {
    var _this_1 = this;

    this.pickingService.cancelCheckShipments(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.serviceProcess = function () {
    var _this_1 = this;

    this.pickingService.serviceProcess(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.returnProcess = function () {
    var _this = this;

    this.$confirm({
      title: this.$t('action.confirm_operate_return_order'),
      onOk: function onOk() {
        _this.returnProcessService();
      },
      onCancel: function onCancel() {}
    });
  };

  PickingDetailMulti.prototype.returnProcessService = function () {
    var _this_1 = this;

    this.pickingService.returnProcess(new http["RequestParams"]({
      picking_id_list: [this.id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.deliveryMore = function () {
    var _this_1 = this;

    this.$modal.open(delivery_more["a" /* default */], {
      picking_id: parseInt(this.id),
      changeSpinning: this.changeSpinning
    }, {
      title: this.$t('action.deliveryMore'),
      width: '800px'
    }).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      if (_this_1.getPickingInfo) {
        _this_1.getPickingInfo(data.new_picking_id);
      } else {
        _this_1.$router.push({
          name: 'picking-detail',
          path: "/picking/picking-detail/" + data.new_picking_id,
          params: {
            id: data.new_picking_id,
            name: data.new_picking_name
          }
        });
      }
    });
  };

  PickingDetailMulti.prototype.productPart = function () {
    var _this_1 = this;

    this.$modal.open(product_part["a" /* default */], {
      picking_id: parseInt(this.id),
      changeSpinning: this.changeSpinning
    }, {
      title: this.$t('action.ProductPart'),
      width: '800px'
    }).subscribe(function (data) {
      var msg = _this_1.$t('save_success');

      _this_1.$message.success(msg);

      _this_1.reset();
    });
  };

  PickingDetailMulti.prototype.customer_service_stop_plz = function () {
    var _this = this;

    this.$confirm({
      title: this.$t('action.confirm_operate_wrong_order'),
      onOk: function onOk() {
        _this.customer_service_stop_plz_service();
      },
      onCancel: function onCancel() {}
    });
  };

  PickingDetailMulti.prototype.customer_service_stop_plz_service = function () {
    var _this_1 = this;

    this.pickingService.customer_service_stop_plz(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.pickingRefundConfirm = function () {
    var _this = this;

    this.$confirm({
      title: this.$t('action.confirm_operate_refund_order'),
      onOk: function onOk() {
        _this.cancel_stock_picking_for_order_refund();
      },
      onCancel: function onCancel() {}
    });
  };

  PickingDetailMulti.prototype.cancel_stock_picking_for_order_refund = function () {
    var _this_1 = this;

    this.pickingService.cancel_stock_picking_for_order_refund(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.fake_shipments = function () {
    var _this_1 = this;

    this.pickingService.fake_shipments(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.upload_shipment = function () {
    var _this_1 = this;

    this.pickingService.upload_shipment(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.upload_fake_shipment = function () {
    var _this_1 = this;

    this.pickingService.upload_fake_shipment(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.updatePickingInfo = function () {
    var _this_1 = this;

    this.pickingService.queryDetail(new http["RequestParams"]({
      picking_id: parseInt(this.id)
    }, this.loading)).subscribe(function (data) {
      data[0]['id'] = parseInt(_this_1.id);
      _this_1.data = data[0];

      _this_1.closeLoading();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.forceVerifyAddress = function () {
    var _this_1 = this;

    this.pickingService.forceVerifyAddress(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.refreshDetailPage = function () {
    this.reset();
  };

  PickingDetailMulti.prototype.multiCreateInvoice = function () {
    var _this_1 = this;

    this.accountService.createInvoice(new http["RequestParams"]({
      order_id_list: [this.data.order_id]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.OnRefund = function () {
    var _this_1 = this;

    this.$modal.open(refund_form["a" /* default */], {
      countryList: this.countryList,
      order_id: this.data.order_id,
      changeSpinning: this.changeSpinning
    }, {
      title: this.$t('action.refund'),
      width: '1000px'
    }).subscribe(function (data) {
      _this_1.reset();
    });
  };

  PickingDetailMulti.prototype.createShipmentByType = function (type) {
    var _this_1 = this;

    this.pickingService.create_shipment_lines_by_ship_type(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)],
      ship_type: type
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.createGift = function () {
    var _this_1 = this;

    this.pickingService.create_dhl_dpd_gift(new http["RequestParams"]({
      picking_ids: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      _this_1.$message.success('创建成功!');

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  PickingDetailMulti.prototype.forceAvailability = function () {
    var _this_1 = this;

    this.pickingService.force_available(new http["RequestParams"]({
      picking_id_list: [parseInt(this.id)]
    }, this.loading)).subscribe(function (data) {
      var msg = _this_1.$t('success');

      _this_1.$message.success(msg);

      _this_1.reset();
    }, function (err) {
      _this_1.$message.error(err.message);

      _this_1.closeLoading();
    });
  };

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "detail", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "id", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: true
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "pageShow", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 'auto'
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "divHeight", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])({
    default: 0
  }), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "cnt", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "countryList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "systemUsers", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "changeSpinning", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["c" /* Prop */])(), tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "getPickingInfo", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "shipTypeList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "getShipType", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "mvShipTypeList", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.Action, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "getMvShipType", void 0);

  tslib_es6["c" /* __decorate */]([datasModule.State, tslib_es6["f" /* __metadata */]("design:type", Object)], PickingDetailMulti.prototype, "companyList", void 0);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('detail'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingDetailMulti.prototype, "onDetailChange", null);

  tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["f" /* Watch */])('cnt'), tslib_es6["f" /* __metadata */]("design:type", Function), tslib_es6["f" /* __metadata */]("design:paramtypes", []), tslib_es6["f" /* __metadata */]("design:returntype", void 0)], PickingDetailMulti.prototype, "onCntChange", null);

  PickingDetailMulti = tslib_es6["c" /* __decorate */]([Object(vue_property_decorator["a" /* Component */])({
    components: {
      PickingBaseDetail: picking_base_detail["a" /* default */],
      OperationDetail: operation_detail["a" /* default */],
      DemandDetail: demand_detail["a" /* default */],
      ShipmentDetail: shipment_detail["a" /* default */],
      ReturnDetail: return_detail["a" /* default */],
      PickingLogDetail: picking_log_detail["a" /* default */],
      RefundForm: refund_form["a" /* default */],
      OrderBaseDetail: order_base_detail["a" /* default */],
      OrderInvoiceDetail: order_invoice_detail["a" /* default */]
    }
  })], PickingDetailMulti);
  return PickingDetailMulti;
}(vue_property_decorator["e" /* Vue */]);

/* harmony default export */ var picking_detail_multivue_type_script_lang_ts_ = (picking_detail_multivue_type_script_lang_ts_PickingDetailMulti);
// CONCATENATED MODULE: ./src/components/picking/picking-detail-multi.vue?vue&type=script&lang=ts&
 /* harmony default export */ var picking_picking_detail_multivue_type_script_lang_ts_ = (picking_detail_multivue_type_script_lang_ts_); 
// EXTERNAL MODULE: ./src/components/picking/picking-detail-multi.vue?vue&type=style&index=0&lang=css&
var picking_detail_multivue_type_style_index_0_lang_css_ = __webpack_require__("6cf4");

// EXTERNAL MODULE: ./node_modules/vue-loader/lib/runtime/componentNormalizer.js
var componentNormalizer = __webpack_require__("2877");

// EXTERNAL MODULE: ./src/components/picking/picking-detail-multi.vue?vue&type=custom&index=0&blockType=i18n
var picking_detail_multivue_type_custom_index_0_blockType_i18n = __webpack_require__("2516");

// CONCATENATED MODULE: ./src/components/picking/picking-detail-multi.vue






/* normalize component */

var component = Object(componentNormalizer["a" /* default */])(
  picking_picking_detail_multivue_type_script_lang_ts_,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* custom blocks */

if (typeof picking_detail_multivue_type_custom_index_0_blockType_i18n["default"] === 'function') Object(picking_detail_multivue_type_custom_index_0_blockType_i18n["default"])(component)

/* harmony default export */ var picking_detail_multi = __webpack_exports__["a"] = (component.exports);

/***/ }),

/***/ "ec78":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"invoices":"Invoices","order_detail":"Order Detail","base":"Picking Info","operation":"Operations","initial_demand":"Initial Demand","shipment":"Shipments","return_info":"Customer Problem","logs":"Logs","pickingdetail":"Picking Detail","title-1":"Details of the products to be shipped","title-2":"Details of the reserved position of the shipped product in the warehouse","title-3":"Logistics package details required to ship products","action":{"create":"Create","batch-create":"EXCEL Import","edit":"Edit","delete":"Delete","ok":"Yes","cancel":"Discard","cancel2":"Cancel","more":"More","confirm_order":"Confirm Order","cancel_order":"Cancel Order","create_invovice":"Create Invovice","detail":"Detail","auto_create":"Auto Create","create_dhl":"Create DHL","create_dpd":"Create DPD","create_gls":"Create GLS","sold_out":"Sold Out","validate_address":"Validate Address","modify_address":"Modify Address","batch_send_email":"Batch Send Email","fake_shipment":"Fake Shipment","upload_shipment":"Upload Shipment","upload_fake_shipment":"Upload Fake Shipment","createReturn":"Create Return","done_picking_get_label":"Shipping Label","deliveryMore":"Delivery More","ProductPart":"Product Part","cancelPicking":"Cancel","setAsDraft":"Set Draft","setPresale":"Set Presale","cancelPresale":"Cancel Presale","markSoldOut":"Mark SoldOut","cancelSoldOut":"Cancel SoldOut","checkShipmentCount":"Check Shipments","cancelShipmentCount":"Cancel Check Shipments","serviceProcess":"Service Process","returnProcess":"Return Process","customer_service_stop_plz":"Wrong Address","cancel_stock_picking_for_order_refund":"Cancel Order For Refund","force_verify_address":"Force Verify Address","refund":"Refund/Supplement","create_brief":"Create Brief","reserved":"Reserved","more_btn":"More Buttons","force_available":"Force Availability","confirm_operate_refund_order":"Are you sure to cancel order for refund?","confirm_operate_return_order":"Are you sure to cancel order for return?","confirm_operate_wrong_order":"Are you sure to cancel order for wrong address?"}},"zh-cn":{"invoices":"发票","order_detail":"订单详情","base":"拣货单详情","operation":"操作","initial_demand":"包裹明细","shipment":"面单","return_info":"客户问题","logs":"操作日志","pickingdetail":"发货明细","title-1":"所需发货产品明细","title-2":"发货产品在仓库预留位置明细","title-3":"发货产品打包物流包裹明细","action":{"create":"新建","batch-create":"EXCEL导入","edit":"编辑","delete":"删除","ok":"确定","cancel":"丢弃","cancel2":"取消","more":"更多操作","confirm_order":"确认订单","cancel_order":"取消订单","create_invovice":"创建发票","detail":"详情","auto_create":"创建运单","create_dhl":"创建DHL","create_dpd":"创建DPD","create_gls":"创建GLS","sold_out":"卖超","validate_address":"验证地址","modify_address":"批量验证","batch_send_email":"批量发邮件","fake_shipment":"假单号","upload_shipment":"上传单号","upload_fake_shipment":"上传假单号","createReturn":"创建回程单","done_picking_get_label":"生成运单号","deliveryMore":"创建补发","ProductPart":"补发零部件","cancelPicking":"取消","setAsDraft":"设为草稿","setPresale":"设为预售","cancelPresale":"取消预售","markSoldOut":"卖超","cancelSoldOut":"取消卖超","checkShipmentCount":"Check Shipments","cancelShipmentCount":"Cancel Check Shipments","serviceProcess":"Service Process","returnProcess":"Return Process","customer_service_stop_plz":"Wrong Address","cancel_stock_picking_for_order_refund":"Cancel Order For Refund","force_verify_address":"强制验证地址","refund":"退/补款","create_brief":"创建Brief","reserved":"预留","more_btn":"更多按钮","force_available":"强制预留","confirm_operate_refund_order":"确定要取消订单[直接退款]吗?","confirm_operate_return_order":"确定要取消订单[退回]吗?","confirm_operate_wrong_order":"确定要取消订单[错误地址]吗?"}}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "ee0e":
/***/ (function(module, exports, __webpack_require__) {

// extracted by mini-css-extract-plugin

/***/ }),

/***/ "f3ce":
/***/ (function(module, exports) {

module.exports = function (Component) {
  Component.options.__i18n = Component.options.__i18n || []
  Component.options.__i18n.push('{"en-us":{"partner":"Partner","partner_name":"Partner Name","company":"Name2/Company","street":"Street","nr":"Nr.","street2":"Street2/Postnumber","zip":"Zip","city":"City","country":"Country","email":"Email","phone":"Phone","shipment_number":"Shipment Number","fake_shipment":"Fake Shipment","check_shipments":"Check Shipments","exception":"Exception","sold_out":"Sold Out","sold_out_time":"Sold Out Time","container_time":"Container Time","user_continue":"User Continue","service_process":"Service Process","stock_process":"Stock Process","latest_ship_date":"Latest Ship Date","latest_delivery_date_new":"Latest Delivery Date","picking_shipment":"Picking Shipment","fee":"Fee","need_resend_memo":"Need Resend Memo","scheduled_date":"Scheduled Date","source_document":"Source Document","updated_in_wish":"Updated in Wish","payment_date":"Payment Date","weight":"Weight(KG)","shipment_content":"Shipment Content","validate_state":"Validate State","validate_error_text":"Validate Error Text","pre_sale":"Pre Sale","send_gift":"Send Gift","send_warehouse":"Send Warehouse","updated_in_platform":"Updated in Platform","resend":"Resend","confirm_return_time":"Confirm Return Time","return_process_time":"Return Process Time","assign_to_user":"Assign to User","remote_district":"Remote District","ebay_type":"Ebay Type","amazon_type":"Amazon Type","nstance":"Instance","total":"Total","ship_method":"Ship Method","save":"Save","cancel":"Discard","ebay_buyer_id":"eBay Buyer ID"},"zh-cn":{"partner":"Partner","partner_name":"Partner Name","company":"Name2/Company","street":"街道","nr":"门牌号","street2":"Street2/Postnumber","zip":"邮编","city":"城市","country":"国家","email":"邮箱","phone":"电话","shipment_number":"物流单号","fake_shipment":"Fake Shipment","check_shipments":"Check Shipments","exception":"异常","sold_out":"卖超","sold_out_time":"卖超时间","container_time":"装箱时间","user_continue":"User Continue","service_process":"Service Process","stock_process":"Stock Process","latest_ship_date":"最晚发货时间","latest_delivery_date_new":"最晚投递时间","picking_shipment":"Picking Shipment","fee":"费用","need_resend_memo":"补发理由","scheduled_date":"约定日期","source_document":"Source Document","updated_in_wish":"Updated in Wish","payment_date":"支付日期","weight":"重量(KG)","shipment_content":"Shipment Content","validate_state":"有效状态","validate_error_text":"Validate Error Text","pre_sale":"预售","send_gift":"送礼品","send_warehouse":"发货仓库","updated_in_platform":"Updated in Platform","resend":"补发","confirm_return_time":"确认退货时间","return_process_time":"退货处理时间","assign_to_user":"分配给用户","remote_district":"偏远地区","ebay_type":"Ebay类型","amazon_type":"Amazon类型","instance":"实例","total":"总计","ship_method":"物流方式","save":"保存","cancel":"丢弃","ebay_buyer_id":"eBay Buyer ID"}}')
  delete Component.options._Ctor
}


/***/ }),

/***/ "f48d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("a444");
/* harmony import */ var _node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0__);
 /* harmony default export */ __webpack_exports__["default"] = (_node_modules_kazupon_vue_i18n_loader_lib_index_js_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_product_part_vue_vue_type_custom_index_0_blockType_i18n__WEBPACK_IMPORTED_MODULE_0___default.a); 

/***/ }),

/***/ "f93a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_delivery_more_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c990");
/* harmony import */ var _node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_delivery_more_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_mini_css_extract_plugin_dist_loader_js_ref_7_oneOf_1_0_node_modules_css_loader_dist_cjs_js_ref_7_oneOf_1_1_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_7_oneOf_1_2_node_modules_cache_loader_dist_cjs_js_ref_1_0_node_modules_vue_loader_lib_index_js_vue_loader_options_delivery_more_vue_vue_type_style_index_0_lang_css___WEBPACK_IMPORTED_MODULE_0__);
/* unused harmony reexport * */


/***/ })

}]);