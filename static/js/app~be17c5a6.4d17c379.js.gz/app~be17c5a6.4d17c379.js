(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["app~be17c5a6"],{

/***/ "061c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SystemController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 权限控制器名称

var controller = 'system';
/**
 * API接口配置
 * 权限服务配置
 */

var SystemController = {
  // 获取用户列表
  query_all_user: {
    controller: controller,
    action: 'query_all_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存用户
  save_user: {
    controller: controller,
    action: 'save_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 禁用用户
  stop_user: {
    controller: controller,
    action: 'stop_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 修改用户密码
  change_user_password: {
    controller: controller,
    action: 'change_user_password',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取所有角色
  query_system_role: {
    controller: controller,
    action: 'query_system_role',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存角色
  save_system_role: {
    controller: controller,
    action: 'save_system_role',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除角色
  delete_system_role: {
    controller: controller,
    action: 'delete_system_role',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 子系统查询
  query_all_sub_system: {
    controller: controller,
    action: 'query_all_sub_system',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存子系统
  save_sub_system: {
    controller: controller,
    action: 'save_sub_system',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除子系统
  delete_sub_system: {
    controller: controller,
    action: 'delete_sub_system',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询所有模块
  query_all_system_model: {
    controller: controller,
    action: 'query_all_system_model',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存模块
  save_system_model: {
    controller: controller,
    action: 'save_system_model',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除模块
  delete_system_model: {
    controller: controller,
    action: 'delete_system_model',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询所有子模块
  query_all_system_sub_model: {
    controller: controller,
    action: 'query_all_system_sub_model',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存子模块
  save_system_sub_model: {
    controller: controller,
    action: 'save_system_sub_model',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存子模块
  delete_system_sub_model: {
    controller: controller,
    action: 'delete_system_sub_model',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 给角色添加用户
  create_role_user_rel: {
    controller: controller,
    action: 'create_role_user_rel',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询角色对应的用户
  query_user_by_role_code: {
    controller: controller,
    action: 'query_user_by_role_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除系统角色对应的用户
  delete_role_user_rel: {
    controller: controller,
    action: 'delete_role_user_rel',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询角色可以添加的用户
  query_role_need_add_user: {
    controller: controller,
    action: 'query_role_need_add_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询角色已添加的菜单
  query_menu_by_role_code: {
    controller: controller,
    action: 'query_menu_by_role_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除角色中的菜单接口
  delete_role_menu_rel: {
    controller: controller,
    action: 'delete_role_menu_rel',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询角色可添加的菜单接口
  query_role_need_add_menu: {
    controller: controller,
    action: 'query_role_need_add_menu',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 角色添加菜单接口
  create_role_menu_rel: {
    controller: controller,
    action: 'create_role_menu_rel',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询菜单接口
  query_all_system_menu: {
    controller: controller,
    action: 'query_all_system_menu',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存菜单接口
  save_system_menu: {
    controller: controller,
    action: 'save_system_menu',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除菜单接口
  delete_system_menu: {
    controller: controller,
    action: 'delete_system_menu',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 添加用户菜单
  add_user_menu: {
    controller: controller,
    action: 'add_user_menu',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除用户菜单
  delete_user_menu: {
    controller: controller,
    action: 'delete_user_menu',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询用户菜单
  query_menu_by_user: {
    controller: controller,
    action: 'query_menu_by_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询角色用户菜单
  query_menu_by_role_user: {
    controller: controller,
    action: 'query_menu_by_role_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存子用户菜单
  add_sub_account_menu: {
    controller: controller,
    action: 'add_sub_account_menu',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据客户ID查询公告
  query_all_user_notice: {
    controller: controller,
    action: 'query_all_user_notice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存公告
  save_notice: {
    controller: controller,
    action: 'save_notice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询单个公告
  query_one_notice: {
    controller: controller,
    action: 'query_one_notice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 废除公告
  discard_notice: {
    controller: controller,
    action: 'discard_notice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 审核公告
  approve_notice: {
    controller: controller,
    action: 'approve_notice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询某菜单的固定查询条件
  query_fixed_search_condition_by_menu_code: {
    controller: controller,
    action: 'query_fixed_search_condition_by_menu_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询某菜单的所有查询条件
  query_search_condition_by_menu_code: {
    controller: controller,
    action: 'query_search_condition_by_menu_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存某菜单的所有查询条件
  batch_create_search_condition: {
    controller: controller,
    action: 'batch_create_search_condition',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 单删查询条件
  delete_one_search_condition: {
    controller: controller,
    action: 'delete_one_search_condition',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 创建单个查询条件
  create_search_condition: {
    controller: controller,
    action: 'create_search_condition',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询某菜单下用户查询条件接口
  query_user_search_condition: {
    controller: controller,
    action: 'query_user_search_condition',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 修改登录者密码
  change_own_password: {
    controller: controller,
    action: 'change_owner_password',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询汇率
  queryCurrencyChange: {
    controller: controller,
    action: 'query_all_currency_exchange',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 接口列表管理
  query_all_system_api: {
    controller: controller,
    action: 'query_all_system_api',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存接口列表
  save_system_api: {
    controller: controller,
    action: 'save_system_api',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 修改接口列表激活状态
  active_system_api: {
    controller: controller,
    action: 'active_system_api',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询行数据访问规则
  query_all_data_access_rule: {
    controller: controller,
    action: 'query_all_data_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存行数据访问规则
  save_data_access_rule: {
    controller: controller,
    action: 'save_data_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 修改行数据访问规则状态
  active_data_access_rule: {
    controller: controller,
    action: 'active_data_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询站点数据访问规则
  query_all_host_data_access_rule: {
    controller: controller,
    action: 'query_all_host_data_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存站点数据访问规则
  save_host_data_access_rule: {
    controller: controller,
    action: 'save_host_data_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 修改站点数据访问规则状态
  active_host_data_access_rule: {
    controller: controller,
    action: 'active_host_data_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 更新角色菜单数据访问规则接口
  update_role_menu_access_rule: {
    controller: controller,
    action: 'update_role_menu_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 更新用户菜单数据访问规则接口
  update_user_menu_access_rule: {
    controller: controller,
    action: 'update_user_menu_access_rule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "1369":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SaleTrendController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'product_sale_trend';
/**
 * API接口配置
 * 订单服务配置
 */

var SaleTrendController = {
  // 获取额度申请列表
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // approve: {
  //     controller,
  //     action: 'approve',
  //     type: RequestMethod.Post
  // },
  // delete: {
  //     controller,
  //     action: 'delete',
  //     type: RequestMethod.Post
  // },
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "1ba9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LocationController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'stock_location';
/**
 * API接口配置
 * 订单服务配置
 */

var LocationController = {
  // 获取库位列表
  query_stock_location: {
    controller: controller,
    action: 'query_stock_location',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "2495":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomerStatus", function() { return CustomerStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerInstanceStatus", function() { return SellerInstanceStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SellerPlatform", function() { return SellerPlatform; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WarehouseId", function() { return WarehouseId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PresaleType", function() { return PresaleType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IsPresale", function() { return IsPresale; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseStatus", function() { return PurchaseStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PredictStatus", function() { return PredictStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PredictStatusConfirm", function() { return PredictStatusConfirm; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PredictStatusApprove", function() { return PredictStatusApprove; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchType", function() { return SearchType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderStatus", function() { return OrderStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PackageSize", function() { return PackageSize; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "WarehouseList", function() { return WarehouseList; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderType", function() { return OrderType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShippingPolicy", function() { return ShippingPolicy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoicePolicy", function() { return InvoicePolicy; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "illegalWords", function() { return illegalWords; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PickingStatus", function() { return PickingStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PickingValidateState", function() { return PickingValidateState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "InvoiceSendStatus", function() { return InvoiceSendStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Operators", function() { return Operators; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EmailGroupStatus", function() { return EmailGroupStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProductType", function() { return ProductType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OceanShipStatus", function() { return OceanShipStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShipStatus", function() { return ShipStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReissueType", function() { return ReissueType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReplenishmentType", function() { return ReplenishmentType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReplenishmentState", function() { return ReplenishmentState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PackageOrderState", function() { return PackageOrderState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseContractState", function() { return PurchaseContractState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchaseShipOrderState", function() { return PurchaseShipOrderState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FinalShipSite", function() { return FinalShipSite; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SkuReplenishState", function() { return SkuReplenishState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SaleState", function() { return SaleState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogisticsProviderState", function() { return LogisticsProviderState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LogisticsProviderAging", function() { return LogisticsProviderAging; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UnsalableApproveState", function() { return UnsalableApproveState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PreProdPriceApproveState", function() { return PreProdPriceApproveState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProdStatus", function() { return ProdStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ShippingPlanState", function() { return ShippingPlanState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PriceCheckProdStatus", function() { return PriceCheckProdStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckProdStatus", function() { return CheckProdStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SentEmailStatus", function() { return SentEmailStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PurchasePriceChangeReportStatus", function() { return PurchasePriceChangeReportStatus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DePoState", function() { return DePoState; });
// 客户状态
var CustomerStatus = [{
  label: 'dict.customer-status.pending',
  value: 10
}, {
  label: 'dict.customer-status.reject',
  value: 20
}, {
  label: 'dict.customer-status.accept',
  value: 30
}, {
  label: 'dict.customer-status.suspend',
  value: 100
}]; // seller instance 状态

var SellerInstanceStatus = [{
  label: 'dict.seller-instance-status.draft',
  value: 10
}, {
  label: 'dict.seller-instance-status.active',
  value: 20
}, {
  label: 'dict.seller-instance-status.cancel',
  value: 60
}, {
  label: 'dict.seller-instance-status.suspend',
  value: 100
}, {
  label: 'dict.seller-instance-status.inactive',
  value: 200
}]; // seller platform

var SellerPlatform = [{
  label: 'dict.seller-platform.b2c',
  value: 10
}, {
  label: 'dict.seller-platform.amz',
  value: 20
}, {
  label: 'dict.seller-platform.eBay',
  value: 30
}, {
  label: 'dict.seller-platform.wish',
  value: 40
}, {
  label: 'dict.seller-platform.cd',
  value: 50
}, {
  label: 'dict.seller-platform.aliexpress',
  value: 60
}, {
  label: 'dict.seller-platform.wayfair',
  value: 100
}]; // 产品销售趋势仓库分类

var WarehouseId = [{
  label: 'dict.warehouse_id.de',
  value: 'de'
}, {
  label: 'dict.warehouse_id.uk',
  value: 'uk'
}, {
  label: 'dict.warehouse_id.us',
  value: 'us'
}]; // 产品预售类型分类

var PresaleType = [{
  label: 'dict.presale_type.type_category',
  value: 10
}, {
  label: 'dict.presale_type.type_sku',
  value: 20
}]; // 产品是否预售

var IsPresale = [{
  label: 'dict.is_presale.type_true',
  value: true
}, {
  label: 'dict.is_presale.type_false',
  value: false
}]; //  产品补货状态

var PurchaseStatus = [{
  label: 'dict.purchase_status.not',
  value: 10
}, {
  label: 'dict.purchase_status.need',
  value: 20
}, {
  label: 'dict.purchase_status.purchased',
  value: 30
}, {
  label: 'dict.purchase_status.cancel',
  value: 40
}]; //  产品补货预测状态

var PredictStatus = [{
  label: 'dict.predict_status.new',
  value: 10
}, {
  label: 'dict.predict_status.active',
  value: 30
}, {
  label: 'dict.predict_status.confirmed',
  value: 50
}, {
  label: 'dict.predict_status.completed',
  value: 70
}, {
  label: 'dict.predict_status.returned',
  value: 100
}, {
  label: 'dict.predict_status.refused',
  value: 200
}]; //  产品补货预测状态

var PredictStatusConfirm = [{
  label: 'dict.predict_status.active',
  value: 30
}, {
  label: 'dict.predict_status.confirmed',
  value: 50
}, {
  label: 'dict.predict_status.completed',
  value: 70
}, {
  label: 'dict.predict_status.returned',
  value: 100
}, {
  label: 'dict.predict_status.refused',
  value: 200
}]; //  产品补货预测状态

var PredictStatusApprove = [{
  label: 'dict.predict_status.confirmed',
  value: 50
}, {
  label: 'dict.predict_status.completed',
  value: 70
}, {
  label: 'dict.predict_status.refused',
  value: 200
}]; //  查询类型

var SearchType = [{
  label: 'dict.search_type.normal',
  value: 10
}, {
  label: 'dict.search_type.favourite',
  value: 20
}]; //  订单类型

var OrderStatus = [{
  label: 'dict.state.draft',
  value: 'draft'
}, {
  label: 'dict.state.sale',
  value: 'sale'
}, {
  label: 'dict.state.done',
  value: 'done'
}, {
  label: 'dict.state.cancel',
  value: 'cancel'
}]; //  包裹规格

var PackageSize = [{
  label: 'dict.package_size.small',
  value: 's'
}, {
  label: 'dict.package_size.medium',
  value: 'm'
}, {
  label: 'dict.package_size.large',
  value: 'l'
}]; //  包裹规格

var WarehouseList = [{
  label: 'dict.warehouse_list.de',
  value: 'de'
}, {
  label: 'dict.warehouse_list.uk',
  value: 'uk'
}, {
  label: 'dict.warehouse_list.uk_own',
  value: 'uk_own'
}, {
  label: 'dict.warehouse_list.fr',
  value: 'fr'
}, {
  label: 'dict.warehouse_list.zqlc',
  value: 'zqlc'
}]; //  订单类型

var OrderType = [{
  label: 'dict.order_type.a',
  value: 'A'
}, {
  label: 'dict.order_type.r',
  value: 'R'
}, {
  label: 'dict.order_type.g',
  value: 'G'
}, {
  label: 'dict.order_type.service',
  value: 'Service'
}]; //  shipping policy

var ShippingPolicy = [{
  label: 'dict.shipping_policy.one',
  value: 'one'
}, {
  label: 'dict.shipping_policy.direct',
  value: 'direct'
}]; //  invoice policy

var InvoicePolicy = [{
  label: 'dict.invoice_policy.order',
  value: 'order'
}, {
  label: 'dict.invoice_policy.delivery',
  value: 'delivery'
}]; //违规词汇

var illegalWords = [{
  label: 'dict.illegal_words.active',
  value: 20
}, {
  label: 'dict.illegal_words.cancel',
  value: 60
}]; //  picking类型

var PickingStatus = [{
  label: 'dict.picking_state.draft',
  value: 'draft'
}, {
  label: 'dict.picking_state.waiting',
  value: 'waiting'
}, {
  label: 'dict.picking_state.confirmed',
  value: 'confirmed'
}, {
  label: 'dict.picking_state.partially_available',
  value: 'partially_available'
}, {
  label: 'dict.picking_state.assigned',
  value: 'assigned'
}, {
  label: 'dict.picking_state.done',
  value: 'done'
}, {
  label: 'dict.picking_state.cancel',
  value: 'cancel'
}]; //picking 有效状态

var PickingValidateState = [{
  label: 'dict.picking_validate_status.no_validate',
  value: 'no validate'
}, {
  label: 'dict.picking_validate_status.error',
  value: 'error'
}, {
  label: 'dict.picking_validate_status.ok',
  value: 'ok'
}]; //picking 发票发送状态

var InvoiceSendStatus = [{
  label: 'dict.invoice_send_status.waiting',
  value: '0'
}, {
  label: 'dict.invoice_send_status.done',
  value: '1'
}, {
  label: 'dict.invoice_send_status.query',
  value: '-1'
}, {
  label: 'dict.invoice_send_status.create_invoice',
  value: '-2'
}, {
  label: 'dict.invoice_send_status.partner_email',
  value: '-3'
}, {
  label: 'dict.invoice_send_status.no_order',
  value: '-4'
}, {
  label: 'dict.invoice_send_status.no_template',
  value: '-10'
}, {
  label: 'dict.picking_validate_status.other',
  value: -100
}]; //picking 有效状态

var Operators = [{
  label: '>',
  value: '>'
}, {
  label: '=',
  value: '='
}, {
  label: '<',
  value: '<'
}, {
  label: '>=',
  value: '>='
}, {
  label: '<=',
  value: '<='
}, {
  label: '!=',
  value: '!='
}, {
  label: 'or',
  value: '|'
}, {
  label: 'prefix_like',
  value: 'prefix_like'
}, {
  label: 'like',
  value: 'like'
}, {
  label: 'not like',
  value: 'not like'
}, {
  label: 'suffix_like',
  value: 'suffix_like'
}, {
  label: 'ilike',
  value: 'ilike'
}, {
  label: 'not ilike',
  value: 'not ilike'
}, {
  label: 'null',
  value: 'null'
}, {
  label: 'not null',
  value: 'not null'
}, {
  label: 'in',
  value: 'in'
}, {
  label: 'not in',
  value: 'not in'
}, {
  label: 'regular_exp',
  value: 'regular_exp'
}, {
  label: 'not regular_exp',
  value: 'not regular_exp'
}, {
  label: 'SQL_QC',
  value: 'sql_query'
}, {
  label: 'SQL_QC_Para',
  value: 'sql_query_para'
}]; //Email Group 状态

var EmailGroupStatus = [{
  label: 'dict.email_group_status.active',
  value: 20
}, {
  label: 'dict.email_group_status.stop',
  value: 200
}]; //  产品类型

var ProductType = [{
  label: 'dict.product_type.consu',
  value: 'consu'
}, {
  label: 'dict.product_type.product',
  value: 'product'
}, {
  label: 'dict.product_type.service',
  value: 'service'
}]; //  海运费货运状态

var OceanShipStatus = [{
  label: 'dict.ocean_ship_status.ship',
  value: 'ship'
}, {
  label: 'dict.ocean_ship_status.process',
  value: 'process'
}, {
  label: 'dict.ocean_ship_status.waiting',
  value: 'waiting'
}, {
  label: 'dict.ocean_ship_status.wait',
  value: 'wait'
}, {
  label: 'dict.ocean_ship_status.land',
  value: 'land'
}]; //  货运状态

var ShipStatus = [{
  label: 'dict.ship_status.confirm',
  value: 'confirm'
}, {
  label: 'dict.ship_status.approved',
  value: 'approved'
}, {
  label: 'dict.ship_status.ship',
  value: 'ship'
}, {
  label: 'dict.ship_status.process',
  value: 'process'
}, {
  label: 'dict.ship_status.waiting',
  value: 'waiting'
}, {
  label: 'dict.ship_status.wait',
  value: 'wait'
}, {
  label: 'dict.ship_status.land',
  value: 'land'
}]; //  补发类型

var ReissueType = [{
  label: 'dict.reissue_type.complete',
  value: 'one'
}, {
  label: 'dict.reissue_type.part',
  value: 'part'
}]; // 补货类型

var ReplenishmentType = [{
  label: 'dict.replenishment_type.operational',
  value: 'operational'
}, {
  label: 'dict.replenishment_type.development',
  value: 'development'
}, {
  label: 'dict.replenishment_type.abnormal_purchase',
  value: 'abnormal_purchase'
}]; // 补货需求状态

var ReplenishmentState = [{
  label: 'dict.replenishment_state.draft',
  value: 'draft'
}, {
  label: 'dict.replenishment_state.to_approve',
  value: 'to approve'
}, {
  label: 'dict.replenishment_state.approved',
  value: 'approved'
}, {
  label: 'dict.replenishment_state.order',
  value: 'order'
}, {
  label: 'dict.replenishment_state.approved_order',
  value: 'approved/order'
}, {
  label: 'dict.replenishment_state.done',
  value: 'done'
}, {
  label: 'dict.replenishment_state.cancel',
  value: 'cancel'
}, {
  label: 'dict.replenishment_state.refuse',
  value: 'refuse'
}]; // 补货类型

var PackageOrderState = [{
  label: 'dict.package_order_state.draft',
  value: 'draft'
}, {
  label: 'dict.package_order_state.confirm',
  value: 'confirm'
}, {
  label: 'dict.package_order_state.approved',
  value: 'approved'
}, {
  label: 'dict.package_order_state.ship',
  value: 'ship'
}, {
  label: 'dict.package_order_state.process',
  value: 'process'
}, {
  label: 'dict.package_order_state.waiting',
  value: 'waiting'
}, {
  label: 'dict.package_order_state.wait',
  value: 'wait'
}, {
  label: 'dict.package_order_state.land',
  value: 'land'
}, {
  label: 'dict.package_order_state.cancel',
  value: 'cancel'
}]; // 补货类型

var PurchaseContractState = [{
  label: 'dict.purchase_contract_state.draft',
  value: 'draft'
}, {
  label: 'dict.purchase_contract_state.confirm',
  value: 'confirm'
}, {
  label: 'dict.purchase_contract_state.approved',
  value: 'approved'
}, {
  label: 'dict.purchase_contract_state.done',
  value: 'done'
}, {
  label: 'dict.purchase_contract_state.refuse',
  value: 'refuse'
}]; // 补货类型

var PurchaseShipOrderState = [{
  label: 'dict.purchase_contract_state.draft',
  value: 'draft'
}, {
  label: 'dict.purchase_contract_state.confirm',
  value: 'confirm'
}, {
  label: 'dict.purchase_contract_state.approved',
  value: 'approved'
}, {
  label: 'dict.purchase_contract_state.done',
  value: 'done'
}, {
  label: 'dict.purchase_contract_state.cancel',
  value: 'cancel'
}]; // 尾程运费涉及站点

var FinalShipSite = [{
  label: 'dict.final_ship_site.de',
  value: 'de'
}, {
  label: 'dict.final_ship_site.fr',
  value: 'fr'
}, {
  label: 'dict.final_ship_site.es',
  value: 'es'
}, {
  label: 'dict.final_ship_site.it',
  value: 'it'
}, {
  label: 'dict.final_ship_site.nl',
  value: 'nl'
}, {
  label: 'dict.final_ship_site.se',
  value: 'se'
}, {
  label: 'dict.final_ship_site.pl',
  value: 'pl'
}, {
  label: 'dict.final_ship_site.at',
  value: 'at'
}, {
  label: 'dict.final_ship_site.be',
  value: 'be'
}, {
  label: 'dict.final_ship_site.lu',
  value: 'lu'
}]; // 补货状态

var SkuReplenishState = [{
  label: 'dict.sku_replenish_state.no',
  value: 10
}, {
  label: 'dict.sku_replenish_state.single',
  value: 30
}, {
  label: 'dict.sku_replenish_state.merge',
  value: 20
}]; // 销售状态

var SaleState = [{
  label: 'dict.sale_state.normal',
  value: 10
}, {
  label: 'dict.sale_state.weed_out',
  value: 100
}, {
  label: 'dict.sale_state.infringement',
  value: 50
}, {
  label: 'dict.sale_state.to_be_seen',
  value: 20
}]; // 物流商状态

var LogisticsProviderState = [{
  label: 'dict.logistics_provider_state.active',
  value: 'active'
}, {
  label: 'dict.logistics_provider_state.inactive',
  value: 'inactive'
}]; // 物流商时效

var LogisticsProviderAging = [{
  label: 'dict.logistics_provider_aging.air',
  value: 'air'
}, {
  label: 'dict.logistics_provider_aging.truck',
  value: 'truck'
}, {
  label: 'dict.logistics_provider_aging.rail',
  value: 'rail'
}, {
  label: 'dict.logistics_provider_aging.sea',
  value: 'sea'
}, {
  label: 'dict.logistics_provider_aging.delivery',
  value: 'delivery'
}]; // 物流商时效

var UnsalableApproveState = [{
  label: 'dict.unsalable_approve_state.approved',
  value: 'approved'
}, {
  label: 'dict.unsalable_approve_state.wait_approve',
  value: 'wait_approve'
}]; // 预调价审核状态

var PreProdPriceApproveState = [{
  label: 'dict.pre_prod_price_approve_state.pre_approve',
  value: 10
}, {
  label: 'dict.pre_prod_price_approve_state.passed',
  value: 20
}, {
  label: 'dict.pre_prod_price_approve_state.not_passed',
  value: 30
}, {
  label: 'dict.pre_prod_price_approve_state.time_out',
  value: 40
}]; // 产品状态

var ProdStatus = [{
  label: 'dict.prod_status.sale',
  value: 'sale'
}, {
  label: 'dict.prod_status.stop',
  value: 'stop'
}, {
  label: 'dict.prod_status.waiting',
  value: 'waiting'
}, {
  label: 'dict.prod_status.sz_prod',
  value: 'sz_prod'
}, {
  label: 'dict.prod_status.uk_sale',
  value: 'uk_sale'
}, {
  label: 'dict.prod_status.tort_stop',
  value: 'tort_stop'
}]; // 产品状态

var ShippingPlanState = [{
  label: 'dict.shipping_plan_state.draft',
  value: 'draft'
}, {
  label: 'dict.shipping_plan_state.confirm',
  value: 'confirm'
}, {
  label: 'dict.shipping_plan_state.assigned',
  value: 'assigned'
}]; // 核价产品状态

var PriceCheckProdStatus = [{
  label: 'dict.price_check_prod_status.sale',
  value: 10
}, {
  label: 'dict.price_check_prod_status.waiting',
  value: 20
}, {
  label: 'dict.price_check_prod_status.tort_stop',
  value: 50
}, {
  label: 'dict.price_check_prod_status.stop',
  value: 100
}]; // 产品状态

var CheckProdStatus = [{
  label: 'dict.check_prod_status.sale',
  value: 10
}, {
  label: 'dict.check_prod_status.waiting',
  value: 20
}, {
  label: 'dict.check_prod_status.tort_stop',
  value: 50
}, {
  label: 'dict.check_prod_status.stop',
  value: 100
}, {
  label: 'dict.check_prod_status.not_onshelf',
  value: 200
}, {
  label: 'dict.check_prod_status.no_stop',
  value: 10000
}]; // 邮件状态

var SentEmailStatus = [{
  label: 'dict.sent_email_state.outgoing',
  value: 'outgoing'
}, {
  label: 'dict.sent_email_state.sent',
  value: 'sent'
}, {
  label: 'dict.sent_email_state.received',
  value: 'received'
}, {
  label: 'dict.sent_email_state.exception',
  value: 'exception'
}, {
  label: 'dict.sent_email_state.cancel',
  value: 'cancel'
}]; // 补货状态

var PurchasePriceChangeReportStatus = [{
  label: 'dict.purchase_price_change_report_status.pre_handled',
  value: 10
}, {
  label: 'dict.purchase_price_change_report_status.handled',
  value: 20
}, {
  label: 'dict.purchase_price_change_report_status.price_adjusted',
  value: 30
}, {
  label: 'dict.purchase_price_change_report_status.no_handled',
  value: 40
}]; // DEPO状态

var DePoState = [{
  label: 'dict.de_po_state.draft',
  value: 'draft'
}, {
  label: 'dict.de_po_state.confirmed',
  value: 'confirmed'
}, {
  label: 'dict.de_po_state.cancel',
  value: 'cancel'
}];

/***/ }),

/***/ "24b7":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SkuSaleController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'report_sku';
/**
 * API接口配置
 * 订单服务配置
 */

var SkuSaleController = {
  // 获取额度申请列表
  query_sum_all: {
    controller: controller,
    action: 'query_sum_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_by_time: {
    controller: controller,
    action: 'query_sales_history_by_time',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "2f4c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return VendorController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'vendor';
/**
 * API接口配置
 * 客户服务配置
 */

var VendorController = {
  // 查询活动的供应商简称
  get_vendor_ref_list: {
    controller: controller,
    action: 'get_vendor_ref_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_vendor: {
    controller: controller,
    action: 'save_vendor',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "32c0":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PricelistController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'pricelist';
/**
 * API接口配置
 * 订单服务配置
 */

var PricelistController = {
  // 获取国家列表
  getList: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "3755":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AmazonListingStockController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'amazon_listing_stock';
/**
 * API接口配置
 * 订单服务配置
 */

var AmazonListingStockController = {
  // Merge User
  mergeUser: {
    controller: controller,
    action: 'merge_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // Merge Auto
  mergeAuto: {
    controller: controller,
    action: 'merge_auto',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // Cancel Auto
  cancelAuto: {
    controller: controller,
    action: 'cancel_auto',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // save
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //  Query All Listing
  queryAll: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // Query SingleListing
  querySingleListing: {
    controller: controller,
    action: 'query_single_listing',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "4904":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GenerateCodeController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'code_generate';
/**
 * API接口配置
 * 订单服务配置
 */

var GenerateCodeController = {
  // 根据组名查询所有code, name
  query_all_code_list: {
    controller: controller,
    action: 'query_all_code_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  query_select_code: {
    controller: controller,
    action: 'query_select_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  create_product_generate_code: {
    controller: controller,
    action: 'create_product_generate_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  create_mix_product_generate_code: {
    controller: controller,
    action: 'create_mix_product_generate_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  import_create_generate_code: {
    controller: controller,
    action: 'import_create_generate_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  query_category_list: {
    controller: controller,
    action: 'query_category_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  query_color_list: {
    controller: controller,
    action: 'query_color_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  delete_code: {
    controller: controller,
    action: 'delete_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "4940":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReportController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'report';
/**
 * API接口配置
 * 订单服务配置
 */

var ReportController = {
  // 获取额度申请列表
  query_order_date_list: {
    controller: controller,
    action: 'query_order_date_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_country_list: {
    controller: controller,
    action: 'query_country_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_category_list: {
    controller: controller,
    action: 'query_category_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_sub_category_list: {
    controller: controller,
    action: 'query_sub_category_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_category_dict: {
    controller: controller,
    action: 'query_category_dict',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_category_profit_data: {
    controller: controller,
    action: 'query_category_profit_data',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_sku_profit_data: {
    controller: controller,
    action: 'query_sku_profit_data',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_profit_data: {
    controller: controller,
    action: 'query_all_profit_data',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "5c4b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return SellerInstanceController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'seller_instance';
/**
 * API接口配置
 * 产品服务配置
 */

var SellerInstanceController = {
  // 产品查询
  instance_query: {
    controller: controller,
    action: 'query_all_instance',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 产品查询
  seller_query: {
    controller: controller,
    action: 'query_all_seller',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 产品保存
  instance_save: {
    controller: controller,
    action: 'save_instance',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 产品保存
  seller_save: {
    controller: controller,
    action: 'save_seller',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  instance_delete: {
    controller: controller,
    action: 'delete_instance',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  seller_delete: {
    controller: controller,
    action: 'delete_seller',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  responsible_users_query: {
    controller: controller,
    action: 'query_responsible_users',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  seller_query_one: {
    controller: controller,
    action: 'query_one_seller',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  query_user_login: {
    controller: controller,
    action: 'query_user_login',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  get_instance_list_for_view: {
    controller: controller,
    action: 'query_instance_list_for_view',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  query_seller_name: {
    controller: controller,
    action: 'query_seller_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  change_seller_status: {
    controller: controller,
    action: 'change_seller_status',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除保存
  change_instance_status: {
    controller: controller,
    action: 'change_instance_status',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 店铺下拉列表
  query_odoo_seller_list: {
    controller: controller,
    action: 'query_odoo_seller_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 店铺实例下拉列表
  query_odoo_seller_instance_list: {
    controller: controller,
    action: 'query_odoo_seller_instance_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_instance_list: {
    controller: controller,
    action: 'query_instance_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_seller_api: {
    controller: controller,
    action: 'save_seller_api',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_instance_by_seller_code: {
    controller: controller,
    action: 'query_instance_by_seller_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "5ded":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return DeliveryMethodController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'delivery_method';
/**
 * API接口配置
 * 订单服务配置
 */

var DeliveryMethodController = {
  // 获取国家列表
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "5fa3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CaseController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'case_management';
/**
 * API接口配置
 */

var CaseController = {
  // 获取所有日程
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取所有日程
  query_all_calendar: {
    controller: controller,
    action: 'query_all_calendar',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存日程
  save_case: {
    controller: controller,
    action: 'save_case',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询日程详情
  query_case_detail: {
    controller: controller,
    action: 'query_case_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 创建消息
  create_message: {
    controller: controller,
    action: 'create_message',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除消息
  delete_message: {
    controller: controller,
    action: 'delete_message',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 状态字典
  query_case_type: {
    controller: controller,
    action: 'query_case_type',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除日程
  delete_case: {
    controller: controller,
    action: 'delete_case',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 修改状态
  change_case_state: {
    controller: controller,
    action: 'change_case_state',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 返回可选择的父日程列表
  get_parent_case_ids: {
    controller: controller,
    action: 'get_parent_case_ids',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "640c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CountryController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'country';
/**
 * API接口配置
 * 订单服务配置
 */

var CountryController = {
  // 获取国家列表
  getList: {
    controller: controller,
    action: 'id_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  getListByISOCode2: {
    controller: controller,
    action: 'iso_code_2_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "65c5":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return LogoutController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'wms';
/**
 * API接口配置
 */

var LogoutController = {
  // 退出登录
  logout: {
    controller: controller,
    action: 'session/logout',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "6762":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WmsController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'wms';
/**
 * API接口配置
 * 订单服务配置
 */

var WmsController = {
  // 登录
  login: {
    controller: controller,
    action: 'user_login',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "6829":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return formConfig; });
/* harmony import */ var _shared_search_items_pay_method_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("3d69");
/* harmony import */ var _shared_search_items_test1_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("74a2");
/* harmony import */ var _shared_search_items_test2_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("53a2");



var formConfig = {
  defaults: function defaults() {
    return [{
      label: '付款方式',
      show: false,
      component: _shared_search_items_pay_method_vue__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"]
    }, {
      label: 'test1',
      show: false,
      component: _shared_search_items_test1_vue__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"]
    }, {
      label: 'test2',
      show: false,
      component: _shared_search_items_test2_vue__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"]
    }];
  },
  customs: {
    order: function order() {
      return [{
        label: '付款方式',
        show: false,
        component: _shared_search_items_pay_method_vue__WEBPACK_IMPORTED_MODULE_0__[/* default */ "a"]
      }, {
        label: 'test1',
        show: false,
        component: _shared_search_items_test1_vue__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"]
      }];
    },
    user: function user() {
      return [{
        label: 'test-list',
        show: false,
        components: [_shared_search_items_test1_vue__WEBPACK_IMPORTED_MODULE_1__[/* default */ "a"], _shared_search_items_test2_vue__WEBPACK_IMPORTED_MODULE_2__[/* default */ "a"]]
      }];
    }
  },
  condition: {
    paymethod: '=',
    test1: 'like',
    test2: '='
  }
};

/***/ }),

/***/ "6db2":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return UserController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'user';
/**
 * API接口配置
 * 客户服务配置
 */

var UserController = {
  // 查询系统用户
  all: {
    controller: controller,
    action: 'all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询销售代表
  availableSales: {
    controller: controller,
    action: 'sales_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询客服代表
  customerServiceUser: {
    controller: controller,
    action: 'customer_service_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询配货员
  pack_man: {
    controller: controller,
    action: 'pack_man',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 仓库人员查询
  warehouse_user: {
    controller: controller,
    action: 'warehouse_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "7a0b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CurrencyController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'currency';
/**
 * API接口配置
 */

var CurrencyController = {
  // 获取支持币种
  getCurrency: {
    controller: controller,
    action: 'all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "7aea":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AccountController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'account';
/**
 * API接口配置
 * 库存服务配置
 */

var AccountController = {
  // 创建账单
  createInvoice: {
    controller: controller,
    action: 'create_normal_invoice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取账单列表
  getInvoiceList: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取账单详情
  getInvoiceDetail: {
    controller: controller,
    action: 'query_invoice_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_invoice_detail_for_edit: {
    controller: controller,
    action: 'query_invoice_detail_for_edit',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_account_invoice: {
    controller: controller,
    action: 'save_account_invoice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  delete_account_invoice: {
    controller: controller,
    action: 'delete_account_invoice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  modify_invoice_address: {
    controller: controller,
    action: 'modify_invoice_address',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  change_invoice_state: {
    controller: controller,
    action: 'change_invoice_state',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  update_refund_time: {
    controller: controller,
    action: 'update_refund_time',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "7d9b":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return EmailController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'amazon_email';
/**
 * API接口配置
 * 邮件回复配置
 */

var EmailController = {
  // 邮件客户查询
  get_userlist: {
    controller: controller,
    action: 'get_user_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  setNoNeedReplyDone: {
    controller: controller,
    action: 'set_no_need_reply_done',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  saveTemplate: {
    controller: controller,
    action: 'save_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  starTemplate: {
    controller: controller,
    action: 'star_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  deleteTemplate: {
    controller: controller,
    action: 'delete_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取当前客户的邮件往来
  get_currentUserMessage: {
    controller: controller,
    action: 'get_content',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //发送邮件
  action_send_email: {
    controller: controller,
    action: 'action_send_email',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //获取邮件模板
  get_templates: {
    controller: controller,
    action: 'get_templates',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //修改订单memo
  action_write_memo: {
    controller: controller,
    action: 'action_write_memo',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //创建批注
  action_create_annotation: {
    controller: controller,
    action: 'action_create_annotation',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //获取原文
  get_origin_message: {
    controller: controller,
    action: 'get_origin_message',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //撤回信息
  revert_message: {
    controller: controller,
    action: 'revert_message',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //创建发送发票
  create_send_invoice: {
    controller: controller,
    action: 'create_send_invoice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //设为已回复
  action_set_reply: {
    controller: controller,
    action: 'set_reply',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //获取picking list
  queryPickingList: {
    controller: controller,
    action: 'query_picking_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //修改订单memo
  modifyMemo: {
    controller: controller,
    action: 'modify_memo',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  queryNoNeedReply: {
    controller: controller,
    action: 'query_no_need_reply',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "8096":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PickingController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'stock_picking';
/**
 * API接口配置
 * 产品服务配置
 */

var PickingController = {
  // 产品查询
  query: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //详情查询
  query_one_picking: {
    controller: controller,
    action: 'query_one_picking',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //多个详情查询
  query_more_picking: {
    controller: controller,
    action: 'query_more_picking',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //stock_operation 查询
  query_stock_operation: {
    controller: controller,
    action: 'query_stock_operation',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //stock_move 查询
  query_stock_move: {
    controller: controller,
    action: 'query_stock_move',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_stock_move_for_return: {
    controller: controller,
    action: 'query_stock_move_for_return',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_stock_move_for_resend: {
    controller: controller,
    action: 'query_stock_move_for_resend',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //stock_move 查询
  query_shipments: {
    controller: controller,
    action: 'query_shipments',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //return info 查询
  query_customer_problem_return_info: {
    controller: controller,
    action: 'query_customer_problem_return_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //根据picking_id查询要校验地址的信息
  query_picking_for_validate_shipment: {
    controller: controller,
    action: 'query_picking_for_validate_shipment',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //提交地址修改并返回校验
  validate_picking_shipping_address: {
    controller: controller,
    action: 'validate_picking_shipping_address',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //取消stock_picking
  cancel_stock_picking: {
    controller: controller,
    action: 'cancel_stock_picking',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //批量保存stock_picking地址
  save_picking_address: {
    controller: controller,
    action: 'save_picking_address',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //Picking设置为草稿
  setAsDraft: {
    controller: controller,
    action: 'set_as_draft',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //设置picking为presale
  setPresale: {
    controller: controller,
    action: 'set_presale',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //Picking设置为取消presale
  cancelPresale: {
    controller: controller,
    action: 'cancel_presale',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //设置picking为卖超
  markSoldOut: {
    controller: controller,
    action: 'mark_sold_out',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //设置picking不是卖超
  cancelSoldOut: {
    controller: controller,
    action: 'cancel_sold_out',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //Check shipments
  checkShipments: {
    controller: controller,
    action: 'check_shipments',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //设置取消shipments
  cancelCheckShipments: {
    controller: controller,
    action: 'cancel_check_shipments',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //标记service process
  serviceProcess: {
    controller: controller,
    action: 'service_process',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //标记return process
  returnProcess: {
    controller: controller,
    action: 'return_process',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //标记customer_service_stop_plz
  customer_service_stop_plz: {
    controller: controller,
    action: 'customer_service_stop_plz',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //标记cancel_stock_picking_for_order_refund
  cancel_stock_picking_for_order_refund: {
    controller: controller,
    action: 'cancel_stock_picking_for_order_refund',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //保存picking
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //保存picking operations
  save_stock_pack_operation: {
    controller: controller,
    action: 'save_stock_pack_operation',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //保存picking move
  save_stock_move: {
    controller: controller,
    action: 'save_stock_move',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //保存picking move
  save_customer_problem: {
    controller: controller,
    action: 'save_customer_problem',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //保存picking shipments
  save_shipment_info: {
    controller: controller,
    action: 'save_shipment_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  reserve: {
    controller: controller,
    action: 'reserve',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  create_shipments_lines: {
    controller: controller,
    action: 'create_shipments_lines',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  ReturnShipment: {
    controller: controller,
    action: 'create_return_shipment',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  cancel_picking_and_send_email: {
    controller: controller,
    action: 'cancel_picking_and_send_email',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_picking_log: {
    controller: controller,
    action: 'query_picking_log',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  delete_dhl_shipment: {
    controller: controller,
    action: 'delete_shipment_line',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  confirm_product_parts: {
    controller: controller,
    action: 'confirm_product_parts',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_product_part: {
    controller: controller,
    action: 'query_product_part',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  fake_shipments: {
    controller: controller,
    action: 'fake_shipments',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  upload_shipment: {
    controller: controller,
    action: 'upload_shipment',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  upload_fake_shipment: {
    controller: controller,
    action: 'upload_fake_shipment',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  assign_to_user: {
    controller: controller,
    action: 'assign_to_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  create_shipment_lines_by_ship_type: {
    controller: controller,
    action: 'create_shipment_lines_by_ship_type',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  force_available: {
    controller: controller,
    action: 'force_available',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  force_pass_validate_shipping_address: {
    controller: controller,
    action: 'force_pass_validate_shipping_address',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_customer_problem_by_order_id: {
    controller: controller,
    action: 'save_customer_problem_by_order_id',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  delete_cancel_picking: {
    controller: controller,
    action: 'delete_cancel_picking',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_stock_move_base_product: {
    controller: controller,
    action: 'query_stock_move_base_product',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  create_product_tmpl_part_sku: {
    controller: controller,
    action: 'save_product_tmpl_part_sku',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_picking_resend_detail: {
    controller: controller,
    action: 'query_all_picking_resend_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  create_dhl_dpd_gift: {
    controller: controller,
    action: 'create_dhl_dpd_gift',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "8494":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WareHouseController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'warehouse';
/**
 * API接口配置
 * 客户服务配置
 */

var WareHouseController = {
  // 查询仓库
  available: {
    controller: controller,
    action: 'available_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "8c20":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomerController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'customer';
/**
 * API接口配置
 * 客户服务配置
 */

var CustomerController = {
  // 客户查询
  query: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 批量分配仓库
  batchSetWms: {
    controller: controller,
    action: 'batch_set_wms',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存客户
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "8e10e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PartnerController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'partner';
/**
 * API接口配置
 * 订单服务配置
 */

var PartnerController = {
  // 获取国家列表
  query_customer_contact: {
    controller: controller,
    action: 'query_customer_contact',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "8f4a":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PreSaleController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'product_pre_sale';
/**
 * API接口配置
 * 订单服务配置
 */

var PreSaleController = {
  // 获取预售数据
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  re_calculate_purchase_predict: {
    controller: controller,
    action: 're_calculate_purchase_predict',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_sku_week_sales: {
    controller: controller,
    action: 'query_sku_week_sales',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  active_purchase_predict: {
    controller: controller,
    action: 'active_purchase_predict',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  confirm_purchase_predict: {
    controller: controller,
    action: 'confirm_purchase_predict',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  approve_purchase_predict: {
    controller: controller,
    action: 'approve_purchase_predict',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  renew_purchase_predict: {
    controller: controller,
    action: 'renew_purchase_predict',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  return_purchase_predict: {
    controller: controller,
    action: 'return_purchase_predict',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "96bb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ShipmentController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'shipment';
/**
 * API接口配置
 * 物流服务配置
 */

var ShipmentController = {
  // 获取物流列表
  query_all_ship_type: {
    controller: controller,
    action: 'query_all_ship_type',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_ship_type: {
    controller: controller,
    action: 'save_ship_type',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  getSendData: {
    controller: controller,
    action: 'get_shipment_to_email',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  done_picking_get_shipping_label: {
    controller: controller,
    action: 'done_picking_get_shipping_label',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  delete_shipment_order: {
    controller: controller,
    action: 'delete_shipment_order',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_shipment: {
    controller: controller,
    action: 'query_all_shipment',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "9780":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TicketController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'helpdesk_ticket';
/**
 * API接口配置
 * 客户服务配置
 */

var TicketController = {
  // 查询系统所有收件箱
  query_fetch_email_server: {
    controller: controller,
    action: 'query_fetch_email_server',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "9977":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CompanyController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'company';
/**
 * API接口配置
 * 订单服务配置
 */

var CompanyController = {
  // 获取公司列表
  query_list: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "a8d3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return MailController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'email';
/**
 * API接口配置
 * 订单服务配置
 */

var MailController = {
  // 获取国家列表
  create_email: {
    controller: controller,
    action: 'create_email',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_email_template: {
    controller: controller,
    action: 'query_email_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  render_email_template: {
    controller: controller,
    action: 'render_email_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_illegal_words: {
    controller: controller,
    action: 'query_all_illegal_words',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  batch_delete_illegal_words: {
    controller: controller,
    action: 'batch_delete_illegal_words',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_illegal_words: {
    controller: controller,
    action: 'save_illegal_words',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_ticket_seller_name: {
    controller: controller,
    action: 'query_ticket_seller_name',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_ticket_site_id_by_ticket_seller_name: {
    controller: controller,
    action: 'query_ticket_site_id_by_ticket_seller_name',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_ticket_type: {
    controller: controller,
    action: 'query_ticket_type',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "a9bc":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GeneralController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'general';
/**
 * API接口配置
 * 订单服务配置
 */

var GeneralController = {
  // 根据组名查询所有code, name
  query_picking_need_resend: {
    controller: controller,
    action: 'query_picking_need_resend',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  queryLangList: {
    controller: controller,
    action: 'query_lang_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询表对应的所有列
  query_table_schema: {
    controller: controller,
    action: 'query_table_schema',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询表对应的所有模板
  query_table_schema_export_template: {
    controller: controller,
    action: 'query_table_schema_export_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 导出模板对应的列
  query_table_schema_export_template_column: {
    controller: controller,
    action: 'query_table_schema_export_template_column',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存导出模板
  save_table_schema_export_template: {
    controller: controller,
    action: 'save_table_schema_export_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除导出模板
  delete_table_schema_export_template: {
    controller: controller,
    action: 'delete_table_schema_export_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "af1d":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return InventoryController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'inventory';
/**
 * API接口配置
 * 库存服务配置
 */

var InventoryController = {
  // 获取库存信息
  inventory: {
    controller: controller,
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "b20c":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CustomProblemController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'custom_problem';
/**
 * API接口配置
 * 库存服务配置
 */

var CustomProblemController = {
  //
  query: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_product_drop_list: {
    controller: controller,
    action: 'query_product_drop_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_template_product_drop_list: {
    controller: controller,
    action: 'query_template_product_drop_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_custom_problem_by_cs: {
    controller: controller,
    action: 'save_custom_problem_by_cs',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_custom_problem_by_rt: {
    controller: controller,
    action: 'save_custom_problem_by_rt',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_cp_reason_enum: {
    controller: controller,
    action: 'query_cp_reason_enum',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_by_order_list: {
    controller: controller,
    action: 'query_by_order_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  batch_in_return_wh: {
    controller: controller,
    action: 'batch_in_return_wh',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  delete_cp: {
    controller: controller,
    action: 'delete_cp',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  get_inital_cp: {
    controller: controller,
    action: 'get_inital_cp',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  create_cp_pic: {
    controller: controller,
    action: 'create_customer_problem_pic',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_pic: {
    controller: controller,
    action: 'query_all_pic',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_customer_problem_product: {
    controller: controller,
    action: 'query_customer_problem_product',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "c232":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return CrmteamController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'crm_team';
/**
 * API接口配置
 * 订单服务配置
 */

var CrmteamController = {
  // 获取国家列表
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "c249":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony default export */ __webpack_exports__["a"] = ({
  server: "http://47.244.150.247:48069",
  debug: "production" === 'development',
  timeout: "3600000",
  mock: "false",
  googleMapApiKey: "AIzaSyDaBlQ-7bhO534-a-u32apwYYoQeln-1eg"
});

/***/ }),

/***/ "c5db":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OrderController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'sale_order';
/**
 * API接口配置
 * 订单服务配置
 */

var OrderController = {
  // 获取订单列表
  getOrderList: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取订单详情
  getOrderDetail: {
    controller: controller,
    action: 'query_order_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取订单拣货列表
  getPickList: {
    controller: controller,
    action: 'query_picking_list',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取發票信息
  getInvoiceList: {
    controller: controller,
    action: 'query_account_invoice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取客户问题信息
  getCustomerList: {
    controller: controller,
    action: 'query_customer_problem',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取日志
  getLogList: {
    controller: controller,
    action: 'query_order_log',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存订单
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 订单生成账单
  createAccountInvoice: {
    controller: controller,
    action: 'create_account_invoice',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 取消订单
  cancelOrder: {
    controller: controller,
    action: 'cancel_sale_order',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 取消状态订单变成草稿状态
  setAsDraft: {
    controller: controller,
    action: 'set_as_draft',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 订单生成RT面单
  return: {
    controller: controller,
    action: 'return',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 标识ebay订单已付款
  markEbayOrderAsPaid: {
    controller: controller,
    action: 'mark_ebay_order_as_paid',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 订单部分退款/全额退款
  refund: {
    controller: controller,
    action: 'refund',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 订单补发
  deliverMore: {
    controller: controller,
    action: 'deliver_more',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取订单AMA/Ebay DZ数据接口
  queryAmaEbayDz: {
    controller: controller,
    action: 'query_ama_ebay_dz',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 订单生成picking
  confirm: {
    controller: controller,
    action: 'confirm',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 订单自动生成picking
  autoConfirm: {
    controller: controller,
    action: 'auto_confirm',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询订单信息
  query_order_info: {
    controller: controller,
    action: 'query_order_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 订单变为草稿状态
  set_to_draft: {
    controller: controller,
    action: 'set_to_draft',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "d04f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PublicController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'system_api';
/**
 * API接口配置
 * 订单服务配置
 */

var PublicController = {
  queryPagination: {
    controller: controller,
    action: 'query_pagination',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query: {
    controller: controller,
    action: 'query',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  modify: {
    controller: controller,
    action: 'modify',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  queryExportPagination: {
    controller: controller,
    action: 'query_export',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "d32f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return OperateLogController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'operate_log';
/**
 * API接口配置
 * 订单服务配置
 */

var OperateLogController = {
  // 查看批次库存操作日志
  view_user_operate_changed_log: {
    controller: controller,
    action: 'view_user_operate_changed_log',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "d33f":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return FiscalPositionController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'fiscal_position';
/**
 * API接口配置
 * 订单服务配置
 */

var FiscalPositionController = {
  // 获取国家列表
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "d72e":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return WorkweekController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'work_week';
/**
 * API接口配置
 * 订单服务配置
 */

var WorkweekController = {
  // 获取列表
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 创建周报
  save_week: {
    controller: controller,
    action: 'save_week',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询周报详情
  query_week_detail: {
    controller: controller,
    action: 'query_week_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // create_message
  create_message: {
    controller: controller,
    action: 'create_message',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // delete_message
  delete_message: {
    controller: controller,
    action: 'delete_message',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "ddb4":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AliexpressController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'aliexpress';
/**
 * API接口配置
 * 服务配置
 */

var AliexpressController = {
  // 手动导入速卖通订单
  importOrders: {
    controller: controller,
    action: 'manually_import_orders',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 速卖通结单
  fulfilOrders: {
    controller: controller,
    action: 'order_fulfil',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 库存管理
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // listing_save
  listing_save: {
    controller: controller,
    action: 'listing_save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // mergeUser
  mergeUser: {
    controller: controller,
    action: 'listing_merge_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // mergeAuto
  mergeAuto: {
    controller: controller,
    action: 'listing_merge_auto',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // cancelAuto
  cancelAuto: {
    controller: controller,
    action: 'listing_cancel_auto',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "de55":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ReleasePreSaleController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 国家分区控制器名称

var controller = 'release_pre_sale';
/**
 * API接口配置
 * 订单服务配置
 */

var ReleasePreSaleController = {
  // 获取所有预售订单
  queryAll: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询具体产品
  queryProduct: {
    controller: controller,
    action: 'query_product',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 取消
  cancel: {
    controller: controller,
    action: 'cancel',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 完成
  done: {
    controller: controller,
    action: 'done',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // query_one
  query_one: {
    controller: controller,
    action: 'query_one',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "e5f6":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ProductPurchaseController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'product_purchase';
/**
 * API接口配置
 * 产品采购服务配置
 */

var ProductPurchaseController = {
  // 所有排单计划查询
  query_all_requirement_schedule: {
    controller: controller,
    action: 'query_all_requirement_schedule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 确认排单计划
  confirm_requirement_schedule: {
    controller: controller,
    action: 'confirm_requirement_schedule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 取消排单计划
  cancel_requirement_schedule: {
    controller: controller,
    action: 'cancel_requirement_schedule',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 修改排单计划数量
  change_requirement_schedule_qty: {
    controller: controller,
    action: 'change_requirement_schedule_qty',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 计算环比
  calculate_category_increase_ratio: {
    controller: controller,
    action: 'calculate_category_increase_ratio',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询货柜
  queryRequirementPackage: {
    controller: controller,
    action: 'query_requirement_package',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "e5fb":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return ProductController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'product';
/**
 * API接口配置
 * 产品服务配置
 */

var ProductController = {
  // 关联sku查询
  query_product_pack_by_sku: {
    controller: controller,
    action: 'query_product_pack_by_sku',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 关联sku
  query_all_for_stock_move: {
    controller: controller,
    action: 'query_all_for_stock_move',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 关联sku
  query_async_product_info: {
    controller: controller,
    action: 'query_async_product_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询通用货号
  query_all_common_sku: {
    controller: controller,
    action: 'query_all_common_sku',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询基础货号
  query_all_basic_sku: {
    controller: controller,
    action: 'query_all_basic_sku',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询组合货号
  query_all_bp_pack: {
    controller: controller,
    action: 'query_all_bp_pack',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品详情
  query_product_basic_info: {
    controller: controller,
    action: 'query_product_basic_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品extra info
  query_product_extra_value: {
    controller: controller,
    action: 'query_product_extra_value',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品shipment info
  query_de_best_logistic_info: {
    controller: controller,
    action: 'query_de_best_logistic_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品shipment info
  query_uk_best_logistic_info: {
    controller: controller,
    action: 'query_uk_best_logistic_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品instock info
  query_product_stock_info: {
    controller: controller,
    action: 'query_product_stock_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品instock info
  query_location_stock_detail: {
    controller: controller,
    action: 'query_location_stock_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品instock info
  query_factory_product_detail: {
    controller: controller,
    action: 'query_factory_product_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品instock info
  query_shipping_product_detail: {
    controller: controller,
    action: 'query_shipping_product_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品instock info
  query_amazon_listing_detail: {
    controller: controller,
    action: 'query_amazon_listing_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存产品基础信息
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存产品额外信息
  save_product_extra_value: {
    controller: controller,
    action: 'save_product_extra_value',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除产品额外信息
  delete_extra_value: {
    controller: controller,
    action: 'delete_extra_value',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 商品出入库记录
  query_product_stock_operation: {
    controller: controller,
    action: 'query_product_stock_operation',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询所有货号
  query_all_type_sku: {
    controller: controller,
    action: 'query_all_type_sku',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询log
  query_product_log: {
    controller: controller,
    action: 'query_product_log',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询说明书版本
  query_manual_version: {
    controller: controller,
    action: 'query_manual_version',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询说明书
  query_all_product_manual: {
    controller: controller,
    action: 'query_all_product_manual',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询配件/B品
  query_all_basic_product_info: {
    controller: controller,
    action: 'query_all_basic_product_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 产品常用查询
  query_all_product_template: {
    controller: controller,
    action: 'query_all_product_template',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 工艺单查询
  query_all_product_specification: {
    controller: controller,
    action: 'query_all_product_specification',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 工艺单版本用查询
  query_specification_version: {
    controller: controller,
    action: 'query_specification_version',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 编辑说明书
  save_prod_manual_info: {
    controller: controller,
    action: 'save_prod_manual_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 编辑工艺单
  save_prod_specification_info: {
    controller: controller,
    action: 'save_prod_specification_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除说明书
  delete_prod_manual_info: {
    controller: controller,
    action: 'delete_prod_manual_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除说明书
  reset_prod_manual_info: {
    controller: controller,
    action: 'reset_prod_manual_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 删除工艺单
  delete_prod_specification_info: {
    controller: controller,
    action: 'delete_prod_specification_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据条件查询产品出入库记录
  query_all_product_in_out_warehouse: {
    controller: controller,
    action: 'query_all_product_in_out_warehouse',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 标记归档
  merge_inactive: {
    controller: controller,
    action: 'merge_inactive',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 还原归档
  merge_active: {
    controller: controller,
    action: 'merge_active',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 同步通用货号信息
  synCommonSkuInfo: {
    controller: controller,
    action: 'syn_common_sku_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 同步通用货号额外属性
  synCommonSkuExtraAttributes: {
    controller: controller,
    action: 'syn_common_sku_extra_attributes',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 同步组合产品分类数据
  updatePackProductCategory: {
    controller: controller,
    action: 'update_pack_product_category',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询产品历史库存
  queryProductHistoryStock: {
    controller: controller,
    action: 'query_all_product_history_stock',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询中文子类
  query_all_sub_category_attributes: {
    controller: controller,
    action: 'query_all_sub_category_attributes',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 保存中文子类属性列表
  save_sub_category_attributes: {
    controller: controller,
    action: 'save_sub_category_attributes',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // query_all_cs_tmp_product_part
  query_all_cs_tmp_product_part: {
    controller: controller,
    action: 'query_all_cs_tmp_product_part',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // save_cs_tmp_product_part
  save_cs_tmp_product_part: {
    controller: controller,
    action: 'save_cs_tmp_product_part',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // save_cs_tmp_product_part
  query_all_for_stock_pack_operation: {
    controller: controller,
    action: 'query_all_for_stock_pack_operation',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "e7a3":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HelpdeskController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 控制器名称

var controller = 'helpdesk';
/**
 * API接口配置
 * 库存服务配置
 */

var HelpdeskController = {
  //
  query_all_ticket: {
    controller: controller,
    action: 'query_all_ticket',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //
  query_ticket: {
    controller: controller,
    action: 'query_ticket  ',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //
  query_helpdesk_ticket_body: {
    controller: controller,
    action: 'query_helpdesk_ticket_body',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  set_picking_cancelled_confirm: {
    controller: controller,
    action: 'set_picking_cancelled_confirm',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  assign_ticket_user: {
    controller: controller,
    action: 'assign_ticket_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  cancel_ticket_user: {
    controller: controller,
    action: 'cancel_ticket_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_ticket_reply_content: {
    controller: controller,
    action: 'query_ticket_reply_content',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_ticket_changed_log: {
    controller: controller,
    action: 'query_ticket_changed_log',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_email_group: {
    controller: controller,
    action: 'query_all_email_group',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_email_group: {
    controller: controller,
    action: 'save_email_group',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  cancel_email_group_status: {
    controller: controller,
    action: 'cancel_email_group_status',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  active_email_group_status: {
    controller: controller,
    action: 'active_email_group_status',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  save_user_allot_ratio: {
    controller: controller,
    action: 'save_user_allot_ratio',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  active_user_allot_ratio: {
    controller: controller,
    action: 'active_user_allot_ratio',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  cancel_user_allot_ratio: {
    controller: controller,
    action: 'cancel_user_allot_ratio',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_allot_user: {
    controller: controller,
    action: 'query_all_allot_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  change_allot_user: {
    controller: controller,
    action: 'change_allot_user',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_user_allot_ratio: {
    controller: controller,
    action: 'query_user_allot_ratio',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  auto_allot_email: {
    controller: controller,
    action: 'auto_allot_email',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 设置自动回复时间
  set_up_send_mail_time: {
    controller: controller,
    action: 'set_up_send_mail_time',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_all_send_email_time: {
    controller: controller,
    action: 'query_all_send_email_time',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 设置自动回复时间
  set_up_send_mail_time_customer: {
    controller: controller,
    action: 'set_up_send_mail_time_customer',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  query_send_customer_email_time: {
    controller: controller,
    action: 'query_send_customer_email_time',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "f243":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return TaxesController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'account_tax';
/**
 * API接口配置
 * 订单服务配置
 */

var TaxesController = {
  // 获取国家列表
  query_all: {
    controller: controller,
    action: 'query_all_by_seller_code',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "f384":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PurchaseController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'purchase_requirement';
/**
 * API接口配置
 * 订单服务配置
 */

var PurchaseController = {
  // 生成库存预算数据
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // save船运费接口
  save_boat_shipping_fee: {
    controller: controller,
    action: 'save_boat_shipping_fee',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // delete船运费接口
  delete_boat_shipping_fee: {
    controller: controller,
    action: 'delete_boat_shipping_fee',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询船费预警接口
  query_all_boat_shipping_fee_monitor: {
    controller: controller,
    action: 'query_all_boat_shipping_fee_monitor',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询船运费接口
  query_all_boat_shipping_fee: {
    controller: controller,
    action: 'query_all_boat_shipping_fee',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询采购金额接口
  query_all_purchase_price_report: {
    controller: controller,
    action: 'query_all_purchase_price_report',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询采购交期接口
  query_all_purchase_give_date_report: {
    controller: controller,
    action: 'query_all_purchase_give_date_report',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询采购降本费用接口
  query_all_purchase_reduce_costs_report: {
    controller: controller,
    action: 'query_all_purchase_reduce_costs_report',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询SKU库存
  query_all_purchase_prod_qty_info: {
    controller: controller,
    action: 'query_all_purchase_prod_qty_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 查询采购产品质量合格率
  query_all_quality_pass_ratio_report: {
    controller: controller,
    action: 'query_all_quality_pass_ratio_report',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "f6a8":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PresaleManageController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'pre_sale_management';
/**
 * API接口配置
 * 订单服务配置
 */

var PresaleManageController = {
  // 保存编辑
  save: {
    controller: controller,
    action: 'save',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 生成释放报告
  release: {
    controller: controller,
    action: 'release',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //  获取货柜及产品信息
  getInfo: {
    controller: controller,
    action: 'get_info',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  //  获取货柜及产品信息
  queryAll: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "f913":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return GeneralCodeController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'general_code';
/**
 * API接口配置
 * 订单服务配置
 */

var GeneralCodeController = {
  // 根据组名查询所有code, name
  queryShipType: {
    controller: controller,
    action: 'query_ship_type',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 根据组名查询所有code, name
  queryMvShipType: {
    controller: controller,
    action: 'query_mv_ship_type',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ }),

/***/ "fd36":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return PurchaseCalController; });
/* harmony import */ var _core_http__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("c4d0");
 // 订单控制器名称

var controller = 'product_purchase_predict';
/**
 * API接口配置
 * 订单服务配置
 */

var PurchaseCalController = {
  // 获取所有产品采购预算
  query_all: {
    controller: controller,
    action: 'query_all',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  // 获取单个产品采购预算
  query_detail: {
    controller: controller,
    action: 'query_detail',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  sales_history: {
    controller: controller,
    action: 'query_half_year_sales_history',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  },
  getLogs: {
    controller: controller,
    action: 'getLogs',
    type: _core_http__WEBPACK_IMPORTED_MODULE_0__["RequestMethod"].Post
  }
};

/***/ })

}]);